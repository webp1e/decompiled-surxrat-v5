package com.love.app;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class LockActivity$$ExternalSyntheticLambda19 implements Runnable {
    public final /* synthetic */ LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda19(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.restartLock();
    }
}
