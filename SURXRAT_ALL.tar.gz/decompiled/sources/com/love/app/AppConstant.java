package com.love.app;

/* JADX INFO: loaded from: classes.dex */
public class AppConstant {
    public double latitude = 0.0d;
    public double longitude = 0.0d;
}
