package com.love.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import java.net.URL;

/* JADX INFO: loaded from: classes.dex */
public class SplashActivity extends AppCompatActivity {
    private static final String TAG = "SplashActivity";

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C1294R.layout.activity_splash);
        ImageView imageView = (ImageView) findViewById(C1294R.id.splashLogo);
        TextView textView = (TextView) findViewById(C1294R.id.splashAppName);
        ConfigFetcher.loadLocalConfigSync(this);
        String appName = ConfigFetcher.getAppName(this);
        if (appName != null && !appName.isEmpty()) {
            textView.setText(appName);
        }
        String logoUrl = ConfigFetcher.getLogoUrl(this);
        if (logoUrl != null && !logoUrl.isEmpty()) {
            loadLogoFromUrl(imageView, logoUrl);
        }
        AnimationSet animationSet = new AnimationSet(true);
        ScaleAnimation scaleAnimation = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setDuration(1000L);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(1000L);
        animationSet.addAnimation(scaleAnimation);
        animationSet.addAnimation(alphaAnimation);
        imageView.startAnimation(animationSet);
        textView.startAnimation(alphaAnimation);
        ConfigFetcher.bootstrapConfig(this, new ConfigFetcher.ConfigListener() { // from class: com.love.app.SplashActivity.1
            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigLoaded(String str) {
                Log.d(SplashActivity.TAG, "Config splash siap: " + str);
            }

            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigFailed() {
                Log.w(SplashActivity.TAG, "Config splash gagal dimuat");
            }
        });
        goToMain();
    }

    private void loadLogoFromUrl(final ImageView imageView, final String str) {
        new Thread(new Runnable() { // from class: com.love.app.SplashActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m358lambda$loadLogoFromUrl$1$comloveappSplashActivity(str, imageView);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$loadLogoFromUrl$1$com-love-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m358lambda$loadLogoFromUrl$1$comloveappSplashActivity(String str, final ImageView imageView) {
        try {
            InputStream inputStreamOpenStream = new URL(str).openStream();
            final Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamOpenStream);
            inputStreamOpenStream.close();
            if (bitmapDecodeStream != null) {
                runOnUiThread(new Runnable() { // from class: com.love.app.SplashActivity$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        imageView.setImageBitmap(bitmapDecodeStream);
                    }
                });
            }
        } catch (Exception e) {
            Log.w(TAG, "Gagal load logo: " + e.getMessage());
        }
    }

    private void goToMain() {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.love.app.SplashActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m357lambda$goToMain$2$comloveappSplashActivity();
            }
        }, 1500L);
    }

    /* JADX INFO: renamed from: lambda$goToMain$2$com-love-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m357lambda$goToMain$2$comloveappSplashActivity() {
        startActivity(new Intent(this, (Class<?>) MainActivity.class));
        finish();
    }
}
