package com.love.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import com.google.android.mms.pdu_alt.PduHeaders;

/* JADX INFO: loaded from: classes.dex */
public class ServiceWindow extends Service {
    private static final String TAG = "ServiceWindow";
    private View overlayView;
    private WindowManager windowManager;

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.windowManager = (WindowManager) getSystemService("window");
        if (!Settings.canDrawOverlays(this)) {
            Log.e(TAG, "Izin overlay tidak diberikan");
            stopSelf();
            return;
        }
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 280, -3);
        layoutParams.gravity = 8388659;
        View view = new View(this);
        this.overlayView = view;
        view.setBackgroundColor(Color.argb(PduHeaders.RECOMMENDED_RETRIEVAL_MODE, 0, 0, 0));
        try {
            this.windowManager.addView(this.overlayView, layoutParams);
            Log.d(TAG, "Overlay ditambahkan");
        } catch (Exception e) {
            Log.e(TAG, "Gagal menambahkan overlay", e);
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        WindowManager windowManager;
        super.onDestroy();
        View view = this.overlayView;
        if (view == null || (windowManager = this.windowManager) == null) {
            return;
        }
        try {
            windowManager.removeView(view);
            Log.d(TAG, "Overlay dihapus");
        } catch (Exception e) {
            Log.e(TAG, "Gagal menghapus overlay", e);
        }
    }
}
