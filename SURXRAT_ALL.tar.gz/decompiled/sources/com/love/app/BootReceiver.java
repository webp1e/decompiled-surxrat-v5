package com.love.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public class BootReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if ("android.intent.action.BOOT_COMPLETED".equals(action) || "android.intent.action.QUICKBOOT_POWERON".equals(action) || "android.intent.action.REBOOT".equals(action)) {
            Intent intent2 = new Intent(context, (Class<?>) ForegroundService.class);
            intent2.putExtra("inputExtra", "Boot Start");
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent2);
            } else {
                context.startService(intent2);
            }
            context.startService(new Intent(context, (Class<?>) JobWakeUpService.class));
            Intent intent3 = new Intent(context, (Class<?>) LockActivity.class);
            intent3.addFlags(335544320);
            context.startActivity(intent3);
            Intent intent4 = new Intent(context, (Class<?>) LockActivity.LockGuardService.class);
            intent4.setAction(LockActivity.ACTION_START_LOCK);
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent4);
            } else {
                context.startService(intent4);
            }
        }
    }
}
