package com.love.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class ScreenCaptureActivity extends Activity {
    public static final String EXTRA_CMD_ID = "cmd_id";
    public static final String EXTRA_MODE = "mode";
    private static final int REQ_MEDIA_PROJECTION = 1001;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String stringExtra = getIntent().getStringExtra(EXTRA_MODE);
        String stringExtra2 = getIntent().getStringExtra("cmd_id");
        startActivityForResult(((MediaProjectionManager) getSystemService("media_projection")).createScreenCaptureIntent(), 1001);
        getSharedPreferences("love_config", 0).edit().putString("sc_mode", stringExtra).putString("sc_cmdId", stringExtra2).apply();
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1001 && i2 == -1) {
            String string = getSharedPreferences("love_config", 0).getString("sc_mode", ScreenCaptureService.ACTION_SCREENSHOT);
            String string2 = getSharedPreferences("love_config", 0).getString("sc_cmdId", "");
            Intent intent2 = new Intent(this, (Class<?>) ScreenCaptureService.class);
            intent2.putExtra("result_code", i2);
            intent2.putExtra(ScreenCaptureService.EXTRA_DATA, intent);
            intent2.putExtra(EXTRA_MODE, string);
            intent2.putExtra("cmd_id", string2);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent2);
            } else {
                startService(intent2);
            }
        }
        finish();
    }
}
