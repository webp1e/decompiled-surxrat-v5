package com.love.app;

import android.app.Application;
import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class App extends Application {
    private static final String TAG = "App";

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "✅ App started — pure HTTP mode");
    }
}
