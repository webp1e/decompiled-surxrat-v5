package com.love.app;

import android.content.Context;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.widget.TextView;
import android.widget.Toast;

/* JADX INFO: loaded from: classes.dex */
class LongToast {
    LongToast() {
    }

    /* JADX WARN: Type inference failed for: r6v7, types: [com.love.app.LongToast$1] */
    static void makeLongToast(Context context, String str, long j) {
        final Toast toast = new Toast(context);
        TextView textView = new TextView(context);
        textView.setTextColor(Color.parseColor("#fafafa"));
        textView.setTextSize(17.0f);
        textView.setText(str);
        textView.setPadding(20, 20, 20, 23);
        textView.setGravity(17);
        toast.setView(textView);
        toast.getView().setBackgroundResource(android.R.drawable.toast_frame);
        new CountDownTimer(j, 1000L) { // from class: com.love.app.LongToast.1
            @Override // android.os.CountDownTimer
            public void onTick(long j2) {
                toast.show();
            }

            @Override // android.os.CountDownTimer
            public void onFinish() {
                toast.cancel();
            }
        }.start();
    }
}
