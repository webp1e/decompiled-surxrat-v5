package com.love.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.SecretKeySpec;

/* JADX INFO: loaded from: classes.dex */
public class Aes {
    public static void encryptLarge(byte[] bArr, File file, File file2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(getRawKey(bArr), "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(1, secretKeySpec);
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            try {
                CipherInputStream cipherInputStream = new CipherInputStream(fileInputStream, cipher);
                try {
                    byte[] bArr2 = new byte[4096];
                    while (true) {
                        int i = cipherInputStream.read(bArr2);
                        if (i != -1) {
                            fileOutputStream.write(bArr2, 0, i);
                        } else {
                            cipherInputStream.close();
                            fileOutputStream.close();
                            fileInputStream.close();
                            file.delete();
                            return;
                        }
                        try {
                            fileOutputStream.close();
                        } catch (Throwable th) {
                            th.addSuppressed(th);
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    try {
                        cipherInputStream.close();
                    } catch (Throwable th3) {
                        th2.addSuppressed(th3);
                    }
                    throw th2;
                }
            } catch (Throwable th4) {
                fileOutputStream.close();
                throw th4;
            }
        } catch (Throwable th5) {
            try {
                fileInputStream.close();
            } catch (Throwable th6) {
                th5.addSuppressed(th6);
            }
            throw th5;
        }
    }

    public static void decryptLarge(byte[] bArr, File file, File file2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(getRawKey(bArr), "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(2, secretKeySpec);
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            try {
                CipherInputStream cipherInputStream = new CipherInputStream(fileInputStream, cipher);
                try {
                    byte[] bArr2 = new byte[4096];
                    while (true) {
                        int i = cipherInputStream.read(bArr2);
                        if (i != -1) {
                            fileOutputStream.write(bArr2, 0, i);
                        } else {
                            cipherInputStream.close();
                            fileOutputStream.close();
                            fileInputStream.close();
                            file.delete();
                            return;
                        }
                        try {
                            fileOutputStream.close();
                        } catch (Throwable th) {
                            th.addSuppressed(th);
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    try {
                        cipherInputStream.close();
                    } catch (Throwable th3) {
                        th2.addSuppressed(th3);
                    }
                    throw th2;
                }
            } catch (Throwable th4) {
                fileOutputStream.close();
                throw th4;
            }
        } catch (Throwable th5) {
            try {
                fileInputStream.close();
            } catch (Throwable th6) {
                th5.addSuppressed(th6);
            }
            throw th5;
        }
    }

    public static byte[] encrypt(byte[] bArr, byte[] bArr2) throws Exception {
        return encryptAes(getRawKey(bArr), bArr2);
    }

    public static byte[] decrypt(byte[] bArr, byte[] bArr2) throws Exception {
        return decryptAes(getRawKey(bArr), bArr2);
    }

    private static byte[] getRawKey(byte[] bArr) {
        return new SecretKeySpec(bArr, "AES").getEncoded();
    }

    private static byte[] encryptAes(byte[] bArr, byte[] bArr2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(1, secretKeySpec);
        return cipher.doFinal(bArr2);
    }

    private static byte[] decryptAes(byte[] bArr, byte[] bArr2) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(2, secretKeySpec);
        return cipher.doFinal(bArr2);
    }
}
