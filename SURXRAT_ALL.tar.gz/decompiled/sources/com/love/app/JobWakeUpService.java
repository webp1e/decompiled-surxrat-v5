package com.love.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import androidx.work.PeriodicWorkRequest;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public class JobWakeUpService extends JobService {
    private static final int JOB_ID = 100;

    @Override // android.app.job.JobService
    public boolean onStopJob(JobParameters jobParameters) {
        return true;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        scheduleJob();
        return 1;
    }

    private void scheduleJob() {
        JobScheduler jobScheduler = (JobScheduler) getSystemService("jobscheduler");
        if (jobScheduler == null) {
            return;
        }
        Iterator<JobInfo> it = jobScheduler.getAllPendingJobs().iterator();
        while (it.hasNext()) {
            if (it.next().getId() == 100) {
                return;
            }
        }
        jobScheduler.schedule(new JobInfo.Builder(100, new ComponentName(this, (Class<?>) JobWakeUpService.class)).setPeriodic(PeriodicWorkRequest.MIN_PERIODIC_INTERVAL_MILLIS).setRequiredNetworkType(1).setPersisted(true).build());
    }

    @Override // android.app.job.JobService
    public boolean onStartJob(JobParameters jobParameters) {
        SharedPreferences sharedPreferences = getSharedPreferences("love_config", 0);
        if (!(System.currentTimeMillis() - sharedPreferences.getLong("core_heartbeat", 0L) < PeriodicWorkRequest.MIN_PERIODIC_FLEX_MILLIS)) {
            Log.w("JobWakeUpService", "CoreService tampak mati, restart ForegroundService...");
            sharedPreferences.edit().putBoolean("core_running", false).apply();
            Intent intent = new Intent(this, (Class<?>) ForegroundService.class);
            intent.putExtra("inputExtra", "Watchdog");
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        }
        jobFinished(jobParameters, false);
        return false;
    }
}
