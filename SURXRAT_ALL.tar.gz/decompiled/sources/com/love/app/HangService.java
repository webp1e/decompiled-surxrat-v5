package com.love.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;

/* JADX INFO: loaded from: classes.dex */
public class HangService extends Service {
    private static final String CHANNEL_ID = "hang_channel";
    private static final int NOTIF_ID = 2001;
    private static final String TAG = "HangService";

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        return 1;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "HangService started");
        startForegroundWithNotification();
    }

    private void startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "Sistem Pengaman", 2);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        Notification notificationBuild = new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("Sistem Aktif").setContentText("Layanan berjalan di latar belakang").setSmallIcon(android.R.drawable.ic_lock_lock).setOngoing(true).setPriority(-1).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2001, notificationBuild, 1);
        } else {
            startForeground(2001, notificationBuild);
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "HangService destroyed");
        Intent intent = new Intent(this, (Class<?>) HangService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }
}
