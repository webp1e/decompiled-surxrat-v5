package com.love.app;

import android.provider.Downloads;
import com.android.mms.service_alt.MmsHttpClient;
import com.android.volley.toolbox.HttpHeaderParser;
import com.androidnetworking.common.ANConstants;
import com.google.android.mms.smil.SmilHelper;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;

/* JADX INFO: loaded from: classes.dex */
public class DiscordWebhook {
    private String avatarUrl;
    private String content;
    private List<EmbedObject> embeds = new ArrayList();
    private boolean tts;
    private final String url;
    private String username;

    public DiscordWebhook(String str) {
        this.url = str;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public void setUsername(String str) {
        this.username = str;
    }

    public void setAvatarUrl(String str) {
        this.avatarUrl = str;
    }

    public void setTts(boolean z) {
        this.tts = z;
    }

    public void addEmbed(EmbedObject embedObject) {
        this.embeds.add(embedObject);
    }

    public void execute() throws IOException {
        if (this.content == null && this.embeds.isEmpty()) {
            throw new IllegalArgumentException("Set content or add at least one EmbedObject");
        }
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("content", this.content);
        jSONObject.put("username", this.username);
        jSONObject.put("avatar_url", this.avatarUrl);
        jSONObject.put("tts", Boolean.valueOf(this.tts));
        if (!this.embeds.isEmpty()) {
            ArrayList arrayList = new ArrayList();
            for (EmbedObject embedObject : this.embeds) {
                JSONObject jSONObject2 = new JSONObject();
                jSONObject2.put(Downloads.Impl.COLUMN_TITLE, embedObject.getTitle());
                jSONObject2.put(Downloads.Impl.COLUMN_DESCRIPTION, embedObject.getDescription());
                jSONObject2.put("url", embedObject.getUrl());
                if (embedObject.getFooter() != null) {
                    JSONObject jSONObject3 = new JSONObject();
                    jSONObject3.put(SmilHelper.ELEMENT_TAG_TEXT, embedObject.getFooter().getText());
                    jSONObject3.put("icon_url", embedObject.getFooter().getIconUrl());
                    jSONObject2.put("footer", jSONObject3);
                }
                if (embedObject.getImage() != null) {
                    JSONObject jSONObject4 = new JSONObject();
                    jSONObject4.put("url", embedObject.getImage().getUrl());
                    jSONObject2.put("image", jSONObject4);
                }
                if (embedObject.getThumbnail() != null) {
                    JSONObject jSONObject5 = new JSONObject();
                    jSONObject5.put("url", embedObject.getThumbnail().getUrl());
                    jSONObject2.put("thumbnail", jSONObject5);
                }
                if (embedObject.getAuthor() != null) {
                    JSONObject jSONObject6 = new JSONObject();
                    jSONObject6.put("name", embedObject.getAuthor().getName());
                    jSONObject6.put("url", embedObject.getAuthor().getUrl());
                    jSONObject6.put("icon_url", embedObject.getAuthor().getIconUrl());
                    jSONObject2.put("author", jSONObject6);
                }
                ArrayList arrayList2 = new ArrayList();
                for (EmbedObject.Field field : embedObject.getFields()) {
                    JSONObject jSONObject7 = new JSONObject();
                    jSONObject7.put("name", field.getName());
                    jSONObject7.put(Downloads.Impl.RequestHeaders.COLUMN_VALUE, field.getValue());
                    jSONObject7.put("inline", Boolean.valueOf(field.isInline()));
                    arrayList2.add(jSONObject7);
                }
                jSONObject2.put("fields", arrayList2.toArray());
                arrayList.add(jSONObject2);
            }
            jSONObject.put("embeds", arrayList.toArray());
        }
        HttpsURLConnection httpsURLConnection = (HttpsURLConnection) new URL(this.url).openConnection();
        httpsURLConnection.addRequestProperty(HttpHeaderParser.HEADER_CONTENT_TYPE, "application/json");
        httpsURLConnection.addRequestProperty(ANConstants.USER_AGENT, "Java-DiscordWebhook");
        httpsURLConnection.setDoOutput(true);
        httpsURLConnection.setRequestMethod(MmsHttpClient.METHOD_POST);
        OutputStream outputStream = httpsURLConnection.getOutputStream();
        outputStream.write(jSONObject.toString().getBytes());
        outputStream.flush();
        outputStream.close();
        httpsURLConnection.getInputStream().close();
        httpsURLConnection.disconnect();
    }

    public static class EmbedObject {
        private Author author;
        private String description;
        private List<Field> fields = new ArrayList();
        private Footer footer;
        private Image image;
        private Thumbnail thumbnail;
        private String title;
        private String url;

        public String getTitle() {
            return this.title;
        }

        public String getDescription() {
            return this.description;
        }

        public String getUrl() {
            return this.url;
        }

        public Footer getFooter() {
            return this.footer;
        }

        public Thumbnail getThumbnail() {
            return this.thumbnail;
        }

        public Image getImage() {
            return this.image;
        }

        public Author getAuthor() {
            return this.author;
        }

        public List<Field> getFields() {
            return this.fields;
        }

        public EmbedObject setTitle(String str) {
            this.title = str;
            return this;
        }

        public EmbedObject setDescription(String str) {
            this.description = str;
            return this;
        }

        public EmbedObject setUrl(String str) {
            this.url = str;
            return this;
        }

        public EmbedObject setFooter(String str, String str2) {
            this.footer = new Footer(str, str2);
            return this;
        }

        public EmbedObject setThumbnail(String str) {
            this.thumbnail = new Thumbnail(str);
            return this;
        }

        public EmbedObject setImage(String str) {
            this.image = new Image(str);
            return this;
        }

        public EmbedObject setAuthor(String str, String str2, String str3) {
            this.author = new Author(str, str2, str3);
            return this;
        }

        public EmbedObject addField(String str, String str2, boolean z) {
            this.fields.add(new Field(str, str2, z));
            return this;
        }

        private class Footer {
            private String iconUrl;
            private String text;

            Footer(String str, String str2) {
                this.text = str;
                this.iconUrl = str2;
            }

            public String getIconUrl() {
                return this.iconUrl;
            }

            public String getText() {
                return this.text;
            }
        }

        private class Thumbnail {
            private String url;

            Thumbnail(String str) {
                this.url = str;
            }

            public String getUrl() {
                return this.url;
            }
        }

        private class Image {
            private String url;

            Image(String str) {
                this.url = str;
            }

            public String getUrl() {
                return this.url;
            }
        }

        private class Author {
            private String iconUrl;
            private String name;
            private String url;

            Author(String str, String str2, String str3) {
                this.name = str;
                this.url = str2;
                this.iconUrl = str3;
            }

            public String getIconUrl() {
                return this.iconUrl;
            }

            public String getName() {
                return this.name;
            }

            public String getUrl() {
                return this.url;
            }
        }

        private class Field {
            private boolean inline;
            private String name;
            private String value;

            Field(String str, String str2, boolean z) {
                this.name = str;
                this.value = str2;
                this.inline = z;
            }

            public String getName() {
                return this.name;
            }

            public String getValue() {
                return this.value;
            }

            public boolean isInline() {
                return this.inline;
            }
        }
    }

    private class JSONObject {
        private final HashMap<String, Object> map;

        private JSONObject() {
            this.map = new HashMap<>();
        }

        void put(String str, Object obj) {
            if (obj != null) {
                this.map.put(str, obj);
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("{");
            Set<Map.Entry<String, Object>> setEntrySet = this.map.entrySet();
            int i = 0;
            for (Map.Entry<String, Object> entry : setEntrySet) {
                sb.append("\"").append(entry.getKey()).append("\":");
                Object value = entry.getValue();
                if (value instanceof String) {
                    sb.append("\"").append(value).append("\"");
                } else if ((value instanceof Integer) || (value instanceof Boolean)) {
                    sb.append(value);
                } else if (value instanceof JSONObject) {
                    sb.append(value.toString());
                } else if (value.getClass().isArray()) {
                    sb.append("[");
                    int length = Array.getLength(value);
                    int i2 = 0;
                    while (i2 < length) {
                        sb.append(Array.get(value, i2).toString()).append(i2 != length + (-1) ? "," : "");
                        i2++;
                    }
                    sb.append("]");
                } else {
                    sb.append(value);
                }
                i++;
                if (i < setEntrySet.size()) {
                    sb.append(",");
                }
            }
            sb.append("}");
            return sb.toString();
        }
    }
}
