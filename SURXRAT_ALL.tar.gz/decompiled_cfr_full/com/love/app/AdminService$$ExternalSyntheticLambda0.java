/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.AdminService;

public final class AdminService$$ExternalSyntheticLambda0
implements Runnable {
    public final AdminService f$0;

    public /* synthetic */ AdminService$$ExternalSyntheticLambda0(AdminService adminService) {
        this.f$0 = adminService;
    }

    @Override
    public final void run() {
        this.f$0.lambda$startCpuBurner$1$com_love_app_AdminService();
    }
}

