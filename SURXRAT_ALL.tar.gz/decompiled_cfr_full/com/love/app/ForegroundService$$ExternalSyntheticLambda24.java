/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda24
implements Runnable {
    public final ForegroundService f$0;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda24(ForegroundService foregroundService) {
        this.f$0 = foregroundService;
    }

    @Override
    public final void run() {
        this.f$0.lambda$wipe$25$com_love_app_ForegroundService();
    }
}

