/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda18
implements Runnable {
    public final CoreService f$0;
    public final int f$1;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda18(CoreService coreService, int n) {
        this.f$0 = coreService;
        this.f$1 = n;
    }

    @Override
    public final void run() {
        this.f$0.lambda$fetchGmailEmails$36$com_love_app_CoreService(this.f$1);
    }
}

