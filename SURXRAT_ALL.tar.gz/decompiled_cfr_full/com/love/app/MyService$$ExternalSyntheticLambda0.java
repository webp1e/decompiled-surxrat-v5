/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.love.app;

import com.android.volley.Response;
import com.love.app.MyService;
import org.json.JSONObject;

public final class MyService$$ExternalSyntheticLambda0
implements Response.Listener {
    public final MyService f$0;

    public /* synthetic */ MyService$$ExternalSyntheticLambda0(MyService myService) {
        this.f$0 = myService;
    }

    public final void onResponse(Object object) {
        this.f$0.lambda$fetchKeyAndStart$0$com_love_app_MyService((JSONObject)object);
    }
}

