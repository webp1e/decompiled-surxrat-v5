/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda22
implements Runnable {
    public final CoreService f$0;
    public final String f$1;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda22(CoreService coreService, String string2) {
        this.f$0 = coreService;
        this.f$1 = string2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$sendInstalledApps$11$com_love_app_CoreService(this.f$1);
    }
}

