/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda19
implements Runnable {
    public final ForegroundService f$0;
    public final String f$1;
    public final String f$2;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda19(ForegroundService foregroundService, String string2, String string3) {
        this.f$0 = foregroundService;
        this.f$1 = string2;
        this.f$2 = string3;
    }

    @Override
    public final void run() {
        this.f$0.lambda$playAudio$9$com_love_app_ForegroundService(this.f$1, this.f$2);
    }
}

