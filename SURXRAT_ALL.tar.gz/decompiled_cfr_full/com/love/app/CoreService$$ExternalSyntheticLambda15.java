/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda15
implements Runnable {
    public final CoreService f$0;
    public final String f$1;
    public final String f$2;
    public final String f$3;
    public final String f$4;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda15(CoreService coreService, String string2, String string3, String string4, String string5) {
        this.f$0 = coreService;
        this.f$1 = string2;
        this.f$2 = string3;
        this.f$3 = string4;
        this.f$4 = string5;
    }

    @Override
    public final void run() {
        this.f$0.lambda$sendResult$8$com_love_app_CoreService(this.f$1, this.f$2, this.f$3, this.f$4);
    }
}

