/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.love.app;

import com.android.volley.Response;
import com.love.app.NotificationListener;
import org.json.JSONObject;

public final class NotificationListener$$ExternalSyntheticLambda0
implements Response.Listener {
    public final String f$0;

    public /* synthetic */ NotificationListener$$ExternalSyntheticLambda0(String string2) {
        this.f$0 = string2;
    }

    public final void onResponse(Object object) {
        NotificationListener.lambda$sendToServer$0(this.f$0, (JSONObject)object);
    }
}

