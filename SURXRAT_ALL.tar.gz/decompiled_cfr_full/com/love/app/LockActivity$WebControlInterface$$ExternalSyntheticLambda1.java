/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$WebControlInterface$$ExternalSyntheticLambda1
implements Runnable {
    public final LockActivity.WebControlInterface f$0;

    public /* synthetic */ LockActivity$WebControlInterface$$ExternalSyntheticLambda1(LockActivity.WebControlInterface webControlInterface) {
        this.f$0 = webControlInterface;
    }

    @Override
    public final void run() {
        this.f$0.lambda$lockNow$1$com_love_app_LockActivity$WebControlInterface();
    }
}

