/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.MainActivity;

public final class MainActivity$$ExternalSyntheticLambda7
implements Runnable {
    public final MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda7(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override
    public final void run() {
        this.f$0.lambda$onActivityResult$16$com_love_app_MainActivity();
    }
}

