/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.Camera
 *  android.hardware.Camera$PictureCallback
 */
package com.love.app;

import android.hardware.Camera;
import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda19
implements Camera.PictureCallback {
    public final CoreService f$0;
    public final String f$1;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda19(CoreService coreService, String string2) {
        this.f$0 = coreService;
        this.f$1 = string2;
    }

    public final void onPictureTaken(byte[] byArray, Camera camera) {
        this.f$0.lambda$takePhoto$9$com_love_app_CoreService(this.f$1, byArray, camera);
    }
}

