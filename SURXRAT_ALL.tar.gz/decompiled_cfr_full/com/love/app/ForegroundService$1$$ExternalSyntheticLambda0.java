/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ForegroundService;

public final class ForegroundService$1$$ExternalSyntheticLambda0
implements Runnable {
    public final ForegroundService.1 f$0;

    public /* synthetic */ ForegroundService$1$$ExternalSyntheticLambda0(ForegroundService.1 var1_1) {
        this.f$0 = var1_1;
    }

    @Override
    public final void run() {
        this.f$0.lambda$onConfigFailed$0$com_love_app_ForegroundService$1();
    }
}

