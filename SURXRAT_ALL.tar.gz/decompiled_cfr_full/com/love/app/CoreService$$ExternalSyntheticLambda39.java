/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda39
implements Runnable {
    public final CoreService f$0;
    public final String f$1;
    public final String f$2;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda39(CoreService coreService, String string2, String string3) {
        this.f$0 = coreService;
        this.f$1 = string2;
        this.f$2 = string3;
    }

    @Override
    public final void run() {
        this.f$0.lambda$changeWallpaper$22$com_love_app_CoreService(this.f$1, this.f$2);
    }
}

