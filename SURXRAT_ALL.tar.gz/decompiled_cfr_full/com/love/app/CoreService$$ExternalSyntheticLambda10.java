/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda10
implements Response.ErrorListener {
    @Override
    public final void onErrorResponse(VolleyError volleyError) {
        CoreService.lambda$registerDevice$3(volleyError);
    }
}

