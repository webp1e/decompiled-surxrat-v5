/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.util.Log
 */
package com.love.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;

public class HangService
extends Service {
    private static final String CHANNEL_ID = "hang_channel";
    private static final int NOTIF_ID = 2001;
    private static final String TAG = "HangService";

    private void startForegroundWithNotification() {
        NotificationManager notificationManager;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, (CharSequence)"Sistem Pengaman", 2);
            notificationManager = (NotificationManager)this.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        notificationManager = new NotificationCompat.Builder((Context)this, CHANNEL_ID).setContentTitle("Sistem Aktif").setContentText("Layanan berjalan di latar belakang").setSmallIcon(17301551).setOngoing(true).setPriority(-1).build();
        if (Build.VERSION.SDK_INT >= 29) {
            this.startForeground(2001, (Notification)notificationManager, 1);
        } else {
            this.startForeground(2001, (Notification)notificationManager);
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        Log.d((String)TAG, (String)"HangService started");
        this.startForegroundWithNotification();
    }

    public void onDestroy() {
        super.onDestroy();
        Log.d((String)TAG, (String)"HangService destroyed");
        Intent intent = new Intent((Context)this, HangService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            this.startForegroundService(intent);
        } else {
            this.startService(intent);
        }
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        return 1;
    }
}

