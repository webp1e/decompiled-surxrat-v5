/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View$OnSystemUiVisibilityChangeListener
 */
package com.love.app;

import android.view.View;
import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda9
implements View.OnSystemUiVisibilityChangeListener {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda9(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    public final void onSystemUiVisibilityChange(int n) {
        this.f$0.lambda$hideSystemUI$14$com_love_app_LockActivity(n);
    }
}

