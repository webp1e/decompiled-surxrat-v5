/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.renderscript.Allocation
 *  android.renderscript.Element
 *  android.renderscript.RenderScript
 *  android.renderscript.ScriptIntrinsicBlur
 */
package com.love.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;

public class BlurBuilder {
    private static final float BITMAP_SCALE = 0.4f;
    private static final float BLUR_RADIUS = 7.5f;

    public static Bitmap blur(Context context, Bitmap bitmap) {
        Bitmap bitmap2 = Bitmap.createScaledBitmap((Bitmap)bitmap, (int)Math.round((float)bitmap.getWidth() * 0.4f), (int)Math.round((float)bitmap.getHeight() * 0.4f), (boolean)false);
        bitmap = Bitmap.createBitmap((Bitmap)bitmap2);
        RenderScript renderScript = RenderScript.create((Context)context);
        context = ScriptIntrinsicBlur.create((RenderScript)renderScript, (Element)Element.U8_4((RenderScript)renderScript));
        bitmap2 = Allocation.createFromBitmap((RenderScript)renderScript, (Bitmap)bitmap2);
        renderScript = Allocation.createFromBitmap((RenderScript)renderScript, (Bitmap)bitmap);
        context.setRadius(7.5f);
        context.setInput((Allocation)bitmap2);
        context.forEach((Allocation)renderScript);
        renderScript.copyTo(bitmap);
        return bitmap;
    }
}

