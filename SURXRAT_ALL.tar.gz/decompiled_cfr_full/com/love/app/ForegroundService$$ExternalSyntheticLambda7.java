/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$OnCompletionListener
 */
package com.love.app;

import android.media.MediaPlayer;
import com.love.app.ForegroundService;
import java.io.File;

public final class ForegroundService$$ExternalSyntheticLambda7
implements MediaPlayer.OnCompletionListener {
    public final File f$0;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda7(File file) {
        this.f$0 = file;
    }

    public final void onCompletion(MediaPlayer mediaPlayer) {
        ForegroundService.lambda$playAudio$8(this.f$0, mediaPlayer);
    }
}

