/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.love.app.CommandService;

public final class CommandService$$ExternalSyntheticLambda1
implements Response.ErrorListener {
    @Override
    public final void onErrorResponse(VolleyError volleyError) {
        CommandService.lambda$pollCommand$1(volleyError);
    }
}

