/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda19
implements Runnable {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda19(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    @Override
    public final void run() {
        LockActivity.$r8$lambda$8COAY49QHjEayl6opLjWO07JdYE(this.f$0);
    }
}

