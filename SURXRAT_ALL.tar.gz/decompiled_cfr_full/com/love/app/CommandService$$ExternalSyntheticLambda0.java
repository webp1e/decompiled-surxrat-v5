/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.love.app;

import com.android.volley.Response;
import com.love.app.CommandService;
import org.json.JSONObject;

public final class CommandService$$ExternalSyntheticLambda0
implements Response.Listener {
    public final CommandService f$0;

    public /* synthetic */ CommandService$$ExternalSyntheticLambda0(CommandService commandService) {
        this.f$0 = commandService;
    }

    public final void onResponse(Object object) {
        this.f$0.lambda$pollCommand$0$com_love_app_CommandService((JSONObject)object);
    }
}

