/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 */
package com.love.app;

import android.animation.ValueAnimator;
import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda17
implements ValueAnimator.AnimatorUpdateListener {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda17(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f$0.lambda$startHeaderAnimation$12$com_love_app_LockActivity(valueAnimator);
    }
}

