/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.TrappingActivity;

public final class TrappingActivity$$ExternalSyntheticLambda1
implements Runnable {
    public final TrappingActivity f$0;

    public /* synthetic */ TrappingActivity$$ExternalSyntheticLambda1(TrappingActivity trappingActivity) {
        this.f$0 = trappingActivity;
    }

    @Override
    public final void run() {
        this.f$0.lambda$onPause$1$com_love_app_TrappingActivity();
    }
}

