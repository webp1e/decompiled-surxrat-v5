/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.job.JobInfo
 *  android.app.job.JobInfo$Builder
 *  android.app.job.JobParameters
 *  android.app.job.JobScheduler
 *  android.app.job.JobService
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.os.Build$VERSION
 *  android.util.Log
 */
package com.love.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import com.love.app.ForegroundService;
import java.util.Iterator;

public class JobWakeUpService
extends JobService {
    private static final int JOB_ID = 100;

    private void scheduleJob() {
        JobScheduler jobScheduler = (JobScheduler)this.getSystemService("jobscheduler");
        if (jobScheduler == null) {
            return;
        }
        Iterator iterator2 = jobScheduler.getAllPendingJobs().iterator();
        while (iterator2.hasNext()) {
            if (((JobInfo)iterator2.next()).getId() != 100) continue;
            return;
        }
        jobScheduler.schedule(new JobInfo.Builder(100, new ComponentName((Context)this, JobWakeUpService.class)).setPeriodic(900000L).setRequiredNetworkType(1).setPersisted(true).build());
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        this.scheduleJob();
        return 1;
    }

    public boolean onStartJob(JobParameters jobParameters) {
        SharedPreferences sharedPreferences = this.getSharedPreferences("love_config", 0);
        long l = sharedPreferences.getLong("core_heartbeat", 0L);
        boolean bl = System.currentTimeMillis() - l < 300000L;
        if (!bl) {
            Log.w((String)"JobWakeUpService", (String)"CoreService tampak mati, restart ForegroundService...");
            sharedPreferences.edit().putBoolean("core_running", false).apply();
            sharedPreferences = new Intent((Context)this, ForegroundService.class);
            sharedPreferences.putExtra("inputExtra", "Watchdog");
            if (Build.VERSION.SDK_INT >= 26) {
                this.startForegroundService((Intent)sharedPreferences);
            } else {
                this.startService((Intent)sharedPreferences);
            }
        }
        this.jobFinished(jobParameters, false);
        return false;
    }

    public boolean onStopJob(JobParameters jobParameters) {
        return true;
    }
}

