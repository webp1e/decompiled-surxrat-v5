/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  android.view.animation.AlphaAnimation
 *  android.view.animation.Animation
 *  android.view.animation.AnimationSet
 *  android.view.animation.ScaleAnimation
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.TextView
 */
package com.love.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.love.app.ConfigFetcher;
import com.love.app.MainActivity;
import com.love.app.SplashActivity$$ExternalSyntheticLambda0;
import com.love.app.SplashActivity$$ExternalSyntheticLambda1;
import com.love.app.SplashActivity$$ExternalSyntheticLambda2;
import java.io.InputStream;
import java.net.URL;

public class SplashActivity
extends AppCompatActivity {
    private static final String TAG = "SplashActivity";

    private void goToMain() {
        new Handler(Looper.getMainLooper()).postDelayed((Runnable)new SplashActivity$$ExternalSyntheticLambda2(this), 1500L);
    }

    static /* synthetic */ void lambda$loadLogoFromUrl$0(ImageView imageView, Bitmap bitmap) {
        imageView.setImageBitmap(bitmap);
    }

    private void loadLogoFromUrl(ImageView imageView, String string2) {
        new Thread(new SplashActivity$$ExternalSyntheticLambda0(this, string2, imageView)).start();
    }

    /* synthetic */ void lambda$goToMain$2$com_love_app_SplashActivity() {
        this.startActivity(new Intent((Context)this, MainActivity.class));
        this.finish();
    }

    /* synthetic */ void lambda$loadLogoFromUrl$1$com_love_app_SplashActivity(String string2, ImageView imageView) {
        block3: {
            Object object = new URL(string2);
            object = ((URL)object).openStream();
            string2 = BitmapFactory.decodeStream((InputStream)object);
            ((InputStream)object).close();
            if (string2 == null) break block3;
            try {
                object = new SplashActivity$$ExternalSyntheticLambda1(imageView, (Bitmap)string2);
                this.runOnUiThread((Runnable)object);
            }
            catch (Exception exception) {
                Log.w((String)TAG, (String)("Gagal load logo: " + exception.getMessage()));
            }
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492895);
        bundle = (ImageView)this.findViewById(2131296676);
        TextView textView = (TextView)this.findViewById(2131296675);
        Object object = (ProgressBar)this.findViewById(2131296677);
        ConfigFetcher.loadLocalConfigSync((Context)this);
        object = ConfigFetcher.getAppName((Context)this);
        if (object != null && !((String)object).isEmpty()) {
            textView.setText((CharSequence)object);
        }
        if ((object = ConfigFetcher.getLogoUrl((Context)this)) != null && !((String)object).isEmpty()) {
            this.loadLogoFromUrl((ImageView)bundle, (String)object);
        }
        AnimationSet animationSet = new AnimationSet(true);
        object = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.5f, 1, 0.5f);
        object.setDuration(1000L);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(1000L);
        animationSet.addAnimation((Animation)object);
        animationSet.addAnimation((Animation)alphaAnimation);
        bundle.startAnimation((Animation)animationSet);
        textView.startAnimation((Animation)alphaAnimation);
        ConfigFetcher.bootstrapConfig((Context)this, new ConfigFetcher.ConfigListener(this){
            final SplashActivity this$0;
            {
                this.this$0 = splashActivity;
            }

            @Override
            public void onConfigFailed() {
                Log.w((String)SplashActivity.TAG, (String)"Config splash gagal dimuat");
            }

            @Override
            public void onConfigLoaded(String string2) {
                Log.d((String)SplashActivity.TAG, (String)("Config splash siap: " + string2));
            }
        });
        this.goToMain();
    }
}

