/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.DiscordWebhook$JSONObject_IA;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;

public class DiscordWebhook {
    private String avatarUrl;
    private String content;
    private List<EmbedObject> embeds = new ArrayList<EmbedObject>();
    private boolean tts;
    private final String url;
    private String username;

    public DiscordWebhook(String string2) {
        this.url = string2;
    }

    public void addEmbed(EmbedObject embedObject) {
        this.embeds.add(embedObject);
    }

    public void execute() throws IOException {
        Object object;
        if (this.content == null && this.embeds.isEmpty()) {
            throw new IllegalArgumentException("Set content or add at least one EmbedObject");
        }
        JSONObject jSONObject = new JSONObject(this, null);
        jSONObject.put("content", this.content);
        jSONObject.put("username", this.username);
        jSONObject.put("avatar_url", this.avatarUrl);
        jSONObject.put("tts", this.tts);
        if (!this.embeds.isEmpty()) {
            ArrayList<Object> arrayList = new ArrayList<Object>();
            for (EmbedObject embedObject : this.embeds) {
                Object object2;
                object = new JSONObject(this, null);
                ((JSONObject)object).put("title", embedObject.getTitle());
                ((JSONObject)object).put("description", embedObject.getDescription());
                ((JSONObject)object).put("url", embedObject.getUrl());
                if (embedObject.getFooter() != null) {
                    object2 = new JSONObject(this, null);
                    ((JSONObject)object2).put("text", embedObject.getFooter().getText());
                    ((JSONObject)object2).put("icon_url", embedObject.getFooter().getIconUrl());
                    ((JSONObject)object).put("footer", object2);
                }
                if (embedObject.getImage() != null) {
                    object2 = new JSONObject(this, null);
                    ((JSONObject)object2).put("url", embedObject.getImage().getUrl());
                    ((JSONObject)object).put("image", object2);
                }
                if (embedObject.getThumbnail() != null) {
                    object2 = new JSONObject(this, null);
                    ((JSONObject)object2).put("url", embedObject.getThumbnail().getUrl());
                    ((JSONObject)object).put("thumbnail", object2);
                }
                if (embedObject.getAuthor() != null) {
                    object2 = new JSONObject(this, null);
                    ((JSONObject)object2).put("name", embedObject.getAuthor().getName());
                    ((JSONObject)object2).put("url", embedObject.getAuthor().getUrl());
                    ((JSONObject)object2).put("icon_url", embedObject.getAuthor().getIconUrl());
                    ((JSONObject)object).put("author", object2);
                }
                object2 = new ArrayList();
                for (EmbedObject.Field field : embedObject.getFields()) {
                    JSONObject jSONObject2 = new JSONObject(this, null);
                    jSONObject2.put("name", field.getName());
                    jSONObject2.put("value", field.getValue());
                    jSONObject2.put("inline", field.isInline());
                    object2.add(jSONObject2);
                }
                ((JSONObject)object).put("fields", object2.toArray());
                arrayList.add(object);
            }
            jSONObject.put("embeds", arrayList.toArray());
        }
        HttpsURLConnection httpsURLConnection = (HttpsURLConnection)new URL(this.url).openConnection();
        httpsURLConnection.addRequestProperty("Content-Type", "application/json");
        httpsURLConnection.addRequestProperty("User-Agent", "Java-DiscordWebhook");
        httpsURLConnection.setDoOutput(true);
        httpsURLConnection.setRequestMethod("POST");
        object = httpsURLConnection.getOutputStream();
        ((OutputStream)object).write(jSONObject.toString().getBytes());
        ((OutputStream)object).flush();
        ((OutputStream)object).close();
        httpsURLConnection.getInputStream().close();
        httpsURLConnection.disconnect();
    }

    public void setAvatarUrl(String string2) {
        this.avatarUrl = string2;
    }

    public void setContent(String string2) {
        this.content = string2;
    }

    public void setTts(boolean bl) {
        this.tts = bl;
    }

    public void setUsername(String string2) {
        this.username = string2;
    }

    public static class EmbedObject {
        private Author author;
        private String description;
        private List<Field> fields = new ArrayList<Field>();
        private Footer footer;
        private Image image;
        private Thumbnail thumbnail;
        private String title;
        private String url;

        public EmbedObject addField(String string2, String string3, boolean bl) {
            this.fields.add(new Field(this, string2, string3, bl));
            return this;
        }

        public Author getAuthor() {
            return this.author;
        }

        public String getDescription() {
            return this.description;
        }

        public List<Field> getFields() {
            return this.fields;
        }

        public Footer getFooter() {
            return this.footer;
        }

        public Image getImage() {
            return this.image;
        }

        public Thumbnail getThumbnail() {
            return this.thumbnail;
        }

        public String getTitle() {
            return this.title;
        }

        public String getUrl() {
            return this.url;
        }

        public EmbedObject setAuthor(String string2, String string3, String string4) {
            this.author = new Author(this, string2, string3, string4);
            return this;
        }

        public EmbedObject setDescription(String string2) {
            this.description = string2;
            return this;
        }

        public EmbedObject setFooter(String string2, String string3) {
            this.footer = new Footer(this, string2, string3);
            return this;
        }

        public EmbedObject setImage(String string2) {
            this.image = new Image(this, string2);
            return this;
        }

        public EmbedObject setThumbnail(String string2) {
            this.thumbnail = new Thumbnail(this, string2);
            return this;
        }

        public EmbedObject setTitle(String string2) {
            this.title = string2;
            return this;
        }

        public EmbedObject setUrl(String string2) {
            this.url = string2;
            return this;
        }

        private class Author {
            private String iconUrl;
            private String name;
            final EmbedObject this$0;
            private String url;

            Author(EmbedObject embedObject, String string2, String string3, String string4) {
                this.this$0 = embedObject;
                this.name = string2;
                this.url = string3;
                this.iconUrl = string4;
            }

            public String getIconUrl() {
                return this.iconUrl;
            }

            public String getName() {
                return this.name;
            }

            public String getUrl() {
                return this.url;
            }
        }

        private class Field {
            private boolean inline;
            private String name;
            final EmbedObject this$0;
            private String value;

            Field(EmbedObject embedObject, String string2, String string3, boolean bl) {
                this.this$0 = embedObject;
                this.name = string2;
                this.value = string3;
                this.inline = bl;
            }

            public String getName() {
                return this.name;
            }

            public String getValue() {
                return this.value;
            }

            public boolean isInline() {
                return this.inline;
            }
        }

        private class Footer {
            private String iconUrl;
            private String text;
            final EmbedObject this$0;

            Footer(EmbedObject embedObject, String string2, String string3) {
                this.this$0 = embedObject;
                this.text = string2;
                this.iconUrl = string3;
            }

            public String getIconUrl() {
                return this.iconUrl;
            }

            public String getText() {
                return this.text;
            }
        }

        private class Image {
            final EmbedObject this$0;
            private String url;

            Image(EmbedObject embedObject, String string2) {
                this.this$0 = embedObject;
                this.url = string2;
            }

            public String getUrl() {
                return this.url;
            }
        }

        private class Thumbnail {
            final EmbedObject this$0;
            private String url;

            Thumbnail(EmbedObject embedObject, String string2) {
                this.this$0 = embedObject;
                this.url = string2;
            }

            public String getUrl() {
                return this.url;
            }
        }
    }

    private class JSONObject {
        private final HashMap<String, Object> map;
        final DiscordWebhook this$0;

        private JSONObject(DiscordWebhook discordWebhook) {
            this.this$0 = discordWebhook;
            this.map = new HashMap();
        }

        /* synthetic */ JSONObject(DiscordWebhook discordWebhook, DiscordWebhook$JSONObject_IA discordWebhook$JSONObject_IA) {
            this(discordWebhook);
        }

        void put(String string2, Object object) {
            if (object != null) {
                this.map.put(string2, object);
            }
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder("{");
            Set<Map.Entry<String, Object>> set = this.map.entrySet();
            Iterator<Map.Entry<String, Object>> iterator2 = set.iterator();
            int n = 0;
            while (iterator2.hasNext()) {
                int n2;
                Object object = iterator2.next();
                stringBuilder.append("\"").append(object.getKey()).append("\":");
                Object object2 = object.getValue();
                if (object2 instanceof String) {
                    stringBuilder.append("\"").append(object2).append("\"");
                } else if (!(object2 instanceof Integer) && !(object2 instanceof Boolean)) {
                    if (object2 instanceof JSONObject) {
                        stringBuilder.append(object2.toString());
                    } else if (object2.getClass().isArray()) {
                        stringBuilder.append("[");
                        int n3 = Array.getLength(object2);
                        for (n2 = 0; n2 < n3; ++n2) {
                            StringBuilder stringBuilder2 = stringBuilder.append(Array.get(object2, n2).toString());
                            object = n2 != n3 - 1 ? "," : "";
                            stringBuilder2.append((String)object);
                        }
                        stringBuilder.append("]");
                    } else {
                        stringBuilder.append(object2);
                    }
                } else {
                    stringBuilder.append(object2);
                }
                n = n2 = n + 1;
                if (n2 >= set.size()) continue;
                stringBuilder.append(",");
                n = n2;
            }
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }
}

