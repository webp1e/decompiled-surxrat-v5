/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ScreenCaptureService;

public final class ScreenCaptureService$$ExternalSyntheticLambda1
implements Runnable {
    public final ScreenCaptureService f$0;
    public final String f$1;

    public /* synthetic */ ScreenCaptureService$$ExternalSyntheticLambda1(ScreenCaptureService screenCaptureService, String string2) {
        this.f$0 = screenCaptureService;
        this.f$1 = string2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$takeScreenshot$0$com_love_app_ScreenCaptureService(this.f$1);
    }
}

