/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$OnCompletionListener
 */
package com.love.app;

import android.media.MediaPlayer;
import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda1
implements MediaPlayer.OnCompletionListener {
    public final void onCompletion(MediaPlayer mediaPlayer) {
        LockActivity.$r8$lambda$XDATxgzGxW2uNxUHpN70XnwbyqM(mediaPlayer);
    }
}

