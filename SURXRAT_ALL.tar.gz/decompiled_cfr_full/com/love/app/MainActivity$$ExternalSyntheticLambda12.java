/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.MainActivity;

public final class MainActivity$$ExternalSyntheticLambda12
implements Runnable {
    public final MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda12(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override
    public final void run() {
        MainActivity.$r8$lambda$wJbBxMVdoIBdV0VPCZlC_JrA9vc(this.f$0);
    }
}

