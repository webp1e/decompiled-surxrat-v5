/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$ChatAdapter$$ExternalSyntheticLambda0
implements Runnable {
    public final String f$0;
    public final LockActivity.ChatAdapter.ViewHolder f$1;

    public /* synthetic */ LockActivity$ChatAdapter$$ExternalSyntheticLambda0(String string2, LockActivity.ChatAdapter.ViewHolder viewHolder) {
        this.f$0 = string2;
        this.f$1 = viewHolder;
    }

    @Override
    public final void run() {
        LockActivity.ChatAdapter.lambda$onBindViewHolder$1(this.f$0, this.f$1);
    }
}

