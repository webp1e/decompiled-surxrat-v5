/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.love.app;

import com.android.volley.Response;
import com.love.app.CoreService;
import org.json.JSONObject;

public final class CoreService$$ExternalSyntheticLambda9
implements Response.Listener {
    public final CoreService f$0;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda9(CoreService coreService) {
        this.f$0 = coreService;
    }

    public final void onResponse(Object object) {
        this.f$0.lambda$registerDevice$2$com_love_app_CoreService((JSONObject)object);
    }
}

