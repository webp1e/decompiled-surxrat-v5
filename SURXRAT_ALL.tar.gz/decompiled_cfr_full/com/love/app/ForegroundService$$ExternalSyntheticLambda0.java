/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.Camera
 *  android.hardware.Camera$PictureCallback
 */
package com.love.app;

import android.hardware.Camera;
import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda0
implements Camera.PictureCallback {
    public final ForegroundService f$0;
    public final String f$1;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda0(ForegroundService foregroundService, String string2) {
        this.f$0 = foregroundService;
        this.f$1 = string2;
    }

    public final void onPictureTaken(byte[] byArray, Camera camera) {
        this.f$0.lambda$takePhoto$6$com_love_app_ForegroundService(this.f$1, byArray, camera);
    }
}

