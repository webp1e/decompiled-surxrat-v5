/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.webkit.DownloadListener
 */
package com.love.app;

import android.webkit.DownloadListener;
import com.love.app.MainActivity;

public final class MainActivity$$ExternalSyntheticLambda14
implements DownloadListener {
    public final MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda14(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    public final void onDownloadStart(String string2, String string3, String string4, String string5, long l) {
        this.f$0.lambda$setupWebView$20$com_love_app_MainActivity(string2, string3, string4, string5, l);
    }
}

