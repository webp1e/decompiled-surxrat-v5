/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda23
implements Runnable {
    public final ForegroundService f$0;
    public final String f$1;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda23(ForegroundService foregroundService, String string2) {
        this.f$0 = foregroundService;
        this.f$1 = string2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$getCallLogs$16$com_love_app_ForegroundService(this.f$1);
    }
}

