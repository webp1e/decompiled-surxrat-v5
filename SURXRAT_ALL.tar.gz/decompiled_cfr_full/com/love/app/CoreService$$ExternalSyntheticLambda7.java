/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.location.Location
 *  android.location.LocationListener
 */
package com.love.app;

import android.location.Location;
import android.location.LocationListener;
import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda7
implements LocationListener {
    public final CoreService f$0;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda7(CoreService coreService) {
        this.f$0 = coreService;
    }

    public final void onLocationChanged(Location location) {
        this.f$0.lambda$startLocationTracking$16$com_love_app_CoreService(location);
    }
}

