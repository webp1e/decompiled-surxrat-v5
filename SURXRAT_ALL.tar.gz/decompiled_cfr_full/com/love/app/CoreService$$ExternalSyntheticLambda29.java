/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda29
implements Response.Listener {
    public final CoreService f$0;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda29(CoreService coreService) {
        this.f$0 = coreService;
    }

    public final void onResponse(Object object) {
        this.f$0.lambda$fetchNotifications$24$com_love_app_CoreService((String)object);
    }
}

