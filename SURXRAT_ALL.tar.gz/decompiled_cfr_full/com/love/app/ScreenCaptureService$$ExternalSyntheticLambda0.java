/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ScreenCaptureService;
import java.io.File;

public final class ScreenCaptureService$$ExternalSyntheticLambda0
implements Runnable {
    public final ScreenCaptureService f$0;
    public final File f$1;
    public final String f$2;

    public /* synthetic */ ScreenCaptureService$$ExternalSyntheticLambda0(ScreenCaptureService screenCaptureService, File file, String string2) {
        this.f$0 = screenCaptureService;
        this.f$1 = file;
        this.f$2 = string2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$stopRecording$1$com_love_app_ScreenCaptureService(this.f$1, this.f$2);
    }
}

