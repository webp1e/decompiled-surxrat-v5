/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda3
implements Response.Listener {
    public final ForegroundService f$0;
    public final String f$1;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda3(ForegroundService foregroundService, String string2) {
        this.f$0 = foregroundService;
        this.f$1 = string2;
    }

    public final void onResponse(Object object) {
        this.f$0.lambda$fetchNotifications$22$com_love_app_ForegroundService(this.f$1, (String)object);
    }
}

