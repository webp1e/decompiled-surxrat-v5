/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.webkit.WebView
 */
package com.love.app;

import android.webkit.WebView;
import com.love.app.MainActivity;

public final class MainActivity$3$$ExternalSyntheticLambda0
implements Runnable {
    public final MainActivity.3 f$0;
    public final String f$1;
    public final WebView f$2;

    public /* synthetic */ MainActivity$3$$ExternalSyntheticLambda0(MainActivity.3 var1_1, String string2, WebView webView) {
        this.f$0 = var1_1;
        this.f$1 = string2;
        this.f$2 = webView;
    }

    @Override
    public final void run() {
        this.f$0.lambda$onReceivedError$0$com_love_app_MainActivity$3(this.f$1, this.f$2);
    }
}

