/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 */
package com.love.app;

import android.content.DialogInterface;
import com.love.app.MainActivity;

public final class MainActivity$$ExternalSyntheticLambda16
implements DialogInterface.OnClickListener {
    public final MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda16(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    public final void onClick(DialogInterface dialogInterface, int n) {
        this.f$0.lambda$requestAccessibilityAndNotification$13$com_love_app_MainActivity(dialogInterface, n);
    }
}

