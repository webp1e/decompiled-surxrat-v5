/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;
import java.util.List;

public final class LockActivity$$ExternalSyntheticLambda3
implements Runnable {
    public final LockActivity f$0;
    public final List f$1;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda3(LockActivity lockActivity, List list) {
        this.f$0 = lockActivity;
        this.f$1 = list;
    }

    @Override
    public final void run() {
        this.f$0.lambda$pollChatMessages$4$com_love_app_LockActivity(this.f$1);
    }
}

