/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.media.projection.MediaProjectionManager
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 */
package com.love.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import com.love.app.ScreenCaptureService;

public class ScreenCaptureActivity
extends Activity {
    public static final String EXTRA_CMD_ID = "cmd_id";
    public static final String EXTRA_MODE = "mode";
    private static final int REQ_MEDIA_PROJECTION = 1001;

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == 1001 && n2 == -1) {
            String string2 = this.getSharedPreferences("love_config", 0).getString("sc_mode", "screenshot");
            String string3 = this.getSharedPreferences("love_config", 0).getString("sc_cmdId", "");
            Intent intent2 = new Intent((Context)this, ScreenCaptureService.class);
            intent2.putExtra("result_code", n2);
            intent2.putExtra("data", (Parcelable)intent);
            intent2.putExtra(EXTRA_MODE, string2);
            intent2.putExtra(EXTRA_CMD_ID, string3);
            if (Build.VERSION.SDK_INT >= 26) {
                this.startForegroundService(intent2);
            } else {
                this.startService(intent2);
            }
        }
        this.finish();
    }

    protected void onCreate(Bundle object) {
        super.onCreate(object);
        object = this.getIntent().getStringExtra(EXTRA_MODE);
        String string2 = this.getIntent().getStringExtra(EXTRA_CMD_ID);
        this.startActivityForResult(((MediaProjectionManager)this.getSystemService("media_projection")).createScreenCaptureIntent(), 1001);
        this.getSharedPreferences("love_config", 0).edit().putString("sc_mode", (String)object).putString("sc_cmdId", string2).apply();
    }
}

