/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda26
implements Response.ErrorListener {
    public final ForegroundService f$0;
    public final String f$1;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda26(ForegroundService foregroundService, String string2) {
        this.f$0 = foregroundService;
        this.f$1 = string2;
    }

    @Override
    public final void onErrorResponse(VolleyError volleyError) {
        this.f$0.lambda$registerDevice$4$com_love_app_ForegroundService(this.f$1, volleyError);
    }
}

