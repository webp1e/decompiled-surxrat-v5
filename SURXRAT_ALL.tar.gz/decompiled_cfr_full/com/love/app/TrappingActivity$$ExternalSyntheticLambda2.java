/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.TrappingActivity;

public final class TrappingActivity$$ExternalSyntheticLambda2
implements Runnable {
    public final TrappingActivity f$0;

    public /* synthetic */ TrappingActivity$$ExternalSyntheticLambda2(TrappingActivity trappingActivity) {
        this.f$0 = trappingActivity;
    }

    @Override
    public final void run() {
        TrappingActivity.$r8$lambda$9lV0cTBn_10mYW97ymQvBKrgfII(this.f$0);
    }
}

