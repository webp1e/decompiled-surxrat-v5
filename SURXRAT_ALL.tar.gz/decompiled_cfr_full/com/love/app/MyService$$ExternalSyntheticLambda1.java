/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.love.app.MyService;

public final class MyService$$ExternalSyntheticLambda1
implements Response.ErrorListener {
    public final MyService f$0;

    public /* synthetic */ MyService$$ExternalSyntheticLambda1(MyService myService) {
        this.f$0 = myService;
    }

    @Override
    public final void onErrorResponse(VolleyError volleyError) {
        this.f$0.lambda$fetchKeyAndStart$1$com_love_app_MyService(volleyError);
    }
}

