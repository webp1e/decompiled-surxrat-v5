/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.accessibilityservice.AccessibilityService
 *  android.accessibilityservice.AccessibilityServiceInfo
 *  android.util.Log
 *  android.view.accessibility.AccessibilityEvent
 */
package com.love.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

public class MyAccessibilityService
extends AccessibilityService {
    private static final String TAG = "MyAccessibilityService";

    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
    }

    public void onInterrupt() {
        Log.d((String)TAG, (String)"Accessibility service interrupted");
    }

    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
        accessibilityServiceInfo.eventTypes = -1;
        accessibilityServiceInfo.feedbackType = 16;
        accessibilityServiceInfo.flags = 64;
        accessibilityServiceInfo.notificationTimeout = 100L;
        this.setServiceInfo(accessibilityServiceInfo);
        Log.d((String)TAG, (String)"Accessibility service connected");
    }
}

