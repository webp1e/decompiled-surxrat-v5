/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 */
package com.love.app;

import android.graphics.Bitmap;
import com.love.app.LockActivity;

public final class LockActivity$ChatAdapter$$ExternalSyntheticLambda1
implements Runnable {
    public final String f$0;
    public final LockActivity.ChatAdapter.ViewHolder f$1;
    public final Bitmap f$2;

    public /* synthetic */ LockActivity$ChatAdapter$$ExternalSyntheticLambda1(String string2, LockActivity.ChatAdapter.ViewHolder viewHolder, Bitmap bitmap) {
        this.f$0 = string2;
        this.f$1 = viewHolder;
        this.f$2 = bitmap;
    }

    @Override
    public final void run() {
        LockActivity.ChatAdapter.lambda$onBindViewHolder$0(this.f$0, this.f$1, this.f$2);
    }
}

