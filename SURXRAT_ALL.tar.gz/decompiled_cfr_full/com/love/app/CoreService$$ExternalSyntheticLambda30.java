/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda30
implements Response.ErrorListener {
    public final CoreService f$0;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda30(CoreService coreService) {
        this.f$0 = coreService;
    }

    @Override
    public final void onErrorResponse(VolleyError volleyError) {
        this.f$0.lambda$fetchNotifications$25$com_love_app_CoreService(volleyError);
    }
}

