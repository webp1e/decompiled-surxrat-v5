/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda3
implements Runnable {
    public final CoreService f$0;
    public final boolean f$1;
    public final int f$2;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda3(CoreService coreService, boolean bl, int n) {
        this.f$0 = coreService;
        this.f$1 = bl;
        this.f$2 = n;
    }

    @Override
    public final void run() {
        this.f$0.lambda$fetchGallery$26$com_love_app_CoreService(this.f$1, this.f$2);
    }
}

