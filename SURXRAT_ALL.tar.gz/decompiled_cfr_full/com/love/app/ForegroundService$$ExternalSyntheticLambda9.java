/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda9
implements Runnable {
    public final ForegroundService f$0;
    public final int f$1;
    public final String f$2;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda9(ForegroundService foregroundService, int n, String string2) {
        this.f$0 = foregroundService;
        this.f$1 = n;
        this.f$2 = string2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$takePhoto$7$com_love_app_ForegroundService(this.f$1, this.f$2);
    }
}

