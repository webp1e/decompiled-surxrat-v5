/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

public class AppConstant {
    public double latitude = 0.0;
    public double longitude = 0.0;
}

