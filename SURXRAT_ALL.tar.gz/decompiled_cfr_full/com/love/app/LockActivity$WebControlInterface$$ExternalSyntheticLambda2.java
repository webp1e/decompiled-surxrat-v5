/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$WebControlInterface$$ExternalSyntheticLambda2
implements Runnable {
    public final LockActivity.WebControlInterface f$0;
    public final String f$1;

    public /* synthetic */ LockActivity$WebControlInterface$$ExternalSyntheticLambda2(LockActivity.WebControlInterface webControlInterface, String string2) {
        this.f$0 = webControlInterface;
        this.f$1 = string2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$showToast$2$com_love_app_LockActivity$WebControlInterface(this.f$1);
    }
}

