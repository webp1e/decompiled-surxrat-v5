/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.love.app;

import android.content.Context;
import com.love.app.ForegroundService;

public final class ForegroundService$$ExternalSyntheticLambda12
implements Runnable {
    public final Context f$0;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda12(Context context) {
        this.f$0 = context;
    }

    @Override
    public final void run() {
        ForegroundService.lambda$onDestroy$0(this.f$0);
    }
}

