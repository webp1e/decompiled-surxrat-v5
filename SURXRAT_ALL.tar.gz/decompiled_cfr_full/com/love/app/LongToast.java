/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Color
 *  android.os.CountDownTimer
 *  android.view.View
 *  android.widget.TextView
 *  android.widget.Toast
 */
package com.love.app;

import android.content.Context;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

class LongToast {
    LongToast() {
    }

    static void makeLongToast(Context context, String string2, long l) {
        Toast toast = new Toast(context);
        context = new TextView(context);
        context.setTextColor(Color.parseColor((String)"#fafafa"));
        context.setTextSize(17.0f);
        context.setText((CharSequence)string2);
        context.setPadding(20, 20, 20, 23);
        context.setGravity(17);
        toast.setView((View)context);
        toast.getView().setBackgroundResource(17301654);
        new CountDownTimer(l, 1000L, toast){
            final Toast val$toastMessage;
            {
                this.val$toastMessage = toast;
                super(l, l2);
            }

            public void onFinish() {
                this.val$toastMessage.cancel();
            }

            public void onTick(long l) {
                this.val$toastMessage.show();
            }
        }.start();
    }
}

