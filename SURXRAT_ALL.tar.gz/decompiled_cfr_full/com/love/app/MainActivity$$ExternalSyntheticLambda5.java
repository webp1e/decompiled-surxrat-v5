/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.MainActivity;

public final class MainActivity$$ExternalSyntheticLambda5
implements Runnable {
    public final MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda5(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override
    public final void run() {
        this.f$0.lambda$onActivityResult$14$com_love_app_MainActivity();
    }
}

