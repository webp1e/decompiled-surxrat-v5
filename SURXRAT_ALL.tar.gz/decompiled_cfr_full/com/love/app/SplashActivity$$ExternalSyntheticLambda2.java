/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.SplashActivity;

public final class SplashActivity$$ExternalSyntheticLambda2
implements Runnable {
    public final SplashActivity f$0;

    public /* synthetic */ SplashActivity$$ExternalSyntheticLambda2(SplashActivity splashActivity) {
        this.f$0 = splashActivity;
    }

    @Override
    public final void run() {
        this.f$0.lambda$goToMain$2$com_love_app_SplashActivity();
    }
}

