/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

public final class LockActivity$WebControlInterface_IA {
}

