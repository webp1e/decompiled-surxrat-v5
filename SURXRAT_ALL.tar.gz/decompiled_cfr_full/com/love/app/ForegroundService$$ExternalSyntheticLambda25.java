/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.love.app;

import com.android.volley.Response;
import com.love.app.ForegroundService;
import org.json.JSONObject;

public final class ForegroundService$$ExternalSyntheticLambda25
implements Response.Listener {
    public final ForegroundService f$0;

    public /* synthetic */ ForegroundService$$ExternalSyntheticLambda25(ForegroundService foregroundService) {
        this.f$0 = foregroundService;
    }

    public final void onResponse(Object object) {
        this.f$0.lambda$registerDevice$2$com_love_app_ForegroundService((JSONObject)object);
    }
}

