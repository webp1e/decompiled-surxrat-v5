/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.love.app.NotificationListener;

public final class NotificationListener$$ExternalSyntheticLambda1
implements Response.ErrorListener {
    @Override
    public final void onErrorResponse(VolleyError volleyError) {
        NotificationListener.lambda$sendToServer$1(volleyError);
    }
}

