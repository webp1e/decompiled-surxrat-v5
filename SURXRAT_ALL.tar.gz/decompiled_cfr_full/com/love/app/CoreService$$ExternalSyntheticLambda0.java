/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda0
implements Runnable {
    public final CoreService f$0;
    public final String f$1;
    public final int f$2;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda0(CoreService coreService, String string2, int n) {
        this.f$0 = coreService;
        this.f$1 = string2;
        this.f$2 = n;
    }

    @Override
    public final void run() {
        this.f$0.lambda$takePhoto$10$com_love_app_CoreService(this.f$1, this.f$2);
    }
}

