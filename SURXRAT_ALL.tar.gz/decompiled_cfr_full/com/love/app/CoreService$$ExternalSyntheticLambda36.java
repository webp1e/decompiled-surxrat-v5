/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda36
implements Runnable {
    public final CoreService f$0;
    public final String f$1;
    public final Runnable f$2;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda36(CoreService coreService, String string2, Runnable runnable2) {
        this.f$0 = coreService;
        this.f$1 = string2;
        this.f$2 = runnable2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$launchAppAndWait$7$com_love_app_CoreService(this.f$1, this.f$2);
    }
}

