/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.CoreService;

public final class CoreService$$ExternalSyntheticLambda25
implements Runnable {
    public final CoreService f$0;

    public /* synthetic */ CoreService$$ExternalSyntheticLambda25(CoreService coreService) {
        this.f$0 = coreService;
    }

    @Override
    public final void run() {
        this.f$0.lambda$onAccessibilityEvent$37$com_love_app_CoreService();
    }
}

