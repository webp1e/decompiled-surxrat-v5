/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnTouchListener
 */
package com.love.app;

import android.view.MotionEvent;
import android.view.View;
import com.love.app.AdminService;

public final class AdminService$$ExternalSyntheticLambda1
implements View.OnTouchListener {
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return AdminService.lambda$showOverlay$0(view, motionEvent);
    }
}

