/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.love.app;

import android.view.View;
import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda15
implements View.OnClickListener {
    public final LockActivity f$0;
    public final int f$1;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda15(LockActivity lockActivity, int n) {
        this.f$0 = lockActivity;
        this.f$1 = n;
    }

    public final void onClick(View view) {
        this.f$0.lambda$setupKeypad$7$com_love_app_LockActivity(this.f$1, view);
    }
}

