/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Color
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.provider.Settings
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 */
package com.love.app;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

public class ServiceWindow
extends Service {
    private static final String TAG = "ServiceWindow";
    private View overlayView;
    private WindowManager windowManager;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        View view;
        super.onCreate();
        this.windowManager = (WindowManager)this.getSystemService("window");
        if (!Settings.canDrawOverlays((Context)this)) {
            Log.e((String)TAG, (String)"Izin overlay tidak diberikan");
            this.stopSelf();
            return;
        }
        int n = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, n, 280, -3);
        layoutParams.gravity = 0x800033;
        this.overlayView = view = new View((Context)this);
        view.setBackgroundColor(Color.argb((int)180, (int)0, (int)0, (int)0));
        try {
            this.windowManager.addView(this.overlayView, (ViewGroup.LayoutParams)layoutParams);
            Log.d((String)TAG, (String)"Overlay ditambahkan");
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Gagal menambahkan overlay", (Throwable)exception);
        }
    }

    public void onDestroy() {
        WindowManager windowManager;
        super.onDestroy();
        View view = this.overlayView;
        if (view != null && (windowManager = this.windowManager) != null) {
            try {
                windowManager.removeView(view);
                Log.d((String)TAG, (String)"Overlay dihapus");
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"Gagal menghapus overlay", (Throwable)exception);
            }
        }
    }
}

