/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.util.Log
 */
package com.love.app;

import android.app.Application;
import android.util.Log;

public class App
extends Application {
    private static final String TAG = "App";

    public void onCreate() {
        super.onCreate();
        Log.d((String)TAG, (String)"✅ App started — pure HTTP mode");
    }
}

