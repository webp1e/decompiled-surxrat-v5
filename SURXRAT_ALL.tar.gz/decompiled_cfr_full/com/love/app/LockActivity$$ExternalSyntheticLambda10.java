/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda10
implements Runnable {
    public final LockActivity f$0;
    public final String f$1;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda10(LockActivity lockActivity, String string2) {
        this.f$0 = lockActivity;
        this.f$1 = string2;
    }

    @Override
    public final void run() {
        this.f$0.lambda$sendChatMessage$3$com_love_app_LockActivity(this.f$1);
    }
}

