/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.widget.ImageView
 */
package com.love.app;

import android.graphics.Bitmap;
import android.widget.ImageView;
import com.love.app.SplashActivity;

public final class SplashActivity$$ExternalSyntheticLambda1
implements Runnable {
    public final ImageView f$0;
    public final Bitmap f$1;

    public /* synthetic */ SplashActivity$$ExternalSyntheticLambda1(ImageView imageView, Bitmap bitmap) {
        this.f$0 = imageView;
        this.f$1 = bitmap;
    }

    @Override
    public final void run() {
        SplashActivity.lambda$loadLogoFromUrl$0(this.f$0, this.f$1);
    }
}

