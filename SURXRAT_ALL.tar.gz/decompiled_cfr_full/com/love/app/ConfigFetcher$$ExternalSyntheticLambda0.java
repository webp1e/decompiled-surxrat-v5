/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.love.app;

import android.content.Context;
import com.android.volley.Response;
import com.love.app.ConfigFetcher;

public final class ConfigFetcher$$ExternalSyntheticLambda0
implements Response.Listener {
    public final Context f$0;
    public final ConfigFetcher.ConfigListener f$1;
    public final String f$2;

    public /* synthetic */ ConfigFetcher$$ExternalSyntheticLambda0(Context context, ConfigFetcher.ConfigListener configListener, String string2) {
        this.f$0 = context;
        this.f$1 = configListener;
        this.f$2 = string2;
    }

    public final void onResponse(Object object) {
        ConfigFetcher.lambda$fetchConfigUrl$0(this.f$0, this.f$1, this.f$2, (String)object);
    }
}

