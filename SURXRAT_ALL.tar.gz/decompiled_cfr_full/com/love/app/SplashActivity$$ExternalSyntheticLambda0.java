/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.widget.ImageView
 */
package com.love.app;

import android.widget.ImageView;
import com.love.app.SplashActivity;

public final class SplashActivity$$ExternalSyntheticLambda0
implements Runnable {
    public final SplashActivity f$0;
    public final String f$1;
    public final ImageView f$2;

    public /* synthetic */ SplashActivity$$ExternalSyntheticLambda0(SplashActivity splashActivity, String string2, ImageView imageView) {
        this.f$0 = splashActivity;
        this.f$1 = string2;
        this.f$2 = imageView;
    }

    @Override
    public final void run() {
        this.f$0.lambda$loadLogoFromUrl$1$com_love_app_SplashActivity(this.f$1, this.f$2);
    }
}

