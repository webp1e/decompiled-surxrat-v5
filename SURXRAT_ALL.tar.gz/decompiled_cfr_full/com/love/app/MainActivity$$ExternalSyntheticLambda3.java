/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.widget.EditText
 */
package com.love.app;

import android.content.DialogInterface;
import android.widget.EditText;
import com.love.app.MainActivity;

public final class MainActivity$$ExternalSyntheticLambda3
implements DialogInterface.OnClickListener {
    public final MainActivity f$0;
    public final EditText f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda3(MainActivity mainActivity, EditText editText) {
        this.f$0 = mainActivity;
        this.f$1 = editText;
    }

    public final void onClick(DialogInterface dialogInterface, int n) {
        this.f$0.lambda$showUsernameDialog$0$com_love_app_MainActivity(this.f$1, dialogInterface, n);
    }
}

