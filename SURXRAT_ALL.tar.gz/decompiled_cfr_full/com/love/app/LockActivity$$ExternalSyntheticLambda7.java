/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.love.app;

import android.view.View;
import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda7
implements View.OnClickListener {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda7(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    public final void onClick(View view) {
        this.f$0.lambda$initViews$1$com_love_app_LockActivity(view);
    }
}

