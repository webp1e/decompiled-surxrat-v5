/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View$OnSystemUiVisibilityChangeListener
 */
package com.love.app;

import android.view.View;
import com.love.app.TrappingActivity;

public final class TrappingActivity$$ExternalSyntheticLambda0
implements View.OnSystemUiVisibilityChangeListener {
    public final TrappingActivity f$0;

    public /* synthetic */ TrappingActivity$$ExternalSyntheticLambda0(TrappingActivity trappingActivity) {
        this.f$0 = trappingActivity;
    }

    public final void onSystemUiVisibilityChange(int n) {
        this.f$0.lambda$hideSystemUI$0$com_love_app_TrappingActivity(n);
    }
}

