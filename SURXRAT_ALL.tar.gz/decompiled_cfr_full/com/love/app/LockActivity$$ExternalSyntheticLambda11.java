/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda11
implements Runnable {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda11(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    @Override
    public final void run() {
        LockActivity.$r8$lambda$PE0SXFF5yDlH6ayMAaGJO_4Wc18(this.f$0);
    }
}

