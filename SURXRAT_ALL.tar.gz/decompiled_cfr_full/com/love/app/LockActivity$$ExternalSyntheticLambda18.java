/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda18
implements Runnable {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda18(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    @Override
    public final void run() {
        LockActivity.$r8$lambda$BmgLwbX4x15rXeY7f_qgI5oN4c4(this.f$0);
    }
}

