/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.love.app;

import android.content.Context;
import com.love.app.AdminReceiver;

public final class AdminReceiver$$ExternalSyntheticLambda1
implements Runnable {
    public final Context f$0;

    public /* synthetic */ AdminReceiver$$ExternalSyntheticLambda1(Context context) {
        this.f$0 = context;
    }

    @Override
    public final void run() {
        AdminReceiver.lambda$startEmergencyHang$1(this.f$0);
    }
}

