/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda5
implements Runnable {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda5(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    @Override
    public final void run() {
        this.f$0.lambda$pollChatMessages$5$com_love_app_LockActivity();
    }
}

