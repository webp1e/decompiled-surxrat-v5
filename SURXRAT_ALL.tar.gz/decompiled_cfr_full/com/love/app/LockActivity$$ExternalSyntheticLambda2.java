/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.LockActivity;

public final class LockActivity$$ExternalSyntheticLambda2
implements Runnable {
    public final LockActivity f$0;

    public /* synthetic */ LockActivity$$ExternalSyntheticLambda2(LockActivity lockActivity) {
        this.f$0 = lockActivity;
    }

    @Override
    public final void run() {
        LockActivity.$r8$lambda$qZZBzx4TJCGPWb2ZimU_DO88a_o(this.f$0);
    }
}

