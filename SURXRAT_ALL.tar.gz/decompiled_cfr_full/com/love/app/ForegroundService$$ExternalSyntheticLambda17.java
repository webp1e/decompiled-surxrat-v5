/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.love.app.ForegroundService;
import java.io.File;
import java.util.Comparator;

public final class ForegroundService$$ExternalSyntheticLambda17
implements Comparator {
    public final int compare(Object object, Object object2) {
        return ForegroundService.lambda$getFileList$19((File)object, (File)object2);
    }
}

