/*
 * Decompiled with CFR 0.152.
 */
package com.love.app;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.love.app.ConfigFetcher;

public final class ConfigFetcher$$ExternalSyntheticLambda1
implements Response.ErrorListener {
    public final String f$0;
    public final ConfigFetcher.ConfigListener f$1;

    public /* synthetic */ ConfigFetcher$$ExternalSyntheticLambda1(String string2, ConfigFetcher.ConfigListener configListener) {
        this.f$0 = string2;
        this.f$1 = configListener;
    }

    @Override
    public final void onErrorResponse(VolleyError volleyError) {
        ConfigFetcher.lambda$fetchConfigUrl$1(this.f$0, this.f$1, volleyError);
    }
}

